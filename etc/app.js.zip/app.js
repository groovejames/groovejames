$.Model.extend("GS.Models.Base", {cache:{},getOneFromCache:function(a) {
    var b = this.shortName.toLowerCase() + "s",c = this.cache[a];
    if (c && GS.user) {
        if (GS.user.favorites[b])c.isFavorite = _.defined(GS.user.favorites[b][a]) ? 1 : 0;
        if (b == "songs" && GS.user.library.songs)c.fromLibrary = _.defined(GS.user.library.songs[a]) ? 1 : 0
    }
    return c
},getManyFromCache:function(a) {
    for (var b = [],c = 0; c < a.length; c++)b.push(this.getOneFromCache(a[c]));
    return b
},wrap:function(a, b) {
    var c = this.id,g = a[c];
    b = _.orEqual(b, true);
    if (g && b)if (g = this.getOneFromCache(g))return g;
    g = this._super(a);
    if (b && g[c])if (this.shortName !== "Song" || g.validate())this.cache[g[c]] = g;
    return g
},wrapCollection:function(a, b, c, g, h) {
    var k,m,n = [],o,r;
    b = _.orEqual(b, null);
    c = _.orEqual(c, false);
    g = _.orEqual(g, false);
    h = _.orEqual(h, true);
    for (k in a)if (a.hasOwnProperty(k)) {
        o = a[k];
        r = this.wrap(o, h).dupe();
        if (c)for (m in o) {
            if (o.hasOwnProperty(m))r[m] = o[m]
        } else if (b)for (m in b)if (b.hasOwnProperty(m))if (m === "USE_INDEX")r[b[m]] = parseInt(k, 10) + 1; else r[m] = _.orEqual(o[m], b[m]);
        if (!g || !$.isFunction(r.validate) ||
                r.validate())n.push(r)
    }
    n._use_call = true;
    return n
},wrapCollectionInObject:function(a, b, c) {
    var g,h,k,m;
    b = _.orEqual(b, null);
    c = _.orEqual(c, false);
    for (g in a)if (a.hasOwnProperty(g)) {
        k = a[g];
        m = this.wrap(k).dupe();
        if (c)for (h in k) {
            if (k.hasOwnProperty(h))m[h] = k[h]
        } else if (b)for (h in b)if (b.hasOwnProperty(h))m[h] = _.orEqual(k[h], b[h]);
        a[g] = m
    }
    return a
}}, {songs:{},dupe:function() {
    return new this.Class(this.attrs())
},wrapSongCollection:function(a, b, c) {
    b = GS.Models.Song.wrapCollection(a.Songs || a.songs || a.result ||
            a, b, c, true);
    for (c = 0; c < b.length; c++)this.songs[b[c].SongID] = b[c];
    if (a && a.hasMore)this.currentPage++; else this.songsLoaded = true;
    return b
},playSongs:function(a) {
    var b = _.orEqual(a.index, -1),c = _.orEqual(a.playOnAdd, false),g = _.orEqual(a.sort, false),h = _.orEqual(a.numericSort, false),k = new GS.Models.PlayContext((this.shortName || "").toLowerCase(), this);
    a.verified && _.isEmpty(this.songs) && this.getSongs(this.callback("playSongs", {index:b,playOnAdd:c,sort:"TrackNum",numericSort:true,verified:false}), null, false);
    var m = [];
    if (g) {
        var n = [];
        _.forEach(this.songs, function(o) {
            n.push(o)
        });
        n = n.sort(function(o, r) {
            if (o.hasOwnProperty(g) && r.hasOwnProperty(g)) {
                var t = o[g],w = r[g];
                if (h) {
                    t = parseFloat(t, 10);
                    if (isNaN(t))t = 0;
                    w = parseFloat(w, 10);
                    if (isNaN(w))w = 0;
                    return t - w
                }
                if (t > w)return 1; else if (t < w)return-1;
                return 0
            } else if (o.hasOwnProperty(g))return 1;
            return 0
        });
        for (b = 0; b < n.length; b++)m.push(n[b].SongID)
    } else _.forEach(this.songs, function(o) {
        m.push(o.SongID)
    });
    GS.player.addSongsToQueueAt(m, a.index, a.playOnAdd, k)
}});
(function(a) {
    GS.Models.Base.extend("GS.Models.Song", {id:"SongID",cache:{},defaults:{AlbumID:null,AlbumName:"",ArtistID:null,ArtistName:"",CoverArtFilename:"",EstimateDuration:0,Flags:0,IsLowBitrateAvailable:0,Popularity:"",SongID:null,SongName:"",TrackNum:"0",Year:"0",artPath:"http://beta.grooveshark.com/static/amazonart/",fromLibrary:0,isFavorite:0,isVerified:-1,TSAdded:"",TSFavorited:"",_token:null,tokenFailed:false},songsLoaded:false,songsUnverifiedLoaded:false,getSong:function(b, c, g, h) {
        var k =
                this.getOneFromCache(b),m = arguments[arguments.length - 1] === h ? {} : arguments[arguments.length - 1];
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getQueueSongListFromSongIDs([b], this.callback(["wrapSingleSongFromIDs",c]), g, m)
        }
    },getSongFromToken:function(b, c, g, h) {
        var k = this.getOneFromCache(b);
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getSongFromToken(b, this.callback("wrapSongFromToken", b, c), g)
        }
    },getVerifiedDivider:function() {
        var b =
                this.wrap({SongID:-1,SongName:"",ArtistName:"",ArtistID:0,AlbumName:"",AlbumID:0,CoverArtFilename:""}, false);
        b.isVerified = 0;
        return b
    },wrap:function(b, c) {
        b = _.orEqual(b, {});
        var g = _.orEqualEx(b.TrackNum, b.trackNum, "0").toString(),h = this._super({AlbumID:_.orEqualEx(b.AlbumID, b.albumID, 0),AlbumName:_.cleanText(_.orEqualEx(b.AlbumName, b.albumName, "Unknown Album")),ArtistID:_.orEqualEx(b.ArtistID, b.artistID, 0),ArtistName:_.cleanText(_.orEqualEx(b.ArtistName, b.artistName, "Unknown Artist")),CoverArtFilename:_.orEqualEx(b.CoverArtFilename,
                b.artFilename, ""),EstimateDuration:_.orEqualEx(b.EstimateDuration, b.estimateDuration, 0),Flags:_.orEqualEx(b.Flags, b.flags, 0),IsLowBitrateAvailable:_.orEqualEx(b.IsLowBitrateAvailable, 0),SongID:_.orEqualEx(b.SongID, b.songID, 0),SongName:_.cleanText(_.orEqualEx(b.SongName, b.songName, b.Name, "Unknown Title")),TrackNum:g,Year:_.cleanText(_.orEqualEx(b.Year, b.year, "0")),_token:_.orEqualEx(b._token, null)}, c);
        if (h.TrackNum !== g && g !== "0")h.TrackNum = g;
        return h
    },wrapQueue:function(b) {
        return this.wrapCollection(b,
                {Flags:0,EstimateDuration:0,autoplayVote:0,parentQueueID:0,queueSongID:0,source:"",index:-1,context:null,sponsoredAutoplayID:0}, false, true)
    },wrapSingleSongFromIDs:function(b) {
        b = this.wrapCollection(b);
        if (b.length)return b[0]
    },wrapSongFromToken:function(b, c, g) {
        if (a.isArray(g))g = {};
        g = this.wrap(g);
        g.validate() && g.checkToken({Token:b});
        a.isFunction(c) && c(g);
        return g
    },archive:function(b) {
        return{A:b.AlbumID,B:b.AlbumName,C:b.ArtistID,D:b.ArtistName,E:b.CoverArtFilename,F:b.EstimateDuration,G:b.Flags,H:b.Popularity,
            I:b.SongID,J:b.SongName,K:b.TSAdded,L:b.TrackNum,M:b.Year,N:b.isFavorite}
    },unarchive:function(b) {
        return{AlbumID:b.A,AlbumName:b.B,ArtistID:b.C,ArtistName:b.D,CoverArtFilename:b.E,EstimateDuration:b.F,Flags:b.G,Popularity:b.H,SongID:b.I,SongName:b.J,TSAdded:b.K,TrackNum:isNaN(b.L) ? "0" : b.L,Year:isNaN(b.M) ? "0" : b.M,isFavorite:b.N}
    }}, {validate:function() {
        if (this.SongID > 0 && this.ArtistID > 0 && this.AlbumID > 0)return true;
        return false
    },init:function(b) {
        if (b) {
            this._super(b);
            this.SongName = _.orEqual(b.SongName,
                    b.Name) || "Unknown Title";
            this.AlbumName = b.AlbumName || "Unknown Album";
            this.ArtistName = b.ArtistName || "Unknown Artist";
            this.searchText = [this.SongName,this.ArtistName,this.AlbumName].join(" ").toLowerCase();
            this.fanbase = GS.Models.Fanbase.wrap({objectID:this.SongID,objectType:"song"});
            this.songs = {};
            delete this.Name
        }
    },toUrl:function(b) {
        if (this._token)return _.cleanUrl(this.SongName, this.SongID, "s", this._token, b); else if (this.tokenFailed)return _.generate404(); else {
            this.getToken();
            return this._token ? _.cleanUrl(this.SongName,
                    this.SongID, "s", this._token, b) : _.generate404()
        }
    },toArtistUrl:function(b) {
        return _.cleanUrl(this.ArtistName, this.ArtistID, "artist", null, b)
    },getToken:function() {
        if (this._token)return this._token; else if (this.tokenFailed)return null; else {
            GS.service.getTokenForSong(this.SongID, this.callback(this.checkToken), this.callback(this.checkToken), {async:false});
            return this._token
        }
    },checkToken:function(b) {
        if (b.Token) {
            this._token = b.Token;
            GS.Models.Song.cache[this._token] = this;
            GS.Models.Song.getOneFromCache(this.SongID)._token =
                    this._token
        } else this.tokenFailed = true
    },getImageURL:function(b) {
        var c = gsConfig.assetHost + "/webincludes/images/default/album_250.png";
        b || (b = "m");
        if (this.CoverArtFilename)c = this.artPath + b + this.CoverArtFilename;
        return c
    },getDetailsForFeeds:function() {
        return{songID:this.SongID,songName:this.SongName,albumID:this.AlbumID,albumName:this.AlbumName,artistID:this.ArtistID,artistName:this.ArtistName,artFilename:this.ArtFilename,track:this.TrackNum}
    },getRelatedSongs:function(b, c, g) {
        g = _.orEqual(g, true);
        this.album ?
                this.album.getSongs(b, c, g) : GS.Models.Album.getAlbum(this.AlbumID, this.callback(function(h) {
            this.album = h;
            h.getSongs(b, c, g)
        }), c, false)
    },getAffiliateDownloadURLs:function(b) {
        var c;
        if (_.isEmpty(this.affiliateDownloadURLs))c = this; else return this.affiliateDownloadURLs;
        var g = [];
        GS.service.getAffiliateDownloadURLs(this.SongName, this.ArtistName, function(h) {
            a.each(h, function(k, m) {
                if (k === "amazon")k = "Amazon";
                g.push({name:k,url:m.url})
            });
            c.affiliateDownloadURLs = g;
            b(c.affiliateDownloadURLs)
        }, function() {
            b({})
        })
    },
        getContextMenu:function(b) {
            b = _.orEqual(b, {});
            var c = [];
            GS.user.isLoggedIn && c.push({title:a.localize.getString("SHARE_EMAIL"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_email",action:{type:"fn",callback:this.callback(function() {
                GS.lightbox.open("share", {service:"email",type:"song",id:this.SongID})
            })}});
            c = c.concat([
                {title:a.localize.getString("SHARE_FACEBOOK"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_facebook",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("share",
                            {service:"facebook",type:"song",id:this.SongID})
                })}},
                {title:a.localize.getString("SHARE_TWITTER"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_twitter",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("share", {service:"twitter",type:"song",id:this.SongID})
                })}},
                {title:a.localize.getString("SHARE_STUMBLE"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_stumbleupon",action:{type:"fn",callback:this.callback(function() {
                    window.open(_.makeUrlForShare("stumbleupon", "song",
                            this), "_blank")
                })}},
                {title:a.localize.getString("SHARE_REDDIT"),customClass:"jj_menu_item_hasIcon jj_menu_item_share jj_menu_item_share_reddit",action:{type:"fn",callback:this.callback(function() {
                    window.open(_.makeUrlForShare("reddit", "song", this), "_blank")
                })}},
                {title:a.localize.getString("SHARE_WIDGET"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_widget",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("share", {service:"widget",type:"song",id:this.SongID})
                })}},
                {title:a.localize.getString("COPY_URL"),
                    type:"sub",action:{type:"fn",callback:this.callback(function() {
                    ZeroClipboard && GS.Models.Song.getSong(this.SongID, function(k) {
                        if (k) {
                            var m = ["http://grooveshark.com/" + k.toUrl().replace("#/", ""),"http://grooveshark.com/" + _.cleanUrl(k.AlbumName, k.AlbumID, "album").replace("#/", ""),"http://grooveshark.com/" + _.cleanUrl(k.ArtistName, k.ArtistID, "artist").replace("#/", "")];
                            k = a("div[id^=jjmenu_main_sub]");
                            if (window.contextMenuClipboards) {
                                window.contextMenuClipboards[0].reposition(a("div.songUrl", k)[0]);
                                window.contextMenuClipboards[1].reposition(a("div.albumUrl",
                                        k)[0]);
                                window.contextMenuClipboards[2].reposition(a("div.artistUrl", k)[0])
                            } else window.contextMenuClipboards = [new ZeroClipboard.Client(a("div.songUrl", k)[0]),new ZeroClipboard.Client(a("div.albumUrl", k)[0]),new ZeroClipboard.Client(a("div.artistUrl", k)[0])];
                            a.each(window.contextMenuClipboards, function(n, o) {
                                o.setText(m[n]);
                                if (!o.hasCompleteEvent) {
                                    o.addEventListener("complete", function(r, t) {
                                        a("div[id^=jjmenu]").remove();
                                        console.log("Copied: ", t)
                                    });
                                    o.hasCompleteEvent = true
                                }
                            });
                            a("div.songUrl", k).bind("remove",
                                    function() {
                                        try {
                                            a.each(window.contextMenuClipboards, function(o, r) {
                                                r.hide()
                                            })
                                        } catch(n) {
                                        }
                                    });
                            a("div[name$=Url]", k).show()
                        }
                    })
                })},customClass:"last copyUrl jj_menu_item_hasIcon jj_menu_item_copy",src:[
                    {title:a.localize.getString("SONG_URL"),customClass:"songUrl jj_menu_item_hasIcon jj_menu_item_copy"},
                    {title:a.localize.getString("ALBUM_URL"),customClass:"albumUrl jj_menu_item_hasIcon jj_menu_item_copy"},
                    {title:a.localize.getString("ARTIST_URL"),customClass:" artistUrl jj_menu_item_hasIcon jj_menu_item_copy"}
                ]}
            ]);
            var g = [];
            GS.user.library.songs[this.SongID] ? g.push({title:a.localize.getString("CONTEXT_REMOVE_FROM_LIBRARY"),customClass:"last jj_menu_item_hasIcon jj_menu_item_remove_music",action:{type:"fn",callback:this.callback(function() {
                GS.user.removeFromLibrary(this.SongID)
            })}}) : g.push({title:a.localize.getString("CONTEXT_ADD_TO_LIBRARY"),customClass:"last jj_menu_item_hasIcon jj_menu_item_music",action:{type:"fn",callback:this.callback(function() {
                GS.user.addToLibrary(this.SongID)
            })}});
            var h = [
                {title:a.localize.getString("CONTEXT_ADD_TO_PLAYLIST"),
                    type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_playlist",src:GS.Models.Playlist.getPlaylistsMenu(this.SongID, this.callback(function(k) {
                    k.addSongs([this.SongID], null, true)
                }))}
            ];
            GS.user.favorites.songs[this.SongID] ? h.push({title:a.localize.getString("CONTEXT_REMOVE_FROM_FAVORITES"),customClass:"last jj_menu_item_hasIcon jj_menu_item_remove_favorite",action:{type:"fn",callback:this.callback(function() {
                GS.user.removeFromSongFavorites(this.SongID)
            })}}) : h.push({title:a.localize.getString("CONTEXT_ADD_TO_FAVORITES"),
                customClass:"last jj_menu_item_hasIcon jj_menu_item_favorites",action:{type:"fn",callback:this.callback(function() {
                    GS.user.addToSongFavorites(this.SongID)
                })}});
            g = g.concat([
                {customClass:"separator"},
                {title:a.localize.getString("CONTEXT_ADD_TO"),type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_add",src:h}
            ]);
            g = g.concat([
                {customClass:"separator"},
                {title:a.localize.getString("CONTEXT_SHARE_SONG"),type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_share",src:c},
                {customClass:"separator"},
                {title:a.localize.getString("CONTEXT_BUY_SONG"),customClass:"last jj_menu_item_hasIcon jj_menu_item_download",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("buySong", this.SongID)
                })}}
            ]);
            if (GS.service.country.ID == 0 || GS.service.country.ID == 1 || GS.service.country.ID == 223)g.push({title:a.localize.getString("CONTEXT_BUY_MERCH"),customClass:"last jj_menu_item_hasIcon jj_menu_item_buy_merch",action:{type:"fn",callback:this.callback(function() {
                GS.lightbox.open("tunipop", {songID:this.SongID})
            })}});
            b.isQueue = _.orEqual(b.isQueue, false);
            b.isQueue && g.push({customClass:"separator"}, {title:a.localize.getString("CONTEXT_FLAG_SONG"),customClass:"last jj_menu_item_hasIcon jj_menu_item_flag",type:"sub",src:[
                {title:a.localize.getString("CONTEXT_FLAG_BAD_SONG"),customClass:"last jj_menu_item_hasIcon jj_menu_item_flag",action:{type:"fn",callback:function() {
                    b.flagSongCallback(1)
                }}},
                {title:a.localize.getString("CONTEXT_FLAG_BAD_METADATA"),customClass:"last jj_menu_item_hasIcon jj_menu_item_flag",action:{type:"fn",
                    callback:function() {
                        b.flagSongCallback(4)
                    }}}
            ]});
            return g
        },getTitle:function() {
            return['"',this.SongName,'" by ',this.ArtistName,' on "',this.AlbumName,'"'].join("")
        },toString:function(b) {
            return(b = _.orEqual(b, false)) ? ["Song. sid:",this.SongID,", name:",this.SongName,", aid:",this.ArtistID,", arname: ",this.ArtistName,", alid: ",this.AlbumID,", alname:",this.AlbumName,", track: ",this.TrackNum,", verified: ",this.isVerified].join("") : _.getString("SELECTION_SONG_SINGLE", {SongName:_.cleanText(this.SongName),
                ArtistName:_.cleanText(this.ArtistName)})
        }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Album", {id:"AlbumID",cache:{},defaults:{AlbumName:"",AlbumID:null,ArtistName:"",ArtistID:null,CoverArtFilename:"",Year:"",IsVerified:0,PathName:false,PathNameEmpty:false,isFavorite:0,songsLoaded:false,songsUnverifiedLoaded:false,fanbase:null},getAlbum:function(b, c, g, h) {
        var k = this.getOneFromCache(b);
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getAlbumByID(b, this.callback(["wrap",c]), g)
        }
    },getFilterAll:function(b) {
        return this.wrap({AlbumID:-1,
            AlbumName:a.localize.getString("ALL_ALBUMS"),ArtistName:b || "",ArtistID:-1,isVerified:2,isFilterAll:1}, false)
    },defaultSongSort:function(b, c) {
        var g = parseFloat(_.orEqual(b.TrackNum, 0), 10),h = parseFloat(_.orEqual(c.TrackNum, 0), 10);
        if (isNaN(g))g = 0;
        if (isNaN(h))h = 0;
        if (g !== 0 && h === 0)return-1;
        if (h !== 0 && g === 0)return 1;
        return g - h
    }}, {smallAlbum:5,artPath:"http://beta.grooveshark.com/static/amazonart/",getSongs:function(b, c, g) {
        var h = arguments[arguments.length - 1] === g ? {} : arguments[arguments.length - 1];
        g = _.orEqual(g,
                true);
        if (this.songsLoaded) {
            var k = this.wrapManySongs(this.songs);
            if (!_.isEmpty(k) || this.songsUnverifiedLoaded)b(k);
            if (!g && !this.songsUnverifiedLoaded) {
                this.songsUnverifiedLoaded = true;
                GS.service.albumGetSongs(this.AlbumID, false, 0, this.callback(["wrapManySongs","resetAlbumInfo",b]), c, h)
            }
        } else {
            this.songsLoaded = true;
            g ? GS.service.albumGetSongs(this.AlbumID, true, 0, this.callback(["wrapManyVerifiedSongs","resetAlbumInfo",b]), c, h) : GS.service.albumGetSongs(this.AlbumID, false, 0, this.callback(["wrapManySongs",
                "resetAlbumInfo",b]), c, h)
        }
    },wrapManySongs:function(b, c) {
        c = _.orEqual(c, false);
        return this.wrapSongCollection(b, {isVerified:c ? 1 : -1,TrackNum:0,AlbumName:this.AlbumName,AlbumID:this.AlbumID,Popularity:""})
    },wrapManyVerifiedSongs:function(b) {
        return this.wrapManySongs(b, true)
    },play:function(b, c) {
        this.getSongs(this.callback("playSongs", {index:b,playOnAdd:c,sort:"TrackNum",numericSort:true,verified:true}))
    },resetAlbumInfo:function(b) {
        for (i = 0; i < b.length; i++) {
            b[i].AlbumName = this.AlbumName;
            b[i].AlbumID = this.AlbumID
        }
        return b
    },
        validate:function() {
            if (this.AlbumID > 0 && this.ArtistID > 0)return true;
            return false
        },init:function(b) {
            this._super(b);
            this.AlbumName = _.orEqual(b.AlbumName, b.Name) || "Unknown Album";
            if (!this.isFilterAll)this.ArtistName = b.ArtistName || "Unknown Artist";
            this.fanbase = GS.Models.Fanbase.wrap({objectID:this.AlbumID,objectType:"album"});
            this.songs = {};
            this.songsUnverifiedLoaded = this.songsLoaded = false;
            this.searchText = [this.AlbumName,this.ArtistName].join(" ").toLowerCase()
        },getDetailsForFeeds:function() {
            return{albumID:this.AlbumID,
                albumName:this.AlbumName,artistID:this.ArtistID,artistName:this.ArtistName,artFilename:this.ArtFilename}
        },toUrl:function(b) {
            return this.PathName ? _.makeUrlFromPathName(this.PathName, b) : _.cleanUrl(this.AlbumName, this.AlbumID, "album", null, b)
        },toArtistUrl:function(b) {
            return _.cleanUrl(this.ArtistName, this.ArtistID, "artist", null, b)
        },_onPathNameSuccess:function(b, c) {
            if (c.name)this.PathName = c.name; else {
                this.PathName = "";
                this.PathNameEmpty = true
            }
            a.isFunction(b) && b(this.PathName)
        },_onPathNameFailed:function(b) {
            this.PathName =
                    "";
            this.PathNameEmpty = true;
            a.isFunction(b) && b(this.PathName)
        },getImageURL:function(b) {
            var c = gsConfig.assetHost + "/webincludes/images/default/album_250.png";
            b || (b = "l");
            if (this.CoverArtFilename)c = this.artPath + b + this.CoverArtFilename;
            return c
        },getTitle:function() {
            return['"',this.AlbumName,'" by ',this.ArtistName].join("")
        },toString:function(b) {
            b = _.orEqual(b, false);
            var c = this.ArtistName ? "SELECTION_ALBUM_SINGLE" : "SELECTION_ALBUM_SINGLE_NO_ARTIST";
            return b ? ["Album. alid: ",this.AlbumID,", alname:",this.AlbumName,
                ", aid:",this.ArtistID,", arname: ",this.ArtistName,", verified: ",this.isVerified].join("") : _.getString(c, {AlbumName:_.cleanText(this.AlbumName),ArtistName:_.cleanText(this.ArtistName)})
        }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Artist", {id:"ArtistID",cache:{},defaults:{ArtistName:"",ArtistID:null,CoverArtFilename:"",PathName:false,PathNameEmpty:false,isFavorite:0,songsLoaded:false,songsUnverifiedLoaded:false,eventsLoaded:false,eventIDs:[],fanbase:null,tunipopID:NaN},getArtist:function(b, c, g, h) {
        var k = this.getOneFromCache(b);
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getArtistByID(b, this.callback(["wrap",c]), g)
        }
    },getFilterAll:function() {
        return this.wrap({ArtistID:-1,
            ArtistName:a.localize.getString("ALL_ARTISTS"),isVerified:2,isFilterAll:1}, false)
    },defaultSongSort:function(b, c) {
        var g = _.orEqual(b.AlbumName, ""),h = _.orEqual(b.AlbumName, "");
        if (g > h)return 1; else if (g < h)return-1;
        return GS.Models.Album.defaultSongSort(b, c)
    }}, {smallCollection:10,getSongs:function(b, c, g) {
        var h = arguments[arguments.length - 1] === g ? {} : arguments[arguments.length - 1];
        g = _.orEqual(g, true);
        if (this.songsLoaded) {
            var k = this.wrapManySongs(this.songs);
            if (!_.isEmpty(k) || this.songsUnverifiedLoaded)b(k);
            if (!g && !this.songsUnverfiedLoaded) {
                this.songsUnverifiedLoaded = true;
                GS.service.artistGetSongsEx(this.ArtistID, false, this.callback(["wrapManySongs",b]), c, h)
            }
        } else {
            this.songsLoaded = true;
            GS.service.artistGetSongsEx(this.ArtistID, true, this.callback(["wrapManySongs",b]), c, h)
        }
    },wrap:function(b, c) {
        b = _.orEqual(b, {});
        try {
            delete b.AlbumID
        } catch(g) {
        }
        return this._super(b, c)
    },wrapManySongs:function(b, c) {
        c = _.orEqual(c, false);
        return this.wrapSongCollection(b, {isVerified:c ? 1 : -1,Popularity:""})
    },wrapManyVerifiedSongs:function(b) {
        return this.wrapManySongs(b,
                true)
    },getEvent:function(b, c, g) {
        var h = arguments[arguments.length - 1] === g ? {} : arguments[arguments.length - 1];
        g = _.orEqual(g, true);
        if (this.eventsLoaded) {
            h = GS.Models.Event.getManyFromCache(this.eventIDs);
            b(h)
        } else {
            g && a.publish("gs.page.loading.grid");
            GS.service.artistGetEvents(this.ArtistID, this.ArtistName, this.callback([GS.Models.Event.wrapMany,b]), c, h)
        }
    },cacheAndReturnEvents:function(b) {
        for (var c = GS.Models.User.wrapMany(b.Users || b.Return.fans || b.Return),g = 0; g < c.length; g++) {
            var h = c[g];
            this.userIDs.push(h.UserID);
            GS.Models.User.cache[h.UserID] = h
        }
        if (_.defined(b.hasMore) && b.hasMore)this.currentPage++; else this.fansLoaded = true;
        return c
    },_tunipopDeferred:null,getTunipopID:function() {
        if (!this._tunipopDeferred) {
            this._tunipopDeferred = a.Deferred();
            GS.service.getTunipopID(this.ArtistName, false, this.callback(this._tunipopSuccess), this.callback(this._tunipopFailed))
        }
        return this._tunipopDeferred.promise()
    },_tunipopSuccess:function(b) {
        console.log("artist tunipop success", b);
        b = parseInt(b, 10);
        if (isNaN(b))b = 0;
        this.tunipopID =
                b;
        this._tunipopDeferred.resolve(this.tunipopID)
    },_tunipopFailed:function(b) {
        console.log("tunipop failed", this.ArtistName, b.details);
        this.tunipopID = 0;
        this._tunipopDeferred.resolve(this.tunipopID)
    },validate:function() {
        if (this.ArtistID > 0)return true;
        return false
    },init:function(b) {
        this._super(b);
        this.ArtistName = _.orEqual(b.ArtistName, b.Name) || "Unknown Artist";
        this.fanbase = GS.Models.Fanbase.wrap({objectID:this.ArtistID,objectType:"artist"});
        this.songs = {};
        this.songsUnverifiedLoaded = this.songsLoaded = false;
        this.eventIDs = [];
        this.eventsLoaded = false;
        this.searchText = this.ArtistName.toLowerCase()
    },getDetailsForFeeds:function() {
        return{artistID:this.ArtistID,artistName:this.ArtistName}
    },toUrl:function(b) {
        return this.PathName ? _.makeUrlFromPathName(this.PathName, b) : _.cleanUrl(this.ArtistName, this.ArtistID, "artist", null, b)
    },getPathName:function(b) {
        if (this.PathName || this.PathNameEmpty)a.isFunction(b) && b(this.PathName); else GS.service.getPageNameByIDType(this.ArtistID, "artist", this.callback(this._onPathNameSuccess,
                b), this.callback(this._onPathNameFailed, b))
    },_onPathNameSuccess:function(b, c) {
        if (c.name)this.PathName = c.name; else {
            this.PathName = "";
            this.PathNameEmpty = true
        }
        a.isFunction(b) && b(this.PathName)
    },_onPathNameFailed:function(b) {
        this.PathName = "";
        this.PathNameEmpty = true;
        a.isFunction(b) && b(this.PathName)
    },getImageURL:function() {
        return gsConfig.assetHost + "/webincludes/images/default/artist_100.png"
    },getTitle:function() {
        return this.ArtistName
    },getContextMenu:function() {
        var b = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ARTIST,
                this);
        return[
            {title:a.localize.getString("CONTEXT_PLAY_ARTIST"),action:{type:"fn",callback:this.callback(function() {
                this.getSongs(function(c) {
                    var g = [];
                    a.each(c, function(h, k) {
                        g.push(k.SongID)
                    });
                    GS.player.addSongsToQueueAt(g, GS.player.INDEX_DEFAULT, true, b)
                }, function() {
                }, false)
            })},customClass:"first"},
            {title:a.localize.getString("CONTEXT_PLAY_ARTIST_NEXT"),action:{type:"fn",callback:this.callback(function() {
                this.getSongs(function(c) {
                    var g = [];
                    a.each(c, function(h, k) {
                        g.push(k.SongID)
                    });
                    GS.player.addSongsToQueueAt(g,
                            GS.player.INDEX_NEXT, false, b)
                }, function() {
                }, false)
            })}},
            {title:a.localize.getString("CONTEXT_PLAY_ARTIST_LAST"),action:{type:"fn",callback:this.callback(function() {
                this.getSongs(function(c) {
                    var g = [];
                    a.each(c, function(h, k) {
                        g.push(k.SongID)
                    });
                    GS.player.addSongsToQueueAt(g, GS.player.INDEX_LAST, false, b)
                }, function() {
                }, false)
            })}},
            {customClass:"separator"},
            {title:a.localize.getString("CONTEXT_REPLACE_ALL_SONGS"),action:{type:"fn",callback:this.callback(function() {
                this.getSongs(function(c) {
                    var g = [],h = GS.player.isPlaying;
                    a.each(c, function(k, m) {
                        g.push(m.SongID)
                    });
                    GS.player.addSongsToQueueAt(g, GS.player.INDEX_REPLACE, h, b)
                }, function() {
                }, false)
            })}}
        ]
    },toString:function(b) {
        return(b = _.orEqual(b, false)) ? ["Artist. aid:",this.ArtistID,", arname: ",this.ArtistName].join("") : _.cleanText(this.ArtistName)
    }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Playlist", {id:"PlaylistID",cache:{},defaults:{PlaylistID:0,PlaylistName:"",UserID:0,Username:"",UserName:"",FName:"",LName:"",Description:"",NumSongs:0,CoverArtFilename:"",Sort:null,isFavorite:0,songs:[],originalOrder:[],songsLoaded:false,hasUnsavedChanges:false,searchText:"",fanbase:null,gridKey:1,gridKeyLookup:{},songIDLookup:{},isDeleted:false,artPath:"http://beta.grooveshark.com/static/amazonart/"},playlistsLoaded:false,playlistIDs:[],getPlaylist:function(b, c, g, h) {
        var k = this.getOneFromCache(b);
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getPlaylistByID(b, this.callback(["wrap",c]), g, {async:false})
        }
    },getPlaylistsOrdered:function(b, c) {
        c = _.orEqual(c, false);
        b = _.orEqual(b, "PlaylistName");
        var g = [];
        a.each(c === false ? GS.user.playlists : GS.user.favorites.playlists, function(h, k) {
            k = GS.Models.Playlist.getOneFromCache(k.PlaylistID);
            if (c)k.TSAdded = k.TSFavorited;
            g.push(k)
        });
        g.sort(function(h, k) {
            var m,n;
            try {
                m = h[b].toString().toLowerCase();
                n = k[b].toString().toLowerCase()
            } catch(o) {
                console.warn("playlistOrdered error: " + o, b, h[b], k[b]);
                return 0
            }
            return m == n ? 0 : m > n ? 1 : -1
        });
        return g
    },getPlaylistsMenu:function(b, c, g, h) {
        b = a.makeArray(b);
        g = _.orEqual(g, false);
        h = _.orEqual(h, true);
        var k;
        k = [];
        if (h) {
            k.push({title:a.localize.getString("CONTEXT_NEW_PLAYLIST"),customClass:"jj_menu_item_hasIcon jj_menu_item_new_playlist",action:{type:"fn",callback:function() {
                GS.lightbox.open("newPlaylist", b)
            }}});
            _.isEmpty(GS.user.playlists) || k.push({customClass:"separator"})
        }
        a.each(this.getPlaylistsOrdered("PlaylistName"),
                function(m, n) {
                    k.push({title:n.PlaylistName,customClass:"jj_menu_item_hasIcon jj_menu_item_playlist",action:{type:"fn",callback:function() {
                        c(n);
                        return true
                    }}})
                });
        g && a.each(this.getPlaylistsOrdered("PlaylistName", true), function(m, n) {
            k.push({title:n.PlaylistName,customClass:"jj_menu_item_hasIcon jj_menu_item_playlist_subscribed",action:{type:"fn",callback:function() {
                c(n)
            }}})
        });
        return k
    }}, {init:function(b) {
        this._super(b);
        this.PlaylistName = _.defined(b.PlaylistName) ? _.cleanText(b.PlaylistName) : _.cleanText(b.Name);
        this.Description = _.orEqual(b.Description, b.About || "");
        this.Username = this.Username && this.Username.length ? this.Username : b.Username;
        this.UserName = _.orEqual(this.Username, this.UserName && this.UserName.length ? this.UserName : _.cleanText(this.FName + (this.LName && this.LName.length ? " " + this.LName : "")));
        this.fanbase = GS.Models.Fanbase.wrap({objectID:this.PlaylistID,objectType:"playlist"});
        this.searchText = [this.PlaylistName,this.FName,this.Description].join(" ").toLowerCase();
        this.songs = [];
        this.originalOrder = [];
        this.songsLoaded = _.orEqual(b.songsLoaded, false);
        this.hasUnsavedChanges = false;
        delete this.Name;
        delete this.About
    },getSongs:function(b, c, g) {
        var h = arguments[arguments.length - 1] === g ? {} : arguments[arguments.length - 1];
        g = _.orEqual(g, true);
        if (this.songsLoaded) {
            this._updateSongs();
            b(this.songs)
        } else {
            g && a.publish("gs.page.loading.grid");
            GS.service.playlistGetSongs(this.PlaylistID, this.callback(["wrapManySongs",b]), c, h)
        }
    },validate:function() {
        if (this.PlaylistID > 0)return true;
        return false
    },wrapManySongs:function(b) {
        var c =
                [];
        if (this.hasUnsavedChanges)c = this.songs;
        var g = b.Songs || b.songs || b.result || b;
        this.songs = [];
        this.gridKeyLookup = {};
        this.songIDLookup = {};
        var h;
        g.sort(function(k, m) {
            return parseFloat(k.Sort, 10) - parseFloat(m.Sort, 10)
        });
        for (h = 0; h < g.length; h++) {
            b = GS.Models.Song.wrap(g[h]).dupe();
            b.Sort = h;
            b.GridKey = this.gridKey;
            this.songs.push(b);
            this.gridKeyLookup[b.GridKey] = b;
            this.songIDLookup[b.SongID] = b;
            this.gridKey++
        }
        for (g = 0; g < c.length; g++) {
            b = c[g];
            b.Sort = g + h;
            b.GridKey = this.gridKey;
            c[g] = b;
            this.gridKeyLookup[b.GridKey] =
                    b;
            this.songIDLookup[b.SongID] = b;
            this.gridKey++
        }
        this.originalOrder = this.songs.concat();
        this.songs = this.songs.concat(c);
        this.songsLoaded = true;
        a.publish("gs.playlist.songs.update", this);
        a.publish("gs.playlist.view.update", this);
        this.songs._use_call = true;
        return this.songs
    },_updateSongs:function() {
        var b,c,g = GS.Models.Song;
        for (b = 0; b < this.songs.length; b++) {
            c = g.getOneFromCache(this.songs[b].SongID);
            this.songs[b].isFavorite = c.isFavorite;
            this.songs[b].fromLibrary = c.fromLibrary
        }
    },reapplySorts:function() {
        for (var b =
                0; b < this.songs.length; b++)this.songs[b].Sort = b
    },play:function(b, c) {
        this.getSongs(this.callback("playSongs", {index:b,playOnAdd:c}))
    },playSongs:function(b) {
        _.orEqual(b.index, -1);
        _.orEqual(b.playOnAdd, false);
        var c = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST, this),g,h = [];
        for (g = 0; g < this.songs.length; g++)h.push(this.songs[g].SongID);
        GS.player.addSongsToQueueAt(h, b.index, b.playOnAdd, c)
    },getImageURL:function() {
        return gsConfig.assetHost + "/webincludes/images/default/album_250.png"
    },_addSongAtEnd:function(b) {
        this.hasUnsavedChanges &&
        this.addSongs([b], this.songs.length, true);
        if (GS.user.UserID != this.UserID)return false;
        if (!(b <= 0)) {
            GS.guts.logEvent("songAddedToPlaylist", {songID:b});
            if (this.songsLoaded) {
                var c;
                c = GS.Models.Song.getOneFromCache(b).dupe();
                c.GridKey = this.gridKey;
                this.gridKeyLookup[c.GridKey] = c;
                this.songIDLookup[c.SongID] = c;
                this.gridKey++;
                this.hasUnsavedChanges = true;
                GS.Controllers.PageController.ALLOW_LOAD = false;
                this.songs.push(c);
                this.reapplySorts();
                GS.user.isLoggedIn ? GS.service.playlistAddSongToExisting(this.PlaylistID,
                        b, this.callback("saveSuccess"), this.callback("saveFailed")) : this.saveSuccess();
                a.publish("gs.playlist.view.update", this)
            } else if (GS.user.isLoggedIn)GS.service.playlistAddSongToExisting(this.PlaylistID, b, this.callback("addSongSuccess"), this.callback("saveFailed")); else return false
        }
    },addSongs:function(b, c, g) {
        c = _.orEqual(c, this.songs.length);
        g = _.orEqual(g, false);
        if (this.songsLoaded && b.length + this.songs.length > 2500) {
            b = (new GS.Models.DataString(a.localize.getString("POPUP_FAIL_ADD_PLAYLIST_TOO_MANY_MSG"),
                    {playlist:this.PlaylistName,numSongs:b.length})).render();
            a.publish("gs.notification", {type:"error",message:b})
        } else if (b.length == 1 && !this.hasUnsavedChanges && g && c == this.songs.length)this._addSongAtEnd(b[0]); else {
            if (GS.user.UserID != this.UserID)return false;
            for (var h,k = [],m = 0; m < b.length; m++)if (!(b[m] <= 0)) {
                h = GS.Models.Song.getOneFromCache(b[m]).dupe();
                h.GridKey = this.gridKey;
                this.gridKeyLookup[h.GridKey] = h;
                this.songIDLookup[h.SongID] = h;
                this.gridKey++;
                k.push(h);
                GS.guts.logEvent("songAddedToPlaylist", {songID:h.SongID})
            }
            this.hasUnsavedChanges =
                    true;
            GS.Controllers.PageController.ALLOW_LOAD = false;
            this.songs.splice.apply(this.songs, [c,0].concat(k));
            this.reapplySorts();
            g && this.save();
            a.publish("gs.playlist.view.update", this)
        }
    },removeSongs:function(b, c) {
        if (GS.user.UserID != this.UserID)return false;
        c = _.orEqual(c, false);
        this.hasUnsavedChanges = true;
        GS.Controllers.PageController.ALLOW_LOAD = false;
        for (var g,h = 0; h < b.length; h++)if (g = this.songs[b[h]])g.isDeleted = true;
        this.reapplySorts();
        c && this.save();
        a.publish("gs.playlist.view.update", this)
    },overwriteWithSongs:function(b, c) {
        if (GS.user.UserID != this.UserID)return false;
        c = _.orEqual(c, false);
        this.songs = [];
        for (var g = 0; g < b.length; g++)if (!(b[g] <= 0)) {
            song = GS.Models.Song.getOneFromCache(b[g]).dupe();
            song.GridKey = this.gridKey;
            this.gridKeyLookup[song.GridKey] = song;
            this.songIDLookup[song.SongID] = song;
            this.gridKey++;
            this.songs.push(song)
        }
        this.reapplySorts();
        this.hasUnsavedChanges = this.songsLoaded = true;
        GS.Controllers.PageController.ALLOW_LOAD = false;
        c && this.save();
        a.publish("gs.playlist.view.update", this)
    },moveSongsTo:function(b, c, g) {
        if (GS.user.UserID != this.UserID)return false;
        g = _.orEqual(g, false);
        this.hasUnsavedChanges = true;
        GS.Controllers.PageController.ALLOW_LOAD = false;
        var h,k = [];
        for (h = 0; h < b.length; h++)k.push(this.songs[b[h]]);
        for (h = 0; h < k.length; h++) {
            b = this.songs.indexOf(k[h]);
            this.songs.splice(b, 1);
            b < c && c--
        }
        this.songs.splice.apply(this.songs, [c,0].concat(k));
        this.reapplySorts();
        g && this.save();
        a.publish("gs.playlist.view.update", this)
    },save:function() {
        if (this.songsLoaded) {
            var b,c = [],g = [];
            for (b = 0; b < this.songs.length; b++)this.songs[b].isDeleted ?
                    GS.guts.logEvent("songRemovedFromPlaylist", {songID:this.songs[b].SongID}) : c.push(this.songs[b].SongID);
            for (b = 0; b < this.originalOrder.length; b++)g.push(this.originalOrder[b].SongID);
            if (c.join(".") == g.join(".")) {
                this.originalOrder = this.songs.concat();
                this.hasUnsavedChanges = false;
                GS.Controllers.PageController.ALLOW_LOAD = true;
                a.publish("gs.playlist.view.update", this)
            } else {
                GS.user.isLoggedIn ? GS.service.overwritePlaylist(this.PlaylistID, c, this.callback("saveSuccess"), this.callback("saveFailed")) : this.saveSuccess();
                GS.guts.gaTrackEvent("playlist", "savePlaylist")
            }
        } else this.getSongs(this.callback("save"), this.callback("saveFailed"), false)
    },saveSuccess:function() {
        for (var b = [],c = 0; c < this.songs.length; c++)this.songs[c].isDeleted || b.push(this.songs[c]);
        this.songsLoaded = true;
        this.songs = b;
        this.originalOrder = this.songs.concat();
        this.hasUnsavedChanges = false;
        GS.Controllers.PageController.ALLOW_LOAD = true;
        b = (new GS.Models.DataString(a.localize.getString("POPUP_SAVE_PLAYLIST_MSG"), {playlist:this.PlaylistName})).render();
        a.publish("gs.notification", {type:"notice",message:b});
        a.publish("gs.playlist.songs.update", this);
        a.publish("gs.playlist.view.update", this)
    },addSongSuccess:function() {
        var b = (new GS.Models.DataString(a.localize.getString("POPUP_SAVE_PLAYLIST_MSG"), {playlist:this.PlaylistName})).render();
        a.publish("gs.notification", {type:"notice",message:b});
        a.publish("gs.playlist.songs.update", this);
        a.publish("gs.playlist.view.update", this)
    },saveFailed:function() {
        a.publish("gs.notification", {type:"error",message:a.localize.getString("POPUP_FAIL_SAVE_PLAYLIST_MSG")})
    },
        remove:function(b) {
            GS.user.deletePlaylist(this.PlaylistID, b);
            GS.guts.logEvent("playlistDeleted", {playlistID:this.PlaylistID})
        },restore:function(b) {
            GS.user.restorePlaylist(this.PlaylistID, b)
        },undo:function() {
            this.songs = this.originalOrder.concat();
            for (var b = 0; b < this.songs.length; b++)this.songs[b].isDeleted = false;
            this.hasUnsavedChanges = false;
            GS.Controllers.PageController.ALLOW_LOAD = true;
            this.reapplySorts();
            a.publish("gs.playlist.songs.update", this);
            a.publish("gs.playlist.view.update", this)
        },rename:function(b, c, g) {
            GS.service.renamePlaylist(this.PlaylistID, b, this.callback([this._renameSuccess,c], b), this.callback([this._renameFailed,g]))
        },_renameSuccess:function(b, c) {
            this.PlaylistName = b;
            a.publish("gs.playlist.view.update", this);
            a.publish("gs.auth.playlists.update", this);
            return c
        },_renameFailed:function(b) {
            return b
        },changeDescription:function(b, c, g) {
            GS.service.setPlaylistAbout(this.PlaylistID, b, this.callback([this._changeDescSuccess,c], b), this.callback([this._changeDescFailed,g]))
        },_changeDescSuccess:function(b, c) {
            this.Description = b;
            a.publish("gs.playlist.view.update", this);
            return c
        },_changeDescFailed:function(b) {
            return b
        },getDetailsForFeeds:function() {
            return{playlistID:this.PlaylistID,playlistName:this.PlaylistName,userID:this.UserID,userName:this.UserName,description:this.Description}
        },getTitle:function() {
            return['"',this.PlaylistName,'" by ',this.UserName].join("")
        },isSubscribed:function() {
            return GS.user.UserID != this.UserID && this.isFavorite || !_.isEmpty(GS.user.favorites.playlists[this.PlaylistID])
        },subscribe:function() {
            GS.user.addToPlaylistFavorites(this.PlaylistID)
        },
        unsubscribe:function() {
            GS.user.removeFromPlaylistFavorites(this.PlaylistID)
        },isShortcut:function() {
            return a.inArray(this.PlaylistID.toString(), GS.user.sidebar.playlists) > -1 || a.inArray(this.PlaylistID.toString(), GS.user.sidebar.subscribedPlaylists) > -1
        },addShortcut:function(b) {
            GS.user.addToShortcuts("playlist", this.PlaylistID, b)
        },removeShortcut:function(b) {
            GS.user.removeFromShortcuts("playlist", this.PlaylistID, b)
        },getContextMenu:function() {
            var b = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST,
                    this),c = [];
            GS.user.isLoggedIn && c.push({title:a.localize.getString("SHARE_EMAIL"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share_email",action:{type:"fn",callback:this.callback(function() {
                GS.lightbox.open("share", {service:"email",type:"playlist",id:this.PlaylistID})
            })}});
            c = c.concat([
                {title:a.localize.getString("SHARE_FACEBOOK"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share_facebook",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("share", {service:"facebook",
                        type:"playlist",id:this.PlaylistID})
                })}},
                {title:a.localize.getString("SHARE_TWITTER"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share_twitter",action:{type:"fn",callback:this.callback(function() {
                    GS.lightbox.open("share", {service:"twitter",type:"playlist",id:this.PlaylistID})
                })}},
                {title:a.localize.getString("SHARE_STUMBLEUPON"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share_stumbleupon",action:{type:"fn",callback:this.callback(function() {
                    window.open(_.makeUrlForShare("stumbleupon",
                            "playlist", this), "_blank")
                })}},
                {title:a.localize.getString("SHARE_REDDIT"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share jj_menu_item_share_reddit",action:{type:"fn",callback:this.callback(function() {
                    window.open(_.makeUrlForShare("reddit", "playlist", this), "_blank")
                })}},
                {title:a.localize.getString("SHARE_WIDGET"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share_widget",action:{type:"fn",callback:this.callback(function() {
                    window.contextClipboard || GS.lightbox.open("share", {service:"widget",
                        type:"playlist",id:this.PlaylistID})
                })}}
            ]);
            return[
                {title:a.localize.getString("CONTEXT_PLAY_PLAYLIST"),customClass:"last jj_menu_item_hasIcon jj_menu_item_play",action:{type:"fn",callback:this.callback(function() {
                    this.getSongs(function(g) {
                        var h = [];
                        a.each(g, function(k, m) {
                            h.push(m.SongID)
                        });
                        GS.player.addSongsToQueueAt(h, GS.player.INDEX_DEFAULT, true, b)
                    }, function() {
                    }, false)
                })}},
                {title:a.localize.getString("CONTEXT_PLAY_PLAYLIST_NEXT"),customClass:"last jj_menu_item_hasIcon jj_menu_item_play_next",action:{type:"fn",
                    callback:this.callback(function() {
                        this.getSongs(function(g) {
                            var h = [];
                            a.each(g, function(k, m) {
                                h.push(m.SongID)
                            });
                            GS.player.addSongsToQueueAt(h, GS.player.INDEX_NEXT, false, b)
                        }, function() {
                        }, false)
                    })}},
                {title:a.localize.getString("CONTEXT_PLAY_PLAYLIST_LAST"),customClass:"last jj_menu_item_hasIcon jj_menu_item_play_last",action:{type:"fn",callback:this.callback(function() {
                    this.getSongs(function(g) {
                        var h = [];
                        a.each(g, function(k, m) {
                            h.push(m.SongID)
                        });
                        GS.player.addSongsToQueueAt(h, GS.player.INDEX_LAST, false,
                                b)
                    }, function() {
                    }, false)
                })}},
                {customClass:"separator"},
                {title:a.localize.getString("SHARE_PLAYLIST"),customClass:"last jj_menu_item_hasIcon jj_menu_item_share",type:"sub",src:c},
                {customClass:"separator"},
                {title:a.localize.getString("CONTEXT_REPLACE_ALL_SONGS"),customClass:"last jj_menu_item_hasIcon jj_menu_item_now_playing",action:{type:"fn",callback:this.callback(function() {
                    this.getSongs(function(g) {
                        var h = [],k = GS.player.isPlaying;
                        a.each(g, function(m, n) {
                            h.push(n.SongID)
                        });
                        GS.player.addSongsToQueueAt(h,
                                GS.player.INDEX_REPLACE, k, b)
                    }, function() {
                    }, false)
                })}}
            ]
        },toUrl:function(b) {
            return _.cleanUrl(this.PlaylistName, this.PlaylistID, "playlist", null, b)
        },toUserUrl:function(b) {
            return _.cleanUrl(this.UserName, this.UserID, "user", null, b)
        },toString:function(b) {
            return(b = _.orEqual(b, false)) ? ["Playlist. pid: ",this.PlaylistID,", pname:",this.PlaylistName,", uid:",this.UserID,", uname: ",this.UserName].join("") : _.getString("SELECTION_PLAYLIST_SINGLE", {PlaylistName:_.cleanText(this.PlaylistName),Username:_.cleanText(this.UserName)})
        }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Popular", {cache:{},getType:function(b) {
        var c = this.getOneFromCache(b);
        if (!c) {
            c = this.wrap({type:b});
            this.cache[b] = c
        }
        return c
    }}, {type:null,songsLoaded:false,init:function(b) {
        this._super(b);
        this.songsLoaded = false;
        this.songs = []
    },getSongs:function(b, c, g) {
        g = _.orEqual(g, true);
        if (this.songsLoaded) {
            this.songs = this.wrapSongCollection(this.songs, {Popularity:0,Weight:"",NumPlays:"",isVerified:-1});
            b(this.songs)
        } else {
            g && a.publish("gs.page.loading.grid");
            GS.service.popularGetSongs(this.type,
                    this.callback(["wrapManySongs",b]), c)
        }
    },wrapManySongs:function(b) {
        b.Songs && b.Songs.reverse();
        return this.wrapSongCollection(b, {USE_INDEX:"Popularity",Weight:"",NumPlays:"",isVerified:-1})
    }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.User", {id:"UserID",cache:{},usersLoaded:false,userIDs:[],artPath:"http://beta.grooveshark.com/static/userimages/",defaults:{UserID:0,Username:"",Name:"",FName:"",LName:"",Picture:"",IsPremium:0,SignupDate:null,Location:"",Sex:"",FollowingFlags:0,Flags:0,PathName:false,PathNameEmpty:false,isFavorite:0,artPath:"http://beta.grooveshark.com/static/userimages/",library:null,favorites:{songs:{},albums:{},artists:{},playlists:{},users:{}},fanbase:null,playlists:{},
        profileFeed:{},communityFeed:{}},getUser:function(b, c, g, h) {
        var k = this.getOneFromCache(b);
        h = _.orEqual(h, true);
        if (k)c(k); else {
            h && a.publish("gs.page.loading.page");
            GS.service.getUserByID(b, this.callback(["wrapProxy",c]), g)
        }
    },itemRenderer:function(b) {
        var c = b.isFavorite ? " following" : "",g = b.isFavorite ? "UNFOLLOW" : "FOLLOW",h = a("body").width() <= 1024 || a("body").height() <= 700,k = "" + ('<a class="name ellipsis capitalize" href="' + _.cleanUrl(b.UserID, b.Name, "user") + '">' + b.Name + "</a>"),m = b.City && b.State && b.Country ?
                b.Location : b.Country ? b.Country : "";
        m = ['<span class="location ellipsis"',m.length ? "" : 'style="font-style: italic; color: #9e9d9d"',">",m.length ? m : "No Location Provided","</span>"].join("");
        h = b.getImageURL(h ? "s" : "m");
        h = ['<img src="',h,'"/>'].join("");
        c = b.UserID === GS.user.UserID ? "" : ['<button class="follow btn btn_style5 ',c,'" data-follow-userid="',b.UserID,'" ><span data-translate-text="',g,'">',a.localize.getString(g),"</span></button>"].join("");
        return['<a href="',_.cleanUrl(b.UserID, b.Name, "user"),
            '" class="userImage"><div class="status ',b.getVipPackage(),'"></div>',h,'</a><div class="meta">',k,m,c,"</div>"].join("")
    },wrapProxy:function(b) {
        return this.wrap(b.User || b)
    },FLAG_PLUS:1,FLAG_LASTFM:2,FLAG_FACEBOOK:4,FLAG_FACEBOOKUSER:16,FLAG_GOOGLEUSER:32,FLAG_GOOGLE:64,FLAG_ANYWHERE:128,FLAG_ISARTIST:256,FLAG_MUSIC_BUSINESS:1024}, {validate:function() {
        if (this.UserID > 0)return true;
        return false
    },init:function(b) {
        this._super(b);
        b = _.orEqual(this.City, "");
        b += this.State && b.length ? ", " + this.State : _.orEqual(this.State,
                "");
        b += this.Country && b.length ? ", " + this.Country : _.orEqual(this.Country, "");
        this.Name = _.cleanText(this.FName) + (this.LName && this.LName.length ? " " + _.cleanText(this.LName) : "");
        this.Username = this.UserID > 0 ? this.Username && this.Username.length ? this.Username : this.Name : "New User";
        this.Location = b;
        this.IsPremium = this.IsPremium == 1 ? 1 : 0;
        this.library = GS.Models.Library.wrap({userID:this.UserID});
        this.fanbase = GS.Models.Fanbase.wrap({objectID:this.UserID,objectType:"user"});
        this.profileFeed = GS.Models.Feed.wrap({user:this});
        this.communityFeed = GS.Models.Feed.wrap({user:this});
        this.recentActiveUsersFeed = GS.Models.Feed.wrap({user:this});
        this.searchText = [this.Locale,this.FName,this.LName].join(" ").toLowerCase();
        this.playlists = {};
        this.favorites = {songs:{},albums:{},artists:{},playlists:{},users:{}}
    },autocompleteFavoriteUsers:function() {
        var b = [];
        a.each(this.favorites.users, function(c, g) {
            a.each(g.searchText.trim().split(), function(h, k) {
                b.push([k.trim(),g.UserID])
            })
        });
        return b
    },getFavoritesByType:function(b, c, g) {
        var h = arguments[arguments.length -
                1] === g ? {} : arguments[arguments.length - 1];
        if (_.isEmpty(this.favorites[b.toLowerCase()]))GS.service.getFavorites(this.UserID, b, !this.isAuth, this.callback(["load" + b + "Favorites",c]), g, h); else {
            h = this.favorites[b.toLowerCase()];
            GS.Models[b.substring(0, b.length - 1)].wrapCollectionInObject(h, {TSFavorited:"",TSAdded:""});
            h = this.favorites[b.toLowerCase()];
            c(h)
        }
    },loadAlbumsFavorites:function(b) {
        var c = {};
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].TSAdded = b[g].TSFavorited;
            c[b[g].AlbumID] = b[g]
        }
        this.favorites.albums =
                GS.Models.Album.wrapCollectionInObject(c, {TSFavorited:"",TSAdded:"",isFavorite:this.isAuth ? 1 : 0});
        return this.favorites.albums
    },loadArtistsFavorites:function(b) {
        var c = {};
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].TSAdded = b[g].TSFavorited;
            c[b[g].ArtistID] = b[g]
        }
        this.favorites.artists = GS.Models.Artist.wrapCollectionInObject(c, {TSFavorited:"",TSAdded:"",isFavorite:this.isAuth ? 1 : 0});
        return this.favorites.artists
    },loadPlaylistsFavorites:function(b) {
        var c = {};
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].TSAdded =
                    b[g].TSFavorited;
            c[b[g].PlaylistID] = b[g]
        }
        this.favorites.playlists = GS.Models.Playlist.wrapCollectionInObject(c, {TSFavorited:"",TSAdded:"",isFavorite:this.isAuth ? 1 : 0});
        return this.favorites.playlists
    },loadSongsFavorites:function(b) {
        var c = {};
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].TSAdded = b[g].TSFavorited;
            c[b[g].SongID] = b[g]
        }
        this.favorites.songs = GS.Models.Song.wrapCollectionInObject(c, {TSFavorited:"",TSAdded:""});
        for (g in this.favorites.songs)if (this.favorites.songs.hasOwnProperty(g)) {
            b = this.favorites.songs[g];
            if (this.isAuth) {
                b.isFavorite = 1;
                b.fromLibrary = 1
            }
            this.library.songs[b.SongID] = b.dupe()
        }
        return this.favorites.songs
    },loadUsersFavorites:function(b) {
        var c = {};
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].TSAdded = b[g].TSFavorited;
            b[g].FollowingFlags = parseInt(b[g].FollowingFlags, 10);
            c[b[g].UserID] = b[g]
        }
        this.favorites.users = GS.Models.User.wrapCollectionInObject(c, {TSFavorited:"",TSAdded:"",isFavorite:this.isAuth ? 1 : 0,FollowingFlags:0});
        return this.favorites.users
    },getPlaylists:function(b, c) {
        if (_.isEmpty(this.playlists))GS.service.userGetPlaylists(this.UserID,
                !this.isAuth, this.callback(["cachePlaylists",b]), c); else a.isFunction(b) && b()
    },cachePlaylists:function(b) {
        var c = {};
        b = b.Playlists;
        for (var g in b)if (b.hasOwnProperty(g)) {
            b[g].UserName = this.Name;
            b[g].UserID = this.UserID;
            c[b[g].PlaylistID] = b[g]
        }
        this.playlists = GS.Models.Playlist.wrapCollectionInObject(c);
        this.isAuth && a.publish("gs.auth.playlists.update")
    },getProfileFeed:function(b, c) {
        this.profileFeed.getProfileFeed(this.callback(b), c)
    },getCommunityFeed:function(b, c) {
        var g;
        g = this.isAuth ? this.filterOutFriends(1) :
                this.favorites.users;
        g = _.toArrayID(g);
        g.length ? this.communityFeed.getCommunityFeed(g, this.callback(b), c) : this.communityFeed.getRecentlyActiveUsersFeed(this.callback(b), c)
    },filterFriends:function(b) {
        var c = {};
        for (var g in this.favorites.users)if (this.favorites.users[g].FollowingFlags & b)c[g] = this.favorites.users[g];
        return c
    },filterOutFriends:function(b) {
        var c = {};
        for (var g in this.favorites.users)this.favorites.users[g].FollowingFlags & b || (c[g] = this.favorites.users[g]);
        return c
    },getRecentlyActiveUsersFeed:function(b, c) {
        this.recentActiveUsersFeed.getRecentlyActiveUsersFeed(this.callback(b), c)
    },getVipPackage:function() {
        var b = "";
        if (this.Flags & GS.Models.User.FLAG_ANYWHERE)b = "anywhere"; else if (this.Flags & GS.Models.User.FLAG_PLUS)b = "plus";
        return b
    },toUrl:function(b) {
        return this.PathName ? _.makeUrlFromPathName(this.PathName, b) : _.cleanUrl(this.UserID ? this.Name : "New User", this.UserID, "user", null, b)
    },getPathName:function(b) {
        if (this.PathName || this.PathNameEmpty)a.isFunction(b) && b(this.PathName); else GS.service.getPageNameByIDType(this.UserID,
                "user", this.callback(this._onPathNameSuccess, b), this.callback(this._onPathNameFailed, b))
    },_onPathNameSuccess:function(b, c) {
        if (c.name)this.PathName = c.name; else {
            this.PathName = "";
            this.PathNameEmpty = true
        }
        a.isFunction(b) && b(this.PathName)
    },_onPathNameFailed:function(b) {
        this.PathName = "";
        this.PathNameEmpty = true;
        a.isFunction(b) && b(this.PathName)
    },getImageURL:function(b) {
        var c = gsConfig.assetHost + "/webincludes/images/default/user_100.png";
        b = _.orEqual(b, "m");
        if (this.Picture)c = GS.Models.User.artPath + b + this.Picture;
        else if (b === "l")c = gsConfig.assetHost + "/webincludes/images/default/user_250.png";
        return c
    },getDetailsForFeeds:function() {
        return{userID:this.UserID,userName:this.Name,isPremium:this.IsPremium,location:this.location,imageURL:this.getImageURL()}
    },getTitle:function() {
        return this.Name
    },toString:function(b) {
        return(b = _.orEqual(b, false)) ? ["User. uid: ",this.UserID,", uname:",this.Name,this.FName,this.LName].join("") : _.cleanText(this.Name)
    }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Library", {}, {currentPage:0,userID:null,lastModified:0,songsLoaded:false,init:function(b) {
        this._super(b);
        this.songsLoaded = false
    },getSongs:function(b, c, g) {
        g = _.orEqual(g, true);
        if (this.songsLoaded) {
            this.songs = this.wrapSongCollection(this.songs, {TSAdded:"",TSFavorited:""});
            b(this.songs)
        } else {
            g && this.currentPage === 0 && a.publish("gs.page.loading.grid");
            GS.service.userGetSongsInLibrary(this.userID, this.currentPage, !(GS.user && GS.user.UserID === this.userID), this.callback(["saveLastModified",
                "loadSongs",b]), c)
        }
    },reloadLibrary:function(b, c, g) {
        this.songsLoaded = false;
        this.lastModified = this.currentPage = 0;
        this.songs = {};
        this.getSongs(b, c, g)
    },loadSongs:function(b) {
        return this.wrapSongCollection(b, {TSAdded:"",TSFavorited:"",fromLibrary:GS.user.UserID == this.userID ? 1 : 0})
    },saveLastModified:function(b) {
        this.lastModified = b.TSModified;
        return b
    },refreshLibrary:function(b) {
        b.TSModified > this.lastModified && this.reloadLibrary(null, null, false)
    }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Station", {TAG_STATIONS:{55:"STATION_80s",9:"STATION_90S_ALT_ROCK",13:"STATION_ALTERNATIVE",75:"STATION_AMBIENT",96:"STATION_BLUEGRASS",230:"STATION_BLUES",750:"STATION_CLASSICAL",3529:"STATION_CLASSIC_ROCK",80:"STATION_COUNTRY",2563:"STATION_DUBSTEP",67:"STATION_ELECTRONICA",191:"STATION_EXPERIMENTAL",122:"STATION_FOLK",29:"STATION_HIP_HOP",136:"STATION_INDIE",43:"STATION_JAZZ",528:"STATION_LATIN",17:"STATION_METAL",102:"STATION_OLDIES",56:"STATION_POP",
        111:"STATION_PUNK",3:"STATION_RAP",160:"STATION_REGGAE",4:"STATION_RNB",12:"STATION_ROCK",69:"STATION_TRANCE"},getStationsMenu:function() {
        var b = [];
        a.each(GS.Models.Station.TAG_STATIONS, this.callback(function(c, g) {
            b.push({title:a.localize.getString(g),customClass:"jj_menu_item_hasIcon jj_menu_item_station",action:{type:"fn",callback:this.callback(function() {
                GS.user.addToShortcuts("station", c, true)
            })}})
        }));
        b.sort(function(c, g) {
            var h = c.title.toLowerCase(),k = g.title.toLowerCase();
            return h == k ? 0 : h > k ? 1 :
                    -1
        });
        return b
    },getStationsStartMenu:function() {
        var b = [];
        a.each(GS.Models.Station.TAG_STATIONS, function(c, g) {
            b.push({title:a.localize.getString(g),customClass:"jj_menu_item_hasIcon jj_menu_item_station",action:{type:"fn",callback:function() {
                GS.player.setAutoplay(true, c)
            }}})
        });
        b.sort(function(c, g) {
            var h = c.title.toLowerCase(),k = g.title.toLowerCase();
            return h == k ? 0 : h > k ? 1 : -1
        });
        return b
    }}, {StationID:0,TagID:0,StationTitle:"",Artists:[],init:function(b) {
        this._super(b)
    }})
})(jQuery);
(function(a) {
    a.Model.extend("GS.Models.PlayContext", {}, {type:null,data:null,init:function(b, c) {
        this.type = _.orEqual(b, "unknown");
        this.data = _.orEqual(c, {});
        if (a.isFunction(this.data.getDetailsForFeeds))this.data = this.data.getDetailsForFeeds()
    }})
})(jQuery);
(function(a) {
    a.fn.dataString = function() {
        if (arguments.length === 0)return _.orEqual(this.data("DataString"), null);
        var b = new GS.Models.DataString(arguments[0], arguments[1]);
        b.hookup(this);
        return b
    };
    a.fn.localeDataString = function(b, c, g) {
        b = _.orEqual(b, "");
        c = _.orEqual(c, {});
        g = _.orEqual(g, false);
        var h = a(this).dataString();
        if (!h) {
            h = new GS.Models.DataString;
            h.hookup(this)
        }
        h.string = a.localize.getString(b);
        h.data = c;
        g ? a(this).attr("data-translate-title", b).attr("title", h.render()) : a(this).attr("data-translate-text",
                b).html(h.render());
        return h
    };
    a.Model.extend("GS.Models.DataString", {}, {string:null,data:null,element:null,init:function(b, c) {
        this.string = _.orEqual(b, "");
        this.data = _.orEqual(c, {})
    },setString:function(b) {
        this.string = b;
        this.render()
    },setData:function(b, c) {
        this.data[b] = c;
        this.render()
    },hookup:function(b) {
        this.element = a(b);
        this.element.data("DataString", this)
    },render:function() {
        for (var b = this.string,c = [],g; b;) {
            if (g = /^[^\{]+/.exec(b))c.push(g[0]); else if (g = /^\{(.*?)\}/.exec(b)) {
                var h = g[1];
                this.data[h] ?
                        c.push(this.data[h]) : c.push(g[0])
            } else throw"Error rendering data object";
            b = b.substring(g[0].length)
        }
        b = c.join("");
        if (this.element)this.element.attr("tagName") == "INPUT" ? this.element.val(b) : this.element.html(b);
        return b
    }})
})(jQuery);
(function(a) {
    GS.Models.User.extend("GS.Models.AuthUser", {id:"AuthUserID",cache:{},loggedOutPlaylistCount:0,wrap:function(b) {
        return this._super(b, false)
    },wrapFromService:function(b) {
        return this.wrap(a.extend({}, b, {Email:b.Email || b.email,Sex:b.Sex || b.sex,UserID:b.UserID || b.userID,IsPremium:b.IsPremium || b.isPremium,FName:b.FName || b.fName,LName:b.LName || b.lName,TSDOB:b.TSDOB || b.tsDOB,Privacy:_.orEqualEx(b.Privacy, b.privacy, 0)}))
    }}, {authRealm:1,authToken:"",autoAutoplay:false,badAuthToken:false,favoritesLimit:500,
        librarySizeLimit:5E3,themeID:"",uploadsEnabled:0,UserID:-1,Username:"",Email:"",City:"",Country:"",State:"",TSDOB:"",Privacy:0,Flags:0,Points:0,settings:null,isLoggedIn:false,isAuth:true,artistsPlayed:[],defaultStations:["750","12","136","3","56","67"],defaultFromService:null,searchVersion:"",init:function(b) {
            this._super(b);
            this.defaultFromService = {};
            this.refreshLibraryStatic = this.callback(this.refreshLibrary);
            this.library.songs = {};
            this.playlists = {};
            this.favorites = {songs:{},albums:{},artists:{},playlists:{},
                users:{}};
            this.sidebarLoaded = false;
            this.sidebar = {playlists:[],stations:[],subscribedPlaylists:[]};
            this.settings = GS.Models.UserSettings.wrap({UserID:this.UserID});
            this.lastSeenFeedEvent = (b = store.get("lastSeenFeedEvent" + this.UserID)) ? b : 0;
            this.unseenFeedEvents = this.unseenFeedEventTimeout = 0;
            this._pointsDirty = true;
            this.Points = 0;
            if (this.UserID > 0) {
                this.isLoggedIn = true;
                this.getPlaylists();
                this.getFavorites();
                this.getSidebar();
                this.getLibrary();
                this.getClearvoiceInfo()
            } else {
                this.isDirty = this.isLoggedIn = false;
                this.sidebarLoaded = true;
                this.sidebar.stations = this.defaultStations.concat()
            }
            this.artistsPlayed = store.get("artistsPlayed" + this.UserID) || [];
            a.subscribe("gs.player.nowplaying", this.callback(this.onSongPlay));
            setTimeout(function() {
                a.publish("gs.auth.stations.update")
            }, 10);
            this.checkVipExpiring();
            this.searchVersion = ""
        },uploadComplete:function() {
            var b = this.toUrl("music").substring(1);
            this.library.reloadLibrary(function() {
                location.hash = b
            })
        },onSongPlay:function(b) {
            if (this === GS.user)if (b && b.ArtistID) {
                var c =
                        this.artistsPlayed.indexOf(b.ArtistID);
                c != -1 && this.artistsPlayed.splice(c, 1);
                this.artistsPlayed.unshift(b.ArtistID);
                this.artistsPlayed.splice(999, 1)
            }
        },storeData:function() {
            if (_.isEmpty(this.library.songs))c = null; else {
                var b = new Date,c = {currentPage:this.library.currentPage,songsLoaded:this.library.songsLoaded,userID:this.library.userID,lastModified:this.library.lastModified,songs:{}};
                for (var g in this.library.songs)if (this.library.songs.hasOwnProperty(g))c.songs[g] = GS.Models.Song.archive(this.library.songs[g])
            }
            try {
                this.settings.changeLocalSettings({});
                store.set("artistsPlayed" + this.UserID, this.artistsPlayed);
                store.set("lastSeenFeedEvent" + this.UserID, this.lastSeenFeedEvent);
                store.set("library" + this.UserID, c);
                console.log("stored data in: " + (new Date - b) + " milliseconds")
            } catch(h) {
                console.error(h);
                a.publish("gs.auth.store.failure")
            }
        },clearData:function() {
            store.remove("library" + this.UserID);
            store.remove("lastSeenFeedEvent" + this.UserID)
        },createPlaylist:function(b, c, g, h, k, m) {
            m = _.orEqual(m, true);
            c = _.orEqual(c, []);
            if (this.isLoggedIn)GS.service.createPlaylist(b,
                    c, g, this.callback(["createPlaylistSuccess"], {callback:h,name:b,songIDs:c,description:g,notify:m}), k); else {
                GS.Models.AuthUser.loggedOutPlaylistCount++;
                g = GS.Models.Playlist.wrap({PlaylistID:-GS.Models.AuthUser.loggedOutPlaylistCount,PlaylistName:b,UserName:this.Name,UserID:this.UserID,songsLoaded:true,TSAdded:(new Date).format("Y-m-d G:i:s"),Description:g});
                g.addSongs(c, 0, true);
                this.playlists[g.PlaylistID] = g;
                this.isDirty = true;
                a.publish("gs.auth.playlists.update");
                m && a.publish("gs.notification.playlist.create",
                        g);
                h(g)
            }
            GS.guts.logEvent("playlistCreated", {playlistName:b});
            GS.guts.gaTrackEvent("user", "newPlaylist")
        },createPlaylistSuccess:function(b, c) {
            var g = GS.Models.Playlist.wrap({PlaylistID:c,PlaylistName:b.name,Description:b.description,UserID:this.UserID,UserName:this.Name,TSAdded:(new Date).format("Y-m-d G:i:s"),NumSongs:b.songIDs.length});
            this.playlists[g.PlaylistID] = g;
            a.publish("gs.auth.playlists.update");
            b.notify && a.publish("gs.notification.playlist.create", g);
            b.callback(g)
        },deletePlaylist:function(b, c) {
            var g = GS.Models.Playlist.getOneFromCache(b);
            if (g && g.UserID === this.UserID) {
                c = _.orEqual(c, true);
                if (this.isLoggedIn)GS.service.deletePlaylist(g.PlaylistID, g.PlaylistName, this.callback(function() {
                    g.isDeleted = true;
                    g.removeShortcut(false);
                    delete this.playlists[g.PlaylistID];
                    a.publish("gs.playlist.view.update", g);
                    a.publish("gs.auth.playlists.update");
                    a.publish("gs.user.playlist.remove");
                    if (c) {
                        var h = (new GS.Models.DataString(a.localize.getString("POPUP_DELETE_PLAYLIST_MSG"), {playlist:g.PlaylistName})).render();
                        a.publish("gs.notification", {type:"notice",message:h})
                    }
                }), this.callback(function() {
                    g.isDeleted = false;
                    if (c) {
                        var h = (new GS.Models.DataString(a.localize.getString("POPUP_FAIL_DELETE_PLAYLIST_MSG"), {playlist:g.PlaylistName})).render();
                        a.publish("gs.notification", {type:"error",message:h})
                    }
                })); else {
                    g.isDeleted = true;
                    g.removeShortcut(false);
                    delete this.playlists[g.PlaylistID];
                    a.publish("gs.playlist.view.update", g);
                    a.publish("gs.auth.playlists.update");
                    a.publish("gs.user.playlist.remove");
                    c && a.publish("gs.notification",
                            {type:"notice",message:a.localize.getString("NOTIFICATION_PLAYLIST_DELETED")})
                }
            }
            GS.guts.gaTrackEvent("user", "deletePlaylist")
        },restorePlaylist:function(b, c) {
            var g = GS.Models.Playlist.getOneFromCache(b);
            if (g && g.UserID === this.UserID) {
                c = _.orEqual(c, true);
                if (this.isLoggedIn)GS.service.playlistUndelete(g.PlaylistID, this.callback(function() {
                    g.isDeleted = false;
                    this.playlists[g.PlaylistID] = g;
                    a.publish("gs.playlist.view.update", g);
                    c && a.publish("gs.notification", {type:"notice",message:a.localize.getString("NOTIFICATION_PLAYLIST_RESTORED")})
                }),
                        function() {
                            c && a.publish("gs.notification", {type:"error",message:a.localize.getString("NOTIFICATION_PLAYLIST_RESTORE_FAIL")})
                        }); else {
                    g.isDeleted = false;
                    this.playlists[g.PlaylistID] = g;
                    a.publish("gs.playlist.view.update", g);
                    c && a.publish("gs.notification", {type:"notice",message:a.localize.getString("NOTIFICATION_PLAYLIST_RESTORED")})
                }
            }
            GS.guts.gaTrackEvent("user", "restorePlaylist")
        },getSidebar:function() {
            GS.service.getUserSidebar(this.callback("loadSidebar"))
        },loadSidebar:function(b) {
            this.sidebarLoaded =
                    true;
            this.sidebar = b;
            a.publish("gs.auth.sidebar.loaded");
            if (this.sidebar.stations.length === 0) {
                var c = this;
                _.forEach(this.defaultStations, function(g) {
                    c.addToShortcuts("station", g, false)
                })
            }
        },getFavorites:function() {
            var b = this;
            _.forEach(["Albums","Artists","Playlists","Songs","Users"], function(c) {
                GS.service.getFavorites(b.UserID, c, false, b.callback("load" + c + "Favorites"))
            })
        },loadAlbumsFavorites:function(b) {
            this._super(b);
            a.publish("gs.auth.favorites.albums.update")
        },loadArtistsFavorites:function(b) {
            this._super(b);
            a.publish("gs.auth.favorites.artists.update")
        },loadPlaylistsFavorites:function(b) {
            this._super(b);
            a.publish("gs.auth.favorites.playlists.update")
        },loadSongsFavorites:function(b) {
            this._super(b);
            a.publish("gs.auth.favorites.songs.update")
        },loadUsersFavorites:function(b) {
            this._super(b);
            a.publish("gs.auth.favorites.users.update");
            this.lastSeenFeedEvent == 0 && this.getUnseenFeeds()
        },getLibrary:function() {
            var b = store.get("library" + this.UserID);
            if (b) {
                var c = b.songs;
                delete b.songs;
                this.library = GS.Models.Library.wrap(b);
                for (var g in c)if (c.hasOwnProperty(g)) {
                    c[g] = GS.Models.Song.unarchive(c[g]);
                    c[g].fromLibrary = 1
                }
                this.library.songs = GS.Models.Song.wrapCollectionInObject(c, {TSAdded:"",TSFavorited:""});
                GS.service.userGetLibraryTSModified(this.UserID, this.callback("refreshLibrary"))
            } else this.library.getSongs(this.callback("loadLibrary"), false, false)
        },refreshLibrary:function(b) {
            if (b.TSModified > this.library.lastModified) {
                this.library.currentPage = 0;
                this.library.songsLoaded = false;
                this.library.getSongs(this.callback("loadLibrary"),
                        false, false)
            } else a.publish("gs.auth.library.update")
        },loadLibrary:function(b) {
            for (var c = 0; c < b.length; c++) {
                b[c].fromLibrary = 1;
                this.library.songs[b[c].SongID] = b[c]
            }
            a.publish("gs.auth.library.update", [b]);
            this.library.songsLoaded || this.library.getSongs(this.callback("loadLibrary"), false, false)
        },addToSongFavorites:function(b, c) {
            c = _.orEqual(c, true);
            if (!this.favorites.songs[b]) {
                var g = GS.Models.Song.getOneFromCache(b);
                if (!g)throw"AUTH.ADDTOSONGFAVES. SONGID NOT IN CACHE: " + b;
                g = g.dupe();
                g.isFavorite = 1;
                g.fromLibrary =
                        1;
                if (!_.defined(g.TSFavorited) || g.TSFavorited == "")g.TSFavorited = (new Date).format("Y-m-d G:i:s");
                if (!_.defined(g.TSAdded) || g.TSAdded == "")g.TSAdded = g.TSFavorited;
                if (this.library.songs[b])this.library.songs[b] = g; else {
                    this.library.songs[b] = g;
                    a.publish("gs.auth.library.add", g)
                }
                this.favorites.songs[b] = g.dupe();
                GS.guts.logEvent("objectFavorited", {type:"song",id:b});
                a.publish("gs.auth.song.update", g);
                a.publish("gs.auth.favorite.song", g);
                a.publish("gs.auth.favorites.songs.add", g);
                c && a.publish("gs.notification.favorite.song",
                        g);
                if (this.isLoggedIn)GS.service.favorite("Song", g.SongID, g.getDetailsForFeeds(), null, this.callback(this._favoriteFail, "Song", g)); else this.isDirty = true;
                GS.guts.gaTrackEvent("user", "favoriteSong")
            }
        },addToPlaylistFavorites:function(b, c) {
            c = _.orEqual(c, true);
            if (!this.favorites.playlists[b]) {
                var g = GS.Models.Playlist.getOneFromCache(b);
                if (!g)throw"AUTH.ADDTOPLAYLISTFAVES. PLAYLISTID NOT IN CACHE: " + b;
                g.isFavorite = 1;
                if (!_.defined(g.TSFavorited))g.TSFavorited = (new Date).format("Y-m-d G:i:s");
                this.favorites.playlists[b] =
                        g;
                GS.guts.logEvent("objectFavorited", {type:"playlist",id:b});
                g.addShortcut(false);
                a.publish("gs.auth.favorites.playlists.update");
                a.publish("gs.auth.playlist.update", g);
                a.publish("gs.auth.favorite.playlist", g);
                a.publish("gs.playlist.view.update", this);
                c && a.publish("gs.notification.favorite.playlist", g);
                if (this.isLoggedIn)GS.service.favorite("Playlist", g.PlaylistID, g.getDetailsForFeeds(), null, this.callback(this._favoriteFail, "Playlist", g)); else this.isDirty = true;
                GS.guts.gaTrackEvent("user", "favoritePlaylist")
            }
        },
        removeFromPlaylistFavorites:function(b, c) {
            c = _.orEqual(c, true);
            var g = GS.Models.Playlist.getOneFromCache(b);
            if (g) {
                g.removeShortcut(false);
                g.isFavorite = 0;
                GS.Models.Playlist.cache[b] = g;
                delete this.favorites.playlists[b];
                GS.guts.logEvent("objectUnfavorited", {type:"playlist",id:b});
                a.publish("gs.auth.favorites.playlists.update");
                a.publish("gs.auth.playlist.update", g);
                a.publish("gs.playlist.view.update", this);
                this.isLoggedIn && GS.service.unfavorite("Playlist", b);
                c && a.publish("gs.notification", {type:"notify",
                    message:a.localize.getString("NOTIFICATION_PLAYLIST_UNSUBSCRIBED")});
                GS.guts.gaTrackEvent("user", "unfavoritePlaylist")
            }
        },removeFromSongFavorites:function(b) {
            var c = this.favorites.songs[b];
            if (c) {
                c.isFavorite = 0;
                delete this.favorites.songs[b];
                GS.guts.logEvent("objectUnfavorited", {type:"song",id:b});
                this.library.songs[b] = c.dupe();
                a.publish("gs.auth.song.update", c);
                a.publish("gs.auth.favorites.songs.remove", c);
                this.isLoggedIn && GS.service.unfavorite("Song", c.SongID);
                GS.guts.gaTrackEvent("user", "unfavoriteSong")
            }
        },
        addToUserFavorites:function(b, c) {
            c = _.orEqual(c, true);
            if (!(!b || this.favorites.users[b])) {
                var g = GS.Models.User.getOneFromCache(b);
                if (!g || this.UserID === g.UserID)this._favoriteFail("User", null); else {
                    g.isFavorite = 1;
                    this.favorites.users[b] = g;
                    GS.guts.logEvent("objectFavorited", {type:"user",id:b});
                    a.publish("gs.auth.favorites.users.update");
                    a.publish("gs.auth.user.update", g);
                    a.publish("gs.auth.favorite.user", g);
                    c && a.publish("gs.notification.favorite.user", g);
                    if (this.isLoggedIn)GS.service.favorite("User",
                            g.UserID, g.getDetailsForFeeds(), null, this.callback(this._favoriteFail, "User", g)); else this.isDirty = true;
                    this.communityFeed.isDirty = true;
                    GS.guts.gaTrackEvent("user", "followUser")
                }
            }
        },removeFromUserFavorites:function(b) {
            var c = GS.Models.User.getOneFromCache(b);
            if (!(!c || this.UserID === c.UserID)) {
                c.isFavorite = 0;
                GS.Models.User.cache[b] = c;
                delete this.favorites.users[b];
                GS.guts.logEvent("objectUnfavorited", {type:"user",id:b});
                a.publish("gs.auth.favorites.users.update");
                a.publish("gs.auth.user.update", c);
                this.communityFeed.isDirty =
                        true;
                this.isLoggedIn && GS.service.unfavorite("User", c.UserID);
                GS.guts.gaTrackEvent("user", "unfollowUser")
            }
        },changeFollowFlags:function(b) {
            this.isLoggedIn ? GS.service.changeFollowFlags(b, this.callback("changeFollowFlagsSuccess", b), this.callback("changeFollowFlagsFail")) : this.changeFollowFlagsFail()
        },changeFollowFlagsSuccess:function(b, c) {
            if (c.success) {
                for (var g in b)if (b.hasOwnProperty(g))if (this.favorites.users[b[g].userID])this.favorites.users[b[g].userID].FollowingFlags = b[g].flags;
                this.communityFeed.isDirty =
                        true;
                a.publish("gs.auth.favorites.users.update")
            } else this.changeFollowFlagsFail()
        },changeFollowFlagsFail:function() {
            a.publish("gs.notification", {message:a.localize.getString("SETTINGS_USER_HIDE_FAIL")})
        },addToLibrary:function(b, c) {
            c = _.orEqual(c, true);
            var g = [];
            b = a.makeArray(b);
            for (var h = 0; h < b.length; h++) {
                var k = b[h];
                if (!this.library.songs[k]) {
                    var m = GS.Models.Song.getOneFromCache(k);
                    if (m) {
                        m = m.dupe();
                        m.fromLibrary = 1;
                        if (this.favorites.songs[k])m.isFavorite = 1;
                        if (!_.defined(m.TSAdded) || m.TSAdded == "")m.TSAdded =
                                (new Date).format("Y-m-d G:i:s");
                        this.library.songs[k] = m;
                        GS.guts.logEvent("songAddedToLibrary", {id:k});
                        a.publish("gs.auth.library.add", m);
                        a.publish("gs.auth.song.update", m);
                        g.push(m.getDetailsForFeeds())
                    }
                }
            }
            if (!_.isEmpty(g)) {
                if (this.isLoggedIn)GS.service.userAddSongsToLibrary(g, this.callback("addToLibrarySuccess", c, g), this.callback("addtoLibraryFailed")); else {
                    this.isDirty = true;
                    this.addToLibrarySuccess(c, g)
                }
                GS.guts.gaTrackEvent("user", "addLibrarySong")
            }
        },addToLibrarySuccess:function(b, c, g) {
            b && a.publish("gs.auth.library.songsAdded",
                    {songs:c});
            if (g) {
                tsAdded = parseInt(g.Timestamps.newTSModified, 10);
                parseInt(g.Timestamps.oldTSModified, 10) > this.library.lastModified && this.library.getSongs(this.callback("loadLibrary"), false, false)
            } else tsAdded = _.unixTime();
            this.library.lastModified = tsAdded;
            b = (new Date(tsAdded * 1E3)).format("Y-m-d G:i:s");
            for (g = 0; g < c.length; g++)this.library.songs[c[g].songID].TSAdded = b
        },_favoriteFail:function(b, c) {
            var g = "NOTIFICATION_LIBRARY_ADD_FAIL",h = {};
            if (c)switch (b) {
                case "Song":
                    g += "_SONG";
                    h.name = c.SongName;
                    break;
                case "Playlist":
                    g += "_PLAYLIST";
                    h.name = c.PlaylistName;
                    break;
                case "User":
                    g += "_USER";
                    h.name = c.Name;
                    break
            }
            a.publish("gs.notification", {type:"error",message:(new GS.Models.DataString(a.localize.getString(g), h)).render()})
        },addToLibraryFailed:function() {
            var b = {numSongs:songIDsToAdd.length};
            a.publish("gs.notification", {type:"error",message:(new GS.Models.DataString(a.localize.getString(songIDsToAdd.length > 1 ? "NOTIFICATION_LIBRARY_ADD_SONGS_FAIL" : "NOTIFICATION_LIBRARY_ADD_SONG_FAIL"), b)).render()})
        },removeFromLibrary:function(b) {
            var c =
                    this.library.songs[b];
            if (c) {
                delete this.library.songs[b];
                GS.guts.logEvent("songRemovedFromLibrary", {id:b});
                delete this.favorites.songs[b];
                c.fromLibrary = 0;
                c.isFavorite = 0;
                GS.Models.Song.cache[c.SongID] = c;
                a.publish("gs.auth.library.remove", c);
                a.publish("gs.auth.song.update", c);
                if (this.isLoggedIn) {
                    GS.service.userRemoveSongFromLibrary(this.UserID, c.SongID, c.AlbumID, c.ArtistID, this.callback("removeFromLibrarySuccess", c), this.callback("removeFromLibraryFailed", c));
                    GS.service.unfavorite("Song", c.SongID)
                } else a.publish("gs.notification",
                        {message:_.printf("NOTIFICATION_LIBRARY_REMOVE_SONG", {song:c.SongName})});
                GS.guts.gaTrackEvent("user", "removeLibrarySong");
                return c
            } else console.warn("removing song not in library!", b)
        },removeFromLibrarySuccess:function(b, c) {
            if (parseInt(c.Timestamps.oldTSModified, 10) > this.library.lastModified)this.library.getSongs(this.callback("loadLibrary"), false, false); else this.library.lastModified = parseInt(c.Timestamps.newTSModified, 10);
            a.publish("gs.notification", {message:_.printf("NOTIFICATION_LIBRARY_REMOVE_SONG",
                    {song:b.SongName})})
        },removeFromLibraryFailed:function() {
            a.publish("gs.notification", {type:"error",message:a.localize.getString("NOTIFICATION_LIBRARY_REMOVE_FAIL")})
        },getUnseenFeeds:function() {
            clearTimeout(this.unseenFeedEventTimeout);
            this.getCommunityFeed(this.callback("countUnseenFeeds"), this.callback("countUnseenFeeds"))
        },countUnseenFeeds:function() {
            this.unseenFeedEvents = 0;
            for (var b = this.communityFeed.events.length,c = 0; c < b; c++)if (this.communityFeed.events[c].time > this.lastSeenFeedEvent)this.unseenFeedEvents++;
            else break;
            a.publish("gs.auth.user.feeds.update");
            this.unseenFeedEventTimeout = setTimeout("GS.user.getUseenFeeds", 72E5)
        },addToShortcuts:function(b, c, g) {
            g = _.orEqual(g, true);
            switch (b) {
                case "playlist":
                    b = GS.Models.Playlist.getOneFromCache(c);
                    if (!b || b.isShortcut())return;
                    var h = b.isSubscribed();
                    b = h ? "subscribedPlaylists" : "playlists";
                    if (h) {
                        this.sidebar.subscribedPlaylists.unshift(c.toString());
                        a.publish("gs.auth.favorites.playlists.update")
                    } else {
                        this.sidebar.playlists.unshift(c.toString());
                        a.publish("gs.auth.playlists.update")
                    }
                    break;
                case "station":
                    b = "stations";
                    if (this.sidebar.stations.indexOf(c.toString()) !== -1)return;
                    this.sidebar.stations.unshift(c.toString());
                    a.publish("gs.auth.stations.update");
                    break;
                default:
                    return
            }
            if (this.isLoggedIn)GS.service.addShortcutToUserSidebar(b, c, this.callback(this._addShortcutSuccess, b, c, g), this.callback(this._addShortcutFailed, b, c, g)); else {
                this.isDirty = true;
                this._addShortcutSuccess(b, c, g, {})
            }
            GS.guts.gaTrackEvent("user", "addShortcut")
        },_addShortcutSuccess:function(b, c, g) {
            var h,k = {};
            switch (b) {
                case "playlists":
                case "subscribedPlaylists":
                    if (b =
                            GS.Models.Playlist.getOneFromCache(c)) {
                        h = "NOTIFICATION_PLAYLIST_SHORTCUT_ADD_SUCCESS";
                        k.playlist = b.PlaylistName;
                        a.publish("gs.playlist.view.update", b)
                    }
                    break;
                case "stations":
                    h = "NOTIFICATION_STATION_SHORTCUT_ADD_SUCCESS";
                    k.station = a.localize.getString(GS.Models.Station.TAG_STATIONS[c]);
                    break
            }
            if (g && h) {
                g = new GS.Models.DataString(a.localize.getString(h), k);
                a.publish("gs.notification", {type:"notice",message:g.render()})
            }
        },_addShortcutFailed:function(b, c, g) {
            var h,k = {};
            switch (b) {
                case "playlists":
                case "subscribedPlaylists":
                    var m =
                            GS.Models.Playlist.getOneFromCache(c);
                    if (m) {
                        h = "NOTIFICATION_PLAYLIST_SHORTCUT_ADD_FAILED";
                        k.playlist = m.PlaylistName
                    }
                    if (b == "playlists") {
                        b = this.sidebar.playlists.indexOf(c.toString());
                        if (b != -1) {
                            this.sidebar.playlists.splice(b, 1);
                            a.publish("gs.auth.playlists.update")
                        }
                    } else {
                        b = this.sidebar.subscribedPlaylists.indexOf(obj.PlaylistID.toString());
                        if (b != -1) {
                            this.sidebar.subscribedPlaylists.splice(b, 1);
                            a.publish("gs.auth.favorites.playlists.update")
                        }
                    }
                    break;
                case "stations":
                    h = "NOTIFICATION_STATION_SHORTCUT_ADD_FAILED";
                    k.station = a.localize.getString(GS.Models.Station.TAG_STATIONS[c]);
                    b = this.sidebar.stations.indexOf(c.toString());
                    if (b != -1) {
                        this.sidebar.stations.splice(b, 1);
                        a.publish("gs.auth.stations.update")
                    }
                    break
            }
            if (g && h) {
                g = new GS.Models.DataString(a.localize.getString(h), k);
                a.publish("gs.notification", {type:"error",message:g.render()})
            }
        },removeFromShortcuts:function(b, c, g) {
            g = _.orEqual(g, true);
            var h;
            switch (b) {
                case "playlist":
                    b = GS.Models.Playlist.getOneFromCache(c);
                    if (!b || !b.isShortcut())return;
                    b = (h = b.isSubscribed()) ?
                            "subscribedPlaylists" : "playlists";
                    if (h) {
                        h = this.sidebar.subscribedPlaylists.indexOf(c.toString());
                        if (h != -1) {
                            this.sidebar.subscribedPlaylists.splice(h, 1);
                            a.publish("gs.auth.favorites.playlists.update")
                        }
                    } else {
                        h = this.sidebar.playlists.indexOf(c.toString());
                        if (h != -1) {
                            this.sidebar.playlists.splice(h, 1);
                            a.publish("gs.auth.playlists.update")
                        }
                    }
                    break;
                case "station":
                    b = "stations";
                    h = this.sidebar.stations.indexOf(c.toString());
                    if (h != -1) {
                        this.sidebar.stations.splice(h, 1);
                        a.publish("gs.auth.stations.update")
                    } else return;
                    break;
                default:
                    return
            }
            if (this.isLoggedIn)GS.service.removeShortcutFromUserSidebar(b, c, this.callback(this._removeShortcutSuccess, b, c, g), this.callback(this._removeShortcutFailed, b, c, h, g)); else {
                this.isDirty = true;
                this._removeShortcutSuccess(b, c, g, {})
            }
            GS.guts.gaTrackEvent("user", "removeShortcut")
        },_removeShortcutSuccess:function(b, c, g) {
            var h,k = {};
            switch (b) {
                case "playlists":
                case "subscribedPlaylists":
                    if (b = GS.Models.Playlist.getOneFromCache(c)) {
                        h = "NOTIFICATION_PLAYLIST_SHORTCUT_REMOVE_SUCCESS";
                        k.playlist =
                                b.PlaylistName;
                        a.publish("gs.playlist.view.update", b)
                    }
                    break;
                case "stations":
                    h = "NOTIFICATION_STATION_SHORTCUT_REMOVE_SUCCESS";
                    k.station = a.localize.getString(GS.Models.Station.TAG_STATIONS[c]);
                    break
            }
            if (g && h) {
                g = new GS.Models.DataString(a.localize.getString(h), k);
                a.publish("gs.notification", {type:"notice",message:g.render()})
            }
        },_removeShortcutFailed:function(b, c, g, h) {
            var k,m = {};
            if (g < 0)g = 0;
            switch (b) {
                case "playlists":
                case "subscribedPlaylists":
                    var n = GS.Models.Playlist.getOneFromCache(c);
                    if (n) {
                        k = "NOTIFICATION_PLAYLIST_SHORTCUT_REMOVE_FAILED";
                        m.playlist = n.PlaylistName
                    }
                    if (b == "playlists") {
                        if (g != -1) {
                            this.sidebar.playlists.splice(g, 0, c.toString());
                            a.publish("gs.auth.playlists.update")
                        }
                    } else if (g != -1) {
                        this.sidebar.subscribedPlaylists.splice(g, 0, c.toString());
                        a.publish("gs.auth.favorites.playlists.update")
                    }
                    break;
                case "stations":
                    k = "NOTIFICATION_STATION_SHORTCUT_REMOVE_FAILED";
                    m.station = a.localize.getString(GS.Models.Station.TAG_STATIONS[c]);
                    if (g != -1) {
                        this.sidebar.stations.splice(g, 0, c.toString());
                        a.publish("gs.auth.stations.update")
                    }
                    break
            }
            if (h &&
                    k) {
                b = new GS.Models.DataString(a.localize.getString(k), m);
                a.publish("gs.notification", {type:"error",message:b.render()})
            }
        },changePassword:function(b, c, g, h) {
            this.isLoggedIn ? GS.service.changePassword(b, c, this.callback(this._passwordSuccess, g, h), this.callback(this._passwordFailed, h)) : this._passwordFailed(h);
            GS.guts.gaTrackEvent("user", "changePassword")
        },_passwordSuccess:function(b, c, g) {
            if (g && g.statusCode === 1)a.isFunction(b) && b(g); else this._passwordFailed(c, g)
        },_passwordFailed:function(b, c) {
            a.isFunction(b) &&
            b(c)
        },updateAccountType:function(b) {
            b = b.toLowerCase();
            switch (b) {
                case "plus":
                    this.IsPremium = 1;
                    this.Flags |= 1;
                    break;
                case "anywhere":
                    this.IsPremium = 1;
                    this.Flags |= 128;
                    break;
                default:
                    this.IsPremium = 0;
                    this.Flags &= -2;
                    this.Flags &= -129;
                    break
            }
            a.publish("gs.auth.update");
            this.checkVipExpiring();
            GS.guts.gaTrackEvent("user", "updateAccount", b)
        },checkVipExpiring:function() {
            this.IsPremium && GS.service.getSubscriptionDetails(this.callback("checkVipExpiringCallback"), this.callback("checkVipExpiringCallback"))
        },checkVipExpiringCallback:function(b) {
            var c,
                    g,h = new Date;
            c = false;
            if (!(b === false || b.fault || b.code)) {
                b.bVip = b.bVip ? parseInt(b.bVip, 10) : false;
                b.bActive = b.bActive ? parseInt(b.bActive, 10) : false;
                if (!b.bRecurring) {
                    g = b.period === "MONTH" ? true : false;
                    if (b.dateEnd) {
                        c = b.dateEnd.split("-");
                        c = g ? new Date(c[0], parseInt(c[1], 10) - 1, c[2]) : new Date(parseInt(c[0], 10) + 1, c[1], c[2])
                    } else if (b.dateStart) {
                        c = b.dateStart.split("-");
                        c = g ? new Date(c[0], parseInt(c[1], 10), c[2]) : new Date(parseInt(c[0], 10) + 1, c[1], c[2])
                    }
                    if (c) {
                        g = _.orEqual(store.get("gs.vipExpire.hasSeen" + this.UserID),
                                0);
                        g = h.getTime() - g;
                        h = c.getTime() - h.getTime();
                        c = Math.max(0, Math.ceil(h / 864E5));
                        c += c == 1 ? " day" : " days";
                        c = h <= 0 ? (new GS.Models.DataString(a.localize.getString("POPUP_VIP_EXPIRES_NO_DAYS"), {vipPackage:b.subscriptionType})).render() : (new GS.Models.DataString(a.localize.getString("POPUP_VIP_EXPIRES_DAYS_LEFT"), {daysLeft:c,vipPackage:b.subscriptionType})).render();
                        b.daysLeft = c;
                        if (g >= 1728E5)if (h < 864E5) {
                            b.timeframe = "oneDay";
                            GS.lightbox.open("vipExpires", b)
                        } else if (h < 1728E5) {
                            b.timeframe = "twoDays";
                            GS.lightbox.open("vipExpires",
                                    b)
                        } else if (h < 12096E5) {
                            b.timeframe = "twoWeeks";
                            GS.lightbox.open("vipExpires", b)
                        } else if (h <= 0 && Math.abs(h) <= 6048E5) {
                            b.timeframe = "expired";
                            GS.lightbox.open("vipExpires", b)
                        }
                        setTimeout(this.callback("checkVipExpiring"), 1728E5)
                    }
                }
            }
        },getAutoNewPlaylistName:function() {
            var b,c,g = [],h = this.Name && this.Name.length ? this.Name + "'s Playlist " : "Playlist ";
            _.forEach(this.playlists, function(k) {
                b = k.PlaylistName.indexOf(h);
                if (b != -1)(c = parseInt(k.PlaylistName.substring(b + h.length), 10)) && g.push(c)
            });
            if (g.length) {
                g.sort(_.numSortA);
                c = g[g.length - 1] + 1
            } else c = 1;
            return h + c
        },isPlaylistNameAvailable:function(b) {
            var c;
            for (c in this.playlists)if (this.playlists.hasOwnProperty(c))if (b === this.playlists[c].PlaylistName)return false;
            return true
        },getClearvoiceInfo:function() {
            if (this.isLoggedIn)this.clearvoice ? this.initClearvoiceNotificationTracking(this.clearvoice) : GS.Models.Clearvoice.getMember(this.callback("initClearvoiceNotificationTracking")); else this.initClearvoiceNotificationTracking(false)
        },initClearvoiceNotificationTracking:function(b) {
            this.clearvoice =
                    b;
            a.publish("gs.auth.update.surveys");
            if (this.clearvoice === false || _.notDefined(this.clearvoice)) {
                console.log("clearvoiceNotifTracking bad member", this.clearvoice);
                return false
            }
            !this.IsPremium && !location.hash.substring(2).match(/^signup/i) && setTimeout(this.callback(function() {
                this.clearvoiceNotificationTracking()
            }), 5E3)
        },clearvoiceNotificationTracking:function() {
            var b,c = function() {
                clearTimeout(b);
                if (GS.user.isLoggedIn && GS.user.clearvoice) {
                    var g = store.get("gs.surveys.hasSeenInvitation" + GS.user.UserID),
                            h = GS.user.clearvoice;
                    if (!h.MemberGuid && (!g || _.toArrayID(h.answers).length === 0))b = setTimeout(h.callback(h.showInvitationNotification), 5E3); else if (h.profileProgress < h.profileProgressTotal && h.MemberGuid)b = setTimeout(h.callback(h.askSurveyQuestionNotification), 5E3); else if (h.AvailableSurveys && h.AvailableSurveys.length)b = setTimeout(h.callback(h.showSurveysAvailableNotification), 5E3)
                }
            };
            a("body").bind("mousemove", this.callback(c));
            a("body").bind("keydown", this.callback(c));
            this.callback(c)()
        },getPoints:function(b, c) {
            if (this._pointsDirty)if (this._pointsPending)this._pointsPending.then(b, c); else {
                this._pointsPending = a.Deferred();
                this._pointsPending.then(b, c);
                GS.service.userGetPoints(this.callback("_pointsSuccess"), this.callback("_pointsFail"))
            } else b(this.Points)
        },_pointsSuccess:function(b) {
            var c = parseInt(b, 10);
            if (isNaN(c)) {
                this._pointsPending.reject(b);
                this._pointsPending = false
            } else {
                var g = this.Points;
                this._pointsDirty = false;
                this.Points = c;
                this._pointsPending.resolve(c);
                this._pointsPending = false;
                g !== c && a.publish("gs.auth.pointsUpdated");
                return b
            }
        },_pointsFail:function(b) {
            this._pointsPending.reject(b);
            this._pointsPending = false;
            return b
        },invalidatePoints:function() {
            this._pointsDirty = true;
            a.publish("gs.auth.pointsUpdated")
        },addPoints:function(b, c) {
            c = _.orEqual(c, false);
            b = parseInt(b, 10);
            if (!isNaN(b)) {
                this._pointsDirty = true;
                this.Points += b;
                a.publish("gs.auth.pointsUpdated");
                c || GS.notice.displaySurveyPoints(b)
            }
        }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.Fanbase", {}, {currentPage:0,objectID:null,objectType:"",userIDs:[],fansLoaded:false,init:function(b) {
        this._super(b);
        this.userIDs = _.orEqual(b.userIDs, []);
        this.fansLoaded = _.orEqual(b.fansLoaded, false)
    },getFans:function(b, c, g) {
        g = _.orEqual(g, true);
        if (this.fansLoaded) {
            c = GS.Models.User.getManyFromCache(this.userIDs);
            b(c)
        } else {
            g && this.currentPage === 0 && a.publish("gs.page.loading.grid");
            this.objectType === "playlist" ? GS.service[this.objectType + "GetFans"](this.objectID,
                    this.callback(["cacheAndReturnUsers",b]), c) : GS.service[this.objectType + "GetFans"](this.objectID, this.currentPage, this.callback(["cacheAndReturnUsers",b]), c)
        }
    },cacheAndReturnUsers:function(b) {
        for (var c = GS.Models.User.wrapCollection(b.Users || b.Return.fans || b.Return),g = 0; g < c.length; g++)this.userIDs.push(c[g].UserID);
        if (_.defined(b.hasMore) && b.hasMore)this.currentPage++; else this.fansLoaded = true;
        return c
    }})
})(jQuery);
(function() {
    GS.Models.Base.extend("GS.Models.Feed", {}, {user:null,currentPage:0,isLoaded:false,hasMore:false,today:null,offset:0,events:[],fromFavorites:false,fromRecent:false,lastRequest:0,isDirty:false,RATE_LIMIT:6E5,getProfileFeed:function(a, b) {
        var c = new Date;
        if (!this.isLoaded && !this.lastRequest || c.getTime() > this.lastRequest + this.RATE_LIMIT) {
            this.events = [];
            this.today = new Date;
            this.offset = 0;
            this.userIDs = [];
            this.onProgress = a;
            this.onErr = b;
            this.isLoaded = this.hasMore = false;
            this.lastRequest = c.getTime();
            this.fetchProfileDay()
        } else a()
    },getCommunityFeed:function(a, b, c) {
        var g = new Date;
        if (!this.isLoaded || g.getTime() > this.lastRequest + this.RATE_LIMIT || this.isDirty) {
            this.events = [];
            this.today = new Date;
            this.offset = 0;
            this.userIDs = a;
            this.onProgress = b;
            this.onErr = c;
            this.fromFavorites = true;
            this.isLoaded = this.hasMore = this.fromRecent = false;
            this.lastRequest = g.getTime();
            this.isDirty = false;
            this.fetchCommunityDay()
        } else b()
    },getRecentlyActiveUsersFeed:function(a, b) {
        var c = new Date;
        if (!this.isLoaded || c.getTime() > this.lastRequest +
                this.RATE_LIMIT || this.isDirty) {
            this.events = [];
            this.today = new Date;
            this.offset = 0;
            this.onProgress = a;
            this.onErr = b;
            this.fromFavorites = false;
            this.fromRecent = true;
            this.isLoaded = this.hasMore = false;
            this.lastRequest = c.getTime();
            if (this.recentUsers && this.recentUsers.length) {
                this.userIDs = _.toArrayID(this.recentUsers);
                this.fetchCommunityDay()
            } else GS.service.getRecentlyActiveUsers(this.callback("onRecentUsers"), this.onErr)
        } else a()
    },onRecentUsers:function(a) {
        var b;
        this.recentUsers = {};
        if (a.users && a.users.length)for (var c =
                0; c < a.users.length; c++) {
            b = a.users[c];
            b = GS.Models.User.wrap(b);
            this.recentUsers[b.UserID] = b
        }
        this.userIDs = _.toArrayID(this.recentUsers);
        this.fetchCommunityDay()
    },fetchProfileDay:function() {
        var a = new Date(this.today.getTime() - this.offset++ * 1E3 * 60 * 60 * 24);
        GS.service.getProcessedUserFeedData(this.user.UserID, a.format("Ymd"), this.callback(["parseProfileFeed",this.onProgress]), this.onErr)
    },fetchCommunityDay:function() {
        var a = new Date(this.today.getTime() - this.offset++ * 1E3 * 60 * 60 * 24);
        GS.service.getCombinedProcessedFeedData(this.userIDs,
                a.format("Ymd"), this.user.UserID, this.callback(["parseCommunityFeed",this.onProgress]), this.onErr)
    },parseProfileFeed:function(a) {
        var b;
        for (var c in a.events)if (a.events.hasOwnProperty(c))if (a.events[c].length) {
            b = this.parseUser(a.events[c], this.user);
            this.events = this.events.concat(b)
        }
        this.isLoaded = !Boolean(a.hasMore) || this.events.length;
        this.events = this.events.sort(this.sortByDate);
        this.events = this.collapse(this.events, 100)
    },parseCommunityFeed:function(a) {
        var b,c;
        for (var g in a.userFeeds)if (a.userFeeds.hasOwnProperty(g))if (a.userFeeds[g].length) {
            if (this.fromFavorites)c =
                    this.user.favorites.users[g]; else if (this.fromRecent)c = this.recentUsers[g];
            b = this.parseUser(a.userFeeds[g], c);
            this.events = this.events.concat(b)
        }
        this.hasMore = Boolean(a.hasMore);
        this.isLoaded = !Boolean(a.hasMore) || this.events.length;
        this.events = this.events.sort(this.sortByDate);
        this.events = this.collapse(this.events);
        this.events.length < 50 && this.offset < 4 && this.fetchCommunityDay()
    },sortByDate:function(a, b) {
        return b.time - a.time
    },sortByWeight:function(a, b) {
        return parseInt(b.weight, 10) - parseInt(a.weight, 10)
    },
        collapse:function(a, b) {
            var c = [],g,h;
            b = _.orEqual(b, 3);
            if (this.fromRecent)a = a.filter(this.filterFollows);
            for (h = 0; h < a.length; h++)if (h > 0 && a[h].time == a[h - 1].time) {
                if (a[h].weight >= a[h - 1].weight) {
                    g = c.indexOf(a[h - 1]);
                    g != -1 && c.splice(g, 1);
                    c.push(a[h])
                }
            } else c.push(a[h]);
            a = c;
            c = [];
            if (a.length <= 9)return a;
            var k = null,m = [],n = null;
            _.forEach(a, function(o) {
                if (o.user !== k) {
                    if (m.length)if (m.length > b) {
                        m.sort(this.sortByWeight);
                        c = c.concat(m.slice(0, b))
                    } else c = c.concat(m);
                    k = o.user;
                    m = [o]
                } else if (m.length) {
                    n = m[m.length - 1];
                    if (o.data && n.data && o.data.songs && n.data.songs && o.data.songs.length == 1 && n.data.songs.length == 1 && o.data.songs[0].SongID == n.data.songs[0].SongID) {
                        if (n.type !== GS.Models.FeedEvent.FAVORITE_SONG_TYPE) {
                            m.pop();
                            m.push(o)
                        }
                    } else m.push(o)
                } else m.push(o)
            }, this);
            if (m.length)if (m.length > b) {
                m = m.sort(this.sortByWeight);
                c = c.concat(m.slice(0, b))
            } else c = c.concat(m);
            return c
        },filterFollows:function(a) {
            return a.type == GS.Models.FeedEvent.USER_FOLLOWED_TYPE || a.type == GS.Models.FeedEvent.USERS_FOLLOWED_TYPE || a.type == GS.Models.FeedEvent.FAVORITE_USERS_TYPE ?
                    false : true
        },parseUser:function(a, b) {
            var c = [],g;
            for (var h in a)if (a.hasOwnProperty(h)) {
                try {
                    g = GS.Models.FeedEvent.wrap(a[h]);
                    g.user = b;
                    g.date = new Date(g.time * 1E3);
                    g.getDataString()
                } catch(k) {
                    console.warn("Feed Parse Error: type, event, user:", a[h].type, a[h], b);
                    continue
                }
                c.push(g)
            }
            return c
        }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.FeedEvent", {BROADCAST_TWITTER_TYPE:1,EMAIL_TYPE:2,CREATE_PLAYLIST_TYPE:3,FAVORITE_SONG_TYPE:4,FAVORITE_USER_TYPE:5,FAVORITE_PLAYLIST_TYPE:6,FAVORITE_ARTIST_TYPE:7,FAVORITE_ALBUM_TYPE:8,SONG_OBSESSION_TYPE:9,EDIT_PLAYLIST_TYPE:10,LISTEN_ARTIST_TYPE:11,LISTEN_ALBUM_TYPE:12,EDIT_PLAYLIST_LOTS_TYPE:13,LISTEN_LOTS_TYPE:14,BROADCAST_FACEBOOK_TYPE:15,BROADCAST_STUMBLEUPON_TYPE:16,USER_FOLLOWED_TYPE:17,PLAYLIST_FOLLOWED_TYPE:18,SHARE_SONG_TYPE:19,SHARE_SONG_RECEIVED_TYPE:20,
        LIBRARY_CLEANUP_TYPE:21,LIBRARY_ADD_ARTIST_TYPE:22,LIBRARY_ADD_ALBUM_TYPE:23,LIBRARY_ADD_SONGS_TYPE:24,SHARE_PLAYLIST_TYPE:25,SHARE_PLAYLIST_RECEIVED_TYPE:26,FAVORITE_SONGS_TYPE:27,USERS_FOLLOWED_TYPE:28,FAVORITE_USERS_TYPE:29,SHARES_SONG_TYPE:30,SHARES_PLAYLIST_TYPE:31,FeedTypes:null,getTypes:function() {
            var b = {};
            b[GS.Models.FeedEvent.BROADCAST_TWITTER_TYPE] = GS.Models.FeedEvent.feedBroadcast;
            b[GS.Models.FeedEvent.EMAIL_TYPE] = GS.Models.FeedEvent.feedShareEmail;
            b[GS.Models.FeedEvent.CREATE_PLAYLIST_TYPE] =
                    GS.Models.FeedEvent.feedPlaylistCreated;
            b[GS.Models.FeedEvent.FAVORITE_SONG_TYPE] = GS.Models.FeedEvent.feedFavorite;
            b[GS.Models.FeedEvent.FAVORITE_SONGS_TYPE] = GS.Models.FeedEvent.feedFavorites;
            b[GS.Models.FeedEvent.FAVORITE_USER_TYPE] = GS.Models.FeedEvent.feedFavoriteUser;
            b[GS.Models.FeedEvent.FAVORITE_USERS_TYPE] = GS.Models.FeedEvent.feedFavoriteUser;
            b[GS.Models.FeedEvent.FAVORITE_PLAYLIST_TYPE] = GS.Models.FeedEvent.feedFavoritePlaylist;
            b[GS.Models.FeedEvent.FAVORITE_ARTIST_TYPE] = GS.Models.FeedEvent.feedFavoriteArtist;
            b[GS.Models.FeedEvent.FAVORITE_ALBUM_TYPE] = GS.Models.FeedEvent.feedFavoriteAlbum;
            b[GS.Models.FeedEvent.SONG_OBSESSION_TYPE] = GS.Models.FeedEvent.feedSongObsession;
            b[GS.Models.FeedEvent.EDIT_PLAYLIST_TYPE] = GS.Models.FeedEvent.feedPlaylistEdited;
            b[GS.Models.FeedEvent.LISTEN_ARTIST_TYPE] = GS.Models.FeedEvent.feedListenArtist;
            b[GS.Models.FeedEvent.LISTEN_ALBUM_TYPE] = GS.Models.FeedEvent.feedListenAlbum;
            b[GS.Models.FeedEvent.EDIT_PLAYLIST_LOTS_TYPE] = GS.Models.FeedEvent.feedPlaylistEditLots;
            b[GS.Models.FeedEvent.LISTEN_LOTS_TYPE] =
                    GS.Models.FeedEvent.feedListenLots;
            b[GS.Models.FeedEvent.BROADCAST_FACEBOOK_TYPE] = GS.Models.FeedEvent.feedFacebook;
            b[GS.Models.FeedEvent.BROADCAST_STUMBLEUPON_TYPE] = GS.Models.FeedEvent.feedBroadcast;
            b[GS.Models.FeedEvent.BROADCAST_REDDIT_TYPE] = GS.Models.FeedEvent.feedBroadcast;
            b[GS.Models.FeedEvent.USER_FOLLOWED_TYPE] = GS.Models.FeedEvent.feedUserFollowed;
            b[GS.Models.FeedEvent.USERS_FOLLOWED_TYPE] = GS.Models.FeedEvent.feedUserFollowed;
            b[GS.Models.FeedEvent.PLAYLIST_FOLLOWED_TYPE] = GS.Models.FeedEvent.feedPlaylistFollowed;
            b[GS.Models.FeedEvent.SHARE_SONG_TYPE] = GS.Models.FeedEvent.feedShareSong;
            b[GS.Models.FeedEvent.SHARES_SONG_TYPE] = GS.Models.FeedEvent.feedSharesSong;
            b[GS.Models.FeedEvent.SHARE_SONG_RECEIVED_TYPE] = GS.Models.FeedEvent.feedShareReceived;
            b[GS.Models.FeedEvent.LIBRARY_ADD_ARTIST_TYPE] = GS.Models.FeedEvent.feedLibraryArtist;
            b[GS.Models.FeedEvent.LIBRARY_ADD_ALBUM_TYPE] = GS.Models.FeedEvent.feedLibraryAlbum;
            b[GS.Models.FeedEvent.LIBRARY_ADD_SONGS_TYPE] = GS.Models.FeedEvent.feedLibrarySongs;
            b[GS.Models.FeedEvent.SHARE_PLAYLIST_TYPE] =
                    GS.Models.FeedEvent.feedSharePlaylist;
            b[GS.Models.FeedEvent.SHARE_PLAYLIST_RECEIVED_TYPE] = GS.Models.FeedEvent.feedSharePlaylistReceived;
            return b
        },feedBroadcast:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            b.dataKey = "FEED_BROADCAST";
            if (b.data.songs[0].albumName.length)c.album =
                    ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join(""); else b.dataKey = "FEED_BROADCAST_NO_ALBUM";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFacebook:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID,
                    "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            b.dataKey = "FEED_FACEBOOK";
            if (b.data.songs[0].albumName.length)c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join(""); else b.dataKey = "FEED_FACEBOOK_NO_ALBUM";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedShareEmail:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',
                _.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            b.dataKey = "FEED_SHARE_SEND_SONG_SINGLE_EMAIL";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedPlaylistCreated:function(b) {
            var c =
            {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName, b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            c.numSongs = _.defined(b.data.songCount) ? parseInt(b.data.songCount, 10) : 0;
            b.dataKey = c.numSongs && c.numSongs > 1 ? "FEED_PLAYLIST_CREATED" : "FEED_PLAYLIST_CREATED_NO_SONGS";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavorite:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            b.dataKey = "FEED_FAVORITE_SONG";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavorites:function(b) {
            var c =
            {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            c.numSongs = b.data.songs.length;
            if (c.numSongs > 2) {
                b.dataKey =
                        "FEED_FAVORITE_SONGS_MANY";
                c.numSongs--
            } else if (c.numSongs == 2) {
                c.song2 = ['<a class="songLink" data-song-index="1">',_.cleanText(b.data.songs[1].songName),"</a>"].join("");
                b.dataKey = "FEED_FAVORITE_SONGS_TWO"
            }
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavoriteUser:function(b) {
            var c = {},g = _.orEqual(b.data.users[0].userName, b.data.users[0].username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.followed = ['<a href="',_.cleanUrl(g, b.data.users[0].userID, "user"),'">',g,"</a>"].join("");
            b.dataKey = "FEED_FAVORITE_USER";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavoritePlaylist:function(b) {
            var c = {},g = _.orEqual(b.data.playlist.userName, b.data.playlist.username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName, b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            c.author = ['<a href="',_.cleanUrl(g, b.data.playlist.userID, "user"),'">',g,"</a>"].join("");
            b.dataKey = "FEED_FAVORITE_PLAYLIST";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavoriteArtist:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.artist = ['<a href="',_.cleanUrl(b.data.artist.artistName, b.data.artist.artistID, "artist"),'">',_.cleanText(b.data.artist.artistName),"</a>"].join("");
            b.dataKey = "FEED_FAVORITE_ARTIST";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedFavoriteAlbum:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.album = ['<a href="',_.cleanUrl(b.data.album.albumName, b.data.album.albumID, "album"),'">',_.cleanText(b.data.album.albumName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.album.artistName, b.data.album.artistID, "artist"),'">',_.cleanText(b.data.album.artistName),"</a>"].join("");
            b.dataKey = "FEED_FAVORITE_ALBUM";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedSongObsession:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',
                _.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            b.dataKey = "FEED_SONG_OBSESSION";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedPlaylistEdited:function(b) {
            var c =
            {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName, b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            if (b.data.songCount > 1) {
                c.numSongs = b.data.songCount;
                b.dataKey = "FEED_PLAYLIST_EDITED"
            } else b.dataKey = "FEED_PLAYLIST_EDITED_NO_SONGS";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedListenArtist:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.numSongs = b.data.songs.length - 1;
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.artist.artistName, b.data.artist.artistID, "artist"),'">',_.cleanText(b.data.artist.artistName),"</a>"].join("");
            b.dataKey = "FEED_LISTEN_ARTIST";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedListenAlbum:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.numSongs = b.data.songs.length;
            c.artist = ['<a href="',
                _.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            b.dataKey = "FEED_LISTEN_ALBUM";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedPlaylistEditLots:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName,
                    b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            b.dataKey = "FEED_PLAYLIST_EDITED_LOTS";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedListenLots:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),
                "</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            c.numSongs = b.data.songs.length - 1;
            b.dataKey = "FEED_LISTEN_LOTS";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedUserFollowed:function(b) {
            var c = {},g = _.orEqual(b.data.users[0].fName, b.data.users[0].username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.fan = ['<a href="',_.cleanUrl(g, b.data.users[0].userID, "user"),
                '">',_.cleanText(g),"</a>"].join("");
            b.dataKey = "FEED_USER_FOLLOWED";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedPlaylistFollowed:function(b) {
            var c = {},g = _.orEqual(b.data.playlist.userName, b.data.playlist.username),h = _.orEqual(b.data.users[0].fName, b.data.users[0].username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName, b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            c.author = ['<a href="',_.cleanUrl(g, b.data.playlist.userID, "user"),'">',g,"</a>"].join("");
            c.fan = ['<a href="',_.cleanUrl(h, b.data.users[0].userID, "user"),'">',h,"</a>"].join("");
            b.dataKey = "FEED_PLAYLIST_FOLLOWED";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedShareSong:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName,
                    b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            b.dataKey = "FEED_SHARE_SEND_SONG_SINGLE_USER";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedSharesSong:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),
                "</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            c.numFriends = b.data.peopleCount;
            b.dataKey = "FEED_SHARE_SEND_SONG_MULTIPLE";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedShareReceived:function(b) {
            var c =
            {},g = _.orEqual(b.data.user.userName, b.data.user.username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            c.friend =
                    ['<a href="',_.cleanUrl(g, b.data.user.userID, "user"),'">',_.cleanText(g),"</a>"].join("");
            b.dataKey = "FEED_SHARE_RECEIVED_SONG";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedLibraryArtist:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.numSongs = b.data.songs.length;
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            b.dataKey = "FEED_ADD_LIBRARY_ARTIST";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedLibraryAlbum:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID, "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            c.numSongs = b.data.songs.length;
            b.dataKey =
                    "FEED_ADD_LIBRARY_ALBUM";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedLibrarySongs:function(b) {
            var c = {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.song = ['<a class="songLink">',_.cleanText(b.data.songs[0].songName),"</a>"].join("");
            c.artist = ['<a href="',_.cleanUrl(b.data.songs[0].artistName, b.data.songs[0].artistID, "artist"),'">',_.cleanText(b.data.songs[0].artistName),"</a>"].join("");
            c.album = ['<a href="',_.cleanUrl(b.data.songs[0].albumName, b.data.songs[0].albumID,
                    "album"),'">',_.cleanText(b.data.songs[0].albumName),"</a>"].join("");
            if (b.data.songs.length > 2) {
                b.dataKey = "FEED_ADD_LIBRARY_SONGS_MANY";
                c.numSongs = b.data.songs.length - 1
            } else if (b.data.songs.length == 2) {
                c.song2 = ['<a class="songLink" data-song-index="1">',_.cleanText(b.data.songs[1].songName),"</a>"].join("");
                b.dataKey = "FEED_ADD_LIBRARY_SONGS_TWO"
            } else if (b.data.songs.length == 1)b.dataKey = "FEED_ADD_LIBRARY_SONG";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedSharePlaylist:function(b) {
            var c =
            {};
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName, b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            b.dataKey = "FEED_SHARE_PLAYLIST";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },feedSharePlaylistReceived:function(b) {
            var c = {},g = _.orEqual(b.data.user.userName, b.data.user.username);
            c.user = GS.Models.FeedEvent.getUserLink(b.user);
            c.playlist = ['<a href="',_.cleanUrl(b.data.playlist.playlistName,
                    b.data.playlist.playlistID, "playlist"),'">',_.cleanText(b.data.playlist.playlistName),"</a>"].join("");
            c.friend = ['<a href="',_.cleanUrl(g, b.data.user.userID, "user"),'">',_.cleanText(g),"</a>"].join("");
            b.dataKey = "FEED_SHARE_PLAYLIST_RECEIVED";
            return new GS.Models.DataString(a.localize.getString(b.dataKey), c)
        },getUserLink:function(b) {
            return['<a href="',b.toUrl(),'">',b.Name.length ? b.Name : b.Username,"</a>"].join("")
        }}, {user:null,time:null,date:null,weight:0,data:null,type:0,dataString:null,dataKey:null,
        validate:function() {
            return true
        },init:function(b) {
            this._super(b);
            if (!GS.Models.FeedEvent.FeedTypes)GS.Models.FeedEvent.FeedTypes = GS.Models.FeedEvent.getTypes()
        },getKey:function() {
            return this.user.UserID + "-" + this.type + "-" + this.time
        },getDataString:function() {
            this.dataString = this.type && GS.Models.FeedEvent.FeedTypes[this.type] ? GS.Models.FeedEvent.FeedTypes[this.type](this) : null
        },toHTML:function() {
            this.type && !this.dataString && this.getDataString();
            return this.dataString ? this.dataString.render() : ""
        },playSongs:function(b, c) {
            c = _.orEqual(c, false);
            if (this.data.songs && this.data.songs.length) {
                var g = [];
                GS.Models.Song.wrapCollection(this.data.songs);
                for (var h in this.data.songs)this.data.songs.hasOwnProperty(h) && g.push(this.data.songs[h].songID);
                GS.player.addSongsToQueueAt(g, b, c, this.getDetailsForFeed())
            } else this.data.playlist && this.data.playlist.playlistID && GS.Models.Playlist.getPlaylist(this.data.playlist.playlistID, this.callback("playPlaylist", {index:b,playOnAdd:c}), null, false)
        },playPlaylist:function(b, c) {
            c && c.PlaylistID &&
            GS.player.playPlaylist(b, c)
        },remove:function(b, c) {
            this.user.UserID == GS.user.UserID ? GS.service.feedsRemoveEventFromProfile(this.type, this.time, b, c) : GS.service.removeItemFromCommunityFeed(this.getKey(), this.date.format("Ymd"), b, c)
        },getDetailsForFeed:function() {
            return new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_FEED, {user:this.user.getDetailsForFeeds(),time:this.time,date:this.date,weight:this.weight,data:this.data,type:this.type})
        },toString:function() {
            return["Feed. type:",this.type,", usname: ",
                this.user.UserName].join("")
        }})
})(jQuery);
(function(a) {
    var b;
    GS.Models.Base.extend("GS.Models.Theme", {}, {themeID:null,version:"1.0",title:"Unknown",author:"Grooveshark",location:"default",premium:false,sponsored:false,sections:null,assetLocation:"",clickIDs:null,tracking:null,pageTracking:null,expandableTracking:null,artistNotifTracking:null,videoLBTracking:null,adSync:false,misc:null,videos:null,artistIDs:null,isFirstLoad:true,screensaver:false,CSS:"css",TOP:"top",BOTTOM:"bottom",CENTER:"center",LEFT:"left",RIGHT:"right",AUTO:"auto",SCALEX:"scalex",
        SCALEY:"scaley",init:function(c) {
            b = this;
            c && this._super(c);
            this.assetLocation = "/themes/" + c.location + "/assets/"
        },bindAssets:function(c) {
            var g,h,k,m,n,o,r = 0,t,w = a(c).attr("id");
            a(c).children().each(function() {
                a(this).is(".flash") || a(this).click(b.callback("handleClick"));
                if (a(this).is(".flash")) {
                    g = _.orEqual(a(this).attr("data-flash-wmode"), "opaque");
                    h = _.orEqual(a(this).attr("data-flash-width"), "100%");
                    k = _.orEqual(a(this).attr("data-flash-height"), "100%");
                    m = _.orEqual(a(this).attr("data-flash-src"), null);
                    flashParams = _.orEqual(a(this).attr("data-flash-params"), "");
                    flashVisualizer = _.orEqual(a(this).attr("data-flash-visualizer"), null);
                    if (m && a(this).attr("id")) {
                        t = flashVisualizer ? "visualizerTheme" : w + "-flash-" + r++;
                        a(this).append('<div id="' + t + '"></div>');
                        swfobject.embedSWF(b.assetLocation + m + "?ver=" + b.version + "&themeID=" + b.themeID + "&currentTarget=#" + a(this).attr("id") + flashParams, t, h, k, "9.0.0", null, null, {wmode:g})
                    }
                } else if (a(this).is(".img"))if (o = _.orEqual(a(this).attr("data-img-src"), null)) {
                    n = new Image;
                    a(this).append(a(n).load(b.callback("onImageLoad", c)).css("visibility", "hidden").attr("src", gsConfig.assetHost + b.assetLocation + o + "?ver=" + b.version))
                }
            })
        },onImageLoad:function(c, g) {
            var h = a(g.currentTarget),k = h.is("[display=none]");
            h.show();
            setTimeout(function() {
                h.css("visibility", "visible").attr("data-img-width", h.width()).attr("data-img-height", h.height());
                k && h.hide();
                b.position(c)
            }, 0)
        },position:function(c) {
            var g,h,k,m,n,o,r,t,w,y,u,E,H,A,x,B,D,F,p = a(c).height(),q = a(c).width();
            a(c).children(".img").each(function() {
                g =
                        a(this);
                h = g.find("img");
                k = _.orEqual(parseInt(h.attr("data-img-width")), 0);
                m = _.orEqual(parseInt(h.attr("data-img-height")), 0);
                if (k && m) {
                    D = _.orEqual(g.attr("data-img-top"), 0);
                    F = _.orEqual(g.attr("data-img-bottom"), 0);
                    x = _.orEqual(g.attr("data-img-left"), 0);
                    B = _.orEqual(g.attr("data-img-right"), 0);
                    o = q - x - B;
                    n = p - D - F;
                    w = parseInt(_.orEqual(g.attr("data-img-min-width"), 0));
                    r = parseInt(_.orEqual(g.attr("data-img-min-height"), 0));
                    t = parseInt(_.orEqual(g.attr("data-img-max-height"), n));
                    maxWidth = parseInt(_.orEqual(g.attr("data-img-max-width"),
                            o));
                    y = g.attr("data-img-proportional") === "false" ? false : true;
                    switch (g.attr("data-img-scale")) {
                        case "scalex":
                            h.width(Math.min(Math.max(w, o), maxWidth));
                            y ? h.height(Math.round(h.width() / k * m)) : h.height(Math.min(Math.max(r, Math.round(n), t)));
                            break;
                        case "scaley":
                            h.height(Math.min(Math.max(r, n), t));
                            y ? h.width(Math.round(h.height() / m * k)) : h.width(Math.min(Math.max(w, Math.round(o), maxWidth)));
                            break;
                        case "fit":
                            u = Math.min(o / k, n / m);
                            h.width(Math.round(u * k));
                            h.height(Math.round(u * m));
                            break;
                        case "auto":
                        default:
                            if (y) {
                                u =
                                        Math.max(o / k, n / m);
                                h.width(Math.round(u * k));
                                h.height(Math.round(u * m))
                            } else {
                                h.width(Math.round(o / k * k));
                                h.height(Math.round(n / m * m))
                            }
                            break
                    }
                    E = _.orEqual(g.attr("data-pos-x"), b.CENTER);
                    H = _.orEqual(g.attr("data-pos-y"), b.CENTER);
                    switch (E) {
                        case b.LEFT:
                            A = isNaN(x) ? x : x + "px";
                            h.css(b.LEFT, A);
                            break;
                        case b.RIGHT:
                            A = isNaN(B) ? B : B + "px";
                            h.css(b.RIGHT, A);
                            break;
                        case b.CENTER:
                            h.css(b.LEFT, Math.round((o - h.width()) / 2) + "px");
                            break
                    }
                    switch (H) {
                        case b.TOP:
                            A = isNaN(D) ? D : D + "px";
                            h.css(b.TOP, A);
                            break;
                        case b.BOTTOM:
                            A = isNaN(F) ? F : F + "px";
                            h.css(b.BOTTOM, A);
                            break;
                        case b.CENTER:
                            h.css(b.TOP, Math.round((n - h.height()) / 2) + "px");
                            break
                    }
                }
            })
        },handleClick:function(c) {
            var g = a(c.currentTarget),h;
            switch (g.attr("data-click-action")) {
                case "playSong":
                    (c = g.attr("data-song-id")) && a.publish("gs.song.play", {songID:c,playOnAdd:true,getFeedback:true});
                    break;
                case "playAlbum":
                    (c = g.attr("data-album-id")) && a.publish("gs.album.play", {albumID:c,playOnAdd:true,getFeedback:true});
                    break;
                case "playPlaylist":
                    (c = g.attr("data-playlist-id")) && a.publish("gs.playlist.play",
                            {playlistID:c,playOnAdd:true,getFeedback:true});
                    break;
                case "playStation":
                    c = g.attr("data-station-id");
                    h = g.attr("data-station-name");
                    if (c && h) {
                        GS.theme.extraStations[c] = h;
                        a.publish("gs.station.play", {tagID:c,stationName:h})
                    }
                    break;
                case "playVideo":
                    c = new GS.Models.Video({src:g.attr("data-video-src"),swf:g.attr("data-video-swf"),title:_.orEqual(g.attr("data-video-title"), null),author:_.orEqual(g.attr("data-video-author"), null),tracking:_.orEqual(g.attr("data-video-tracking"), null),originalWidth:_.orEqual(g.attr("data-video-originalWidth"),
                            null),originalHeight:_.orEqual(g.attr("data-video-originalHeight"), null)});
                    c.swf.length && GS.lightbox.open("video", {video:c});
                    break;
                case "playVideos":
                    if (b.videos && b.videos.length) {
                        c = _.defined(c.index) ? c.index % b.videos.length : 0;
                        GS.lightbox.open("video", {video:b.videos[c],videos:b.videos,index:c})
                    }
                    break;
                case "promotion":
                    GS.lightbox.open("promotion", {theme:b});
                    break;
                case "expandable":
                    c = g.attr("data-expandable-id");
                    h = g.attr("data-expandable-height");
                    a(c).animate({height:h});
                    if (a.isArray(b.expandableTracking)) {
                        var k =
                                (new Date).valueOf(),m = a("body"),n;
                        _.forEach(b.expandableTracking, function(o) {
                            o += o.indexOf("?") != -1 ? "&" + k : "?" + k;
                            n = new Image;
                            m.append(a(n).load(
                                    function(r) {
                                        a(r.target).remove()
                                    }).css("visibility", "hidden").attr("src", o))
                        })
                    }
                    break;
                case "collapse":
                    c = g.attr("data-expandable-id");
                    a(c).height(0);
                    break;
                default:
                    break
            }
            g.attr("data-click-id") && GS.service.logThemeOutboundLinkClick(b.themeID, g.attr("data-click-id"))
        }})
})(jQuery);
(function() {
    GS.Models.Base.extend("GS.Models.Event", {}, {EventID:0,City:"",EventName:"",StartTime:"",TicketsURL:"",VenueName:"",ArtistName:"",searchText:"",init:function(a) {
        this._super(a);
        this.TicketsURL.match("utm_source") || (this.TicketsURL += "?utm_source=1&utm_medium=partner");
        this.searchText = [a.ArtistName,a.EventName,a.City,a.VenueName].join(" ").toLowerCase()
    }})
})(jQuery);
(function(a) {
    GS.Models.Base.extend("GS.Models.UserSettings", {NOTIF_EMAIL_USER_FOLLOW:1,NOTIF_EMAIL_INVITE_SIGNUP:2,NOTIF_EMAIL_PLAYLIST_SUBSCRIBE:16,NOTIF_EMAIL_NEW_FEATURE:4096,RSS_LISTENS:2,RSS_FAVORITES:1}, {UserID:0,local:{restoreQueue:0,lowerQuality:0,noPrefetch:0,playPauseFade:0,crossfadeAmount:5E3,crossfadeEnabled:0,tooltips:0,persistShuffle:1,lastShuffle:0},FName:"",Email:"",Country:"",Zip:"",Sex:"",TSDOB:"",FeedsDisabled:0,NotificationEmailPrefs:0,emailNotifications:{userFollow:true,inviteSignup:true,
        playlistSubscribe:true,newFeature:true},rssFeeds:{listens:true,favorites:true},_hasLoadedSettings:false,init:function(b) {
        this._super(b);
        this.local.restoreQueue = _.orEqual(store.get("player.restoreQueue" + this.UserID), 0);
        this.local.lowerQuality = _.orEqual(store.get("player.lowerQuality" + this.UserID), 0);
        this.local.noPrefetch = _.orEqual(store.get("player.noPrefetch" + this.UserID), 0);
        this.local.playPauseFade = _.orEqual(store.get("player.playPauseFade" + this.UserID), 0);
        this.local.crossfadeAmount = _.orEqual(store.get("player.crossfadeAmount" +
                this.UserID), 5E3);
        this.local.crossfadeEnabled = _.orEqual(store.get("player.crossfadeEnabled" + this.UserID), 0);
        this.local.lastShuffle = _.orEqual(store.get("player.lastShuffle" + this.UserID), 0);
        this.local.persistShuffle = _.orEqual(store.get("player.persistShuffle" + this.UserID), 1);
        this.local.tooltips = _.orEqual(store.get("user.tooltips" + this.UserID), 0);
        this.local.themeFlags = _.orEqual(store.get("user.themeFlags" + this.UserID), 0);
        if (this.UserID <= 0)this._hasLoadedSettings = true
    },getUserSettings:function(b, c) {
        if (this.UserID)if (this._hasLoadedSettings)a.isFunction(b) &&
        b(this); else GS.service.getUserSettings(this.callback(this._onSettingsSuccess, b), this.callback(this._onSettingsFailed, c))
    },_onSettingsSuccess:function(b, c) {
        if (c.hasOwnProperty("userInfo")) {
            a.extend(this, c.userInfo);
            if (this.hasOwnProperty("LName") && this.hasOwnProperty("FName")) {
                var g = this.LName,h = this.FName;
                this.LName = a.trim(this.LName);
                this.FName = a.trim(this.FName);
                if (this.LName) {
                    this.FName += " " + this.LName;
                    this.FName = a.trim(this.FName)
                }
                delete this.LName;
                var k = {};
                if (this.FName !== h)k.FName = this.FName;
                if (g)k.LName = "";
                _.isEmpty(k) || GS.service.changeUserInfoEx(k)
            }
            this.NotificationEmailPrefs = parseInt(this.NotificationEmailPrefs, 10);
            this.FeedsDisabled = parseInt(this.FeedsDisabled, 10);
            this._updateBitmaskProps()
        }
        this._hasLoadedSettings = true;
        a.isFunction(b) && b(this)
    },_onSettingsFailed:function(b) {
        a.isFunction(b) && b(this)
    },_updateBitmaskProps:function() {
        this.emailNotifications = {userFollow:!(this.NotificationEmailPrefs & GS.Models.UserSettings.NOTIF_EMAIL_USER_FOLLOW),inviteSignup:!(this.NotificationEmailPrefs &
                GS.Models.UserSettings.NOTIF_EMAIL_INVITE_SIGNUP),playlistSubscribe:!(this.NotificationEmailPrefs & GS.Models.UserSettings.NOTIF_EMAIL_PLAYLIST_SUBSCRIBE),newFeature:!(this.NotificationEmailPrefs & GS.Models.UserSettings.NOTIF_EMAIL_NEW_FEATURE)};
        this.rssFeeds = {listens:!(this.FeedsDisabled & GS.Models.UserSettings.RSS_LISTENS),favorites:!(this.FeedsDisabled & GS.Models.UserSettings.RSS_FAVORITES)}
    },updateProfile:function(b, c, g) {
        b = a.extend({}, {FName:this.FName,Email:this.Email,Country:this.Country,Zip:this.Zip,
            Sex:this.Sex,TSDOB:this.TSDOB,PageName:GS.user.PathName}, b);
        if (this.UserID < 1)this._saveProfileFailed({statusCode:-1}); else {
            b.PageName === GS.user.PathName && delete b.PageName;
            var h;
            for (h in b)b.hasOwnProperty(h) && b[h] == this[h] && delete b[h];
            if (_.isEmpty(b))this._saveProfileSuccess({statusCode:1}); else if ((b.hasOwnProperty("Email") || b.hasOwnProperty("PageName")) && !_.defined(b.password))GS.lightbox.open("confirmPasswordProfile", {params:b,callback:c,errback:g}); else {
                h = b.password;
                delete b.password;
                GS.service.changeUserInfoEx(b,
                        h, this.callback(this._saveProfileSuccess, b, c, g), this.callback(this._saveProfileFailed, g))
            }
        }
    },_saveProfileSuccess:function(b, c, g, h) {
        if (h && h.statusCode === 1) {
            a.extend(this, b);
            if (b.hasOwnProperty("PageName"))GS.user.PathName = b.PageName;
            a.isFunction(c) && c(h)
        } else this._saveProfileFailed(g, h)
    },_saveProfileFailed:function(b, c) {
        a.isFunction(b) && b(c)
    },changeNotificationSettings:function(b, c, g) {
        b = a.extend({}, this.emailNotifications, b);
        b = (b.userFollow ? 0 : GS.Models.UserSettings.NOTIF_EMAIL_USER_FOLLOW) | (b.inviteSignup ?
                0 : GS.Models.UserSettings.NOTIF_EMAIL_INVITE_SIGNUP) | (b.playlistSubscribe ? 0 : GS.Models.UserSettings.NOTIF_EMAIL_PLAYLIST_SUBSCRIBE) | (b.newFeature ? 0 : GS.Models.UserSettings.NOTIF_EMAIL_NEW_FEATURE);
        if (this.UserID < 1)a.isFunction(g) && g("Not logged in"); else GS.service.changeNotificationSettings(b, this.callback(this._notificationsSuccess, b, c, g), this.callback(this._notificationsFailed, g))
    },_notificationsSuccess:function(b, c, g, h) {
        if (h && h.statusCode === 1) {
            this.NotificationEmailPrefs = b;
            this._updateBitmaskProps();
            a.isFunction(c) && c(h)
        } else this._notificationsFailed(g, h)
    },_notificationsFailed:function(b, c) {
        a.isFunction(b) && b(c)
    },changeRSSSettings:function(b, c, g) {
        b = a.extend({}, this.rssFeeds, b);
        b = (b.listens ? 0 : GS.Models.UserSettings.RSS_LISTENS) | (b.favorites ? 0 : GS.Models.UserSettings.RSS_FAVORITES);
        if (this.UserID < 1)a.isFunction(g) && g("Not logged in"); else GS.service.changeFeedSettings(b, this.callback(this._notificationsSuccess, b, c, g), this.callback(this._notificationsFailed, g))
    },_rssSuccess:function(b, c, g, h) {
        if (h &&
                h.statusCode === 1) {
            this.FeedsDisabled = b;
            this._updateBitmaskProps();
            a.isFunction(c) && c(h)
        } else this._rssFailed(g, h)
    },_rssFailed:function(b, c) {
        a.isFunction(b) && b(c)
    },changeLocalSettings:function(b, c, g) {
        a.extend(this.local, b);
        try {
            store.set("player.restoreQueue" + this.UserID, this.local.restoreQueue);
            store.set("player.lowerQuality" + this.UserID, this.local.lowerQuality);
            store.set("player.noPrefetch" + this.UserID, this.local.noPrefetch);
            store.set("player.playPauseFade" + this.UserID, this.local.playPauseFade);
            store.set("player.crossfadeAmount" +
                    this.UserID, this.local.crossfadeAmount);
            store.set("player.crossfadeEnabled" + this.UserID, this.local.crossfadeEnabled);
            store.set("player.lastShuffle" + this.UserID, this.local.lastShuffle);
            store.set("player.persistShuffle" + this.UserID, this.local.persistShuffle);
            store.set("user.tooltips" + this.UserID, this.local.tooltips);
            store.set("user.themeFlags" + this.UserID, this.local.themeFlags)
        } catch(h) {
            a.isFunction(g) && g(this);
            return
        }
        a.publish("gs.settings.local.update", this.local);
        a.isFunction(c) && c(this)
    }})
})(jQuery);
(function(a) {
    var b;
    GS.Models.Base.extend("GS.Models.Video", {wrapYoutube:function(c, g) {
        var h = c.Thumbnails.length && c.Thumbnails[0] ? c.Thumbnails[0].url : "";
        g = _.orEqual(g, c.Video);
        return this.wrap(a.extend(true, {}, c, {title:g,youTubeTitle:c.Video,duration:_.millisToMinutesSeconds(c.Duration * 1E3),type:"youtube",swf:"http://www.youtube.com/v/" + c.VideoID + "?version=3&enablejsapi=1&version=3&fs=1",thumbnail:h,width:480,height:385,author:""}))
    }}, {title:"",author:"",type:"flash",swf:"/webincludes/flash/videoplayer.swf",
        src:"",thumb:null,thumbnail:null,originalWidth:null,originalHeight:null,width:480,height:385,flashvars:{version:gsConfig.coreVersion},params:{allowscriptaccess:"always",allowfullscreen:true},attributes:{name:"videoPlayer"},object:null,init:function(c) {
            b = this;
            c && this._super(c)
        },embed:function(c, g) {
            g = _.orEqual(g, b.refreshWindow);
            if (this.type == "flash")object = swfobject.embedSWF(this.swf, c, this.width, this.height, "9.0.0", null, this.flashvars, this.params, this.attributes, g); else if (this.type == "iframe")GS.vimeo.attachPlayer(c,
                    this.VimeoID, this.width, this.height); else this.type == "youtube" && GS.youtube.attachPlayer(this.VideoID, this.width, this.height)
        },refreshWindow:function() {
            setTimeout(function() {
                a(window).resize()
            }, 500)
        }})
})(jQuery);
(function(a) {
    function b(m, n) {
        var o = true,r = "http://rest.clearvoicesurveys.com/CVSRestfulService.svc/Json/";
        n = _.orEqual(n, 0);
        if (n >= 3)console.warn("service.sendRequest. numRetries maxed out. ", m); else {
            if (n > 0)o = false;
            if (m.url)r = m.url;
            r += m.method + "?orgGUID=BDE3B99E-44DD-4806-9278-89543B177460";
            if (m.memberGuid && !m.nomemberGuid)r += "&memberGUID=" + m.memberGuid;
            a.ajax(a.extend({}, m.options, {contentType:"application/json",cache:o,url:r,success:function(t, w, y) {
                if (t) {
                    if (t.HasError)if (a.isFunction(m.errback)) {
                        m.errback(t,
                                y, w);
                        return
                    }
                    a.isFunction(m.callback) && m.callback(t, w, y)
                } else {
                    n++;
                    console.warn("service.success NO DATA.  retry request again", m);
                    setTimeout(function() {
                        b(m, n)
                    }, 100 + n * 100)
                }
            },error:function(t, w, y) {
                a.isFunction(m.errback) && m.errback(false, t, w, y)
            }}))
        }
    }

    var c = [19,49,50,63,94,97,103,104,117,139,153,159,160,173,182,191,200],g = {create:"Member/CreateMember/",member:"Member/GetMember/",profile:"Demographics/GetProfilesForMember/",demographic:"Demographics/GetDemographicQuestions/",save:"Demographics/SaveDemographicAnswers/",
        reward:"Rewards/GetAvailableRewards/",redeem:"Rewards/RedeemReward/"},h = {method:false,options:{contentType:"application/json",dataType:"jsonp",data:{},cache:false}},k = [
        {ChildDemographics:null,Conditions:null,DemographicId:125,DemographicTypeId:2,LocalizedValue:"Which cellular phone network do you subscribe to?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:668,DemographicId:125,LocalizedValue:"Alltel",SortOrder:1},
            {AnswerCount:0,AnswerId:651,DemographicId:125,LocalizedValue:"AT&T",SortOrder:2},
            {AnswerCount:0,AnswerId:669,DemographicId:125,LocalizedValue:"Bell Mobility",SortOrder:3},
            {AnswerCount:0,AnswerId:656,DemographicId:125,LocalizedValue:"Boost",SortOrder:4},
            {AnswerCount:0,AnswerId:650,DemographicId:125,LocalizedValue:"Cingular",SortOrder:5},
            {AnswerCount:0,AnswerId:655,DemographicId:125,LocalizedValue:"Cricket",SortOrder:6},
            {AnswerCount:0,AnswerId:61584,DemographicId:125,LocalizedValue:"Metro PCS",SortOrder:6},
            {AnswerCount:0,AnswerId:670,DemographicId:125,LocalizedValue:"Microcell Fido",
                SortOrder:7},
            {AnswerCount:0,AnswerId:660,DemographicId:125,LocalizedValue:"Mobile World",SortOrder:8},
            {AnswerCount:0,AnswerId:665,DemographicId:125,LocalizedValue:"Optus",SortOrder:9},
            {AnswerCount:0,AnswerId:661,DemographicId:125,LocalizedValue:"Orange",SortOrder:12},
            {AnswerCount:0,AnswerId:671,DemographicId:125,LocalizedValue:"Rogers Wireless",SortOrder:13},
            {AnswerCount:0,AnswerId:654,DemographicId:125,LocalizedValue:"Sprint",SortOrder:14},
            {AnswerCount:0,AnswerId:664,DemographicId:125,LocalizedValue:"Telecom",
                SortOrder:15},
            {AnswerCount:0,AnswerId:663,DemographicId:125,LocalizedValue:"Telef\u00f3nica M\u00f3viles",SortOrder:16},
            {AnswerCount:0,AnswerId:666,DemographicId:125,LocalizedValue:"Telstra",SortOrder:17},
            {AnswerCount:0,AnswerId:672,DemographicId:125,LocalizedValue:"Telus Mobility",SortOrder:18},
            {AnswerCount:0,AnswerId:667,DemographicId:125,LocalizedValue:"Three",SortOrder:19},
            {AnswerCount:0,AnswerId:662,DemographicId:125,LocalizedValue:"TIM",SortOrder:20},
            {AnswerCount:0,AnswerId:653,DemographicId:125,
                LocalizedValue:"T-Mobile",SortOrder:21},
            {AnswerCount:0,AnswerId:652,DemographicId:125,LocalizedValue:"Verizon",SortOrder:22},
            {AnswerCount:0,AnswerId:659,DemographicId:125,LocalizedValue:"Vodafone",SortOrder:23},
            {AnswerCount:0,AnswerId:658,DemographicId:125,LocalizedValue:"Does Not Apply",SortOrder:24},
            {AnswerCount:0,AnswerId:657,DemographicId:125,LocalizedValue:"Other",SortOrder:25},
            {AnswerCount:0,AnswerId:673,DemographicId:125,LocalizedValue:"Virgin Mobile",SortOrder:26}
        ],ProjectMgmtProfileId:14,
            SortOrder:6,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:264,DemographicTypeId:2,LocalizedValue:"Which type of Cell Phone do you have?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:57149,DemographicId:264,LocalizedValue:"Android",SortOrder:999},
            {AnswerCount:0,AnswerId:57151,DemographicId:264,LocalizedValue:"Blackberry",SortOrder:999},
            {AnswerCount:0,AnswerId:57148,DemographicId:264,LocalizedValue:"iPhone",SortOrder:999},
            {AnswerCount:0,AnswerId:57152,
                DemographicId:264,LocalizedValue:"Windows Mobile",SortOrder:999},
            {AnswerCount:0,AnswerId:57153,DemographicId:264,LocalizedValue:"Standard Phone",SortOrder:999}
        ],ProjectMgmtProfileId:14,SortOrder:4,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:179,DemographicTypeId:7,LocalizedValue:"Do you own any of the following gaming systems? (Select all that apply)",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:1945,DemographicId:179,LocalizedValue:"Gameboy",
                SortOrder:9},
            {AnswerCount:0,AnswerId:1946,DemographicId:179,LocalizedValue:"Gameboy Advance",SortOrder:10},
            {AnswerCount:0,AnswerId:1947,DemographicId:179,LocalizedValue:"Gameboy DS",SortOrder:999},
            {AnswerCount:0,AnswerId:57157,DemographicId:179,LocalizedValue:"iPad",SortOrder:999},
            {AnswerCount:0,AnswerId:57155,DemographicId:179,LocalizedValue:"iPhone",SortOrder:999},
            {AnswerCount:0,AnswerId:57156,DemographicId:179,LocalizedValue:"iPod Touch",SortOrder:999},
            {AnswerCount:0,AnswerId:1937,DemographicId:179,
                LocalizedValue:"Nintendo",SortOrder:1},
            {AnswerCount:0,AnswerId:1938,DemographicId:179,LocalizedValue:"Nintendo 64",SortOrder:2},
            {AnswerCount:0,AnswerId:1947,DemographicId:179,LocalizedValue:"Nintendo DS",SortOrder:999},
            {AnswerCount:0,AnswerId:1939,DemographicId:179,LocalizedValue:"Nintendo Game Cube",SortOrder:3},
            {AnswerCount:0,AnswerId:1948,DemographicId:179,LocalizedValue:"Nintendo Wii",SortOrder:999},
            {AnswerCount:0,AnswerId:57154,DemographicId:179,LocalizedValue:"PC",SortOrder:999},
            {AnswerCount:0,
                AnswerId:1949,DemographicId:179,LocalizedValue:"Playstation",SortOrder:14},
            {AnswerCount:0,AnswerId:1941,DemographicId:179,LocalizedValue:"Playstation 2",SortOrder:999},
            {AnswerCount:0,AnswerId:1940,DemographicId:179,LocalizedValue:"Playstation 3",SortOrder:999},
            {AnswerCount:0,AnswerId:1942,DemographicId:179,LocalizedValue:"PSP",SortOrder:999},
            {AnswerCount:0,AnswerId:1943,DemographicId:179,LocalizedValue:"Xbox",SortOrder:999},
            {AnswerCount:0,AnswerId:1944,DemographicId:179,LocalizedValue:"Xbox 360",
                SortOrder:999},
            {AnswerCount:0,AnswerId:1936,DemographicId:179,LocalizedValue:"None",SortOrder:999}
        ],ProjectMgmtProfileId:1002,SortOrder:1,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:181,DemographicTypeId:7,LocalizedValue:"Which video game genres do you play? (Please select all that apply)",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:1967,DemographicId:181,LocalizedValue:"Action/Adventure",SortOrder:999},
            {AnswerCount:0,AnswerId:1968,DemographicId:181,
                LocalizedValue:"Card/Board Games",SortOrder:999},
            {AnswerCount:0,AnswerId:1969,DemographicId:181,LocalizedValue:"Fighting",SortOrder:999},
            {AnswerCount:0,AnswerId:1970,DemographicId:181,LocalizedValue:"First Person Shooter",SortOrder:999},
            {AnswerCount:0,AnswerId:1971,DemographicId:181,LocalizedValue:"MMO",SortOrder:999},
            {AnswerCount:0,AnswerId:1972,DemographicId:181,LocalizedValue:"Puzzle",SortOrder:999},
            {AnswerCount:0,AnswerId:1973,DemographicId:181,LocalizedValue:"Racing",SortOrder:999},
            {AnswerCount:0,
                AnswerId:1977,DemographicId:181,LocalizedValue:"Real-Time Strategy",SortOrder:999},
            {AnswerCount:0,AnswerId:1974,DemographicId:181,LocalizedValue:"Rhythm/Music",SortOrder:999},
            {AnswerCount:0,AnswerId:1975,DemographicId:181,LocalizedValue:"Role-Playing Game",SortOrder:999},
            {AnswerCount:0,AnswerId:1976,DemographicId:181,LocalizedValue:"Sports",SortOrder:999},
            {AnswerCount:0,AnswerId:1978,DemographicId:181,LocalizedValue:"Turn-Based Strategy",SortOrder:999},
            {AnswerCount:0,AnswerId:1979,DemographicId:181,
                LocalizedValue:"I do not play video games",SortOrder:13}
        ],ProjectMgmtProfileId:1002,SortOrder:8,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:221,DemographicTypeId:7,LocalizedValue:"Are you a member of any of the following sites?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:2302,DemographicId:221,LocalizedValue:"Bebo",SortOrder:11},
            {AnswerCount:0,AnswerId:2305,DemographicId:221,LocalizedValue:"BlackPlanet",SortOrder:13},
            {AnswerCount:0,AnswerId:2295,
                DemographicId:221,LocalizedValue:"Classmates.com",SortOrder:4},
            {AnswerCount:0,AnswerId:2292,DemographicId:221,LocalizedValue:"Facebook",SortOrder:1},
            {AnswerCount:0,AnswerId:2296,DemographicId:221,LocalizedValue:"Flickr",SortOrder:5},
            {AnswerCount:0,AnswerId:2299,DemographicId:221,LocalizedValue:"Habbo",SortOrder:8},
            {AnswerCount:0,AnswerId:2300,DemographicId:221,LocalizedValue:"hi5",SortOrder:9},
            {AnswerCount:0,AnswerId:2294,DemographicId:221,LocalizedValue:"LinkedIn",SortOrder:3},
            {AnswerCount:0,AnswerId:2297,
                DemographicId:221,LocalizedValue:"LiveJournal",SortOrder:6},
            {AnswerCount:0,AnswerId:2293,DemographicId:221,LocalizedValue:"MySpace",SortOrder:2},
            {AnswerCount:0,AnswerId:2307,DemographicId:221,LocalizedValue:"Orkut",SortOrder:14},
            {AnswerCount:0,AnswerId:2303,DemographicId:221,LocalizedValue:"Plaxo",SortOrder:12},
            {AnswerCount:0,AnswerId:2304,DemographicId:221,LocalizedValue:"Reunion.com",SortOrder:12},
            {AnswerCount:0,AnswerId:2298,DemographicId:221,LocalizedValue:"Windows Live Spaces",SortOrder:7},
            {AnswerCount:0,
                AnswerId:2301,DemographicId:221,LocalizedValue:"Xanga",SortOrder:10},
            {AnswerCount:0,AnswerId:2306,DemographicId:221,LocalizedValue:"None of the above",SortOrder:15}
        ],ProjectMgmtProfileId:0,SortOrder:6,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:104,DemographicTypeId:2,LocalizedValue:"What is the highest level of education you have completed?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:525,DemographicId:104,LocalizedValue:"8th Grade or below",
                SortOrder:1},
            {AnswerCount:0,AnswerId:526,DemographicId:104,LocalizedValue:"9th Grade to 11th Grade",SortOrder:2},
            {AnswerCount:0,AnswerId:527,DemographicId:104,LocalizedValue:"High School Graduate",SortOrder:3},
            {AnswerCount:0,AnswerId:528,DemographicId:104,LocalizedValue:"Some College",SortOrder:4},
            {AnswerCount:0,AnswerId:529,DemographicId:104,LocalizedValue:"Associate's degree",SortOrder:5},
            {AnswerCount:0,AnswerId:530,DemographicId:104,LocalizedValue:"Bachelor's degree",SortOrder:6},
            {AnswerCount:0,
                AnswerId:531,DemographicId:104,LocalizedValue:"Some postgraduate study",SortOrder:7},
            {AnswerCount:0,AnswerId:532,DemographicId:104,LocalizedValue:"Masters Degree",SortOrder:8},
            {AnswerCount:0,AnswerId:533,DemographicId:104,LocalizedValue:"Doctorate / PhD",SortOrder:9},
            {AnswerCount:0,AnswerId:534,DemographicId:104,LocalizedValue:"Trade School",SortOrder:10},
            {AnswerCount:0,AnswerId:535,DemographicId:104,LocalizedValue:"None of the above",SortOrder:11}
        ],ProjectMgmtProfileId:10,SortOrder:10,SortTypeId:1,
            TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:105,DemographicTypeId:2,LocalizedValue:"What is your current employment status?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:536,DemographicId:105,LocalizedValue:"Employed full-time",SortOrder:1},
            {AnswerCount:0,AnswerId:537,DemographicId:105,LocalizedValue:"Employed part-time",SortOrder:2},
            {AnswerCount:0,AnswerId:538,DemographicId:105,LocalizedValue:"Self employed",SortOrder:3},
            {AnswerCount:0,AnswerId:539,DemographicId:105,
                LocalizedValue:"Temporarily unemployed",SortOrder:4},
            {AnswerCount:0,AnswerId:540,DemographicId:105,LocalizedValue:"Student",SortOrder:5},
            {AnswerCount:0,AnswerId:541,DemographicId:105,LocalizedValue:"Homemaker",SortOrder:6},
            {AnswerCount:0,AnswerId:542,DemographicId:105,LocalizedValue:"Retired",SortOrder:7},
            {AnswerCount:0,AnswerId:543,DemographicId:105,LocalizedValue:"Disabled or Permanently Unemployed",SortOrder:8}
        ],ProjectMgmtProfileId:12,SortOrder:14,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,
            Conditions:null,DemographicId:36,DemographicTypeId:2,LocalizedValue:"Approximately how many people are employed, by the company that you work for in your country only?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:164,DemographicId:36,LocalizedValue:"1",SortOrder:1},
            {AnswerCount:0,AnswerId:165,DemographicId:36,LocalizedValue:"2-3",SortOrder:2},
            {AnswerCount:0,AnswerId:166,DemographicId:36,LocalizedValue:"4-5",SortOrder:3},
            {AnswerCount:0,AnswerId:167,DemographicId:36,LocalizedValue:"6-10",
                SortOrder:4},
            {AnswerCount:0,AnswerId:168,DemographicId:36,LocalizedValue:"11-20",SortOrder:5},
            {AnswerCount:0,AnswerId:169,DemographicId:36,LocalizedValue:"21 - 50",SortOrder:6},
            {AnswerCount:0,AnswerId:170,DemographicId:36,LocalizedValue:"51 - 100",SortOrder:7},
            {AnswerCount:0,AnswerId:171,DemographicId:36,LocalizedValue:"101 - 500",SortOrder:8},
            {AnswerCount:0,AnswerId:172,DemographicId:36,LocalizedValue:"501 - 1,000",SortOrder:9},
            {AnswerCount:0,AnswerId:173,DemographicId:36,LocalizedValue:"1,001 - 2,500",
                SortOrder:10},
            {AnswerCount:0,AnswerId:174,DemographicId:36,LocalizedValue:"2,501 - 5,000",SortOrder:11},
            {AnswerCount:0,AnswerId:175,DemographicId:36,LocalizedValue:"5,001+",SortOrder:12},
            {AnswerCount:0,AnswerId:176,DemographicId:36,LocalizedValue:"Not Sure",SortOrder:13},
            {AnswerCount:0,AnswerId:177,DemographicId:36,LocalizedValue:"Not Applicable",SortOrder:14}
        ],ProjectMgmtProfileId:12,SortOrder:5,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:34,DemographicTypeId:2,
            LocalizedValue:"In which of the following functions do you work? ",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:74,DemographicId:34,LocalizedValue:"Accountant",SortOrder:1},
            {AnswerCount:0,AnswerId:83,DemographicId:34,LocalizedValue:"Administrator/clerical",SortOrder:2},
            {AnswerCount:0,AnswerId:75,DemographicId:34,LocalizedValue:"Attorney",SortOrder:3},
            {AnswerCount:0,AnswerId:129,DemographicId:34,LocalizedValue:"Cab/Limo Driver",SortOrder:4},
            {AnswerCount:0,AnswerId:92,DemographicId:34,
                LocalizedValue:"Civil servant/government/military",SortOrder:5},
            {AnswerCount:0,AnswerId:91,DemographicId:34,LocalizedValue:"Consultant/advisor/analyst",SortOrder:6},
            {AnswerCount:0,AnswerId:87,DemographicId:34,LocalizedValue:"Customer support",SortOrder:7},
            {AnswerCount:0,AnswerId:80,DemographicId:34,LocalizedValue:"Department manager",SortOrder:8},
            {AnswerCount:0,AnswerId:84,DemographicId:34,LocalizedValue:"Designer/artist",SortOrder:9},
            {AnswerCount:0,AnswerId:76,DemographicId:34,LocalizedValue:"Doctor / Physician",
                SortOrder:10},
            {AnswerCount:0,AnswerId:89,DemographicId:34,LocalizedValue:"Engineer (Electrical, Mechanical or Aerospace)",SortOrder:11},
            {AnswerCount:0,AnswerId:93,DemographicId:34,LocalizedValue:"Entertainer (musician, actor, performer, model, DJ)",SortOrder:12},
            {AnswerCount:0,AnswerId:128,DemographicId:34,LocalizedValue:"Florist",SortOrder:13},
            {AnswerCount:0,AnswerId:123,DemographicId:34,LocalizedValue:"Hair Dresser/Stylist",SortOrder:14},
            {AnswerCount:0,AnswerId:136,DemographicId:34,LocalizedValue:"Human Resources",
                SortOrder:15},
            {AnswerCount:0,AnswerId:79,DemographicId:34,LocalizedValue:"Information Systems Manager (MIS)",SortOrder:16},
            {AnswerCount:0,AnswerId:127,DemographicId:34,LocalizedValue:"Janitorial Services",SortOrder:17},
            {AnswerCount:0,AnswerId:82,DemographicId:34,LocalizedValue:"Marketing/sales",SortOrder:18},
            {AnswerCount:0,AnswerId:94,DemographicId:34,LocalizedValue:"Other",SortOrder:19},
            {AnswerCount:0,AnswerId:125,DemographicId:34,LocalizedValue:"Pharmacist",SortOrder:20},
            {AnswerCount:0,AnswerId:126,
                DemographicId:34,LocalizedValue:"Process Worker",SortOrder:21},
            {AnswerCount:0,AnswerId:85,DemographicId:34,LocalizedValue:"Professor/educator",SortOrder:22},
            {AnswerCount:0,AnswerId:88,DemographicId:34,LocalizedValue:"Programmer",SortOrder:23},
            {AnswerCount:0,AnswerId:86,DemographicId:34,LocalizedValue:"Registered Nurse",SortOrder:24},
            {AnswerCount:0,AnswerId:133,DemographicId:34,LocalizedValue:"Retired",SortOrder:25},
            {AnswerCount:0,AnswerId:90,DemographicId:34,LocalizedValue:"Skilled labor (plumber, carpenter, electrician)",
                SortOrder:26},
            {AnswerCount:0,AnswerId:77,DemographicId:34,LocalizedValue:"Top Management (CEO, CFO, partner, etc.)",SortOrder:27},
            {AnswerCount:0,AnswerId:130,DemographicId:34,LocalizedValue:"Tourism",SortOrder:28},
            {AnswerCount:0,AnswerId:124,DemographicId:34,LocalizedValue:"Veterinarian",SortOrder:29},
            {AnswerCount:0,AnswerId:78,DemographicId:34,LocalizedValue:"Web developer",SortOrder:30},
            {AnswerCount:0,AnswerId:81,DemographicId:34,LocalizedValue:"Writer/reporter/editor",SortOrder:31},
            {AnswerCount:0,
                AnswerId:95,DemographicId:34,LocalizedValue:"None of the above",SortOrder:32}
        ],ProjectMgmtProfileId:12,SortOrder:3,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:33,DemographicTypeId:2,LocalizedValue:"What is the principle / main sector that the company you work for operates in?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:36,DemographicId:33,LocalizedValue:"Accommodation, Food Services (hotels/restaurants)",SortOrder:1},
            {AnswerCount:0,AnswerId:37,
                DemographicId:33,LocalizedValue:"Administrative Support Services",SortOrder:2},
            {AnswerCount:0,AnswerId:57192,DemographicId:33,LocalizedValue:"Agriculture, Forestry & Fishing, and Hunting",SortOrder:3},
            {AnswerCount:0,AnswerId:40,DemographicId:33,LocalizedValue:"Architectural Services",SortOrder:4},
            {AnswerCount:0,AnswerId:39,DemographicId:33,LocalizedValue:"Arts",SortOrder:5},
            {AnswerCount:0,AnswerId:41,DemographicId:33,LocalizedValue:"Automotive",SortOrder:6},
            {AnswerCount:0,AnswerId:42,DemographicId:33,
                LocalizedValue:"Banking and Finance",SortOrder:7},
            {AnswerCount:0,AnswerId:30,DemographicId:33,LocalizedValue:"Casino",SortOrder:8},
            {AnswerCount:0,AnswerId:43,DemographicId:33,LocalizedValue:"Chemical industry",SortOrder:9},
            {AnswerCount:0,AnswerId:44,DemographicId:33,LocalizedValue:"Communications (electronic + technology)",SortOrder:10},
            {AnswerCount:0,AnswerId:45,DemographicId:33,LocalizedValue:"Construction",SortOrder:11},
            {AnswerCount:0,AnswerId:46,DemographicId:33,LocalizedValue:"Education",SortOrder:12},
            {AnswerCount:0,AnswerId:49,DemographicId:33,LocalizedValue:"Electrical",SortOrder:13},
            {AnswerCount:0,AnswerId:47,DemographicId:33,LocalizedValue:"Engineering Services",SortOrder:14},
            {AnswerCount:0,AnswerId:48,DemographicId:33,LocalizedValue:"Entertainment",SortOrder:15},
            {AnswerCount:0,AnswerId:50,DemographicId:33,LocalizedValue:"Food and Consumer Products",SortOrder:16},
            {AnswerCount:0,AnswerId:33,DemographicId:33,LocalizedValue:"Government",SortOrder:17},
            {AnswerCount:0,AnswerId:51,DemographicId:33,
                LocalizedValue:"Health Care",SortOrder:18},
            {AnswerCount:0,AnswerId:52,DemographicId:33,LocalizedValue:"Hotels/restaurants",SortOrder:19},
            {AnswerCount:0,AnswerId:53,DemographicId:33,LocalizedValue:"Insurance",SortOrder:20},
            {AnswerCount:0,AnswerId:54,DemographicId:33,LocalizedValue:"Internet",SortOrder:21},
            {AnswerCount:0,AnswerId:35,DemographicId:33,LocalizedValue:"Law Enforcement",SortOrder:22},
            {AnswerCount:0,AnswerId:55,DemographicId:33,LocalizedValue:"Legal Services",SortOrder:23},
            {AnswerCount:0,
                AnswerId:56,DemographicId:33,LocalizedValue:"Leisure & Recreation Services",SortOrder:24},
            {AnswerCount:0,AnswerId:58,DemographicId:33,LocalizedValue:"Management Consultancy",SortOrder:25},
            {AnswerCount:0,AnswerId:57,DemographicId:33,LocalizedValue:"Market Research",SortOrder:26},
            {AnswerCount:0,AnswerId:31,DemographicId:33,LocalizedValue:"Manufacturing",SortOrder:27},
            {AnswerCount:0,AnswerId:34,DemographicId:33,LocalizedValue:"Military",SortOrder:28},
            {AnswerCount:0,AnswerId:59,DemographicId:33,LocalizedValue:"Mining / Natural Resources",
                SortOrder:29},
            {AnswerCount:0,AnswerId:60,DemographicId:33,LocalizedValue:"Printing Trade/Publishing",SortOrder:33},
            {AnswerCount:0,AnswerId:61,DemographicId:33,LocalizedValue:"Public Administration and Government/Military",SortOrder:34},
            {AnswerCount:0,AnswerId:62,DemographicId:33,LocalizedValue:"Real Estate",SortOrder:35},
            {AnswerCount:0,AnswerId:63,DemographicId:33,LocalizedValue:"Religious/Non-profit Organizations",SortOrder:36},
            {AnswerCount:0,AnswerId:64,DemographicId:33,LocalizedValue:"Repair Services",
                SortOrder:37},
            {AnswerCount:0,AnswerId:65,DemographicId:33,LocalizedValue:"Retail/Wholesale Trade",SortOrder:38},
            {AnswerCount:0,AnswerId:66,DemographicId:33,LocalizedValue:"Sales/Advertising/Marketing",SortOrder:39},
            {AnswerCount:0,AnswerId:67,DemographicId:33,LocalizedValue:"Technology Services (Computers, Software, Etc.)",SortOrder:40},
            {AnswerCount:0,AnswerId:68,DemographicId:33,LocalizedValue:"Transportation and Warehousing",SortOrder:41},
            {AnswerCount:0,AnswerId:69,DemographicId:33,LocalizedValue:"Travel",
                SortOrder:42},
            {AnswerCount:0,AnswerId:70,DemographicId:33,LocalizedValue:"Utilities and energy providers e.g. gas, water, electricity",SortOrder:43},
            {AnswerCount:0,AnswerId:71,DemographicId:33,LocalizedValue:"Wholesale Trade",SortOrder:44},
            {AnswerCount:0,AnswerId:72,DemographicId:33,LocalizedValue:"Other Business Services",SortOrder:997},
            {AnswerCount:0,AnswerId:73,DemographicId:33,LocalizedValue:"Prefer not to state",SortOrder:998},
            {AnswerCount:0,AnswerId:32,DemographicId:33,LocalizedValue:"Not Applicable",
                SortOrder:999}
        ],ProjectMgmtProfileId:12,SortOrder:2,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:35,DemographicTypeId:2,LocalizedValue:"What best describes your job title?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:141,DemographicId:35,LocalizedValue:"Chairman / Board Member",SortOrder:1},
            {AnswerCount:0,AnswerId:142,DemographicId:35,LocalizedValue:"Partner / Owner",SortOrder:2},
            {AnswerCount:0,AnswerId:143,DemographicId:35,LocalizedValue:"President / CEO / COO",
                SortOrder:3},
            {AnswerCount:0,AnswerId:144,DemographicId:35,LocalizedValue:"CFO / Controller / Treasurer",SortOrder:4},
            {AnswerCount:0,AnswerId:145,DemographicId:35,LocalizedValue:"CIO / CTO",SortOrder:5},
            {AnswerCount:0,AnswerId:146,DemographicId:35,LocalizedValue:"EVP / SVP",SortOrder:6},
            {AnswerCount:0,AnswerId:147,DemographicId:35,LocalizedValue:"VP / Assistant VP / Principal",SortOrder:7},
            {AnswerCount:0,AnswerId:148,DemographicId:35,LocalizedValue:"General Manager",SortOrder:8},
            {AnswerCount:0,AnswerId:149,
                DemographicId:35,LocalizedValue:"Director / Department Head",SortOrder:9},
            {AnswerCount:0,AnswerId:150,DemographicId:35,LocalizedValue:"Manager / Senior Manager",SortOrder:10},
            {AnswerCount:0,AnswerId:151,DemographicId:35,LocalizedValue:"Assistant Director / Assistant Manager",SortOrder:11},
            {AnswerCount:0,AnswerId:152,DemographicId:35,LocalizedValue:"Account Manager / Account Director",SortOrder:12},
            {AnswerCount:0,AnswerId:153,DemographicId:35,LocalizedValue:"Product Manager",SortOrder:13},
            {AnswerCount:0,
                AnswerId:154,DemographicId:35,LocalizedValue:"Publisher / Producer",SortOrder:14},
            {AnswerCount:0,AnswerId:155,DemographicId:35,LocalizedValue:"Supervisor",SortOrder:15},
            {AnswerCount:0,AnswerId:156,DemographicId:35,LocalizedValue:"Associate / Senior Associate",SortOrder:16},
            {AnswerCount:0,AnswerId:157,DemographicId:35,LocalizedValue:"Technician / Technical Specialist",SortOrder:17},
            {AnswerCount:0,AnswerId:158,DemographicId:35,LocalizedValue:"Developer / Programmer",SortOrder:18},
            {AnswerCount:0,AnswerId:159,
                DemographicId:35,LocalizedValue:"Professional / Professional Specialist",SortOrder:19},
            {AnswerCount:0,AnswerId:160,DemographicId:35,LocalizedValue:"Certified Public Accountant",SortOrder:20},
            {AnswerCount:0,AnswerId:161,DemographicId:35,LocalizedValue:"Tradesman / Trade Specialist",SortOrder:21},
            {AnswerCount:0,AnswerId:162,DemographicId:35,LocalizedValue:"Administrator",SortOrder:22},
            {AnswerCount:0,AnswerId:138,DemographicId:35,LocalizedValue:"Cashier",SortOrder:23},
            {AnswerCount:0,AnswerId:140,DemographicId:35,
                LocalizedValue:"Cab/Limo Driver",SortOrder:24},
            {AnswerCount:0,AnswerId:139,DemographicId:35,LocalizedValue:"Tour Guide",SortOrder:25},
            {AnswerCount:0,AnswerId:163,DemographicId:35,LocalizedValue:"Other",SortOrder:26}
        ],ProjectMgmtProfileId:12,SortOrder:1,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:44,DemographicTypeId:7,LocalizedValue:"Which of the following areas of the company that you work for do you have the authority to make purchases or influence the purchasing decisions? (Select all that apply)",
            MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:264,DemographicId:44,LocalizedValue:"Banking / Business Credit",SortOrder:1},
            {AnswerCount:0,AnswerId:246,DemographicId:44,LocalizedValue:"Computer Services / Hardware / Software",SortOrder:2},
            {AnswerCount:0,AnswerId:247,DemographicId:44,LocalizedValue:"Employee Benefits",SortOrder:3},
            {AnswerCount:0,AnswerId:245,DemographicId:44,LocalizedValue:"Employment / Tax Services",SortOrder:4},
            {AnswerCount:0,AnswerId:256,DemographicId:44,LocalizedValue:"Equipment",
                SortOrder:5},
            {AnswerCount:0,AnswerId:248,DemographicId:44,LocalizedValue:"Financial Services",SortOrder:6},
            {AnswerCount:0,AnswerId:249,DemographicId:44,LocalizedValue:"HR / Personnel Services",SortOrder:7},
            {AnswerCount:0,AnswerId:250,DemographicId:44,LocalizedValue:"Internet Services",SortOrder:8},
            {AnswerCount:0,AnswerId:251,DemographicId:44,LocalizedValue:"Legal Services",SortOrder:9},
            {AnswerCount:0,AnswerId:252,DemographicId:44,LocalizedValue:"Maintenance",SortOrder:10},
            {AnswerCount:0,AnswerId:253,
                DemographicId:44,LocalizedValue:"Marketing / Advertising Services",SortOrder:11},
            {AnswerCount:0,AnswerId:254,DemographicId:44,LocalizedValue:"Meeting Accommodations",SortOrder:12},
            {AnswerCount:0,AnswerId:255,DemographicId:44,LocalizedValue:"Office Services / Moving",SortOrder:13},
            {AnswerCount:0,AnswerId:257,DemographicId:44,LocalizedValue:"Print / Copy / Photo Services",SortOrder:14},
            {AnswerCount:0,AnswerId:258,DemographicId:44,LocalizedValue:"Raw Materials / Components",SortOrder:15},
            {AnswerCount:0,
                AnswerId:259,DemographicId:44,LocalizedValue:"Real Estate Services",SortOrder:16},
            {AnswerCount:0,AnswerId:260,DemographicId:44,LocalizedValue:"Shipping / Mail Services",SortOrder:17},
            {AnswerCount:0,AnswerId:261,DemographicId:44,LocalizedValue:"Telecommunications",SortOrder:18},
            {AnswerCount:0,AnswerId:262,DemographicId:44,LocalizedValue:"Training",SortOrder:19},
            {AnswerCount:0,AnswerId:263,DemographicId:44,LocalizedValue:"Travel / Transportation",SortOrder:20},
            {AnswerCount:0,AnswerId:265,DemographicId:44,
                LocalizedValue:"None of the above",SortOrder:21}
        ],ProjectMgmtProfileId:12,SortOrder:16,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:106,DemographicTypeId:2,LocalizedValue:"Which classification best describes your total pre-tax household income?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:544,DemographicId:106,LocalizedValue:"Under $10,000",SortOrder:1},
            {AnswerCount:0,AnswerId:545,DemographicId:106,LocalizedValue:"$10,000 - $19,999",SortOrder:2},
            {AnswerCount:0,AnswerId:546,DemographicId:106,LocalizedValue:"$20,000 - $29,999",SortOrder:3},
            {AnswerCount:0,AnswerId:547,DemographicId:106,LocalizedValue:"$30,000 - $39,999",SortOrder:4},
            {AnswerCount:0,AnswerId:548,DemographicId:106,LocalizedValue:"$40,000 - $49,999",SortOrder:5},
            {AnswerCount:0,AnswerId:549,DemographicId:106,LocalizedValue:"$50,000 - $74,999",SortOrder:6},
            {AnswerCount:0,AnswerId:550,DemographicId:106,LocalizedValue:"$75,000 - $99,999",SortOrder:7},
            {AnswerCount:0,AnswerId:551,DemographicId:106,
                LocalizedValue:"$100,000 - $124,999",SortOrder:8},
            {AnswerCount:0,AnswerId:552,DemographicId:106,LocalizedValue:"$125,000 - $149,999",SortOrder:9},
            {AnswerCount:0,AnswerId:553,DemographicId:106,LocalizedValue:"$150,000 - $174,999",SortOrder:10},
            {AnswerCount:0,AnswerId:554,DemographicId:106,LocalizedValue:"$175,000 - $199,999",SortOrder:11},
            {AnswerCount:0,AnswerId:555,DemographicId:106,LocalizedValue:"More than $200,000",SortOrder:12},
            {AnswerCount:0,AnswerId:556,DemographicId:106,LocalizedValue:"Prefer not to state",
                SortOrder:13}
        ],ProjectMgmtProfileId:10,SortOrder:3,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:98,DemographicTypeId:2,LocalizedValue:"What is your current relationship status?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:472,DemographicId:98,LocalizedValue:"Single",SortOrder:1},
            {AnswerCount:0,AnswerId:473,DemographicId:98,LocalizedValue:"Married",SortOrder:2},
            {AnswerCount:0,AnswerId:474,DemographicId:98,LocalizedValue:"Divorced",SortOrder:3},
            {AnswerCount:0,AnswerId:475,DemographicId:98,LocalizedValue:"Widowed",SortOrder:4},
            {AnswerCount:0,AnswerId:471,DemographicId:98,LocalizedValue:"Domestic Partnership",SortOrder:5}
        ],ProjectMgmtProfileId:10,SortOrder:17,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:101,DemographicTypeId:9,LocalizedValue:"What is your primary ethnicity?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:497,DemographicId:101,LocalizedValue:"American Indian or Alaskan Native",
                SortOrder:999},
            {AnswerCount:0,AnswerId:498,DemographicId:101,LocalizedValue:"Asian Indian",SortOrder:999},
            {AnswerCount:0,AnswerId:495,DemographicId:101,LocalizedValue:"Black or African American",SortOrder:999},
            {AnswerCount:0,AnswerId:494,DemographicId:101,LocalizedValue:"Caucasian",SortOrder:999},
            {AnswerCount:0,AnswerId:499,DemographicId:101,LocalizedValue:"Chinese",SortOrder:999},
            {AnswerCount:0,AnswerId:500,DemographicId:101,LocalizedValue:"Filipino",SortOrder:999},
            {AnswerCount:0,AnswerId:496,DemographicId:101,
                LocalizedValue:"Hispanic",SortOrder:999},
            {AnswerCount:0,AnswerId:501,DemographicId:101,LocalizedValue:"Japanese",SortOrder:999},
            {AnswerCount:0,AnswerId:502,DemographicId:101,LocalizedValue:"Korean",SortOrder:999},
            {AnswerCount:0,AnswerId:507,DemographicId:101,LocalizedValue:"Middle Eastern",SortOrder:999},
            {AnswerCount:0,AnswerId:57193,DemographicId:101,LocalizedValue:"Other Asian",SortOrder:999},
            {AnswerCount:0,AnswerId:504,DemographicId:101,LocalizedValue:"Pacific Islander",SortOrder:999},
            {AnswerCount:0,
                AnswerId:503,DemographicId:101,LocalizedValue:"Vietnamese",SortOrder:999},
            {AnswerCount:0,AnswerId:506,DemographicId:101,LocalizedValue:"Other Race",SortOrder:999}
        ],ProjectMgmtProfileId:10,SortOrder:8,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:103,DemographicTypeId:7,LocalizedValue:"What languages do you speak?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:516,DemographicId:103,LocalizedValue:"Chinese",SortOrder:999},
            {AnswerCount:0,AnswerId:515,
                DemographicId:103,LocalizedValue:"Dutch",SortOrder:999},
            {AnswerCount:0,AnswerId:510,DemographicId:103,LocalizedValue:"English",SortOrder:999},
            {AnswerCount:0,AnswerId:523,DemographicId:103,LocalizedValue:"Farsi",SortOrder:999},
            {AnswerCount:0,AnswerId:512,DemographicId:103,LocalizedValue:"French",SortOrder:999},
            {AnswerCount:0,AnswerId:513,DemographicId:103,LocalizedValue:"German",SortOrder:999},
            {AnswerCount:0,AnswerId:524,DemographicId:103,LocalizedValue:"Hindi",SortOrder:999},
            {AnswerCount:0,AnswerId:514,
                DemographicId:103,LocalizedValue:"Italian",SortOrder:999},
            {AnswerCount:0,AnswerId:517,DemographicId:103,LocalizedValue:"Japanese",SortOrder:999},
            {AnswerCount:0,AnswerId:518,DemographicId:103,LocalizedValue:"Korean",SortOrder:999},
            {AnswerCount:0,AnswerId:522,DemographicId:103,LocalizedValue:"Mandarin",SortOrder:999},
            {AnswerCount:0,AnswerId:520,DemographicId:103,LocalizedValue:"Russian",SortOrder:999},
            {AnswerCount:0,AnswerId:511,DemographicId:103,LocalizedValue:"Spanish",SortOrder:999},
            {AnswerCount:0,
                AnswerId:519,DemographicId:103,LocalizedValue:"Vietnamese",SortOrder:999},
            {AnswerCount:0,AnswerId:521,DemographicId:103,LocalizedValue:"Other",SortOrder:999}
        ],ProjectMgmtProfileId:10,SortOrder:12,SortTypeId:2,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:109,DemographicTypeId:7,LocalizedValue:"What kind of pet(s) do you own?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:571,DemographicId:109,LocalizedValue:"Dog",SortOrder:1},
            {AnswerCount:0,AnswerId:572,DemographicId:109,
                LocalizedValue:"Cat",SortOrder:2},
            {AnswerCount:0,AnswerId:573,DemographicId:109,LocalizedValue:"Reptile",SortOrder:3},
            {AnswerCount:0,AnswerId:574,DemographicId:109,LocalizedValue:"Rodent",SortOrder:4},
            {AnswerCount:0,AnswerId:575,DemographicId:109,LocalizedValue:"Bird",SortOrder:5},
            {AnswerCount:0,AnswerId:576,DemographicId:109,LocalizedValue:"Fish (Fresh Water)",SortOrder:6},
            {AnswerCount:0,AnswerId:577,DemographicId:109,LocalizedValue:"Fish (Salt Water)",SortOrder:7},
            {AnswerCount:0,AnswerId:580,DemographicId:109,
                LocalizedValue:"Horse",SortOrder:8},
            {AnswerCount:0,AnswerId:578,DemographicId:109,LocalizedValue:"Other",SortOrder:9},
            {AnswerCount:0,AnswerId:579,DemographicId:109,LocalizedValue:"None",SortOrder:10}
        ],ProjectMgmtProfileId:10,SortOrder:15,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:107,DemographicTypeId:2,LocalizedValue:"Do you own or rent your place of residence?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:557,DemographicId:107,LocalizedValue:"Own",
                SortOrder:1},
            {AnswerCount:0,AnswerId:558,DemographicId:107,LocalizedValue:"Rent",SortOrder:2},
            {AnswerCount:0,AnswerId:559,DemographicId:107,LocalizedValue:"Other",SortOrder:3}
        ],ProjectMgmtProfileId:10,SortOrder:11,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:108,DemographicTypeId:2,LocalizedValue:"How long have you lived at your current address?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:570,DemographicId:108,LocalizedValue:"less than 1 year",
                SortOrder:0},
            {AnswerCount:0,AnswerId:560,DemographicId:108,LocalizedValue:"1 year",SortOrder:1},
            {AnswerCount:0,AnswerId:561,DemographicId:108,LocalizedValue:"2 years",SortOrder:2},
            {AnswerCount:0,AnswerId:562,DemographicId:108,LocalizedValue:"3 years",SortOrder:3},
            {AnswerCount:0,AnswerId:563,DemographicId:108,LocalizedValue:"4 years",SortOrder:4},
            {AnswerCount:0,AnswerId:564,DemographicId:108,LocalizedValue:"5 years",SortOrder:5},
            {AnswerCount:0,AnswerId:565,DemographicId:108,LocalizedValue:"6 years",
                SortOrder:6},
            {AnswerCount:0,AnswerId:566,DemographicId:108,LocalizedValue:"7 years",SortOrder:7},
            {AnswerCount:0,AnswerId:567,DemographicId:108,LocalizedValue:"8 years",SortOrder:8},
            {AnswerCount:0,AnswerId:568,DemographicId:108,LocalizedValue:"9 years",SortOrder:9},
            {AnswerCount:0,AnswerId:569,DemographicId:108,LocalizedValue:"10 years or more",SortOrder:10}
        ],ProjectMgmtProfileId:10,SortOrder:13,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:99,DemographicTypeId:2,
            LocalizedValue:"How many people (including yourself) live in your home?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:476,DemographicId:99,LocalizedValue:"1",SortOrder:1},
            {AnswerCount:0,AnswerId:477,DemographicId:99,LocalizedValue:"2",SortOrder:2},
            {AnswerCount:0,AnswerId:478,DemographicId:99,LocalizedValue:"3",SortOrder:3},
            {AnswerCount:0,AnswerId:479,DemographicId:99,LocalizedValue:"4",SortOrder:4},
            {AnswerCount:0,AnswerId:480,DemographicId:99,LocalizedValue:"5",SortOrder:5},
            {AnswerCount:0,
                AnswerId:481,DemographicId:99,LocalizedValue:"6",SortOrder:6},
            {AnswerCount:0,AnswerId:482,DemographicId:99,LocalizedValue:"7",SortOrder:7},
            {AnswerCount:0,AnswerId:483,DemographicId:99,LocalizedValue:"8",SortOrder:8},
            {AnswerCount:0,AnswerId:484,DemographicId:99,LocalizedValue:"9",SortOrder:9},
            {AnswerCount:0,AnswerId:485,DemographicId:99,LocalizedValue:"10",SortOrder:10},
            {AnswerCount:0,AnswerId:486,DemographicId:99,LocalizedValue:"10+",SortOrder:11}
        ],ProjectMgmtProfileId:10,SortOrder:4,SortTypeId:1,
            TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:100,DemographicTypeId:2,LocalizedValue:"How many children 18 years old or younger live in your home?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:491,DemographicId:100,LocalizedValue:"None",SortOrder:1},
            {AnswerCount:0,AnswerId:492,DemographicId:100,LocalizedValue:"1",SortOrder:2},
            {AnswerCount:0,AnswerId:493,DemographicId:100,LocalizedValue:"2",SortOrder:3},
            {AnswerCount:0,AnswerId:487,DemographicId:100,LocalizedValue:"3",
                SortOrder:4},
            {AnswerCount:0,AnswerId:488,DemographicId:100,LocalizedValue:"4",SortOrder:5},
            {AnswerCount:0,AnswerId:489,DemographicId:100,LocalizedValue:"5",SortOrder:6},
            {AnswerCount:0,AnswerId:490,DemographicId:100,LocalizedValue:"5+",SortOrder:7}
        ],ProjectMgmtProfileId:10,SortOrder:5,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:193,DemographicTypeId:7,LocalizedValue:"Please select the bank you currently use (select all that apply):",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,
                AnswerId:2012,DemographicId:193,LocalizedValue:"Bank of America",SortOrder:1},
            {AnswerCount:0,AnswerId:2013,DemographicId:193,LocalizedValue:"Chase",SortOrder:2},
            {AnswerCount:0,AnswerId:2014,DemographicId:193,LocalizedValue:"Wachovia",SortOrder:3},
            {AnswerCount:0,AnswerId:2015,DemographicId:193,LocalizedValue:"Wells Fargo",SortOrder:4},
            {AnswerCount:0,AnswerId:2016,DemographicId:193,LocalizedValue:"Citibank",SortOrder:5},
            {AnswerCount:0,AnswerId:2017,DemographicId:193,LocalizedValue:"Washington Mutual",
                SortOrder:6},
            {AnswerCount:0,AnswerId:2018,DemographicId:193,LocalizedValue:"Sun Trust",SortOrder:7},
            {AnswerCount:0,AnswerId:2019,DemographicId:193,LocalizedValue:"US Bank",SortOrder:8},
            {AnswerCount:0,AnswerId:2020,DemographicId:193,LocalizedValue:"USAA Federal Credit Union",SortOrder:9},
            {AnswerCount:0,AnswerId:2021,DemographicId:193,LocalizedValue:"HSBC",SortOrder:10},
            {AnswerCount:0,AnswerId:2022,DemographicId:193,LocalizedValue:"Merrill Lynch",SortOrder:11},
            {AnswerCount:0,AnswerId:2023,DemographicId:193,
                LocalizedValue:"Key Bank",SortOrder:12},
            {AnswerCount:0,AnswerId:2024,DemographicId:193,LocalizedValue:"Royal Bank of Canada",SortOrder:13},
            {AnswerCount:0,AnswerId:2025,DemographicId:193,LocalizedValue:"National Bank of Canada",SortOrder:14},
            {AnswerCount:0,AnswerId:2026,DemographicId:193,LocalizedValue:"Bank of Nova Scotia",SortOrder:15},
            {AnswerCount:0,AnswerId:2027,DemographicId:193,LocalizedValue:"Bank of Montreal",SortOrder:16},
            {AnswerCount:0,AnswerId:2028,DemographicId:193,LocalizedValue:"Abbey National",
                SortOrder:17},
            {AnswerCount:0,AnswerId:2029,DemographicId:193,LocalizedValue:"Alliance & Leicester",SortOrder:18},
            {AnswerCount:0,AnswerId:2030,DemographicId:193,LocalizedValue:"Barclays",SortOrder:19},
            {AnswerCount:0,AnswerId:2031,DemographicId:193,LocalizedValue:"Other",SortOrder:20}
        ],ProjectMgmtProfileId:0,SortOrder:7,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:200,DemographicTypeId:7,LocalizedValue:"Do you own any of the following types of credit cards?",MemberAnswers:null,
            PossibleAnswers:[
                {AnswerCount:0,AnswerId:2119,DemographicId:200,LocalizedValue:"Visa Credit Card",SortOrder:1},
                {AnswerCount:0,AnswerId:2120,DemographicId:200,LocalizedValue:"Visa Debit Card",SortOrder:2},
                {AnswerCount:0,AnswerId:2121,DemographicId:200,LocalizedValue:"Mastercard Credit Card",SortOrder:3},
                {AnswerCount:0,AnswerId:2122,DemographicId:200,LocalizedValue:"Mastercard Debit Card",SortOrder:4},
                {AnswerCount:0,AnswerId:2123,DemographicId:200,LocalizedValue:"Discover Card",SortOrder:5},
                {AnswerCount:0,
                    AnswerId:2124,DemographicId:200,LocalizedValue:"American Express Card",SortOrder:6},
                {AnswerCount:0,AnswerId:2125,DemographicId:200,LocalizedValue:"Diners Club Card",SortOrder:7},
                {AnswerCount:0,AnswerId:2128,DemographicId:200,LocalizedValue:"Visa Business Credit Card",SortOrder:8},
                {AnswerCount:0,AnswerId:2129,DemographicId:200,LocalizedValue:"Mastercard Business Credit Card",SortOrder:9},
                {AnswerCount:0,AnswerId:2130,DemographicId:200,LocalizedValue:"American Express Business Credit Card",SortOrder:10},
                {AnswerCount:0,AnswerId:2131,DemographicId:200,LocalizedValue:"Discover Business Credit Card",SortOrder:11},
                {AnswerCount:0,AnswerId:2126,DemographicId:200,LocalizedValue:"Other Debit Card",SortOrder:12},
                {AnswerCount:0,AnswerId:2127,DemographicId:200,LocalizedValue:"Other Credit Card",SortOrder:13},
                {AnswerCount:0,AnswerId:2132,DemographicId:200,LocalizedValue:"I do not have a credit or debit card",SortOrder:14}
            ],ProjectMgmtProfileId:0,SortOrder:10,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,
            Conditions:null,DemographicId:31,DemographicTypeId:7,LocalizedValue:"What kinds of Insurance do you currently have?",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,AnswerId:19,DemographicId:31,LocalizedValue:"Home Owners Insurance",SortOrder:1},
            {AnswerCount:0,AnswerId:20,DemographicId:31,LocalizedValue:"Auto Insurance",SortOrder:2},
            {AnswerCount:0,AnswerId:23,DemographicId:31,LocalizedValue:"Health Insurance",SortOrder:3},
            {AnswerCount:0,AnswerId:21,DemographicId:31,LocalizedValue:"Life Insurance",
                SortOrder:4},
            {AnswerCount:0,AnswerId:22,DemographicId:31,LocalizedValue:"Umbrella Policy",SortOrder:5},
            {AnswerCount:0,AnswerId:24,DemographicId:31,LocalizedValue:"None",SortOrder:6}
        ],ProjectMgmtProfileId:11,SortOrder:5,SortTypeId:1,TotalAnswers:0},
        {ChildDemographics:null,Conditions:null,DemographicId:115,DemographicTypeId:2,LocalizedValue:"How many vehicles do you have in your household? (Please select year/make/model/vehicle type/deal type for each vehicle you choose). ",MemberAnswers:null,PossibleAnswers:[
            {AnswerCount:0,
                AnswerId:590,DemographicId:115,LocalizedValue:"None",SortOrder:1},
            {AnswerCount:0,AnswerId:591,DemographicId:115,LocalizedValue:"1",SortOrder:2},
            {AnswerCount:0,AnswerId:592,DemographicId:115,LocalizedValue:"2",SortOrder:3},
            {AnswerCount:0,AnswerId:593,DemographicId:115,LocalizedValue:"3",SortOrder:4},
            {AnswerCount:0,AnswerId:594,DemographicId:115,LocalizedValue:"4 or More",SortOrder:5}
        ],ProjectMgmtProfileId:13,SortOrder:1,SortTypeId:1,TotalAnswers:0}
    ];
    GS.Models.Base.extend("GS.Models.Clearvoice", {createMember:function(m, n, o, r, t, w, y, u) {
        var E = a.extend(true, {}, h);
        m = {emailAddress:_.orEqual(m, ""),firstName:_.orEqual(n, ""),lastName:_.orEqual(o, ""),gender:_.orEqual(r, ""),zipCode:_.orEqual(t, ""),dateOfBirth:_.orEqual(w, "")};
        y = a.extend(true, {}, m, {callback:y,errback:u});
        E.method = g.create;
        E.nomemberGuid = true;
        E.options.data = a.extend(true, {}, m, E.options.data);
        E.callback = this.callback("createSuccess", y);
        E.errback = this.callback("createFailed", y);
        b(E)
    },createSuccess:function(m, n) {
        if ((m.member = n) && n.MemberGuid)GS.service.saveClearvoiceMemberInfo(n.MemberGuid,
                m.firstName, m.lastName, m.emailAddress, this.callback("saveSuccess", m), this.callback("saveFail", m)); else a.isFunction(m.errback) && m.errback(m.member)
    },createFailed:function(m, n) {
        m.member = n;
        if (n.ExceptionMessage && n.ExceptionMessage.match(/email/i) && n.ExceptionMessage.match(/exists/i)) {
            var o = n.MemberGuid;
            GS.user.clearvoice && GS.user.clearvoice.MemberGuid == o ? GS.service.saveClearvoiceMemberInfo(o, m.firstName, m.lastName, m.emailAddress, this.callback("saveSuccess", m), this.callback("saveFail", m)) : GS.service.getClearvoiceMemberInfo(o,
                    this.callback("_createMemberGSCheckSuccess", m), this.callback("_createMemberGSCheckFailed", m))
        } else a.isFunction(m.errback) && m.errback(m.member)
    },_createMemberGSCheckSuccess:function(m, n) {
        if (_.isArray(n) && n.length === 0 || !n.hasOwnProperty("userID")) {
            m.member = a.extend(true, m.member, n);
            GS.service.getUserIDByClearvoiceEmail(m.emailAddress, this.callback("_createMemberEmailCheckSuccess", m), this.callback("_createMemberEmailCheckFailed", m))
        } else if (n.hasOwnProperty("userID") && n.userID == GS.user.UserID)this.memberSuccess(m,
                n); else if (a.isFunction(m.errback)) {
            try {
                delete m.member.ExceptionMessage
            } catch(o) {
            }
            m.errback(m.member)
        }
    },_createMemberGSCheckFailed:function(m) {
        a.isFunction(m.errback) && m.errback(m.member)
    },_createMemberEmailCheckSuccess:function(m, n) {
        if ((n = parseInt(n, 10)) && n === GS.user.UserID)this.memberSuccess(m, m.member); else if (a.isFunction(m.errback))if (n === 0)GS.service.saveClearvoiceMemberInfo(m.member.MemberGuid, m.firstName, m.lastName, m.emailAddress, this.callback("saveSuccess", m), this.callback("saveFail", m));
        else {
            if (n)try {
                delete m.member.ExceptionMessage
            } catch(o) {
            }
            m.errback(m.member)
        }
    },_createMemberEmailCheckFailed:function(m) {
        a.isFunction(m.errback) && m.errback(m.member)
    },saveSuccess:function(m) {
        a.isFunction(m.callback) && GS.Models.Clearvoice.getMember(m.callback)
    },saveFail:function(m, n) {
        a.isFunction(m.errback) && m.errback(n, m.member)
    },getMember:function(m, n) {
        GS.service.getClearvoiceMemberInfo(null, this.callback("memberSuccess", {callback:m,errback:n}), n)
    },memberSuccess:function(m, n) {
        if (_.isArray(n) && n.length ===
                0) {
            n = GS.Models.Clearvoice.wrap(n);
            GS.user.clearvoice = n;
            m.callback(n)
        } else if (n && n.guid) {
            m.member = n;
            this.getMemberClearvoice(n.guid, this.callback("clearvoiceMemberSuccess", m), m.errback)
        } else {
            n = GS.Models.Clearvoice.wrap({});
            GS.user.clearvoice = n;
            m.callback(n)
        }
    },clearvoiceMemberSuccess:function(m, n) {
        n = a.extend(true, m.member, n);
        n = GS.Models.Clearvoice.wrap(n);
        GS.user.clearvoice = this.member;
        m.callback(n);
        GS.header.update()
    },getMemberClearvoice:function(m, n, o) {
        request = a.extend(true, {}, h);
        request.memberGuid =
                m;
        request.method = g.member;
        request.callback = n;
        request.errback = o;
        b(request)
    },defaultPointsPerProfiler:6,defaultPointsPerSurvey:150,numPointsForPlus:600,numPointsForAnywhere:900,CLEARVOICE_TO_GROOVESHARK_CONVERSION:100}, {MemberGuid:false,EmailAddress:"",FirstName:"",LastName:"",AvailableSurveys:[],CompletedSurveys:[],DynamicSurveys:[],RewardHistory:[],Profilers:[],profileProgress:0,profileProgressTotal:0,baseRequest:{},answers:null,surveyLookup:{},init:function(m) {
        this._super(m);
        (this.enabled = GS.service.country &&
                c.indexOf(parseInt(GS.service.country.ID, 10)) === -1) || (GS.service.country ? console.log("clearvoice disabled, banned country", GS.service.country.ID) : console.warn("clearvoice init, service has no country. disabled"));
        this.Profilers = _.orEqual(this.Profilers, []);
        this.baseRequest = a.extend(true, {memberGuid:this.MemberGuid}, h);
        this.questions = this.getQuestions();
        this.profileProgressTotal = this.questions.length;
        this.surveyLookup = {};
        this.AvailableSurveys = _.orEqual(this.AvailableSurveys, []);
        this.CompletedSurveys =
                _.orEqual(this.CompletedSurveys, []);
        for (m = 0; m < this.AvailableSurveys.length; m++)this.surveyLookup[this.AvailableSurveys[m].SurveyId] = this.AvailableSurveys[m];
        for (m = 0; m < this.CompletedSurveys.length; m++)this.surveyLookup[this.CompletedSurveys[m].SurveyId] = this.CompletedSurveys[m];
        window.displaySurveyResult = this.callback(function(n) {
            if ((this.lastSurveyResult = n) && n.SurveyLength) {
                n.gsResult > 0 && GS.user.addPoints(n.gsResult, true);
                if (n.ResultCode == "S" && a("#page").is(".gs_page_surveys")) {
                    a("#survey" + n.SurveyID +
                            " a.startSurvey").replaceWith('<span class="surveyCompleted"><span data-translate-text="SURVEY_SURVEY_COMPLETED">' + a.localize.getString("SURVEY_SURVEY_COMPLETED") + "</span></span>");
                    a("div.surveys.completed", "#page.gs_page_surveys").append(a("#survey" + n.SurveyID));
                    a("div.surveys.available div.survey", "#page.gs_page_surveys").removeClass("last").filter(":last").addClass("last");
                    a("div.surveys.completed div.survey", "#page.gs_page_surveys").removeClass("last").filter(":last").addClass("last");
                    a("div.surveys.completed,h3.completed",
                            "#page.gs_page_surveys").show()
                }
                GS.lightbox.open("surveyResult", n)
            } else GS.lightbox.open("surveyResult", {ResultCode:"R",gsResult:-1})
        })
    },questions:false,getQuestions:function(m) {
        if (this.questions)if (a.isFunction(m))m(this.questions); else return this.questions;
        var n = [];
        this.formatDemographics(k, n);
        this.questions = n;
        if (a.isFunction(m))m(this.questions); else return this.questions
    },getDemographics:function(m, n, o) {
        request = a.extend(true, {}, this.baseRequest);
        request.method = g.demographic;
        request.options.data =
                a.extend(true, {profileId:m}, request.options.data);
        request.callback = this.callback("demographicSuccess", n, m);
        request.errback = this.callback("handleError", o);
        b(request)
    },demographicSuccess:function(m, n, o) {
        n = [];
        this.formatDemographics(o.Demographics, n);
        a.isFunction(m) && m(n)
    },answers:{},formatDemographics:function(m, n) {
        var o = {};
        _.forEach(m, this.callback(function(r) {
            if (!o[r.DemographicId]) {
                var t = r.Conditions;
                this.cacheAnswers(r.PossibleAnswers);
                n.push(r);
                o[r.DemographicId] = true;
                r.MemberAnswers && this.saveLocalAnswers(r.MemberAnswers);
                t && t.length && _.forEach(t, this.callback(function(w) {
                    var y = w.ConditionalDemographics;
                    if (y && y.length == 1)if (!o[w.DemographicId]) {
                        n.push(a.extend(true, {}, w, y[0]));
                        o[w.DemographicId] = true;
                        this.cacheAnswers(y[0].PossibleAnswers);
                        y[0].MemberAnswers && this.saveLocalAnswers(y[0].MemberAnswers)
                    }
                }))
            }
        }))
    },answerLookup:{},cacheAnswers:function(m) {
        _.forEach(m, this.callback(function(n) {
            this.answerLookup[n.AnswerId] = n
        }))
    },saveLocalAnswers:function(m) {
        m = _.isArray(m) ? m : [m];
        if (!this.answers)this.answers = {};
        for (var n =
                0; n < m.length; n++) {
            this.answers[m[n].DemographicId] || (this.answers[m[n].DemographicId] = {});
            this.answers[m[n].DemographicId][m[n].AnswerId] = m[n]
        }
    },saveAnswers:function(m, n, o) {
        m = _.isArray(m) ? m : [m];
        this.saveLocalAnswers(m);
        request = a.extend(true, {}, this.baseRequest);
        request.method = g.save;
        request.options.data = a.extend(true, {memberAnswers:JSON.stringify(m)}, request.options.data);
        b(request);
        var r,t = {};
        for (r = 0; r < m.length; r++) {
            t[m[r].DemographicId] || (t[m[r].DemographicId] = []);
            t[m[r].DemographicId].push(m[r].AnswerId)
        }
        GS.service.addClearvoiceAnswers(t,
                n, o);
        GS.user.addPoints(GS.Models.Clearvoice.defaultPointsPerProfiler, true)
    },answerSuccess:function(m, n) {
        a.isFunction(m) && m(n)
    },resetProgress:function() {
        this.profileProgress = _.toArrayID(this.answers).length;
        this.profileProgressTotal = this.getQuestions().length
    },getRewards:function(m, n) {
        request = a.extend(true, {}, baseRequest);
        request.method = g.reward;
        request.callback = this.callback("rewardsSuccess", m);
        request.errback = this.callback("handleError", n);
        b(request)
    },rewardsSuccess:function(m, n) {
        a.isFunction(m) &&
        m(n)
    },payByPoints:function() {
        var m = hex_md5((new Date).getTime()),n = {callbackMethod:m,callbackUrl:location.protocol + "//" + location.host + "/vipCallback.php",bExtend:GS.user.IsPremium ? 1 : 0};
        GS.service.httpsFormSubmit((gsConfig.runMode == "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/") + "payByPoints.php", n);
        window[m] = this.callback(function(o) {
            console.warn("payByPoints win.callback", n, o, "success:", o.bSuccess, a("#httpsIframe"));
            if (o.bSuccess && o.token) {
                var r = hex_md5((new Date).getTime()),
                        t = o.description.match(/anywhere/i) ? "anywhere" : "plus",w = {callbackMethod:r,callbackUrl:location.protocol + "//" + location.host + "/vipCallback.php",token:o.token};
                GS.service.httpsFormSubmit((gsConfig.runMode == "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/") + "payByPointsConfirm.php", w);
                window[r] = this.callback(function(y) {
                    console.warn("payByPointsConfirm win.callback", w, y, "success:", y.bSuccess, a("#httpsIframe"));
                    if (y.bSuccess) {
                        GS.user.updateAccountType(t);
                        location.hash += " "
                    }
                })
            }
        })
    },
        redeemRewards:function(m, n, o) {
            request = a.extend(true, {}, baseRequest);
            request.method = g.redeem;
            request.callback = this.callback("redeemSuccess", n);
            request.errback = this.callback("handleError", o);
            b(request)
        },redeemSuccess:function(m, n) {
            a.isFunction(m) && m(n)
        },handleError:function(m, n, o, r, t) {
            a.isFunction(m) && m(n, o, r, t)
        },askSurveyQuestionNotification:function() {
            if (!a("#page_content").is(".surveys"))if (this.enabled)for (var m,n = 0,o = {6:true,7:true}; m = this.questions[n];)if (this.answers && this.answers[m.DemographicId])n++;
            else if (this.answers && m.AnswerId && this.answers[m.ParentDemographicId] && !this.answers[m.ParentDemographicId][m.AnswerId])n++; else if (o[m.DemographicTypeId])n++; else if (n < this.questions.length) {
                GS.notice.displaySurveyQuestion({question:m,questionIndex:n,callback:this.callback("questionNotificationAnswered")});
                return
            }
        },questionNotificationAnswered:function(m, n, o) {
            if (this.answerLookup[n]) {
                this.saveAnswers([this.answerLookup[n]], function(r) {
                    GS.user.clearvoice.determineValidAnswer(r)
                });
                o == this.questions.length -
                        1 ? GS.notice.displaySurveyProfilersComplete() : setTimeout(this.callback("askSurveyQuestionNotification"), 750)
            }
        },determineValidAnswer:function(m) {
            var n = false,o = [];
            if (m && m.questionResults) {
                _.forEach(m.questionResults, function(r, t) {
                    if (r < 1) {
                        o.push(t + "=" + r);
                        n = true
                    }
                });
                n && GS.notice.displaySurveyAnswerError(o.join(", "))
            }
        },showInvitationNotification:function() {
            this.enabled && !GS.user.IsPremium && GS.notice.displaySurveyInvitation()
        },showSurveysAvailableNotification:function() {
            this.enabled && this.AvailableSurveys.length >
                    0 && GS.notice.displaySurveysAvailable(GS.user.clearvoice.AvailableSurveys[0])
        }})
})(jQuery);
(function() {
    GS.Models.Base.extend("GS.Models.Visualizer", {}, {title:"",author:"",swf:"/webincludes/flash/visualizerplayer.swf",src:"",thumb:null,width:480,height:270,flashvars:{version:gsConfig.coreVersion},params:{allowscriptaccess:true,allowfullscreen:true,wmode:"window"},attributes:{name:"visualizerPlayer"},object:null,init:function(a) {
        a && this._super(a)
    },embed:function(a) {
        object = swfobject.embedSWF(this.swf, a, this.width, this.height, "9.0.0", null, this.flashvars, this.params, this.attributes)
    }})
})(jQuery);
(function() {
    GS.Models.Base.extend("GS.Models.Promotion", {promotions:{1:{title:"Can't Wait to Get It On Playlists"}},submitPlaylistForCampaign:function(a, b, c, g) {
        GS.service.submitPlaylistForCampaign(a, b, c, g)
    }}, {campaignID:0,title:null,playlists:null,init:function(a) {
        this.campaignID = a;
        this.title = GS.Models.Promotion.promotions[this.campaignID].title
    },getPlaylistsForCampaign:function(a, b) {
        GS.service.getPlaylistsForCampaign(this.campaignID, this.callback(["savePlaylists",a]), b)
    },savePlaylists:function(a) {
        return this.playlists =
                GS.Models.Playlist.wrapCollection(a)
    }})
})(jQuery);
(function(a) {
    a.Model.extend("GS.Models.Feature", {TYPE_ACTIVATE:"ACTIVATE",TYPE_PASSIVE:"PASSIVE",TYPE_PLUGIN:"PLUGIN",Features:{},Activated:{},Plugins:{},init:function() {
        GS.Models.Feature.Plugins.sharkZapper = new GS.Models.Feature({})
    },register:function(b, c) {
        GS.Models.Feature.Features[b] = new GS.Models.Feature(c)
    }}, {FeatureID:"",TextKey:"",Author:"Grooveshark",URL:"",IsPremium:true,Type:"PASSIVE",IsLoaded:false,LoadOnActivate:false,ActivateCallback:null,IsActiveCallback:null,init:function(b) {
        this._super(b)
    },
        activate:function(b) {
            if ((GS.user.IsPremium || !this.IsPremium) && this.ActivateCallback) {
                this.ActivateCallback();
                b && b()
            } else this.ActivateCallback && GS.lightbox.open("vipOnlyFeature", {callback:this.callback(this.activate, b)})
        },isActive:function() {
            return this.IsActiveCallback ? this.IsActiveCallback() : false
        },getImageURL:function(b) {
            b = _.orEqual(b, "s");
            return gsConfig.assetHost + "/features/" + this.FeatureID + "/icon_" + b + ".png"
        },getButtonKey:function() {
            return this.Type + (this.isActive() ? "_BUTTON_OFF" : "_BUTTON_ON")
        }})
})(jQuery);
$.extend($.View.EJS.Helpers.prototype, {localeTag:function(a, b, c, g) {
    c = c || {};
    c["data-translate-text"] = b;
    b = $.localize.getString(b);
    if (g)b = $("<span></span>").dataString(b, g).render();
    return[this.tag(a, c),b,this.tagEnd(a)].join("")
},tag:function(a, b, c) {
    var g = ["<" + a];
    _.forEach(b, function(h, k) {
        g.push(" " + k + '="' + h + '"')
    });
    g.push(c || ">");
    return g.join("")
},tagEnd:function(a) {
    return["</",a,">"].join("")
}});
jQuery.Controller.extend("GS.Controllers.BaseController", {init:function() {
    this._super();
    if (this.onWindow)new this($(window)); else this.onElement && new this($(this.onElement))
},instance:function() {
    if (this.onDocument)return $(document.documentElement).controller(this._shortName);
    if (this.onWindow)return $(window).controller(this._shortName);
    if (this.onElement)return $(this.onElement).controller(this._shortName);
    if (this.hasActiveElement)return $(this.hasActiveElement).controller(this._shortName);
    throw"BaseController. controller, " +
            this._shortName + ", is improperly embedded on page";
},viewBundles:{},bundleVersions:{}}, {init:function() {
    this.subscribe("gs.app.ready", this.callback(this.appReady))
},appReady:function() {
},destroy:function() {
    if ($.isArray(this.subscriptions))for (; this.subscriptions.length;)$.unsubscribe(this.subscriptions.pop());
    this._super()
},subscribe:function(a, b, c) {
    c = _.orEqual(c, true);
    if (!_.defined(this.subscriptions))this.subscriptions = [];
    c ? this.subscriptions.push($.subscribe(a, b)) : $.subscribe(a, b)
},view:function(a, b, c, g) {
    var h = ["gs","views"];
    if (a.match(/^themes/))h = [a]; else if (a.match(/^\//))h.push(a.replace(/^\//, "")); else {
        h.push(this.Class._shortName);
        h.push(a)
    }
    h = "/" + h.join("/");
    h += $.View.ext;
    var k = h.replace(/[\/\.]/g, "_").replace(/_+/g, "_").replace(/^_/, ""),m = GS.Controllers.BaseController.viewBundles[k],n = GS.Controllers.BaseController.bundleVersions[m] || "",o = "",r = true;
    b = _.orEqual(b, this);
    c = this.calculateHelpers.call(this, c);
    if ($.View.preCached[k] || !m)return $.View(h, b, c);
    g = _.orEqual(g, 0);
    if (!(g >= 3)) {
        if (g >
                0)r = false;
        $.ajax({contentType:"application/json",dataType:"json",type:"GET",url:"/gs/views/" + m + ".json?" + n,async:false,cache:r,success:this.callback(function(t) {
            if (t) {
                _.forEach(t, function(w, y) {
                    $.View.preCached[y] = w
                });
                o = $.View(h, b, c)
            } else {
                g++;
                setTimeout(this.callback(function() {
                    this.view(a, b, c, g)
                }), 100 + g * 100)
            }
        }),error:this.callback(function() {
            g++;
            setTimeout(this.callback(function() {
                this.view(a, b, c, g)
            }), 100 + g * 100)
        })});
        return o
    }
}});
GS.Controllers.BaseController.extend("GS.Controllers.AirbridgeController", {onDocument:true}, {isDesktop:false,_bridge:null,oldWindowOpen:null,init:function() {
    if (window.parentSandboxBridge) {
        this.isDesktop = true;
        this._bridge = window.parentSandboxBridge;
        window.childSandboxBridge = this;
        window.console.error = this._bridge.consoleError;
        window.store.set = this._bridge.storeSet;
        window.store.get = this._bridge.storeGet;
        window.store.remove = this._bridge.storeRemove;
        window.store.clear = this._bridge.storeClear;
        gsConfig.assetHost =
                "http://" + window.location.host;
        this.subscribe("gs.player.playstatus", this.callback(this._onPlayStatus));
        this.subscribe("gs.player.song.change", this.callback(this._onSongChange));
        this.subscribe("gs.player.queue.change", this.callback(this._onQueueChange));
        this.subscribe("gs.auth.favorites.songs.add", this.callback(this._onFavLibChanged));
        this.subscribe("gs.auth.favorites.songs.remove", this.callback(this._onFavLibChanged));
        this.subscribe("gs.auth.library.add", this.callback(this._onFavLibChanged));
        this.subscribe("gs.auth.library.remove",
                this.callback(this._onFavLibChanged));
        var a = this;
        $("body").delegate('a[target="_blank"]', "click", function(b) {
            if (!$(b.target).closest("a").hasClass("airNoFollow")) {
                b.preventDefault();
                b = $(b.target).closest("a").attr("href");
                a._bridge.consoleWarn(b);
                b && a._bridge.navigateToUrl(b, "_blank");
                return false
            }
        });
        this.oldWindowOpen = window.open;
        window.open = function(b, c, g) {
            g = _.orEqual(g, "width=800,height=600");
            return c == "_blank" ? a._bridge.navigateToUrl(b, c) : a.oldWindowOpen.call(window, b, c, g)
        }
    }
    this._super()
},_lastStatus:null,
    _onPlayStatus:function(a) {
        if (a && this._lastStatus)if (a.status === this._lastStatus.status)if (!a.activeSong && !this._lastStatus.activeSong) {
            this._lastStatus = a;
            return
        } else if (a.activeSong && this._lastStatus.activeSong)if (a.activeSong.SongID == this._lastStatus.activeSong.SongID && a.activeSong.autoplayVote == this._lastStatus.activeSong.autoplayVote) {
            this._lastStatus = a;
            return
        }
        this._lastStatus = a;
        this._bridge && this._bridge.playerChange()
    },_onQueueChange:function() {
        this._bridge && this._bridge.playerChange()
    },_onSongChange:function(a) {
        if (!this._lastStatus ||
                this._lastStatus.activeSong && this._lastStatus.activeSong.SongID === a.SongID && this._lastStatus.activeSong.autoplayVote !== a.autoplayVote) {
            if (this._lastStatus)this._lastStatus.activeSong.autoplayVote = a.autoplayVote;
            this._bridge && this._bridge.playerChange()
        }
    },_onFavLibChanged:function(a) {
        if (a && GS.player.queue && GS.player.queue.activeSong && parseInt(a.SongID, 10) == parseInt(GS.player.queue.activeSong.SongID, 10)) {
            GS.player.queue.activeSong.isFavorite = a.isFavorite;
            GS.player.queue.activeSong.fromLibrary = a.fromLibrary;
            this._bridge && this._bridge.playerChange()
        }
    },appReady:function() {
        this._bridge && this._bridge.ready()
    },getDesktopPreferences:function() {
        return this._bridge ? this._bridge.getDesktopPreferences() : null
    },setDesktopPreferences:function(a) {
        this._bridge && this._bridge.setDesktopPreferences(a)
    },displayNotification:function(a, b) {
        $.publish("gs.notification", {type:a,message:$.localize.getString(b)})
    },getQueueStatus:function() {
        var a = GS.player.getCurrentQueue(true);
        a || (a = {});
        if (a.activeSong) {
            a.activeSong.url = "http://grooveshark.com/" +
                    a.activeSong.toUrl().replace("#/", "");
            a.activeSong.imageUrl = a.activeSong.getImageURL()
        }
        a.playStatus = GS.player.lastStatus;
        return a
    },setHash:function(a) {
        window.location.hash = a
    },safeToClose:function() {
        return window.onbeforeunload()
    },addSongsToQueueAt:function() {
        return GS.player.addSongsToQueueAt.apply(GS.player, arguments)
    },playSong:function() {
        return GS.player.playSong.apply(GS.player, arguments)
    },pauseSong:function() {
        return GS.player.pauseSong.apply(GS.player, arguments)
    },resumeSong:function() {
        return GS.player.resumeSong.apply(GS.player,
                arguments)
    },stopSong:function() {
        return GS.player.stopSong.apply(GS.player, arguments)
    },previousSong:function() {
        return GS.player.previousSong.apply(GS.player, arguments)
    },nextSong:function() {
        return GS.player.nextSong.apply(GS.player, arguments)
    },flagSong:function() {
        return GS.player.flagSong.apply(GS.player, arguments)
    },voteSong:function() {
        return GS.player.voteSong.apply(GS.player, arguments)
    },getIsMuted:function() {
        return GS.player.getIsMuted.apply(GS.player, arguments)
    },setIsMuted:function() {
        return GS.player.setIsMuted.apply(GS.player,
                arguments)
    },getVolume:function() {
        return GS.player.getVolume.apply(GS.player, arguments)
    },setVolume:function() {
        return GS.player.setVolume.apply(GS.player, arguments)
    },getShuffle:function() {
        return GS.player.getShuffle.apply(GS.player, arguments)
    },setShuffle:function() {
        return GS.player.setShuffle.apply(GS.player, arguments)
    },setAutoplay:function() {
        return GS.player.setAutoplay.apply(GS.player, arguments)
    },clearQueue:function() {
        return GS.player.clearQueue.apply(GS.player, arguments)
    },getRepeat:function() {
        return GS.player.getRepeat.apply(GS.player,
                arguments)
    },setRepeat:function() {
        return GS.player.setRepeat.apply(GS.player, arguments)
    },addPlaylist:function(a, b, c) {
        GS.Models.Playlist.getPlaylist(a, function(g) {
            g.play(b, c)
        }, null, false)
    },addSongFromToken:function(a, b, c) {
        GS.Models.Song.getSongFromToken(a, function(g) {
            GS.player.addSongsToQueueAt([g.SongID], b, c)
        }, null, false)
    },favoriteSong:function(a) {
        GS.user.addToSongFavorites(a)
    },unfavoriteSong:function(a) {
        GS.user.removeFromSongFavorites(a)
    },addSongToLibrary:function(a) {
        GS.user.addToLibrary([a])
    },removeSongFromLibrary:function(a) {
        GS.user.removeFromLibrary(a)
    },
    executeProtocol:function(a) {
        GS.Controllers.ApiController.instance().executeProtocol(a)
    }});
(function() {
    function a() {
        this.requests = [];
        this.pendingRequest = null
    }

    function b(p) {
        var q = [].slice.call(arguments, 1),s = (new Date).valueOf(),v = new this;
        this.apply(v, q);
        if (p) {
            q = v.getCacheKey();
            var C = v.pendingCallCache[q];
            if (_.defined(C) && (!C.isResolved() || s - C.lastResolution < 6E5))v = C; else v.pendingCallCache[q] = v
        }
        return v
    }

    function c(p, q, s, v, C) {
        function G() {
            I.isPending = false;
            I.lastResolution = (new Date).valueOf()
        }

        this.method = _.orEqual(p, "");
        this.parameters = _.orEqual(q, {});
        this.options = _.orEqual(s, {});
        this.useHTTPS =
                _.orEqual(v, false);
        this.useSWF = _.orEqual(C, false);
        this.overrideHeaders = {};
        this.type = "normal";
        this.isPending = this.failedAuth = false;
        this.numRetries = 0;
        this.lastFault = null;
        this.lastResolution = 0;
        this.successFilters = [];
        this.faultFilters = [];
        this._dfd = $.Deferred();
        var I = this;
        this.promise().then(G, G)
    }

    function g(p, q, s) {
        c.call(this, p, q);
        this.httpMethod = _.orEqual(s, "POST");
        this.type = "facebook"
    }

    function h(p, q) {
        c.call(this, p, q);
        this.type = "lastfm"
    }

    function k() {
        var p = String(Math.floor(Math.random() * 1E4));
        return!GS.service.outgoingSWFCalls[p] ?
                p : k()
    }

    function m(p, q) {
        var s;
        if ($.isFunction(GS.service.swfProxy)) {
            s = k();
            GS.service.outgoingSWFCalls[s] = p;
            GS.service.swfProxy(p.getSWFable(), q, s)
        } else {
            p.isPending = false;
            GS.service.callsPendingSWF.push(p)
        }
    }

    function n() {
        for (var p = "",q = 0; q < 6; q++)p += Math.floor(Math.random() * 16).toString(16);
        return p != GS.service.lastRandomizer ? p : n()
    }

    function o(p) {
        p = _.orEqual(p, {});
        var q = {client:GS.service.client,clientRevision:GS.service.clientRevision,privacy:GS.service.privacy,country:GS.service.country,uuid:GS.service.uuID};
        if (GS.service.sessionID)q.session = GS.service.sessionID;
        return $.extend(q, p)
    }

    function r(p, q) {
        _.defined(p) || (p = {fault:{message:"Empty Result",code:GS.service.faultCodes.EMPTY_RESULT}});
        if (p.header) {
            var s = p.header,v = s.session;
            if (v && v != GS.service.sessionID) {
                GS.service.sessionID = v;
                GS.service.tokenPending = false;
                w()
            }
            s = s.secondsUntilDowntime;
            if (s < 0)_.wait(5E3).then(A); else if (s > 0) {
                s = Math.floor(s / 60);
                v = (new Date).valueOf();
                if (s <= 60)if (GS.service.lastDowntimeNotification == 0 || s > 30 && v - GS.service.lastDowntimeNotification >
                        36E5 || s <= 30 && s > 15 && v - GS.service.lastDowntimeNotification > 18E5 || s <= 15 && s > 10 && v - GS.service.lastDowntimeNotification > 9E5 || s <= 10 && s > 5 && v - GS.service.lastDowntimeNotification > 6E5 || s <= 5 && v - GS.service.lastDowntimeNotification > 3E5) {
                    GS.service.lastDowntimeNotification = v;
                    s = new GS.Models.DataString($.localize.getString("NOTIFICATION_MAINTENANCE_WARNING"), {min:s});
                    $.publish("gs.notification", {type:"info",message:s})
                }
            }
        }
        p.fault ? t(p, q) : q.resolve(_.orEqual(p.result, p))
    }

    function t(p, q) {
        if (p && _.defined(p.code)) {
            console.log("HANDLE FAULT CODE",
                    p.code, q.method);
            if (p.code == GS.service.faultCodes.INVALID_TOKEN) {
                var s = (new Date).valueOf();
                if ((!GS.service.lastTokenFailed || s - GS.service.lastTokenFailed >= 3E5) && q.numRetries === 0) {
                    GS.service.lastTokenFailed = false;
                    q.isPending = false;
                    q.numRetries++;
                    GS.service.callsPendingToken.push(q);
                    w();
                    return
                } else $.publish("gs.notification", {type:"error",message:$.localize.getString("SERVICE_ERROR_COMMUNICATING"),uniqueInstance:"errorCommunicating"})
            } else if (p.code == GS.service.faultCodes.HTTP_TIMEOUT || p.code == GS.service.faultCodes.EMPTY_RESULT) {
                q.lastFault =
                        p;
                q.retry(100 + q.numRetries * 100);
                return
            } else if (p.code == GS.service.faultCodes.MAINTENANCE)_.wait(5E3).then(A); else if (p.code == GS.service.faultCodes.INVALID_CLIENT)GS.lightbox.open("invalidClient"); else if (p.code == GS.service.faultCodes.MUST_BE_LOGGED_IN)if (!q.failedAuth) {
                q.failedAuth = true;
                q.isPending = false;
                GS.service.callsPendingAuth.push(q);
                if (!GS.service.reauthPending) {
                    GS.service.reauthPending = true;
                    GS.service.reauthPending = true;
                    GS.auth.reauthenticate(E, H)
                }
                return
            }
        }
        q.reject(p)
    }

    function w() {
        if (!GS.service.tokenPending) {
            GS.service.currentToken =
                    null;
            GS.service.tokenExpires = 0;
            GS.service.tokenPending = true;
            if (GS.service.sessionID) {
                var p = hex_md5(GS.service.sessionID);
                req = c.createRequest(false, "getCommunicationToken", {secretKey:p}, {}, true);
                req.promise().then(y, function() {
                    var q = new Date;
                    GS.service.tokenPending = false;
                    for (GS.service.lastTokenFailed = q.valueOf(); GS.service.callsPendingToken.length;) {
                        q = GS.service.callsPendingToken.shift();
                        q.reject({message:$.localize.getString("SERVICE_CREATE_TOKEN_FAIL"),code:GS.service.faultCodes.INVALID_TOKEN})
                    }
                })
            } else req =
                    c.createRequest(false, "initiateSession");
            req.send()
        }
    }

    function y(p) {
        var q = new Date;
        GS.service.lastTokenFailed = false;
        GS.service.currentToken = p;
        GS.service.tokenPending = false;
        for (GS.service.tokenExpires = 15E5 + q.valueOf(); GS.service.callsPendingToken.length;) {
            p = GS.service.callsPendingToken.shift();
            p.send()
        }
    }

    function u(p) {
        for (this.country = p ? p : {CC1:0,ID:223,CC4:1073741824,CC3:0,CC2:0}; this.callsPendingCountry.length;) {
            p = this.callsPendingCountry.shift();
            p.parameters.country = this.country;
            p.send()
        }
    }

    function E() {
        GS.service.reauthPending =
                false;
        for (var p; this.callsPendingAuth.length;) {
            p = this.callsPendingAuth.shift();
            p.send()
        }
    }

    function H() {
        GS.service.reauthPending = false;
        for (var p; this.callsPendingAuth.length;) {
            p = this.callsPendingAuth.shift();
            p.reject({code:GS.service.faultCodes.MUST_BE_LOGGED_IN,message:$.localize.getString("SERVICE_LOGIN_REQUIRED")})
        }
    }

    function A() {
        if (!GS.service.downForMaintenance) {
            GS.service.downForMaintenance = true;
            GS.lightbox.open("maintenance");
            x()
        }
    }

    function x() {
        req = c.createRequest(false, "getServiceStatus");
        req.promise().then(B,
                D);
        req.send()
    }

    function B(p) {
        if (p.status == 1) {
            GS.service.downForMaintenance = false;
            GS.lightbox.close()
        } else _.wait(2E4).then(x)
    }

    function D() {
        _.wait(2E4).then(x)
    }

    a.prototype.queue = function(p) {
        function q() {
            if (this.requests.length) {
                this.pendingRequest = this.requests.shift();
                var s = this,v = function() {
                    s.pendingRequest = null;
                    q.call(s)
                };
                this.pendingRequest.promise().then(v, v);
                this.pendingRequest.send()
            }
        }

        this.requests.push(p);
        this.pendingRequest || q.call(this)
    };
    c.createRequest = function() {
        return b.apply(this, arguments)
    };
    c.prototype.promise = function() {
        return this._dfd.promise()
    };
    c.prototype.isResolved = function() {
        return this._dfd.isResolved()
    };
    c.prototype.isRejected = function() {
        return this._dfd.isRejected()
    };
    c.prototype.resolve = function(p) {
        for (var q = 0; q < this.successFilters.length; q++)if ($.isFunction(this.successFilters[q]))p = this.successFilters[q](p);
        this.lastResolution = (new Date).valueOf();
        this._dfd.resolve(p)
    };
    c.prototype.resolveWith = function(p, q) {
        for (var s = 0; s < this.successFilters.length; s++)if ($.isFunction(this.successFilters[s]))q =
                this.successFilters[s](q);
        this.lastResolution = (new Date).valueOf();
        this._dfd.resolveWith(p, q)
    };
    c.prototype.reject = function(p) {
        for (var q = 0; q < this.faultFilters.length; q++)if ($.isFunction(this.faultFilters[q]))p = this.faultFilters[q](p);
        this._dfd.reject(p)
    };
    c.prototype.rejectWith = function(p, q) {
        for (var s = 0; s < this.faultFilters.length; s++)if ($.isFunction(this.faultFilters[s]))q = this.faultFilters[s](q);
        this._dfd.rejectWith(p, q)
    };
    c.prototype.getSWFable = function() {
        return{type:this.type,method:this.method,parameters:this.parameters,
            useHTTPS:this.useHTTPS,overrideHeaders:this.overrideHeaders,overrideKey:GS.service ? GS.service.revToken : GS.Controllers.ServiceController.instance().revToken}
    };
    c.prototype.pendingCallCache = [];
    c.prototype.cacheKeyProps = ["method","parameters","type"];
    c.prototype.getCacheKey = function() {
        var p,q,s = "";
        for (p in this.cacheKeyProps)if (this.cacheKeyProps.hasOwnProperty(p)) {
            q = this[this.cacheKeyProps[p]];
            s += q instanceof String ? q : JSON.stringify(q)
        }
        return hex_md5(s)
    };
    c.prototype.send = function() {
        GS.service = GS.service ||
                GS.Controllers.ServiceController.instance();
        var p = this,q = true,s = (new Date).valueOf();
        if (!(this.isPending || this.isResolved())) {
            this.isPending = true;
            if (this.numRetries >= 3)this.reject(this.lastFault); else {
                if (this.numRetries > 0)q = false;
                if (this.type == "facebook" || this.type == "lastfm")m(this, {}); else if (GS.service.tokenExpires > s || ["getCommunicationToken","initiateSession","getServiceStatus"].indexOf(this.method) != -1)if (GS.service.downForMaintenance && this.method != "getServiceStatus")this.reject({message:$.localize.getString("SERVICE_DOWN_MAINTENANCE"),
                    code:GS.service.faultCodes.MAINTENANCE}); else {
                    s = "http://" + GS.service.hostname + "/" + GS.service.defaultEndpoint + "?" + this.method;
                    var v = {header:o(this.overrideHeaders),method:this.method,parameters:this.parameters};
                    if (GS.service.currentToken) {
                        GS.service.lastRandomizer = n();
                        var C = hex_sha1(this.method + ":" + GS.service.currentToken + ":" + GS.service.revToken + ":" + GS.service.lastRandomizer);
                        v.header.token = GS.service.lastRandomizer + C
                    }
                    this.useSWF || this.useHTTPS ? m(this, v.header) : $.ajax($.extend({}, this.options, {contentType:"application/json",
                        dataType:"json",type:"POST",data:JSON.stringify(v),cache:q,url:s,success:function(G) {
                            r(G, p)
                        },error:function(G, I, J) {
                            console.warn("ajax error: status: " + I + ", error: " + J, G, this);
                            G = {};
                            switch (I) {
                                case "parsererror":
                                    G.code = GS.service.faultCodes.PARSE_ERROR;
                                    G.message = $.localize.getString("SERVICE_PARSE_JSON");
                                    break;
                                case "timeout":
                                    G.code = GS.service.faultCodes.HTTP_TIMEOUT;
                                    G.message = $.localize.getString("SERVICE_REQUEST_TIMEOUT");
                                    break;
                                case "error":
                                case "notmodified":
                                default:
                                    G.code = GS.service.faultCodes.HTTP_ERROR;
                                    G.message = $.localize.getString("SERVICE_HTTP_ERROR");
                                    break
                            }
                            t(G, p)
                        }}))
                } else {
                    this.isPending = false;
                    GS.service.callsPendingToken.push(this);
                    w()
                }
            }
        }
    };
    c.prototype.retry = function(p) {
        var q = this;
        this.isPending = false;
        this.numRetries++;
        _.wait(p).then(function() {
            q.send()
        })
    };
    c.prototype.queue = function(p) {
        if (!_.defined(c.prototype.queues))c.prototype.queues = {};
        var q = c.prototype.queues[p];
        _.defined(q) || (q = c.prototype.queues[p] = new a);
        q.queue(this)
    };
    g.createRequest = function() {
        return b.apply(this, arguments)
    };
    g.prototype =
            $.extend(g.prototype, c.prototype);
    g.prototype.getSWFable = function() {
        return{type:this.type,method:this.method,parameters:this.parameters,httpMethod:this.httpMethod}
    };
    h.createRequest = function() {
        return b.apply(this, arguments)
    };
    h.prototype = $.extend(h.prototype, c.prototype);
    h.prototype.getSWFable = function() {
        return{type:this.type,method:this.method,parameters:this.parameters}
    };
    var F;
    $.Class.extend("GS.Controllers.ServiceController", {configDefaults:{hostname:window.location.host,sessionID:null,client:"htmlshark",
        clientRevision:"20110722",revToken:"neverGonnaGiveYouUp",country:null,privacy:0,uuID:"",defaultEndpoint:"more.php"},instance:function() {
        F || (F = new GS.Controllers.ServiceController({hostname:window.location.host,sessionID:gsConfig.sessionID,country:gsConfig.country,privacy:gsConfig.user.Privacy,uuID:gsConfig.uuid,defaultEndpoint:gsConfig.endpoint}));
        return F
    }}, {faultCodes:{INVALID_CLIENT:1024,RATE_LIMITED:512,INVALID_TOKEN:256,INVALID_SESSION:16,MAINTENANCE:10,MUST_BE_LOGGED_IN:8,HTTP_TIMEOUT:6,PARSE_ERROR:4,
        HTTP_ERROR:2,EMPTY_RESULT:-256},init:function(p) {
        $.extend(this, GS.Controllers.ServiceController.configDefaults, p);
        this.currentToken = null;
        this.tokenExpires = 0;
        this.lastTokenFailed = this.tokenPending = false;
        this.reauthPending = this.lastRandomizer = null;
        this.downForMaintenance = false;
        this.lastDowntimeNotification = 0;
        this.callsPendingToken = [];
        this.callsPendingAuth = [];
        this.callsPendingCountry = [];
        this.callsPendingSWF = [];
        this.outgoingSWFCalls = {};
        this.swfProxy = null;
        this.sessionID || c.createRequest(false, "initiateSession",
                {}, {async:false}).send();
        var q = c.createRequest(false, "getCountry");
        q.faultFilters.push(function() {
            return false
        });
        q.promise().then(this.callback(u), this.callback(u));
        this.country ? q.resolve(this.country) : _.wait(1).then(function() {
            q.send()
        })
    },serviceExists:function() {
        return true
    },swfReady:function() {
        for (var p; this.callsPendingSWF.length;) {
            p = this.callsPendingSWF.shift();
            p.send()
        }
        return true
    },swfBadHost:function() {
        GS.lightbox.open("badHost")
    },swfSuccess:function(p, q) {
        var s = this.outgoingSWFCalls[q];
        s &&
        r(p, s);
        delete this.outgoingSWFCalls[q]
    },swfFault:function(p, q) {
        var s = this.outgoingSWFCalls[q];
        s && t(p, s);
        delete this.outgoingSWFCalls[q]
    },swfNeedsToken:function() {
        w()
    },onChatData:function(p) {
        console.log("Got chat data:", p);
        p = p.data.data || p.data || p;
        p.hasOwnProperty("awardedPoints") && GS.user && GS.user.addPoints(p.awardedPoints)
    },onChatError:function(p) {
        console.log("Got chat error, event:", p)
    },httpsFormSubmit:function(p, q) {
        var s = $("#httpsForm");
        $("#httpsIframe");
        var v = [];
        s.html("");
        s.attr("action", p);
        s.attr("method", "post");
        s.attr("target", "httpsIframe");
        s.attr("enctype", "multipart/form-data");
        _.forEach(q, function(C, G) {
            v.push('<input type="hidden" name="' + G + '" value="' + C + '" />')
        });
        s.append(v.join(""));
        s.submit()
    },isFirstVisit:function(p) {
        req = c.createRequest(false, "isFirstVisit", {}, {}, false, true);
        req.promise().then(p);
        req.send()
    },makeFacebookRequest:function(p, q, s, v, C) {
        req = g.createRequest(false, p, q, s);
        req.promise().then(v, C);
        req.send()
    },lastfmHandshake:function(p, q, s) {
        req = h.createRequest(false,
                "handshake", p);
        req.promise().then(q, s);
        req.send()
    },lastfmNowPlaying:function(p, q, s) {
        req = h.createRequest(false, "nowPlaying", p);
        req.promise().then(q, s);
        req.send()
    },lastfmSongPlay:function(p, q, s) {
        req = h.createRequest(false, "submission", p);
        req.promise().then(q, s);
        req.send()
    },rapleafPersonalize:function(p, q, s) {
        req = c.createRequest(false, "personalize", {redirectURL:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
        req.type = "rapleaf";
        req.promise().then(q, s);
        req.send()
    },rapleafDirect:function(p, q, s) {
        req = c.createRequest(false, "direct", {email:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
        req.type = "rapleaf";
        req.promise().then(q, s);
        req.send()
    },getAlbumByID:function(p, q, s) {
        req = c.createRequest(true, "getAlbumByID", {albumID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },getArtistByID:function(p, q, s) {
        req = c.createRequest(true, "getArtistByID", {artistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length -
                1]);
        req.promise().then(q, s);
        req.send()
    },getPlaylistByID:function(p, q, s) {
        req = c.createRequest(true, "getPlaylistByID", {playlistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },getQueueSongListFromSongIDs:function(p, q, s) {
        req = c.createRequest(true, "getQueueSongListFromSongIDs", {songIDs:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },getSongFromToken:function(p, q, s) {
        req = c.createRequest(true,
                "getSongFromToken", {token:p,country:this.country}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        this.country ? req.send() : this.callsPendingCountry.push(req)
    },getTokenForSong:function(p, q, s) {
        req = c.createRequest(true, "getTokenForSong", {songID:p,country:this.country}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        this.country ? req.send() : this.callsPendingCountry.push(req)
    },getUserByID:function(p, q, s) {
        req = c.createRequest(true,
                "getUserByID", {userID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },albumGetSongs:function(p, q, s, v, C) {
        q = _.orEqual(q, true);
        s = _.orEqual(s, 0);
        req = c.createRequest(true, "albumGetSongs", {albumID:p,isVerified:q,offset:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
        req.promise().then(v, C);
        req.send()
    },artistGetAlbums:function(p, q, s, v, C) {
        req = c.createRequest(true, "artistGetAlbums", {artistID:p,isVerified:q,offset:s}, arguments[arguments.length -
                1] === C ? {} : arguments[arguments.length - 1]);
        req.promise().then(v, C);
        req.send()
    },artistGetSongsEx:function(p, q, s, v) {
        req = c.createRequest(true, "artistGetSongsEx", {artistID:p,isVerifiedOrPopular:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
        req.promise().then(s, v);
        req.send()
    },playlistGetSongs:function(p, q, s) {
        req = c.createRequest(true, "playlistGetSongs", {playlistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },popularGetSongs:function(p, q, s) {
        var v = arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1];
        ({daily:true,weekly:true,monthly:true})[p] || (p = "daily");
        req = c.createRequest(true, "popularGetSongs", {type:p}, v);
        req.promise().then(q, s);
        req.send()
    },getArtistsForTagRadio:function(p, q, s) {
        req = c.createRequest(true, "getArtistsForTagRadio", {tagID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },albumGetFans:function(p, q, s, v) {
        req = c.createRequest(true, "albumGetFans", {albumID:p,
            offset:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
        req.promise().then(s, v);
        req.send()
    },artistGetFans:function(p, q, s, v) {
        req = c.createRequest(true, "artistGetFans", {artistID:p,offset:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
        req.promise().then(s, v);
        req.send()
    },playlistGetFans:function(p, q, s) {
        req = c.createRequest(true, "playlistGetFans", {playlistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
        req.promise().then(q, s);
        req.send()
    },
        songGetFans:function(p, q, s, v) {
            req = c.createRequest(true, "songGetFans", {songID:p,offset:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },userGetFans:function(p, q, s, v) {
            req = c.createRequest(true, "userGetFans", {userID:p,offset:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },authenticateUser:function(p, q, s, v, C) {
            req = c.createRequest(false, "authenticateUser", {username:p,password:q,savePassword:s},
                    arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(v, C);
            req.send()
        },authenticateFacebookUser:function(p, q, s, v, C, G) {
            req = c.createRequest(false, "authenticateFacebookUser", {facebookUserID:p,sessionKey:q,accessToken1:s,accessToken3:v}, arguments[arguments.length - 1] === G ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(C, G);
            req.send()
        },authenticateGoogleUser:function(p, q) {
            req = c.createRequest(false, "authenticateGoogleUser", {}, arguments[arguments.length -
                    1] === q ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(p, q);
            req.send()
        },getStoredUsers:function(p, q) {
            req = c.createRequest(false, "getStoredUsers", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(p, q);
            req.send()
        },deleteStoredUser:function(p, q, s) {
            req = c.createRequest(false, "deleteStoredUser", {username:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(q, s);
            req.send()
        },loginStoredUser:function(p, q, s) {
            req = c.createRequest(false, "loginStoredUser", {username:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(q, s);
            req.send()
        },reportUserChange:function(p, q, s, v, C) {
            req = c.createRequest(false, "reportUserChange", {userID:p,email:q,username:"",privacy:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(v, C);
            req.send()
        },killAuthToken:function(p, q) {
            req = c.createRequest(false, "killAuthToken", {}, arguments[arguments.length -
                    1] === q ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(p, q);
            req.send()
        },logoutUser:function(p, q) {
            req = c.createRequest(false, "logoutUser", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(p, q);
            req.send()
        },userForgotPassword:function(p, q, s) {
            req = c.createRequest(false, "userForgotPassword", {usernameOrEmail:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], true);
            req.promise().then(q, s);
            req.send()
        },resetPassword:function(p, q, s, v, C) {
            req = c.createRequest(false, "resetPassword", {usernameOrEmail:p,secretResetCode:q,newPassword:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1], true);
            req.promise().then(v, C);
            req.send()
        },changePassword:function(p, q, s, v) {
            req = c.createRequest(false, "changePassword", {oldPassword:p,newPassword:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(s, v);
            req.send()
        },registerUser:function(p, q, s, v, C, G, I, J, K, M, N, L) {
            req = c.createRequest(false,
                    "registerUser", {username:p,password:q,firstName:s,lastName:v,emailAddress:C,sex:G,birthDate:I,flags:J,inviteID:K,savePassword:M}, arguments[arguments.length - 1] === L ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(N, L);
            req.send()
        },userDisableAccount:function(p, q, s, v, C, G) {
            req = c.createRequest(false, "userDisableAccount", {password:p,reason:q,details:s,contact:v}, arguments[arguments.length - 1] === G ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(C, G);
            req.send()
        },getIsUsernameEmailAvailable:function(p, q, s, v) {
            req = c.createRequest(false, "getIsUsernameEmailAvailable", {username:p,emailAddress:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },getUserByInviteID:function(p, q, s) {
            req = c.createRequest(true, "getUserByInviteID", {inviteID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], true);
            req.promise().then(q, s);
            req.send()
        },sendInvites:function(p, q, s) {
            req = c.createRequest(false, "sendInvites", {emailAddresses:p}, arguments[arguments.length -
                    1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },getUserSettings:function(p, q) {
            req = c.createRequest(false, "getUserSettings", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },changeUserInfoEx:function(p, q, s, v) {
            req = c.createRequest(false, "changeUserInfoEx", {shitToChange:p,password:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1], true);
            req.promise().then(s, v);
            req.send()
        },changeNotificationSettings:function(p, q, s) {
            req = c.createRequest(false, "changeNotificationSettings", {newValue:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },changePrivacySettings:function(p, q, s) {
            req = c.createRequest(false, "changePrivacySettings", {newValue:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },changeFeedSettings:function(p, q, s) {
            req = c.createRequest(false, "changeFeedSettings", {newValue:p}, arguments[arguments.length -
                    1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },getSubscriptionDetails:function(p, q) {
            req = c.createRequest(false, "getSubscriptionDetails", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(p, q);
            req.send()
        },userGetSongsInLibrary:function(p, q, s, v, C) {
            q = _.orEqual(q, 0);
            req = c.createRequest(s, "userGetSongsInLibrary", {userID:p,page:q}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },
        userGetLibraryTSModified:function(p, q, s) {
            req = c.createRequest(false, "userGetLibraryTSModified", {userID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },userAddSongsToLibrary:function(p, q, s) {
            req = c.createRequest(false, "userAddSongsToLibrary", {songs:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.queue("library")
        },userRemoveSongFromLibrary:function(p, q, s, v, C, G) {
            req = c.createRequest(false, "userRemoveSongFromLibrary",
                    {userID:p,songID:q,albumID:s,artistID:v}, arguments[arguments.length - 1] === G ? {} : arguments[arguments.length - 1]);
            req.promise().then(C, G);
            req.queue("library")
        },getFavorites:function(p, q, s, v, C) {
            q = q || "Songs";
            req = c.createRequest(s, "getFavorites", {userID:p,ofWhat:q}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },favorite:function(p, q, s, v, C) {
            req = c.createRequest(false, "favorite", {what:p,ID:q,details:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(v, C);
            req.queue("library")
        },unfavorite:function(p, q, s, v) {
            req = c.createRequest(false, "unfavorite", {what:p,ID:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("library")
        },getUserSidebar:function(p, q) {
            req = c.createRequest(false, "getUserSidebar", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },addShortcutToUserSidebar:function(p, q, s, v) {
            req = c.createRequest(false, "addShortcutToUserSidebar",
                    {what:p,id:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("library")
        },removeShortcutFromUserSidebar:function(p, q, s, v) {
            req = c.createRequest(false, "removeShortcutFromUserSidebar", {what:p,id:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("library")
        },userGetPlaylists:function(p, q, s, v) {
            req = c.createRequest(q, "userGetPlaylists", {userID:p}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(s, v);
            req.send()
        },createPlaylist:function(p, q, s, v, C) {
            req = c.createRequest(false, "createPlaylist", {playlistName:p,songIDs:q,playlistAbout:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },deletePlaylist:function(p, q, s, v) {
            req = c.createRequest(false, "deletePlaylist", {playlistID:p,name:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("playlist")
        },playlistUndelete:function(p, q, s) {
            req = c.createRequest(false, "playlistUndelete", {playlistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.queue("playlist")
        },overwritePlaylist:function(p, q, s, v) {
            req = c.createRequest(false, "overwritePlaylist", {playlistID:p,songIDs:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("playlist")
        },playlistAddSongToExisting:function(p, q, s, v) {
            req = c.createRequest(false, "playlistAddSongToExisting", {playlistID:p,
                songID:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("playlist")
        },renamePlaylist:function(p, q, s, v) {
            req = c.createRequest(false, "renamePlaylist", {playlistID:p,playlistName:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.queue("playlist")
        },setPlaylistAbout:function(p, q, s, v) {
            req = c.createRequest(false, "setPlaylistAbout", {playlistID:p,about:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(s, v);
            req.queue("playlist")
        },getSearchResultsEx:function(p, q, s, v, C) {
            req = c.createRequest(true, "getSearchResultsEx", {query:p,type:q,guts:GS.guts ? GS.guts.shouldLog : 0,ppOverride:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },getSearchSuggestion:function(p, q, s) {
            req = c.createRequest(true, "getSearchSuggestion", {query:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },getArtistAutocomplete:function(p, q, s) {
            req = c.createRequest(true, "getArtistAutocomplete", {query:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },getProcessedUserFeedData:function(p, q, s, v) {
            req = c.createRequest(true, "getProcessedUserFeedData", {userID:p,day:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },getCombinedProcessedFeedData:function(p, q, s, v, C) {
            req = c.createRequest(true, "getCombinedProcessedFeedData", {userIDs:p,day:q,
                loggedInUserID:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },getRecentlyActiveUsers:function(p, q) {
            req = c.createRequest(true, "getRecentlyActiveUsers", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },feedsBanArtist:function(p, q, s) {
            req = c.createRequest(false, "feedsBanArtist", {artistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },
        feedsUnbanArtist:function(p, q, s) {
            req = c.createRequest(false, "feedsUnbanArtist", {artistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },feedsGetBannedArtists:function(p, q) {
            req = c.createRequest(false, "feedsGetBannedArtists", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },feedsRemoveEventFromProfile:function(p, q, s, v) {
            req = c.createRequest(false, "feedsRemoveEventFromProfile", {type:p,time:q},
                    arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },removeItemFromCommunityFeed:function(p, q, s, v) {
            req = c.createRequest(false, "removeItemFromCommunityFeed", {key:p,day:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },changeFollowFlags:function(p, q, s) {
            req = c.createRequest(false, "changeFollowFlags", {userIDsFlags:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q,
                    s);
            req.send()
        },getIsTargetingActive:function(p, q, s) {
            req = c.createRequest(false, "getIsTargetingActive", {themeID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },logTargetedThemeImpression:function(p, q, s) {
            req = c.createRequest(false, "logTargetedThemeImpression", {themeID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },logThemeOutboundLinkClick:function(p, q, s, v) {
            req = c.createRequest(false,
                    "logThemeOutboundLinkClick", {themeID:p,linkID:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },provideSongFeedbackMessage:function(p, q, s, v) {
            req = c.createRequest(false, "provideSongFeedbackMessage", {songID:p,message:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },provideSongFeedbackVote:function(p, q, s, v, C) {
            req = c.createRequest(false, "provideSongFeedbackVote", {songID:p,vote:q,artistID:s},
                    arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },sendShare:function(p, q, s, v, C, G, I, J) {
            req = c.createRequest(false, "sendShare", {what:p,ID:q,people:s,country:this.country,override:v,message:C}, arguments[arguments.length - 1] === J ? {} : arguments[arguments.length - 1]);
            req.promise().then(I, J);
            if (G)req.overrideHeaders.privacy = 1;
            this.country ? req.send() : this.callsPendingCountry.push(req);
            GS.guts.logEvent("itemSharePerformed", {type:p,id:q})
        },getContactInfoForFollowers:function(p, q) {
            req = c.createRequest(false, "getContactInfoForFollowers", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },artistGetSongkickEvents:function(p, q, s, v) {
            req = c.createRequest(true, "artistGetSongkickEvents", {artistID:p,name:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },getGoogleAuthToken:function(p, q, s, v) {
            req = c.createRequest(false, "getGoogleAuthToken", {Email:p,Passwd:q,source:"EscapeMG-Grooveshark-" +
                    this.clientRevision}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1], true);
            req.promise().then(s, v);
            req.send()
        },getGoogleContacts:function(p, q, s) {
            req = c.createRequest(false, "getGoogleContacts", {authToken:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
            req.promise().then(q, s);
            req.send()
        },getDetailsForBroadcast:function(p, q, s) {
            req = c.createRequest(true, "getDetailsForBroadcast", {songID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(q, s);
            req.send()
        },broadcastSong:function(p, q, s, v, C, G, I, J, K) {
            req = c.createRequest(false, "broadcastSong", {songID:p,message:q,username:s,password:v,saveCredentials:C,service:G,song:I}, arguments[arguments.length - 1] === K ? {} : arguments[arguments.length - 1], true);
            req.promise().then(J, K);
            req.send()
        },logBroadcast:function(p, q, s, v, C) {
            req = c.createRequest(false, "logBroadcast", {type:p,item:q,service:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },getUserFacebookData:function(p, q) {
            req = c.createRequest(false, "getUserFacebookDataEx", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1], true);
            req.promise().then(p, q);
            req.send()
        },saveUserFacebookData:function(p, q, s, v, C, G, I) {
            req = c.createRequest(false, "saveUserFacebookDataEx", {facebookUserID:p,sessionKey:q,accessToken1:s,accessToken3:v,flags:C}, arguments[arguments.length - 1] === I ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(G, I);
            req.send()
        },updateUserFacebookData:function(p, q, s, v, C, G, I) {
            req = c.createRequest(false, "updateUserFacebookData", {facebookUserID:p,sessionKey:q,accessToken1:s,accessToken3:v,flags:C}, arguments[arguments.length - 1] === I ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(G, I);
            req.send()
        },removeUserFacebookData:function(p, q) {
            req = c.createRequest(false, "removeUserFacebookData", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },getUserGoogleData:function(p, q) {
            req = c.createRequest(false,
                    "getUserGoogleData", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(p, q);
            req.send()
        },saveUserGoogleData:function(p, q) {
            req = c.createRequest(false, "saveUserGoogleData", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },removeUserGoogleData:function(p, q) {
            req = c.createRequest(false, "removeUserGoogleData", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },getUsernameSuggestions:function(p, q, s, v, C) {
            req = c.createRequest(true, "getUsernameSuggestions", {baseUsername:p,fullName:q,idOrRand:s}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },registerFacebookUser:function(p, q, s, v, C, G, I, J, K, M, N, L, O) {
            req = c.createRequest(false, "registerFacebookUser", {username:p,firstName:q,emailAddress:s,sex:v,birthDate:C,flags:G,inviteID:I,facebookUserID:J,sessionKey:K,accessToken1:M,accessToken3:N}, arguments[arguments.length -
                    1] === O ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(L, O);
            req.send()
        },getGroovesharkUsersFromFacebookUserIDs:function(p, q, s) {
            req = c.createRequest(false, "getGroovesharkUsersFromFacebookUserIDs", {facebookUserIDs:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },registerGoogleUser:function(p, q, s, v, C, G, I, J, K) {
            req = c.createRequest(false, "registerGoogleUser", {username:p,firstName:q,emailAddress:s,sex:v,birthDate:C,flags:G,inviteID:I},
                    arguments[arguments.length - 1] === K ? {} : arguments[arguments.length - 1], true, true);
            req.promise().then(J, K);
            req.send()
        },removeUserGoogleLogin:function(p, q) {
            req = c.createRequest(false, "removeUserGoogleLogin", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },updateLastfmService:function(p, q, s, v, C, G, I) {
            req = c.createRequest(false, "updateLastfmService", {session:p,token:q,username:s,flagsAdd:v,flagsRemove:C}, arguments[arguments.length - 1] === I ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(G, I);
            req.send()
        },getLastfmService:function(p, q) {
            req = c.createRequest(false, "getLastfmService", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },removeLastfmService:function(p, q) {
            req = c.createRequest(false, "removeLastfmService", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },getAffiliateDownloadURLs:function(p, q, s, v) {
            req = c.createRequest(false, "getAffiliateDownloadURLs",
                    {songName:p,artistName:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },getYoutubeSearchResults:function(p, q, s, v, C) {
            req = c.createRequest(true, "getYoutubeSearchResults", {query:p,options:q}, arguments[arguments.length - 1] === C ? {} : arguments[arguments.length - 1]);
            req.promise().then(v, C);
            req.send()
        },getServiceStatus:function(p, q) {
            req = c.createRequest(false, "getServiceStatus", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p,
                    q);
            req.send()
        },provideVIPFeedback:function(p, q, s, v) {
            req = c.createRequest(false, "provideVIPFeedback", {fromAddress:p,message:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.send()
        },getEmailAddress:function(p, q) {
            req = c.createRequest(false, "getEmailAddress", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },sendMobileAppSMS:function(p, q, s, v, C, G) {
            req = c.createRequest(false, "sendMobileAppSMS", {phoneNumber:p,
                platform:q,callingCode:s,country:v}, arguments[arguments.length - 1] === G ? {} : arguments[arguments.length - 1]);
            req.promise().then(C, G);
            req.send()
        },getCountryFromRequestIP:function(p, q) {
            req = c.createRequest(true, "getCountryFromRequestIP", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },artistGetSimilarArtists:function(p, q, s) {
            req = c.createRequest(true, "artistGetSimilarArtists", {artistID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length -
                    1]);
            req.promise().then(q, s);
            req.send()
        },getThemeFromDFP:function(p, q, s) {
            req = c.createRequest(false, "getThemeFromDFP", {paramString:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
            req.type = "dfp";
            req.promise().then(q, s);
            req.send()
        },getNotificationFromDFP:function(p, q, s) {
            req = c.createRequest(false, "getNotificationFromDFP", {paramString:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false, true);
            req.type = "dfp";
            req.promise().then(q, s);
            req.send()
        },getItemByPageName:function(p, q, s) {
            req = c.createRequest(true, "getItemByPageName", {name:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1]);
            req.promise().then(q, s);
            req.send()
        },getPageNameByIDType:function(p, q, s, v) {
            req = c.createRequest(true, "getPageNameByIDType", {id:p,type:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1]);
            req.promise().then(s, v);
            req.promise().then(function(C) {
                C.name && window.GS && GS.router && GS.router.cachePageName(C.name, q, p)
            });
            req.send()
        },userGetPoints:function(p, q) {
            req = c.createRequest(false,
                    "userGetPoints", {}, arguments[arguments.length - 1] === q ? {} : arguments[arguments.length - 1]);
            req.promise().then(p, q);
            req.send()
        },getClearvoiceMemberInfo:function(p, q, s) {
            var v = arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1],C = {};
            if (p)C.guid = p;
            req = c.createRequest(false, "getClearvoiceMemberInfo", C, v, true);
            req.promise().then(q, s);
            req.send()
        },getUserIDByClearvoiceEmail:function(p, q, s) {
            req = c.createRequest(false, "getUserIDByClearvoiceEmail", {email:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length -
                    1], true);
            req.promise().then(q, s);
            req.send()
        },saveClearvoiceMemberInfo:function(p, q, s, v, C, G) {
            req = c.createRequest(false, "saveClearvoiceMemberInfo", {guid:p,fName:q,lName:s,email:v}, arguments[arguments.length - 1] === G ? {} : arguments[arguments.length - 1], true);
            req.promise().then(C, G);
            req.send()
        },addClearvoiceAnswers:function(p, q, s) {
            req = c.createRequest(false, "addClearvoiceAnswers", {questionsAndAnswers:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], true);
            req.promise().then(q, s);
            req.send()
        },
        submitPlaylistForCampaign:function(p, q, s, v) {
            req = new c("submitPlaylistForCampaign", {playlistID:p,campaignID:q}, arguments[arguments.length - 1] === v ? {} : arguments[arguments.length - 1], false);
            req.promise().then(s, v);
            req.send()
        },getPlaylistsForCampaign:function(p, q, s) {
            req = new c("getPlaylistsForCampaign", {campaignID:p}, arguments[arguments.length - 1] === s ? {} : arguments[arguments.length - 1], false);
            req.promise().then(q, s);
            req.send()
        },getTunipopID:function(p, q, s, v) {
            var C = arguments[arguments.length - 1] === v ? {} : arguments[arguments.length -
                    1],G = {};
            if (q)G.brand = p; else G.artist = p;
            req = c.createRequest(true, "getTunipopID", G, C, null, true);
            req.type = "tunipop";
            req.promise().then(s, v);
            req.send()
        }})
})();
(function(a) {
    GS.Controllers.BaseController.extend("GS.Controllers.AuthController", {onWindow:true}, {init:function() {
        GS.service = GS.service || GS.Controllers.ServiceController.instance();
        if (!gsConfig.user.UserID)gsConfig.user.UserID = -1;
        this._handleLoginChange(GS.Models.AuthUser.wrap(gsConfig.user));
        this._super();
        this.subscribe("gs.auth.update", this.callback(this._onAuthUpdate))
    },appReady:function() {
        if (GS.user.UserID > 0 && GS.user.TSDOB != "" && GS.user.UserID != 42) {
            var b = new Date,c = GS.user.TSDOB.split("-"),g =
                    parseInt(c[1], 10) - 1;
            c = parseInt(c[2], 10);
            b.getMonth() == g && b.getDate() == c && GS.notice.displayPerAnum()
        }
    },login:function(b, c, g, h, k) {
        GS.service.authenticateUser(b, c, g, this.callback(this._loginSuccess, "normal", h, k), this.callback(this._loginFailed, "normal", k))
    },reauthenticate:function(b, c) {
        GS.user.UserID > 0 ? GS.service.loginStoredUser(GS.user.Email, this.callback(this._loginSuccess, "reauth", b, c), this.callback(this._loginFailed, "reauth", c)) : c({message:"Not logged in"})
    },loginViaFacebook:function(b, c) {
        GS.facebook.gsLogin(this.callback(this._loginSuccess,
                "facebook", b, c), this.callback(this._loginFailed, "facebook", c))
    },loginViaGoogle:function(b, c) {
        GS.google.login(this.callback(this._loginSuccess, "google", b, c), this.callback(this._loginFailed, "google", c))
    },_loginSuccess:function(b, c, g, h) {
        if (h && h.userID == 0 || !h)return this._loginFailed(b, g, h);
        h.authType = b;
        if (window.GS && GS.Controllers.PageController.activePageName === "surveys")h.doNotReset = true;
        b == "reauth" && h.userID === GS.user.UserID || GS.service.getUserByID(h.userID, this.callback(this._updateUser, h));
        if ((gsConfig.isPreview ||
                GS.airbridge && GS.airbridge.isDesktop) && parseInt(h.isPremium, 10) !== 1) {
            if (a.isFunction(g)) {
                h.error = "POPUP_SIGNUP_LOGIN_FORM_PREMIUM_REQUIRED_ERROR";
                g(h)
            }
        } else a.isFunction(c) && c(h);
        return h
    },_loginFailed:function(b, c, g) {
        g || (g = {});
        g.authType = b;
        b == "reauth" && this._logoutSuccess({});
        a.isFunction(c) && c(g);
        return g
    },logout:function() {
        GS.service.logoutUser(this.callback(this._logoutSuccess), this.callback(this._logoutFailed))
    },_logoutSuccess:function() {
        GS.user.clearData();
        GS.guts.logEvent("logout", {});
        GS.guts.endContext("userID");
        location.hash = "/";
        this._handleLoginChange(GS.Models.AuthUser.wrap({}))
    },_logoutFailed:function() {
    },signup:function(b, c, g, h, k, m, n, o, r, t) {
        var w = this._getInviteCode();
        GS.service.registerUser(b, c, g, "", h, k, m, n, w, o, this.callback(this._signupSuccess, "normal", w, r, t), this.callback(this._signupFailed, "normal", t))
    },signupViaFacebook:function(b, c, g, h, k, m, n, o, r) {
        var t = this._getInviteCode();
        GS.service.registerFacebookUser(b, c, g, h, k, m, t, n.facebookUserID, n.sessionKey, n.accessToken1, n.accessToken3, this.callback(this._signupSuccess,
                "facebook", t, o, r), this.callback(this._signupFailed, "facebook", r))
    },signupViaGoogle:function(b, c, g, h, k, m, n, o) {
        var r = this._getInviteCode();
        GS.service.registerGoogleUser(b, c, g, h, k, m, r, this.callback(this._signupSuccess, "google", r, n, o), this.callback(this._signupFailed, "google", o))
    },_signupSuccess:function(b, c, g, h, k) {
        if (k && k.userID == 0 || !k)return this._signupFailed(b, h, k);
        k.authType = b;
        if (c) {
            store.set("lastInviteCode", null);
            gsConfig.inviteCode = null;
            GS.service.getUserByInviteID(c, this.callback(this._getInviterSuccess))
        }
        switch (b) {
            case "facebook":
                k.Flags =
                        4;
                break;
            case "google":
                k.Flags = 32;
                break
        }
        k.doNotReset = true;
        GS.service.getUserByID(k.userID, this.callback(this._updateUser, k));
        a.isFunction(g) && g(k);
        return k
    },_signupFailed:function(b, c, g) {
        g || (g = {});
        g.authType = b;
        a.isFunction(c) && c(g);
        return g
    },_getInviteCode:function() {
        var b = "",c = new Date,g = store.get("lastInviteCode");
        if (g)if (g.expires && g.expires > c.valueOf())b = g.inviteCode; else store.set("lastInviteCode", null); else if (gsConfig.inviteCode)b = gsConfig.inviteCode;
        return b
    },_getInviterSuccess:function(b) {
        b =
                GS.Models.User.wrap(b);
        GS.lightbox.open("followInviter", {user:b})
    },_updateUser:function(b, c) {
        c.User.UserID = b.userID;
        if (!b.doNotReset)location.hash = "/";
        var g = a.extend({}, b, c.User);
        this._handleLoginChange(GS.Models.AuthUser.wrapFromService(g), b);
        a("#notifications li.survey").remove()
    },_handleLoginChange:function(b, c) {
        if (GS.user && GS.user.isDirty) {
            _.forEach(GS.user.playlists, function(h) {
                var k = [];
                _.forEach(h.songs, function(m) {
                    k.push(m.SongID)
                });
                b.createPlaylist(h.PlaylistName, k, h.Description, function(m) {
                            m.addShortcut(false)
                        },
                        null, false)
            });
            var g = _.map(GS.user.library.songs, function(h) {
                return h.SongID
            });
            b.addToLibrary(g, false);
            _.forEach(GS.user.favorites.playlists, function(h) {
                b.addToPlaylistFavorites(h.PlaylistID, false)
            });
            _.forEach(GS.user.favorites.songs, function(h) {
                b.addToSongFavorites(h.SongID, false)
            });
            _.forEach(GS.user.favorites.users, function(h) {
                b.addToUserFavorites(h.UserID, false)
            });
            _.forEach(GS.user.sidebar.stations, function(h) {
                GS.user.defaultStations.indexOf(h) == -1 && b.addToShortcuts("station", h, false)
            })
        }
        GS.user =
                b;
        GS.service.reportUserChange(GS.user.UserID, GS.user.Email, GS.user.Privacy);
        a.publish("gs.auth.update", c);
        if (!GS.user.IsPremium && (gsConfig.isPreview || GS.Controllers.AirbridgeController.instance().isDesktop)) {
            if (g = GS.Controllers.LightboxController ? GS.Controllers.LightboxController.instance() : null)g.open("login", {premiumRequired:true}); else gsConfig.lightboxOnInit = {type:"login",defaults:{premiumRequired:true}};
            GS.player && GS.player.pauseNextSong()
        }
        GS.user.isLoggedIn || a.publish("gs.auth.library.update");
        if (GS.guts && GS.user && GS.user.UserID > 0) {
            GS.guts.logEvent("login", {userID:GS.user.UserID});
            GS.guts.beginContext({userID:GS.user.UserID})
        }
    },_onAuthUpdate:function() {
        a.isFunction(this.vipUpdateCallback) && GS.user.IsPremium && this.vipUpdateCallback();
        this.vipUpdateCallback = null;
        a.isFunction(this.authUpdateCallback) && this.authUpdateCallback();
        this.authUpdateCallback = null
    }})
})(jQuery);
GS.Controllers.BaseController.extend("GS.Controllers.ThemeController", {onDocument:true,themes:themes,sortOrder:themesSortOrder,plusThemes:plusThemes,artistThemes:artistThemes,promoThemes:promoThemes}, {currentTheme:null,themes:null,sort:null,themesLocation:"themes",lastDFPChange:null,lastUserChange:null,themePreferences:null,currentSong:null,extraStations:{},personalizeParams:null,hasSeenSponsoredTheme:true,promptOnLogin:false,themePreferences:{},firstTheme:false,manualSelectThemeID:null,themeVisualizerForcedOnce:false,
    sessionStart:null,lastThemeNotification:null,themeIsReady:false,lastActivePage:null,PAGE_HOME:"home",DEFAULT_USER_THEMEID:4,DEFAULT_PREMIUM_THEMEID:4,THEME_URL_PATTERN:/^#\/(theme)\/(.*)\/?/,THEME_USER_LIMIT:6E5,THEME_RATE_LIMIT:6E4,THEME_NOTIF_RATE_LIMIT:864E5,THEME_FLAG_DEFAULT:0,THEME_FLAG_FAMILY_FRIENDLY:1,init:function() {
        this.themes = themes;
        this.sort = themesSortOrder;
        this.themePreferences = store.get("themePreferences") || {};
        this.sessionStart = (new Date).getTime();
        this.subscribe("window.resize", this.callback(this.positionTheme));
        this.subscribe("gs.auth.update", this.callback(this.onAuthUpdate));
        this.subscribe("gs.page.home.update", this.callback(this.positionTheme));
        this.subscribe("gs.player.nowplaying", this.callback(this.onSongPlay));
        this.subscribe("gs.player.streamserver", this.callback(this.onStreamServer));
        this.subscribe("gs.page.view", this.callback(this.pageView));
        this.subscribe("gs.theme.click", this.callback(this.onThemeClick));
        this.subscribe("gs.theme.playVideo", this.callback(this.playVideo));
        this._super()
    },appReady:function() {
        if (!(location.hash &&
                location.hash.match(GS.theme.THEME_URL_PATTERN)))if (GS.user.UserID > 0)this.resetTheme(); else if (_.defined(store.get("isFirstVisit")) || _.defined(gsConfig.isNoob) && !gsConfig.isNoob) {
            this.isFirstVisit = false;
            this.resetTheme()
        } else GS.service.isFirstVisit(this.callback("onIsFirstVisit"))
    },onIsFirstVisit:function(a) {
        this.isFirstVisit = a;
        store.set("isFirstVisit", false);
        if (this.isFirstVisit) {
            this.setCurrentTheme(this.DEFAULT_USER_THEMEID);
            this.trackFirstVisit()
        } else this.resetTheme()
    },onAuthUpdate:function(a) {
        if (!(a &&
                a.hasOwnProperty("doNotReset") || location.hash.indexOf("#/signup") == 0)) {
            this.lastDFPChange = this.lastUserChange = this.lastThemeNotification = null;
            this.hasSeenSponsoredTheme = true;
            if (this.promptOnLogin && GS.user.UserID > 0) {
                this.promptOnLogin = false;
                this.lastDFPChange = (new Date).getTime();
                GS.lightbox.open("promotion", {theme:this.currentTheme})
            } else!this.promptOnLogin && GS.lightbox.curType !== "promotion" && this.resetTheme()
        }
    },resetTheme:function(a) {
        if (!(a && a.hasOwnProperty("doNotReset") || location.hash.indexOf("#/signup") ==
                0 || this.isFirstVisit)) {
            a = new Date;
            !GS.user.IsPremium && this.hasSeenSponsoredTheme && (!this.lastUserChange || a.getTime() - this.lastUserChange > this.THEME_USER_LIMIT) ? this.loadFromDFP() : this.lastOrDefault()
        }
    },lastOrDefault:function() {
        var a = this.getLastTheme();
        if (this.themes) {
            if (a && themes[a] && (GS.user.IsPremium && a || themes[a] && !themes[a].premium)) {
                themes[a].pageTracking = [];
                this.setCurrentTheme(a)
            } else GS.user.IsPremium ? this.setCurrentTheme(this.DEFAULT_PREMIUM_THEMEID) : this.setCurrentTheme(this.DEFAULT_USER_THEMEID);
            this.onReady();
            this.themeNotification(GS.player.getCurrentSong())
        }
    },onReady:function() {
        if (!this.themeIsReady) {
            this.themeIsReady = true;
            GS.user.IsPremium || GS.ad.startAdTimer()
        }
    },loadFromDFPManual:function(a) {
        this.manualSelectThemeID = a;
        a = [];
        a.push("id=" + this.manualSelectThemeID);
        a.push("m=1");
        a.push("dcmt=text/json");
        a.push("sz=777x777");
        a = ";" + a.join(";");
        GS.service.getThemeFromDFP(a, this.callback("onGetThemeManual"), this.callback("onGetThemeErr"))
    },onGetThemeManual:function(a) {
        try {
            a = JSON.parse(a)
        } catch(b) {
            console.log("invalid json from DFP",
                    b);
            this.onGetThemeErr();
            return
        }
        if (a)if (this.manualSelectThemeID && this.manualSelectThemeID != a.themeID) {
            if (!this.themes[this.manualSelectThemeID]) {
                var c = this.createThemeObject(a);
                if (!c) {
                    this.lastOrDefault();
                    return
                }
            }
            this.themes[this.manualSelectThemeID].pageTracking = [];
            this.setCurrentTheme(this.manualSelectThemeID, true);
            this.onReady()
        } else {
            if (this.themes[this.manualSelectThemeID])this.themes[a.themeID].version = a.version; else {
                c = this.createThemeObject(a);
                if (!c) {
                    this.lastOrDefault();
                    return
                }
            }
            this.themes[a.themeID].clickIDs =
                    a.clickIDs;
            this.themes[a.themeID].tracking = a.tracking;
            this.themes[a.themeID].expandableTracking = a.expandableTracking;
            this.themes[a.themeID].pageTracking = a.pageTracking;
            this.themes[a.themeID].artistNotifTracking = a.artistNotifTracking;
            this.themes[a.themeID].videoLBTracking = a.videoLBTracking;
            this.themes[a.themeID].misc = a.misc;
            this.themes[a.themeID].videos = a.videos;
            this.themes[a.themeID].adSync = a.adSync === "true";
            this.themes[a.themeID].adUnSync = a.adUnSync === "true";
            c = parseFloat(a.pageHeaderFrequency);
            if (!isNaN(c))if (c ==
                    0 || Math.random() > c)this.themes[a.themeID].pageTracking = null;
            c = parseFloat(a.artistNotifFrequency);
            if (!isNaN(c))if (c == 0 || Math.random() > c)this.themes[a.themeID].artistNotifTracking = null;
            this.setCurrentTheme(a.themeID, true);
            this.themeIsReady ? this.adSync() : this.onReady();
            this.themeImpression()
        } else this.lastOrDefault()
    },loadFromDFP:function() {
        var a = new Date;
        if (!GS.user.IsPremium && (!this.lastDFPChange || a.getTime() - this.lastDFPChange > this.THEME_RATE_LIMIT))GS.service.getThemeFromDFP(this.buildParams(), this.callback("onGetTheme"),
                this.callback("onGetThemeErr"))
    },createThemeObject:function(a) {
        if (a.themeID == "-1")return false;
        try {
            var b = parseInt(a.themeID);
            this.themes[b] = {themeID:b,title:a.title,author:a.author,location:a.location,premium:a.premium === "true",sponsored:a.sponsored === "true",artistIDs:a.artistIDs,sections:a.sections,adSync:a.adSync === "true",adUnSync:a.adUnSync === "true",version:a.version}
        } catch(c) {
            console.warn("[ Invalid Theme Object ]");
            return false
        }
        return true
    },onGetTheme:function(a) {
        var b = new Date;
        if (b.getTime() -
                this.lastUserChange < this.THEME_USER_LIMIT)console.warn("[Stopped DFP Override]"); else {
            try {
                a = JSON.parse(a)
            } catch(c) {
                console.log("invalid json from DFP", c);
                this.lastOrDefault();
                return
            }
            if (a)if (this.getLastSeen(a.themeID)) {
                a.themeID == -1 && this.trackDefault();
                this.lastOrDefault()
            } else {
                if (this.themes[a.themeID])this.themes[a.themeID].version = a.version; else if (!this.createThemeObject(a)) {
                    this.lastOrDefault();
                    return
                }
                this.themes[a.themeID].clickIDs = a.clickIDs;
                this.themes[a.themeID].tracking = a.tracking;
                this.themes[a.themeID].expandableTracking =
                        a.expandableTracking;
                this.themes[a.themeID].pageTracking = a.pageTracking;
                this.themes[a.themeID].artistNotifTracking = a.artistNotifTracking;
                this.themes[a.themeID].videoLBTracking = a.videoLBTracking;
                this.themes[a.themeID].misc = a.misc;
                this.themes[a.themeID].videos = a.videos;
                this.themes[a.themeID].adSync = a.adSync === "true";
                this.themes[a.themeID].adUnSync = a.adUnSync === "true";
                var g = parseFloat(a.pageHeaderFrequency);
                if (!isNaN(g))if (g == 0 || Math.random() > g)this.themes[a.themeID].pageTracking = null;
                g = parseFloat(a.artistNotifFrequency);
                if (!isNaN(g))if (g == 0 || Math.random() > g)this.themes[a.themeID].artistNotifTracking = null;
                if (this.setCurrentTheme(a.themeID)) {
                    this.lastDFPChange = b.getTime();
                    this.themeIsReady ? this.adSync() : this.onReady();
                    if (this.currentTheme.sponsored)this.hasSeenSponsoredTheme = false;
                    this.themeImpression()
                } else this.onReady()
            } else this.lastOrDefault()
        }
    },onGetThemeErr:function() {
        if (this.manualSelectThemeID && this.manualSelectThemeID != this.currentTheme.themeID && this.themes[this.manualSelectThemeID]) {
            this.setCurrentTheme(this.manualSelectThemeID,
                    true);
            this.manualSelectThemeID = null
        } else this.lastOrDefault()
    },setCurrentTheme:function(a, b) {
        if (!this.themes[a] || this.currentTheme && this.currentTheme.themeID == a || !GS.user.IsPremium && this.themes[a].premium)return false;
        this.lastTheme = this.currentTheme;
        this.promptOnLogin = false;
        this.currentTheme = GS.Models.Theme.wrap(this.themes[a]);
        this.renderTheme();
        if (b) {
            this.hasSeenSponsoredTheme = true;
            this.setLastTheme(a);
            if (this.lastTheme)this.setLastSeen(this.lastTheme.themeID); else this.lastUserChange = (new Date).getTime()
        }
        if (!this.firstTheme) {
            GS.guts.gaTrackEvent("themes",
                    "firstTheme", a);
            this.firstTheme = "" + a
        }
        GS.guts.gaTrackEvent("themes", "change", a);
        return true
    },setLastTheme:function(a) {
        if (this.themePreferences[GS.user.UserID])this.themePreferences[GS.user.UserID].lastTheme = a; else this.themePreferences[GS.user.UserID] = {lastTheme:a,lastSeen:{}}
    },setLastSeen:function(a) {
        var b = new Date;
        this.lastUserChange = b.getTime();
        if (this.themePreferences[GS.user.UserID])this.themePreferences[GS.user.UserID].lastSeen[a] = b.getTime()
    },getLastTheme:function() {
        return this.themePreferences[GS.user.UserID] &&
                this.themePreferences[GS.user.UserID].lastTheme ? this.themePreferences[GS.user.UserID].lastTheme : null
    },getLastSeen:function(a) {
        return this.themePreferences[GS.user.UserID] && this.themePreferences[GS.user.UserID].lastSeen[a] ? this.themePreferences[GS.user.UserID].lastSeen[a] : null
    },renderTheme:function() {
        if (this.currentTheme) {
            $("#themeStyleSheet").attr("href", [gsConfig.assetHost,this.themesLocation,this.currentTheme.location,"theme.css"].join("/") + "?ver=" + this.currentTheme.version);
            $(".theme_component").html("").removeClass("active");
            for (var a = 0; a < this.currentTheme.sections.length; a++)this.renderSection(this.currentTheme.sections[a]);
            this.positionTheme();
            $(window).resize();
            if (window.location.hash !== "#/" && window.location.hash !== "" && window.location.hash.toString().indexOf("#/theme") != 0 && window.location.hash.toString().indexOf("#/sessions") != 0) {
                $("#theme_home object").hide();
                if (window.location.hash.toString().indexOf("#/signup") != 0)if (this.currentTheme.pageTracking) {
                    $("#theme_page_header.active").css("display", "block");
                    this.loadTracking(this.currentTheme.pageTracking)
                }
                this.currentTheme.artistIDs &&
                this.themeNotification(GS.player.getCurrentSong())
            }
        }
    },renderSection:function(a) {
        if (this.currentTheme && a.length && $(a).length) {
            var b = [this.themesLocation,this.currentTheme.location];
            b.push(a.substr(7, a.length));
            b = b.join("/");
            $(a).html(this.view(b)).addClass("active");
            if (a === "#theme_page_header" || a === "#theme_page_header_expandable")$(a).prepend($("<div class='border'></div>"));
            this.currentTheme.bindAssets(a)
        }
    },positionTheme:function() {
        var a;
        if (this.currentTheme && this.currentTheme.sections)for (var b =
                0; b < this.currentTheme.sections.length; b++) {
            a = this.currentTheme.sections[b];
            this.currentTheme.position(a)
        }
    },themeNotification:function(a) {
        a = _.orEqual(a, this.currentSong);
        var b = new Date;
        if (a && this.currentTheme.artistIDs && window.location.hash !== "#/" && window.location.hash !== "")for (var c,g = 0; g < this.currentTheme.artistIDs.length; g++) {
            c = this.currentTheme.artistIDs[g];
            if (c == a.ArtistID && this.currentTheme.artistNotifTracking && (!this.lastThemeNotification || b.getTime() - this.lastThemeNotification > this.THEME_NOTIF_RATE_LIMIT)) {
                this.lastThemeNotification =
                        b.getTime();
                GS.notice.displayThemeArtistNotification(a, this.currentTheme);
                break
            }
        }
    },onSongPlay:function(a) {
        if (a && a.SongID) {
            if (!this.currentSong || this.currentSong.SongID != a.SongID) {
                this.currentSong = a;
                this.canCallAdServer() ? this.loadFromDFP() : this.themeNotification(a)
            }
        } else this.currentSong = null
    },onStreamServer:function(a) {
        if (document.visualizerTheme && document.visualizerTheme.loadCrossdomain) {
            document.visualizerTheme.loadCrossdomain(a.streamServer);
            if (!this.themeVisualizerForcedOnce)if (document.visualizerTheme &&
                    document.visualizerTheme.visualizerForceStart) {
                document.visualizerTheme.visualizerForceStart();
                this.themeVisualizerForcedOnce = true
            }
        }
    },pageView:function(a) {
        if (!(!this.currentTheme && !this.themeIsReady || !this.lastActivePage))switch (a) {
            case "home":
                this.positionTheme();
                this.hasAdSyncUnSync() && this.adSync();
                this.themeImpression();
                break;
            default:
                this.canCallAdServer() && this.loadFromDFP();
                this.hasAdSyncUnSync() && this.lastActivePage == this.PAGE_HOME && this.adUnSync();
                this.themePageImpression();
                break
        }
        this.lastActivePage =
                a
    },canCallAdServer:function() {
        return!GS.user.IsPremium && this.hasSeenSponsoredTheme && (!this.lastUserChange || (new Date).getTime() - this.lastUserChange > this.THEME_USER_LIMIT)
    },themeImpression:function() {
        if (this.currentTheme && this.themeIsReady && this.currentTheme.sponsored) {
            this.hasSeenSponsoredTheme = true;
            GS.service.logTargetedThemeImpression(this.currentTheme.themeID);
            this.loadTracking(this.currentTheme.tracking)
        }
    },themePageImpression:function() {
        this.currentTheme && this.themeIsReady && this.currentTheme.sponsored &&
                $("#theme_page_header").is(".active:visible") && this.loadTracking(this.currentTheme.pageTracking)
    },loadTracking:function(a) {
        if ($.isArray(a)) {
            var b = (new Date).valueOf(),c;
            _.forEach(a, function(g) {
                g += g.indexOf("?") != -1 ? "&" + b : "?" + b;
                c = new Image;
                $("body").append($(c).load(
                        function(h) {
                            $(h.target).remove()
                        }).css("visibility", "hidden").attr("src", g))
            })
        }
    },trackDefault:function() {
        this.loadTracking(["http://ad.doubleclick.net/ad/grooveshark.wall/;id=-1;d=1;sz=1x1;ord="])
    },trackFirstVisit:function() {
        this.loadTracking(["http://ad.doubleclick.net/ad/grooveshark.wall/;id=-1;v=1;sz=1x1;ord="])
    },
    adSync:function() {
        if (this.currentTheme.misc && this.currentTheme.misc.adSync || this.currentTheme.adSync)GS.ad.startAdTimer()
    },adUnSync:function() {
        if (this.currentTheme.misc && this.currentTheme.misc.adUnSync || this.currentTheme.adUnSync)GS.ad.startAdTimer()
    },hasAdSyncUnSync:function() {
        return this.currentTheme.misc && this.currentTheme.misc.adSync && this.currentTheme.misc.adUnSync || this.currentTheme.adSync && this.currentTheme.adUnSync
    },onThemeClick:function(a) {
        a && a.currentTarget && this.currentTheme && this.currentTheme.handleClick(a)
    },
    savePreferences:function() {
        try {
            store.set("themePreferences", this.themePreferences)
        } catch(a) {
        }
    },buildParams:function() {
        var a = [];
        this.currentSong && a.push("2=" + this.currentSong.ArtistID);
        if (GS.user.isLoggedIn) {
            if (GS.user.Sex)a.push("1=" + (GS.user.Sex.toLowerCase() == "m" ? "0" : "1"));
            if (GS.user.TSDOB) {
                var b = GS.user.TSDOB.split("-");
                if (b.length == 3) {
                    var c = new Date,g = c.getFullYear() - parseInt(b[0], 10);
                    if (parseInt(b[1], 10) > c.month)g -= 1; else if (parseInt(b[1], 10) == c.month && parseInt(b[2], 10) > c.date)g -= 1;
                    var h;
                    if (g >=
                            13 && g < 18)h = "13-17"; else if (g >= 18 && g < 25)h = "18-24"; else if (g >= 25 && g < 35)h = "25-34"; else if (g >= 35 && g < 50)h = "35-49"; else if (g >= 50)h = "50-";
                    g >= 21 && a.push("a=1");
                    h && a.push("0=" + h)
                }
            }
        }
        a.push("3=" + Math.round(((new Date).getTime() - this.sessionStart) / 1E3));
        a.push("4=" + GS.ad.rotationCount);
        a.push("5=" + ((GS.user.settings.local.themeFlags & this.THEME_FLAG_FAMILY_FRIENDLY) == this.THEME_FLAG_FAMILY_FRIENDLY ? 1 : 0));
        a.push("dcmt=text/json");
        a.push("sz=777x777");
        if (!GS.user.IsPremium && !GS.user.isLoggedIn && store.get("webvisit") &&
                store.get("webvisit").theme)a = a.concat(store.get("webvisit").theme);
        return";" + a.join(";")
    },playVideo:function(a) {
        if (this.currentTheme) {
            index = _.orEqual(a.index, 0);
            GS.lightbox.open("video", {video:this.currentTheme.videos[index],videos:this.currentTheme.videos,index:index})
        }
    }});
GS.Controllers.BaseController.extend("GS.Controllers.NotificationsController", {onDocument:true}, {displayDuration:5E3,queue:[],seenArtistNotifications:[],currentArtistFeedback:null,currentFacebookNotification:null,currentFavoritedNotification:null,currentLibraryAddedNotification:null,currentSurveyQuestion:null,currentSurveyInvitation:null,sawSignupNotification:false,feedbackOnNextSong:false,currentPromotion:null,lastPromoNotification:null,PROMO_NOTIF_RATE_LIMIT:432E5,init:function() {
    this.subscribe("gs.notification",
            this.callback("displayMessage"));
    this.subscribe("gs.player.nowplaying", this.callback("onSongPlay"));
    this.subscribe("gs.player.restorequeue", this.callback("displayRestoreQueue"));
    this.subscribe("gs.facebook.notification.override", this.callback("displayFacebookRateLimit"));
    this.subscribe("gs.facebook.notification.sent", this.callback("displayFacebookSent"));
    this.subscribe("gs.facebook.notification.removed", this.callback("displayFacebookUndoPost"));
    this.subscribe("gs.notification.favorite.song", this.callback("displayFavoritedObject",
            "song"));
    this.subscribe("gs.notification.favorite.playlist", this.callback("displayFavoritedObject", "playlist"));
    this.subscribe("gs.notification.favorite.user", this.callback("displayFavoritedObject", "user"));
    this.subscribe("gs.notification.playlist.create", this.callback("displayFavoritedObject", "newPlaylist"));
    this.subscribe("gs.auth.library.songsAdded", this.callback("displayLibraryAddedObject"));
    this.subscribe("gs.facebook.notification.connect", this.callback(this.displayFacebookConnect));
    this.subscribe("gs.facebook.notification.songComment",
            this.callback(this.displayFacebookSongComment));
    this.subscribe("gs.facebook.notification.findFriends", this.callback(this.displayFacebookFindFriends));
    this._super()
},onSongPlay:function(a) {
    if (a && (this.feedbackOnNextSong || a.sponsoredAutoplayID)) {
        this.feedbackOnNextSong = false;
        if (this.seenArtistNotifications.indexOf(a.ArtistID) === -1) {
            this.seenArtistNotifications.push(a.ArtistID);
            this.displayArtistFeedback(a)
        }
    } else this.getPromoNotifFromDFP(a);
    if (!this.sawSignupNotification && GS.user.UserID <= 0 && GS.ad.lastActive &&
            GS.player.player) {
        a = (new Date).valueOf() - GS.ad.lastActive.valueOf();
        var b = GS.player.player.getCulmulativeListenTime();
        if (!b.firstVisit && a < 6E4 && b.seconds > 300) {
            this.sawSignupNotification = true;
            this.setNotificationTimeout(this._addNotification("signupNotification", {controller:this}))
        }
    }
},displayMessage:function(a) {
    var b;
    if (a.uniqueInstance)b = $("#notification_" + a.uniqueInstance);
    if (!b || b.length === 0)b = this._addNotification("notification", {controller:this,notification:a});
    a.manualClose || this.setNotificationTimeout(b,
            typeof a.displayDuration != "undefined" ? a.displayDuration : null)
},getPromoNotifFromDFP:function(a) {
    var b = new Date;
    if (!this.lastPromoNotification || b.getTime() - this.lastPromoNotification > this.PROMO_NOTIF_RATE_LIMIT) {
        this.lastPromoNotification = b.getTime();
        GS.service.getNotificationFromDFP(this.buildParams(a), this.callback("displayPromotion"), this.callback("displayPromotionErr"))
    }
},buildParams:function(a) {
    var b = [];
    b.push("notif=1");
    if (GS.theme && GS.theme.currentTheme) {
        var c = parseInt(GS.theme.currentTheme.themeID,
                10);
        c && b.push("ThemeID=" + c)
    }
    a && b.push("2=" + a.ArtistID);
    if (GS.user.isLoggedIn) {
        if (GS.user.Sex)b.push("1=" + (GS.user.Sex.toLowerCase() == "m" ? "0" : "1"));
        if (GS.user.TSDOB) {
            a = GS.user.TSDOB.split("-");
            if (a.length == 3) {
                c = new Date;
                var g = c.getFullYear() - parseInt(a[0], 10);
                if (parseInt(a[1], 10) > c.month)g -= 1; else if (parseInt(a[1], 10) == c.month && parseInt(a[2], 10) > c.date)g -= 1;
                var h;
                if (g >= 13 && g < 18)h = "13-17"; else if (g >= 18 && g < 25)h = "18-24"; else if (g >= 25 && g < 35)h = "25-34"; else if (g >= 35 && g < 50)h = "35-49"; else if (g >= 50)h = "50-";
                h && b.push("0=" + h)
            }
        }
    }
    b.push("3=" + Math.round(((new Date).getTime() - GS.theme.sessionStart) / 1E3));
    b.push("4=" + GS.ad.rotationCount);
    b.push("dcmt=text/json");
    b.push("sz=777x777");
    if (!GS.user.IsPremium && !GS.user.isLoggedIn && store.get("webvisit") && store.get("webvisit").theme)b = b.concat(store.get("webvisit").theme);
    return";" + b.join(";")
},displayPromotion:function(a) {
    try {
        a = JSON.parse(a)
    } catch(b) {
        console.log("invalid json from DFP", b);
        return
    }
    if (!this.currentPromotion && a.tracking) {
        if ($.isArray(a.tracking)) {
            var c =
                    (new Date).valueOf(),g = $("body"),h;
            _.forEach(a.tracking, function(r) {
                r += r.indexOf("?") != -1 ? "&" + c : "?" + c;
                h = new Image;
                g.append($(h).load(
                        function(t) {
                            $(t.target).remove()
                        }).css("visibility", "hidden").attr("src", r))
            })
        }
        var k = 0,m = 15E3;
        if (a.notif_delay && a.notif_delay.length)try {
            k = Math.max(0, Math.min(15E3, parseInt(a.notif_delay)))
        } catch(n) {
        }
        if (a.notif_duration && a.notif_duration.length)try {
            m = Math.max(0, Math.min(15E3, parseInt(a.notif_duration)))
        } catch(o) {
        }
        setTimeout(this.callback(function() {
            this.currentPromotion =
                    this._addNotification("promotionalNotification", {controller:this,notifData:a}).data("notifData", a);
            this.setNotificationTimeout(this.currentPromotion, m)
        }), k)
    }
},displayPromotionErr:function() {
    console.warn("Promotional Notification Error")
},displayArtistFeedback:function(a) {
    if (!this.currentArtistFeedback) {
        this.currentArtistFeedback = this._addNotification("artistNotification", {controller:this,feedbackSong:a}).data("song", a);
        this.setNotificationTimeout(this.currentArtistFeedback, 15E3)
    }
},displaySurveyQuestion:function(a) {
    a =
            _.orEqual(a, {});
    var b = (new Date).getTime(),c = store.get("gs.surveys.lastQuestionClosedTime" + GS.user.UserID);
    if (!(store.get("gs.surveys.notificationAnswerClosed" + GS.user.UserID) >= 3 && b - c < 2592E6 || c && b - c < 36E5))if (!$("#page_content").is(".surveyPage")) {
        if (!this.currentSurveyQuestion) {
            this.currentSurveyQuestion = this._addNotification("surveyQuestion", {controller:this,question:a.question,questionIndex:a.questionIndex});
            this.currentSurveyQuestion.data("question", a.question).data("callback", a.callback).data("questionIndex",
                    a.questionIndex);
            this.setNotificationTimeout(this.currentSurveyQuestion, 6E4)
        }
        $("#selectbox_surveyNotificationAnswer span").html($("select.selection_survey option:selected").html())
    }
},"li.notification form.survey submit":function(a, b) {
    b.preventDefault();
    if (this.currentSurveyQuestion) {
        var c = this.currentSurveyQuestion.data("question"),g = this.currentSurveyQuestion.data("questionIndex");
        if ($.isFunction(this.currentSurveyQuestion.data("callback"))) {
            if ($("[name=" + c.DemographicTypeId + "]", a).val() !== "--") {
                try {
                    this.currentSurveyQuestion.data("callback")(c,
                            $("[name=" + c.DemographicTypeId + "]", a).val(), g)
                } catch(h) {
                    console.warn("error answering question", c);
                    console.warn(h)
                }
                this._removeNotification(this.currentSurveyQuestion);
                this.currentSurveyQuestion = false
            }
        } else console.warn("bad survey callback", this.currentSurveyQuestion.data("callback"))
    }
    return false
},"li.notification.survey button.startNow click":function() {
    if (this.currentSurveyAvailable) {
        var a = this.currentSurveyAvailable.data("survey");
        a && GS.lightbox.open("startSurvey", {survey:a});
        this._removeNotification(this.currentSurveyAvailable);
        this.currentSurveyAvailable = false
    }
},"li.notification.survey .close click":function(a) {
    if (this.currentSurveyQuestion && a.parents("li.notification").is(".invitation")) {
        var b = this.currentSurveyQuestion.data("question");
        this.currentSurveyQuestion.data("callback") && this.currentSurveyQuestion.data("callback")(b, 0)
    }
    if (a.parents("li.notification").is(".question")) {
        a = _.orEqual(store.get("gs.surveys.notificationAnswerClosed" + GS.user.UserID), 0);
        a++;
        store.set("gs.surveys.notificationAnswerClosed" + GS.user.UserID,
                a);
        store.set("gs.surveys.lastQuestionClosedTime" + GS.user.UserID, (new Date).getTime())
    } else if (a.parents("li.notification").is(".invitation")) {
        a = _.orEqual(store.get("gs.surveys.notificationInvitationClosed" + GS.user.UserID), 0);
        a++;
        store.set("gs.surveys.notificationInvitationClosed" + GS.user.UserID, a);
        store.set("gs.surveys.lastInvitationClosedTime" + GS.user.UserID, (new Date).getTime())
    } else if (a.parents("li.notification").is(".available")) {
        a = _.orEqual(store.get("gs.surveys.notificationAvailableClosed" +
                GS.user.UserID), 0);
        a++;
        store.set("gs.surveys.notificationAvailableClosed" + GS.user.UserID, a);
        store.set("gs.surveys.lastAvailableClosedTime" + GS.user.UserID, (new Date).getTime())
    }
},displaySurveyInvitation:function() {
    store.set("gs.surveys.hasSeenInvitation" + GS.user.UserID, 1);
    var a = (new Date).getTime(),b = store.get("gs.surveys.lastInvitationClosedTime" + GS.user.UserID);
    if (!(store.get("gs.surveys.notificationInvitationClosed" + GS.user.UserID) >= 3 && a - b < 2592E6 || b && a - b < 36E5))if (!$("#page_content").is(".surveyPage"))if (!this.currentSurveyInvitation) {
        this.currentSurveyInvitation =
                this._addNotification("surveyInvitation", {controller:this});
        this.setNotificationTimeout(this.currentSurveyInvitation, 6E4)
    }
},"li.notification.survey button.surveyStart click":function() {
    if (this.currentSurveyInvitation) {
        location.hash = "/surveys";
        this._removeNotification(this.currentSurveyInvitation);
        this.currentSurveyInvitation = false
    }
},displaySurveysAvailable:function(a) {
    var b = (new Date).getTime(),c = store.get("gs.surveys.lastAvailableClosedTime" + GS.user.UserID);
    if (!(store.get("gs.surveys.notificationAvailableClosed" +
            GS.user.UserID) >= 3 && b - c < 2592E6 || c && b - c < 36E5))if (!this.currentSurveyAvailable) {
        this.currentSurveyAvailable = this._addNotification("surveyAvailable", {controller:this,survey:a}).data("survey", a);
        this.setNotificationTimeout(this.currentSurveyAvailable, 6E4)
    }
},displaySurveyPoints:function(a) {
    this.setNotificationTimeout(this._addNotification("surveyPoints", {controller:this,points:a}), 15E3)
},displaySurveyAnswerError:function(a) {
    this.setNotificationTimeout(this._addNotification("surveyAnswerError", {controller:this,
        errorCode:a}))
},"button.redeemPoints click":function(a) {
    location.hash = "/surveys";
    this._removeNotification(a.parents("li.notification.survey.points"))
},displaySurveyProfilersComplete:function() {
    this.setNotificationTimeout(this._addNotification("surveyProfilersComplete", {controller:this}))
},displayPerAnum:function() {
    this._addNotification("perAnum", {controller:this})
},displayThemeArtistNotification:function(a, b) {
    this.currentArtistFeedback && this.currentArtistFeedback.remove();
    this.feedbackSong = a;
    GS.theme.lastDFPChange =
            (new Date).getTime() + 15E3;
    this.currentArtistFeedback = this._addNotification("themes/" + b.location + "/artist_notification").data("song", a);
    this.setNotificationTimeout(this.currentArtistFeedback, 15E3)
},"li.notification a.theme_link click":function(a, b) {
    b.index = parseInt($(a).attr("data-video-index"), 10);
    GS.theme.currentTheme.handleClick(b);
    GS.theme.lastDFPChange = (new Date).getTime();
    if ($(a).attr("data-click-action")) {
        this._removeNotification($(a).closest("li.notification"));
        this.currentArtistFeedback = null
    }
},
    displayLibraryAddedObject:function(a) {
        var b = {controller:this},c;
        if (a.songs) {
            if (a.songs.length == 1) {
                b.msgKey = "NOTIF_LIBRARY_ADDED_SONG";
                b.msgData = a.songs[0];
                c = "song"
            } else {
                b.msgKey = "NOTIFICATION_LIBRARY_ADD_SONGS";
                b.msgData = {numSongs:a.songs.length};
                c = "songs"
            }
            this.currentLibraryAddedNotification = this._addNotification("libraryAddedNotification", b).data("object", a.songs[0]).data("type", c);
            this.setNotificationTimeout(this.currentLibraryAddedNotification)
        }
    },displayFavoritedObject:function(a, b) {
        if (b) {
            if (this.currentLibraryAddedNotification &&
                    this.currentLibraryAddedNotification.data("type") == a) {
                var c = this.currentLibraryAddedNotification.data("object");
                a == "song" && _.orEqual(b.songID, b.SongID) == _.orEqual(c.SongID, c.songID) && this._removeNotification(this.currentLibraryAddedNotification)
            }
            c = {controller:this,type:a};
            switch (a) {
                case "playlist":
                    c.msgKey = "NOTIF_SUBSCRIBED_PLAYLIST";
                    c.msgData = {playlistName:b.PlaylistName};
                    break;
                case "song":
                    c.msgKey = "NOTIF_FAVORITED_SONG";
                    c.msgData = {songName:_.orEqual(b.SongName, b.songName),artistName:_.orEqual(b.ArtistName,
                            b.artistName)};
                    break;
                case "user":
                    if (b.Username) {
                        c.msgKey = "NOTIF_FOLLOWED_USER";
                        c.msgData = {userName:b.Name}
                    } else {
                        c.msgKey = "NOTIF_FOLLOWED_USERS";
                        c.msgData = {}
                    }
                    break;
                case "newPlaylist":
                    c.msgKey = "NOTIF_CREATED_PLAYLIST";
                    c.msgData = {playlistName:b.PlaylistName};
                    break
            }
            this.currentFavoritedNotification = this._addNotification("favoriteNotification", c).data("object", b).data("type", a);
            this.setNotificationTimeout(this.currentFavoritedNotification)
        }
    },"li.notification .favorited button.shareWithFacebook click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).closest("li.notification");
        $("button.shareWithFacebook", c).hide();
        $("div.facebookShare", c).show();
        $(a).closest("li.notification").removeClass("notification_success").addClass("notification_form");
        $("div.content", c).prepend('<img src="/webincludes/images/notifications/facebook.png" />');
        $("div.content p", c).addClass("hasIcon");
        var g = $("#fb_share_message", c);
        g.focus(this.callback(function() {
            g.val() == $.localize.getString("NOTIF_SHARE_PREFILL_MSG") && g.val("")
        }));
        g.focusout(this.callback(function() {
            g.val() == "" && g.val($.localize.getString("NOTIF_SHARE_PREFILL_MSG"))
        }));
        return false
    },"li.notification .favorited button.shareWithFacebookSubmit click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).closest("li.notification"),g = $(c).data("object"),h = $(c).data("type"),k = $("#fb_share_message", c).val();
        if (k == $.localize.getString("NOTIF_SHARE_PREFILL_MSG"))k = "";
        console.log("sharing to facebook: ", h, g, k);
        switch (h) {
            case "song":
                GS.facebook.onFavoriteSong(g, k);
                break;
            case "playlist":
                GS.facebook.onSubscribePlaylist(g, k);
                break;
            case "newPlaylist":
                GS.facebook.onPlaylistCreate(g, k);
                break;
            case "user":
                GS.facebook.onFollowUser(g, k);
                break
        }
        this._removeNotification(c);
        return false
    },displayFacebookRateLimit:function(a) {
        if (a) {
            $("#notifications li.facebook").remove();
            this.currentFacebookNotification = this._addNotification("facebookRateLimitNotification", {controller:this,type:a.type}).data("params", a);
            this.setNotificationTimeout(this.currentFacebookNotification)
        }
    },"li.notification .facebook button.override click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).closest("li.notification"),g = $(c).data("params");
        GS.facebook.postEvent(g, true);
        this._removeNotification(c);
        return false
    },displayFacebookSent:function(a) {
        if (a && a.params && a.data) {
            $("#notifications li.facebook").remove();
            this.currentFacebookNotification = this._addNotification("facebookPostNotification", {controller:this,type:a.params.type,hideUndo:a.params.hideUndo}).data("data", a.data);
            this.setNotificationTimeout(this.currentFacebookNotification)
        }
    },"li.notification .facebook button.undo click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).closest("li.notification"),g = $(c).data("data");
        console.log("facebook.params", g);
        GS.facebook.removeEvent(g, true);
        this._removeNotification(c);
        return false
    },"li.notification .facebook a.resetPerms click":function(a, b) {
        b.stopImmediatePropagation();
        GS.lightbox.open("reAuthFacebook");
        this._removeNotification($(a).closest("li.notification"));
        return false
    },displayFacebookUndoPost:function(a) {
        if (a) {
            $("#notifications li.facebook").remove();
            this.currentFacebookNotification =
                    this._addNotification("facebookUndoPostNotification", {controller:this}).data("data", a);
            this.setNotificationTimeout(this.currentFacebookNotification)
        }
    },"li.notification form.artistFeedback button click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).attr("data-vote"),g = this.currentArtistFeedback.find("textarea").val(),h = this.currentArtistFeedback.data("song");
        this.feedbackSong = h;
        g && g.length && GS.service.provideSongFeedbackMessage(h.SongID, g);
        GS.service.provideSongFeedbackVote(h.SongID, c, h.ArtistID,
                this.callback("onArtistFeedback", c), this.callback("onArtistFeebackFail"));
        return false
    },displayFacebookConnect:function() {
        $("#notifications li.facebook").remove();
        this.currentFacebookNotification = this._addNotification("facebookConnectNotification", {controller:this});
        this.setNotificationTimeout(this.currentFacebookNotification, 1E4)
    },"#fbNotifConnect-btn click":function(a) {
        GS.facebook.login(function() {
        }, this.callback("fbConnectErrback"));
        this._removeNotification($(a).closest("li.notification"))
    },fbConnectErrback:function(a) {
        if (typeof a ==
                "object" && a.error)a = a.error;
        this.setNotificationTimeout(this._addNotification("notification", {controller:this,notification:{type:"error",message:$.localize.getString(a)}}), 5E3)
    },displayFacebookFindFriends:function(a, b) {
        $("#notifications li.facebook").remove();
        this.currentFacebookNotification = this._addNotification("facebookFindFriendsNotification", {controller:this,message:a,inviteFriends:b});
        this.setNotificationTimeout(this.currentFacebookNotification, 1E4)
    },"a.findFriends click":function(a, b) {
        if (b.which) {
            GS.facebook.getGroovesharkUsersFromFriends();
            this._removeNotification($(a).closest("li.notification"))
        }
    },"a.inviteFriends click":function(a, b) {
        if (b.which) {
            GS.lightbox.open("invite");
            this._removeNotification($(a).closest("li.notification"))
        }
    },displayFacebookSongComment:function() {
        $("#notifications li.facebook").remove();
        this.currentFacebookNotification = this._addNotification("facebookSongCommentNotification", {controller:this});
        this.setNotificationTimeout(this.currentFacebookNotification, 1E4)
    },"a.songLink click":function(a) {
        (a = parseInt($(a).attr("rel"),
                10)) && GS.Models.Song.getSong(a, function(b) {
            if (b)location.hash = b.toUrl()
        })
    },onArtistFeedback:function(a, b) {
        var c = {controller:this,feedbackSong:this.currentArtistFeedback.data("song")};
        if (b.success && a == 2) {
            c.urls = b.urls;
            this.currentArtistFeedback.find(".content").html(this.view("artistNotificationResult", c));
            _.isEmpty(b.urls) && this.setNotificationTimeout(this.currentArtistFeedback, this.displayDuration, true)
        } else {
            this._removeNotification(this.currentArtistFeedback);
            this.currentArtistFeedback = null
        }
    },onArtistFeedbackFail:function() {
        this._removeNotification(this.currentArtistFeedback);
        this.currentArtistFeedback = null
    },"li.notification.artist a.close click":function(a) {
        this._removeNotification($(a).closest("li.notification"));
        this.currentArtistFeedback = null
    },displayRestoreQueue:function() {
        console.log("display restore queue");
        this.setNotificationTimeout(this._addNotification("restoreQueue", {controller:this}))
    },focusInText:false,mouseOut:false,setNotificationTimeout:function(a, b, c) {
        b = _.orEqual(b, this.displayDuration);
        if (!c) {
            $(a).mouseout(this.callback(function() {
                this.mouseOut = true;
                this.focusInText || this.setNotificationTimeout(a, b, true)
            }));
            $(a).mouseover(this.callback(function() {
                this.mouseOut = false;
                this.clearNotificationTimeout(a)
            }));
            $("textarea", a).focus(this.callback(function() {
                this.focusInText = true;
                this.clearNotificationTimeout(a)
            }));
            $("textarea", a).focusout(this.callback(function() {
                this.focusInText = false;
                this.mouseOut && this.setNotificationTimeout(a, b, true)
            }))
        }
        a.timer && this.clearNotificationTimeout(a);
        a.timer = setTimeout(this.callback(function() {
            this.hideNotification(a)
        }),
                b)
    },clearNotificationTimeout:function(a) {
        clearTimeout(a.timer)
    },hideNotification:function(a) {
        if (this.currentArtistFeedback == a)this.currentArtistFeedback = null; else if (this.currentPromotion == a)this.currentPromotion = null;
        this._removeNotification(a)
    },"li.notification a.close click":function(a) {
        this._removeNotification($(a).closest("li.notification"))
    },"li.notification .cancel click":function(a) {
        this._removeNotification($(a).closest("li.notification"))
    },"form.feedback submit":function() {
        console.log("submit song feedback");
        return false
    },"li.notification .loginCTA click":function(a) {
        this._removeNotification($(a).closest("li.notification"));
        GS.lightbox.open("login")
    },"li.notification .signupCTA click":function(a) {
        this._removeNotification($(a).closest("li.notification"));
        location.hash = "#/signup"
    },"li.notification.restoreQueue .restore click":function(a) {
        this._removeNotification($(a).closest("li.notification"));
        GS.player.restoreQueue()
    },"li.notification.restoreQueue a.settings click":function(a) {
        if (GS.user.isLoggedIn)location.hash =
                "/settings"; else GS.lightbox.open("login");
        this._removeNotification($(a).closest("li.notification"))
    },"input focus":function(a) {
        $(a).parent().parent().addClass("active")
    },"textarea focus":function(a) {
        $(a).parent().parent().parent().addClass("active")
    },"input blur":function(a) {
        $(a).parent().parent().removeClass("active")
    },"textarea blur":function(a) {
        $(a).parent().parent().parent().removeClass("active")
    },"select focus":function(a) {
        a.parents(".input_wrapper").addClass("active");
        a.change()
    },"select blur":function(a) {
        a.parents(".input_wrapper").removeClass("active");
        a.change()
    },"select keydown":function(a) {
        a.change()
    },"select change":function(a) {
        a.siblings("span").html(a.find("option:selected").html())
    },_addNotification:function(a, b) {
        b = _.orEqual(b, this);
        $("#notifications").append(this.view(a, b));
        return $("#notifications li.notification").last().hide().slideDown("fast")
    },_removeNotification:function(a) {
        $(a).stop().slideUp("fast", function() {
            $(a).remove()
        })
    }});
GS.Controllers.BaseController.extend("GS.Controllers.HeaderController", {onElement:"#header"}, {init:function() {
    this.subscribe("gs.auth.update", this.callback("update"));
    this.subscribe("gs.auth.update.surveys", this.callback("update"));
    this.subscribe("gs.auth.user.feeds.update", this.callback("updateFeedCount"));
    this.subscribe("gs.router.history.change", this.callback("updateNavButtons"));
    this._super()
},appReady:function() {
    this.update()
},update:function() {
    this.user = GS.user;
    this.isDesktop = GS.airbridge ? GS.airbridge.isDesktop :
            false;
    if (GS.user.isLoggedIn) {
        $("#nav").html(this.view("navLoggedIn"));
        $("#userOptions").html(this.view("loggedIn"))
    } else {
        $("#nav").html(this.view("navLoggedOut"));
        $("#userOptions").html(this.view("loggedOut"))
    }
    this.updateNavButtons()
},updateFeedCount:function() {
    this.user = GS.user;
    this.isDesktop = GS.airbridge ? GS.airbridge.isDesktop : false;
    GS.user.isLoggedIn ? $("#nav").html(this.view("navLoggedIn")) : $("#nav").html(this.view("navLoggedOut"));
    this.updateNavButtons()
},updateNavButtons:function() {
    if (GS.router) {
        $("button.back",
                this.element).attr("disabled", !GS.router.hasBack);
        $("button.forward", this.element).attr("disabled", !GS.router.hasForward)
    }
},"#grooveshark click":function() {
    if ($("#page").is(".gs_page_home")) {
        $("input.search.autocomplete", "#page").blur();
        $("#searchBar_input input").val() == "" && $("#searchBar_input span").show()
    } else setTimeout(function() {
        $("input.search.autocomplete", "#page").blur()
    }, 0)
},"#headerSearchBtn mousedown":function() {
    if ($("#page").is(".gs_page_home")) {
        $("input.search.autocomplete", "#page").focus();
        $("#searchBar_input input").val() == "" && $("#searchBar_input span").show().addClass("faded");
        $("#searchBar_input input").addClass("focused")
    } else var a = $.subscribe("gs.page.home.view", function() {
        setTimeout(function() {
            $("input.search.autocomplete", "#page").focus()
        }, 0);
        $("#searchBar_input span").show();
        $.unsubscribe(a)
    })
},"button.forward click":function() {
    GS.router.forward()
},"button.back click":function() {
    GS.router.back()
},"#header_login click":function(a) {
    $(a).toggleClass("active");
    $("#dropdown_loginForm_box").toggle();
    if ($("#dropdown_loginForm_box").is(":visible")) {
        $("#dropdown_loginForm_box").find("input:first").focus();
        this.element.find(".error").hide()
    } else $("#dropdown_loginForm_box").find("input").blur();
    var b = this;
    $("body").click(function(c) {
        !$(c.target).parents("#dropdown_loginForm_box").length && !$(c.target).parents("#header_loginOption").length && b.closeLoginDropdown()
    })
},closeLoginDropdown:function() {
    $("#dropdown_loginForm_box").hide();
    $("#dropdown_loginForm_box").find("input").blur();
    $("#header_login").removeClass("active")
},
    "button.account click":function(a) {
        $(a).toggleClass("active");
        $("#userSelectOptions").toggle();
        $("body").click(function(b) {
            if (!$(b.target).parents("#header_account_group").length) {
                $("#header_account_button").removeClass("active");
                $("#userSelectOptions").hide()
            }
        })
    },"ul.dropdownOptions li.option a click":function() {
        $("#header_account_button").removeClass("active");
        $("#userSelectOptions").hide()
    },"button.locale click":function() {
        GS.lightbox.open("locale")
    },"button.surveyLink click":function() {
        location.hash =
                "/surveys"
    },"a.invite click":function() {
        GS.user.UserID > 0 && GS.lightbox.open("invite")
    },"a.feedback click":function() {
        GS.user.IsPremium && GS.lightbox.open("feedback")
    },"a.logout click":function() {
        GS.auth.logout()
    },"input focus":function(a) {
        $(a).parent().parent().addClass("active")
    },"textarea focus":function(a) {
        $(a).parent().parent().parent().addClass("active")
    },"input blur":function(a) {
        $(a).parent().parent().removeClass("active")
    },"textarea blur":function(a) {
        $(a).parent().parent().parent().removeClass("active")
    },
    showError:function(a) {
        $("div.message", this.element).html($.localize.getString(a));
        this.element.find(".error").show()
    },showMessage:function(a) {
        $("div.message", this.element).html(a);
        this.element.find(".error").show()
    },"form#dropdown_loginForm submit":function(a, b) {
        b.preventDefault();
        this.element.find(".error").hide();
        var c = $("input[name=username]", a).val(),g = $("input[name=password]", a).val(),h = $("input[name=save]", a).val() ? 1 : 0;
        switch (c.toLowerCase()) {
            case "dbg:googlelogin":
                GS.google.lastError ? this.showMessage("Last Google Login Error: " +
                        JSON.stringify(GS.google.lastError)) : this.showMessage("There does not appear to be any errors with Google Login");
                break;
            case "dbg:facebooklogin":
                GS.facebook.lastError ? this.showMessage("Last Facebook Login Error: " + JSON.stringify(GS.facebook.lastError)) : this.showMessage("There does not appear to be any errors with Facebook Login");
                break;
            default:
                GS.auth.login(c, g, h, this.callback(this.loginSuccess), this.callback(this.loginFailed));
                break
        }
        return false
    },"button.facebookLogin click":function() {
        GS.auth.loginViaFacebook(null,
                this.callback(this.extLoginFailed));
        this.closeLoginDropdown()
    },"button.googleLogin click":function() {
        GS.auth.loginViaGoogle(null, this.callback(this.extLoginFailed));
        this.closeLoginDropdown()
    },loginSuccess:function() {
        this.closeLoginDropdown()
    },loginFailed:function(a) {
        if (a.error)this.showError(a.error); else a && a.userID == 0 ? this.showError("POPUP_SIGNUP_LOGIN_FORM_AUTH_ERROR") : this.showError("POPUP_SIGNUP_LOGIN_FORM_GENERAL_ERROR")
    },extLoginFailed:function(a) {
        var b = {error:"POPUP_SIGNUP_LOGIN_FORM_GENERAL_ERROR"};
        if (a.error)b.error = a.error; else if (a && a.authType == "facebook")b.error = "POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"; else if (a && a.authType == "google")b.error = "POPUP_SIGNUP_LOGIN_FORM_GOOGLE_ERROR";
        GS.lightbox.open("login", b)
    },"a.loginLink click":function() {
        $("#dropdown_loginForm_box").hide();
        $("#dropdown_loginForm_box").find("input").blur();
        $("#header_login").removeClass("active").parent("li").removeClass("header_hasBorder").siblings("li").removeClass("header_borderAdjust")
    },"a.forget click":function() {
        GS.lightbox.open("forget")
    }});
GS.Controllers.BaseController.extend("GS.Controllers.SidebarController", {onElement:"#sidebar"}, {playlists:[],subscribedPlaylists:[],stations:[],sortBy:"sidebarSort",doingSubscribed:false,doResize:true,init:function() {
    this.subscribe("gs.auth.update", this.callback("update"));
    this.subscribe("gs.auth.playlists.update", this.callback("populateSidebarPlaylists"));
    this.subscribe("gs.auth.favorites.playlists.update", this.callback("populateSidebarSubscribedPlaylists"));
    this.subscribe("gs.auth.stations.update",
            this.callback("populateSidebarStations"));
    try {
        var a = store.get("gs.sort.sidebar")
    } catch(b) {
    }
    if (["sidebarSort","PlaylistName"].indexOf(a) != -1)this.sortBy = a;
    this.subscribe("gs.auth.sidebar.loaded", this.callback(function() {
        this.populateSidebarStations();
        this.populateSidebarSubscribedPlaylists();
        this.populateSidebarPlaylists();
        $(window).resize()
    }));
    this._super()
},appReady:function() {
    this.update()
},update:function() {
    if (GS.user) {
        this.user = GS.user;
        $("#sidebar").resizable("destroy");
        this.element.html(this.view("index"));
        var a = this;
        $("#sidebar").resizable({handles:{e:$("#sidebar .border")},minWidth:65,maxWidth:350,animate:false,resize:function() {
            $("#deselector").select();
            $(window).resize();
            if ($.browser.mozilla) {
                a.populateSidebarPlaylists();
                a.populateSidebarSubscribedPlaylists();
                a.populateSidebarStations()
            }
        }});
        this.populateSidebarPlaylists();
        this.populateSidebarSubscribedPlaylists();
        this.populateSidebarStations();
        $(window).resize();
        this.beginDragDrop()
    }
},changeSort:function(a) {
    this.sortBy = a;
    this.populateSidebarPlaylists();
    this.populateSidebarSubscribedPlaylists();
    this.populateSidebarStations();
    try {
        store.set("gs.sort.sidebar", a)
    } catch(b) {
    }
},playlistSort:function(a, b) {
    var c,g;
    try {
        if (this.sortBy === "sidebarSort") {
            c = a[this.sortBy];
            g = b[this.sortBy]
        } else {
            c = a[this.sortBy].toString().toLowerCase();
            g = b[this.sortBy].toString().toLowerCase()
        }
    } catch(h) {
    }
    return c == g ? 0 : c > g ? 1 : -1
},populateSidebarPlaylists:function() {
    if (GS.user.sidebarLoaded) {
        this.playlists = [];
        for (var a = GS.user.sidebar.playlists,b = 0; b < a.length; b++) {
            var c = GS.user.playlists[a[b]];
            if (c) {
                c.sidebarSort = b + 1;
                this.playlists.push(c)
            }
        }
        this.playlists.sort(this.callback("playlistSort"));
        this.showPlaylists()
    }
},populateSidebarSubscribedPlaylists:function() {
    if (GS.user.sidebarLoaded) {
        this.subscribedPlaylists = [];
        for (var a = GS.user.sidebar.subscribedPlaylists,b = 0; b < a.length; b++) {
            var c = GS.user.favorites.playlists[a[b]];
            if (c) {
                c.sidebarSort = b + 1;
                this.subscribedPlaylists.push(c)
            }
        }
        this.subscribedPlaylists.sort(this.callback(this.playlistSort));
        this.showSubscribedPlaylists()
    }
},populateSidebarStations:function() {
    if (GS.user.sidebarLoaded) {
        this.stations =
                [];
        for (var a = GS.user.sidebar.stations,b = 0; b < a.length; b++) {
            var c = a[b],g = $.localize.getString(GS.Models.Station.TAG_STATIONS[c]);
            g && this.stations.push({StationID:c,Station:GS.Models.Station.TAG_STATIONS[c],Name:g,PlaylistName:g,sidebarSort:b + 1})
        }
        this.stations.sort(this.callback("playlistSort"));
        this.showStations()
    }
},showPlaylists:function() {
    $("#sidebar_playlists").html(this.view("playlists", {playlists:this.playlists,doingSubscribed:false}));
    $("#sidebar_playlists_divider").show();
    this.playlists.length ?
            $("#sidebar_playlist_new").hide() : $("#sidebar_playlist_new").show()
},showSubscribedPlaylists:function() {
    $("#sidebar_subscribed_playlists").html(this.view("playlists", {playlists:this.subscribedPlaylists,doingSubscribed:true}));
    $("#sidebar_playlists_divider").show();
    this.subscribedPlaylists.length ? $("#sidebar_playlist_new").hide() : $("#sidebar_playlist_new").show()
},showStations:function() {
    $("#sidebar_stations").html(this.view("stations"));
    $("#sidebar_stations_divider").show();
    GS.user.sidebar.stations.length <
            1 ? $("#sidebar_station_new").show() : $("#sidebar_station_new").hide()
},loginFailed:function(a) {
    if (a && a.authType)if (a.error)GS.lightbox.open("login", {error:a.error}); else switch (a.authType) {
        case "facebook":
            GS.lightbox.open("login", {error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"});
            break;
        case "google":
            GS.lightbox.open("login", {error:"POPUP_SIGNUP_LOGIN_FORM_GOOGLE_ERROR"});
            break
    }
},"#sidebar_playlists_divider a.sidebarNew click":function(a, b) {
    b.stopPropagation();
    GS.lightbox.open("newPlaylist", []);
    return false
},
    "#sidebar_playlist_new a click":function(a, b) {
        b.stopPropagation();
        GS.lightbox.open("newPlaylist", []);
        return false
    },"#sidebar_stations_divider a.sidebarNew click":function(a, b) {
        b.stopPropagation();
        var c = GS.Models.Station.getStationsMenu();
        if ($("div.jjsidebarMenuNew").is(":visible")) {
            $("div.jjsidebarMenuNew").hide();
            a.removeClass("active-context")
        } else $(a).jjmenu(b, c, null, {xposition:"right",yposition:"top",orientation:"bottom",show:"show",className:"sidebarmenu jjsidebarMenuNew",useEllipsis:false});
        return false
    },"#sidebar_station_new a click":function(a, b) {
        b.stopPropagation();
        var c = GS.Models.Station.getStationsMenu();
        if ($("div.jjsidebarMenuNew").is(":visible")) {
            $("div.jjsidebarMenuNew").hide();
            a.removeClass("active-context")
        } else $(a).jjmenu(b, c, null, {xposition:"right",yposition:"top",orientation:"bottom",show:"show",className:"sidebarmenu jjsidebarMenuNew",useEllipsis:false});
        return false
    },".sidebar_playlist_own .remove click":function(a, b) {
        b.stopPropagation();
        b.preventDefault();
        var c = a.parent().parent().attr("rel");
        GS.lightbox.open("removePlaylistSidebar", c);
        return false
    },".sidebar_playlist_subscribed .remove click":function(a, b) {
        b.stopPropagation();
        b.preventDefault();
        var c = a.parent().parent().attr("rel");
        GS.lightbox.open("removePlaylistSidebar", c);
        return false
    },"li.playlist mousedown":function(a, b) {
        if (b.button === 2) {
            b.stopPropagation();
            var c = a.attr("rel");
            c = GS.Models.Playlist.getOneFromCache(c).getContextMenu();
            $(a).jjmenu(b, c, null, {xposition:"mouse",yposition:"mouse",show:"show",className:"playlistmenu"})
        }
        return false
    },
    "li.station click":function(a, b) {
        b.stopPropagation();
        var c = a.attr("rel");
        GS.player.setAutoplay(true, c);
        return false
    },"li.station .remove click":function(a, b) {
        b.stopPropagation();
        var c = a.parent().parent().attr("rel");
        this.removeStationID = c;
        GS.user.removeFromShortcuts("station", c, true);
        return false
    },"a.noProfile click":function() {
        GS.lightbox.open("login")
    },"a.upload click":function() {
        window.open("http://" + location.host + "/upload", "_blank")
    },"#sidebar_footer a click":function(a, b) {
        b.stopImmediatePropagation();
        var c = GS.Models.Station.getStationsMenu(),g = [],h = GS.Models.Playlist.getPlaylistsMenu([], function(o) {
            o.addShortcut()
        }, true, false),k = {title:$.localize.getString("CONTEXT_NEW_PLAYLIST"),customClass:"jj_menu_item_sidebar jj_menu_item_hasIcon jj_menu_item_new_playlist",action:{type:"fn",callback:function() {
            GS.lightbox.open("newPlaylist", [])
        }}};
        if (h.length > 0) {
            h = [k,{customClass:"separator"}].concat(h);
            g.push({title:$.localize.getString("CONTEXT_ADD_PLAYLIST"),customClass:"addplaylist jj_menu_item_hasIcon jj_menu_item_new_playlist",
                type:"sub",src:h})
        } else g.push(k);
        g.push({title:$.localize.getString("CONTEXT_ADD_STATION"),customClass:"addstation jj_menu_item_hasIcon jj_menu_item_new_station",type:"sub",src:c});
        c = [
            {title:$.localize.getString("SETTINGS"),customClass:"jj_menu_item_hasIcon jj_menu_item_gear",action:{type:"fn",callback:function() {
                window.location.hash = "#/settings"
            }}},
            {title:$.localize.getString("CONTEXT_SORT_BY"),customClass:"jj_menu_item_hasIcon jj_menu_item_sort",type:"sub",src:[
                {title:$.localize.getString("DATE_ADDED"),
                    customClass:this.sortBy == "sidebarSort" ? "jj_menu_item_sidebar jj_menu_item_hasIcon jj_menu_item_tick" : "jj_menu_item_sidebar jj_menu_item_hasIcon jj_menu_item_blank",action:{type:"fn",callback:this.callback(function() {
                    this.changeSort("sidebarSort")
                })}},
                {title:$.localize.getString("CONTEXT_SORT_BY_NAME"),customClass:this.sortBy == "PlaylistName" ? "jj_menu_item_sidebar jj_menu_item_hasIcon jj_menu_item_tick " : "jj_menu_item_sidebar jj_menu_item_hasIcon jj_menu_item_blank",action:{type:"fn",callback:this.callback(function() {
                    this.changeSort("PlaylistName")
                })}}
            ]}
        ];
        var m,n;
        switch (a.attr("name")) {
            case "new":
                m = g;
                n = "jjsidebarMenuNew";
                break;
            case "options":
                m = c;
                n = "jjsidebarMenuOptions";
                break
        }
        if ($("div." + n).is(":visible")) {
            $("div." + n).hide();
            a.removeClass("active-context")
        } else $(a).jjmenu(b, m, null, {xposition:"left",yposition:"top",orientation:"top",show:"show",className:"sidebarmenu " + n,useEllipsis:false})
    },beginDragDrop:function() {
        function a(h, k, m) {
            _.orEqual(m, false);
            if (!($("#sidebar").within(h.clientX, h.clientY).length <= 0)) {
                h = $(".sidebar_link a", "#sidebar").within(h.clientX,
                        h.clientY);
                $("#sidebar .sidebar_link a").removeClass("hover");
                h.length && k.draggedItemsType !== "playlist" && h.addClass("hover")
            }
        }

        function b(h, k) {
            var m = [],n,o;
            h.draggedItemsType = h.draggedItemsType || _.guessDragType(h.draggedItems);
            switch (h.draggedItemsType) {
                case "song":
                    for (n = 0; n < h.draggedItems.length; n++)m.push(h.draggedItems[n].SongID);
                    break;
                case "album":
                    for (n = 0; n < h.draggedItems.length; n++)h.draggedItems[n].getSongs(function(u) {
                                u.sort(GS.Models.Album.defaultSongSort);
                                for (o = 0; o < u.length; o++)m.push(u[o].SongID)
                            },
                            null, false, {async:false});
                    break;
                case "artist":
                    for (n = 0; n < h.draggedItems.length; n++)h.draggedItems[n].getSongs(function(u) {
                        u.sort(GS.Models.Artist.defaultSongSort);
                        for (o = 0; o < u.length; o++)m.push(u[o].SongID)
                    }, null, false, {async:false});
                    break;
                case "playlist":
                    for (n = 0; n < h.draggedItems.length; n++)h.draggedItems[n].getSongs(function(u) {
                        for (o = 0; o < u.length; o++)m.push(u[o].SongID)
                    }, null, false, {async:false});
                    break;
                case "user":
                    for (n = 0; n < h.draggedItems.length; n++)h.draggedItems[n].getFavoritesByType("Song", function(u) {
                        for (o =
                                     0; o < u.length; o++)m.push(u[o].SongID)
                    }, null, false, {async:false});
                    break;
                default:
                    console.error("sidebar drop, invalid drag type", h, h.draggedItemsType);
                    return
            }
            if (k === "library")GS.user.addToLibrary(m, true); else if (k === "favorites")for (n = 0; n < m.length; n++)GS.user.addToSongFavorites(m[n]); else if (k === "newPlaylist")GS.lightbox.open("newPlaylist", m); else if (k instanceof GS.Models.Playlist) {
                k.addSongs(m, null, true);
                var r,t = [],w = [];
                if ($("#grid").controller()) {
                    var y = $("#grid").controller().dataView.rows;
                    $('#grid .slick-row.selected[id!="showQueue"]').each(function(u, E) {
                        r = parseInt($(E).attr("row"), 10);
                        if (!isNaN(r)) {
                            t.push(r + 1);
                            var H = y[r].ppVersion;
                            H && w.push(H)
                        }
                    })
                }
                n = {ranks:t,songIDs:m};
                if (w.length > 0)n.ppVersions = w.join();
                GS.guts.logEvent("OLSongsDraggedToPlaylistSidebarItem", n)
            } else {
                console.error("sidebar drop, invalid thing", k);
                return
            }
            GS.guts.gaTrackEvent("sidebar", "dropSuccess")
        }

        var c = $("li.sidebar_myMusic"),g = $("li.sidebar_favorites");
        $("#sidebar_playlists,#sidebar_subscribed_playlists").bind("draginit",
                function(h, k) {
                    var m = $(h.target).closest(".playlist");
                    if (m.length ===
                            0)return false;
                    k.draggedPlaylistItem = m;
                    k.proxyOffsetX = h.clientX - m.offset().left;
                    k.proxyOffsetY = h.clientY - m.offset().top
                }).bind("dragstart",
                function(h, k) {
                    k.draggedItems = [GS.Models.Playlist.getOneFromCache(k.draggedPlaylistItem.attr("rel"))];
                    k.draggedItemsType = "playlist";
                    k.draggedItemsSource = "sidebar";
                    GS.guts.gaTrackEvent("sidebar", "dragSuccess");
                    return $(k.draggedPlaylistItem).clone().prepend('<div class="status"></div>').addClass("dragProxy").css("position", "absolute").css("zIndex", "99999").appendTo("body").mousewheel(function(m, n) {
                        var o = $("#queue_list_window"),r = $("#sidebar .container_inner_wrapper"),t = $("#grid .slick-viewport");
                        o.within(m.clientX, m.clientY).length > 0 && o.scrollLeft(o.scrollLeft() - 82 * n);
                        r.within(m.clientX, m.clientY).length > 0 && r.scrollTop(r.scrollTop() - 82 * n);
                        t.within(m.clientX, m.clientY).length > 0 && t.scrollTop(t.scrollTop() - 82 * n)
                    })
                }).bind("drag",
                function(h, k) {
                    $(k.proxy).css("top", h.clientY - k.proxyOffsetY).css("left", h.clientX - k.proxyOffsetX);
                    var m = false;
                    _.forEach(k.drop, function(n) {
                        $.isFunction(n.updateDropOnDrag) &&
                        n.updateDropOnDrag(h, k);
                        if (!m)if ($(n).within(h.clientX, h.clientY).length > 0)m = true
                    });
                    m ? $(k.proxy).addClass("valid").removeClass("invalid") : $(k.proxy).addClass("invalid").removeClass("valid")
                }).bind("dragend",
                function(h, k) {
                    $(k.proxy).remove();
                    GS.guts.gaTrackEvent("sidebar", "dragEnd")
                }).bind("dropinit",
                function() {
                    this.updateDropOnDrag = function(h, k) {
                        a(h, k, k.draggedItemsType === "playlist")
                    }
                }).bind("dropstart",
                function(h, k) {
                    if (!k.draggedItems) {
                        this.updateDropOnDrag = null;
                        return false
                    }
                    k.draggedItemsType = k.draggedItemsType ||
                            _.guessDragType(k.draggedItems);
                    if (k.draggedItemsSource == "sidebar") {
                        this.updateDropOnDrag = null;
                        return false
                    }
                    if (k.draggedItemsType !== "playlist" && $(this).attr("id") === "sidebar_subscribed_playlists") {
                        this.updateDropOnDrag = null;
                        return false
                    }
                }).bind("dropend",
                function() {
                    $("#sidebar .sidebar_link a").removeClass("hover")
                }).bind("drop", function(h, k) {
                    k.draggedItemsType = k.draggedItemsType || _.guessDragType(k.draggedItems);
                    var m,n;
                    if (k.draggedItemsType === "playlist")for (m = 0; m < k.draggedItems.length; m++) {
                        n = k.draggedItems[m];
                        n.UserID == GS.user.UserID || n.isSubscribed() ? n.addShortcut(true) : GS.user.addToPlaylistFavorites(n.PlaylistID, true)
                    } else {
                        m = $(".playlist", "#sidebar_playlists").within(h.clientX, h.clientY).attr("rel");
                        n = GS.Models.Playlist.getOneFromCache(m);
                        if (n instanceof GS.Models.Playlist)b(k, n); else m == "new" && b(k, "newPlaylist")
                    }
                });
        c.bind("dropinit",
                function() {
                    this.updateDropOnDrag = function(h, k) {
                        a(h, k, true)
                    }
                }).bind("dropstart",
                function(h, k) {
                    if (!k.draggedItems) {
                        this.updateDropOnDrag = null;
                        return false
                    }
                }).bind("dropend",
                function() {
                    $("#sidebar .sidebar_link a").removeClass("hover")
                }).bind("drop", function(h, k) {
                    b(k, "library")
                });
        g.bind("dropinit",
                function() {
                    this.updateDropOnDrag = function(h, k) {
                        a(h, k, true)
                    }
                }).bind("dropstart",
                function(h, k) {
                    if (!k.draggedItems) {
                        this.updateDropOnDrag = null;
                        return false
                    }
                }).bind("dropend",
                function() {
                    $("#sidebar .sidebar_link a").removeClass("hover")
                }).bind("drop", function(h, k) {
            b(k, "favorites")
        })
    },"a.fromSidebar click":function() {
        GS.page.setFromSidebar(1)
    }});
(function() {
    var a;
    GS.Controllers.BaseController.extend("GS.Controllers.PlayerController", {onElement:"#footer"}, {REPEAT_NONE:0,REPEAT_ALL:1,REPEAT_ONE:2,repeatStates:{none:0,all:1,one:2},INDEX_DEFAULT:-1,INDEX_NEXT:-2,INDEX_LAST:-3,INDEX_REPLACE:-4,PLAY_STATUS_NONE:0,PLAY_STATUS_INITIALIZING:1,PLAY_STATUS_LOADING:2,PLAY_STATUS_PLAYING:3,PLAY_STATUS_PAUSED:4,PLAY_STATUS_BUFFERING:5,PLAY_STATUS_FAILED:6,PLAY_STATUS_COMPLETED:7,PLAY_CONTEXT_UNKNOWN:"unknown",PLAY_CONTEXT_SONG:"song",PLAY_CONTEXT_ALBUM:"album",
        PLAY_CONTEXT_ARTIST:"artist",PLAY_CONTEXT_PLAYLIST:"playlist",PLAY_CONTEXT_RADIO:"radio",PLAY_CONTEXT_SEARCH:"search",PLAY_CONTEXT_POPULAR:"popular",PLAY_CONTEXT_FEED:"feed",PLAY_CONTEXT_SIDEBAR:"sidebar",crossfadeAmount:5E3,crossfadeEnabled:false,playPauseFade:false,prefetchEnabled:true,lowerQuality:false,embedTimeout:0,playlistName:$.localize.getString("NOW_PLAYING"),songCountString:new GS.Models.DataString,numSongs:0,player:null,isPlaying:false,isPaused:false,isLoading:false,nullStatus:{activeSong:{},
            bytesLoaded:0,bytesTotal:0,duration:0,position:0,status:0},SCRUB_LOCK:false,queueIsVisible:true,userChangedQueueVisibility:false,QUEUE_SIZES:{s:{width:139,activeWidth:147},m:{width:80,activeWidth:96}},queueSize:"m",songWidth:80,activeSongWidth:96,gsQueue:null,allowRestore:true,videoModeEnabled:false,powerModeEnabled:false,exists:false,init:function() {
            a = this;
            var b = location.hash.match(/^#\/s\/(.*)\/?/);
            if (b) {
                b = b[0].replace(/\?([^#]*)$/, "");
                this.allowRestore = false;
                this.songToPlayOnReadyToken = b.split("/")[3]
            }
            this.beginDragDrop();
            this.addQueueSeek();
            this.addQueueMousewheel();
            this.addShortcuts();
            this.addVolumeSlider();
            this.setQueue(_.orEqual(store.get("queueSize"), "m"));
            this.subscribe("gs.auth.update", this.callback(this.userChange));
            this.subscribe("gs.auth.song.update", this.callback(this.songChange));
            this.subscribe("gs.auth.library.update", this.callback(this.libraryChange));
            this.subscribe("gs.auth.favorites.songs.update", this.callback(this.libraryChange));
            this.subscribe("gs.settings.local.update", this.callback(this.updateWithLocalSettings));
            this.subscribe("gs.song.play", this.callback(this.eventPlaySong));
            this.subscribe("gs.album.play", this.callback(this.eventPlayAlbum));
            this.subscribe("gs.playlist.play", this.callback(this.eventPlayPlaylist));
            this.subscribe("gs.station.play", this.callback(this.eventPlayStation));
            this.subscribe("window.resize", this.callback(this.resize));
            this.exists = true;
            GS.Models.Feature.register("videoMode", {FeatureID:"videoMode",TextKey:"VIDEO_MODE",ActivateCallback:this.callback("enableVideoMode"),Type:"ACTIVATED"});
            GS.Models.Feature.register("visualizers", {FeatureID:"visualizers",TextKey:"VISUALIZERS",ActivateCallback:this.callback(function() {
                GS.lightbox.open("visualizer", {showPlayerControls:true})
            }),Type:"ACTIVATED"});
            GS.Models.Feature.register("powerHour", {FeatureID:"powerHour",TextKey:"POWER_HOUR_MODE",ActivateCallback:this.callback("togglePowerMode"),IsActiveCallback:this.callback(function() {
                return this.powerModeEnabled
            })});
            this._super()
        },appReady:function() {
            if (swfobject.hasFlashPlayerVersion("9.0.0"))this.embedTimeout =
                    setTimeout(this.callback(this.onEmbedTimeout), 1E4); else setTimeout(function() {
                GS.lightbox.open("noFlash")
            }, 500)
        },resize:function() {
            a.updateQueueWidth()
        },setQueue:function(b) {
            var c = b === "s" ? a.smallQueueSongToHtml : a.queueSongToHtml,g = _.defined(a.queue) && a.queue.songs ? a.queue.songs : [],h = a.getCurrentQueue(),k = 0;
            a.queueSize = b;
            a.songWidth = a.QUEUE_SIZES[b].width;
            a.activeSongWidth = a.QUEUE_SIZES[b].activeWidth;
            store.set("queueSize", b);
            if (h && h.activeSong)k = h.activeSong.index;
            a.gsQueue = $("#queue").toggleClass("small",
                    b === "s").gsQueue({activeItemWidth:a.activeSongWidth,itemWidth:a.songWidth,itemRenderer:c,activeIndex:k}, g);
            $(window).resize()
        },userChange:function() {
            this.updateWithLocalSettings()
        },libraryChange:function() {
            var b = {};
            b = a.player ? a.player.getCurrentQueue() : {activeSong:false,songs:[]};
            var c = b.songs;
            c = GS.Models.Song.wrapQueue(c);
            a.gsQueue.setItems(c);
            a.updateQueueDetails();
            if (b.activeSong) {
                b = GS.Models.Song.wrapQueue([b.activeSong])[0];
                a.updateSongOnPlayer(b, true)
            }
        },playerExists:function() {
            return this.exists
        },
        playerReady:function() {
            a.player.setErrorCallback("GS.Controllers.PlayerController.instance().playerError");
            a.player.setPlaybackStatusCallback("GS.Controllers.PlayerController.instance().playerStatus");
            a.player.setPropertyChangeCallback("GS.Controllers.PlayerController.instance().propertyChange");
            a.player.setQueueChangeCallback("GS.Controllers.PlayerController.instance().queueChange");
            a.player.setSongPropertyChangeCallback("GS.Controllers.PlayerController.instance().songChange");
            a.player.setChatServers(gsConfig.chatServersWeighted ?
                    gsConfig.chatServersWeighted : {});
            var b = a.player.setZoomChangeCallback("GS.Controllers.PlayerController.instance().onZoomChange");
            a.onZoomChange(b);
            $("#volumeSlider").slider("value", a.player.getVolume());
            a.updateWithLocalSettings();
            clearTimeout(a.embedTimeout);
            a.embedTimeout = null;
            GS.lightbox && GS.lightbox.isOpen && GS.lightbox.curType == "swfTimeout" && GS.lightbox.close();
            this.songToPlayOnReadyToken && GS.Models.Song.getSongFromToken(this.songToPlayOnReadyToken, function(c) {
                        c && c.validate() && a.addSongAndPlay(c.SongID)
                    },
                    null, false);
            return true
        },onEmbedTimeout:function() {
            a.player || GS.lightbox.open("swfTimeout")
        },queueIsRestorable:function() {
            var b = a.getCurrentQueue();
            if (GS.user.settings.local.restoreQueue && a.allowRestore)a.restoreQueue(); else {
                b.hasRestoreQueue = true;
                $("#queue_clear_button").addClass("undo");
                _.defined(restoreQueue) || $.publish("gs.player.restorequeue")
            }
        },onZoomChange:function(b) {
            var c = window.GS && GS.airbridge ? GS.airbridge : GS.Controllers.AirbridgeController.instance();
            if (b && !c.isDesktop) {
                console.warn("ZOOM CHANGED, NOT ZERO",
                        b);
                alert($.localize.getString("ZOOM_ALERT"));
                window._gaq && window._gaq.push && window._gaq.push(["_trackPageview","#/lb/zoom"])
            } else $(window).resize()
        },storeQueue:function() {
            a.player && a.player.storeQueue()
        },playerError:function(b) {
            console.log("player.playererror", b);
            switch (b.type) {
                case "errorAddingSongs":
                    console.log("player. failed to add songs: ", b.details.songs, b.details.reason);
                    b.details.reason == "tooManySongs" ? $.publish("gs.notification", {type:"notice",message:$.localize.getString("ERROR_TOO_MANY_SONGS")}) :
                            $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_ADDING_SONG") + ": " + b.details.reason});
                    break;
                case "playbackError":
                    console.log("player. error playing song", b.details.song, b.details.reason, b.details.errorDetail);
                    b.details.reason === "unknownHasNext" ? $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_HASNEXT_MESSAGE")}) : $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_PLAYING_SONG")});
                    break;
                case "autoplayFailed":
                    console.log("player. error fetching autoplay song",
                            b.details.reason);
                    b.details.reason === "unknownHasNext" ? $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_HASNEXT_MESSAGE")}) : $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_FETCHING_RADIO")});
                    break;
                case "autoplayVoteError":
                    console.log("player. error voting song", b.details.song);
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_VOTING_SONG")});
                    break;
                case "serviceError":
                    console.log("player. service error", b.details);
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("ERROR_FETCHING_INFO")});
                    break
            }
            b.details.errorDetail ? GS.guts.gaTrackEvent("playerError", b.type, b.details.reason + ", " + b.details.errorDetail) : GS.guts.gaTrackEvent("playerError", b.type, b.details.reason)
        },$seekBar:$("#seeking_wrapper .bar:first"),$seekBuffer:$("#seeking_wrapper .bar.buffer"),$seekProgress:$("#seeking_wrapper .bar.progress"),$seekScrubber:$("#seeking_wrapper .scrubber"),lastStatus:false,lastPlayedQueueSongID:false,
        playerStatus:function(b) {
            b = b || this.nullStatus;
            if (!this.currentSong || !b.activeSong || this.currentSong && b.activeSong && this.currentSong.queueSongID !== b.activeSong.queueSongID) {
                b.activeSong = GS.Models.Song.wrapQueue([b.activeSong ? b.activeSong : {}])[0];
                this.updateSongOnPlayer(b.activeSong)
            } else b.activeSong = this.currentSong;
            var c = Math.min(1, b.bytesLoaded / b.bytesTotal),g = Math.min(1, b.position / b.duration),h = this.$seekBar.width();
            c = Math.min(h, c * 100);
            var k = Math.min(h, g * 100);
            g = Math.min(h, Math.max(0, h * g));
            c = isNaN(c) ?
                    0 : c;
            k = isNaN(k) ? 0 : k;
            g = isNaN(g) ? 0 : g;
            this.$seekBuffer.width(c + "%");
            this.$seekProgress.width(k + "%");
            this.SCRUB_LOCK || this.$seekScrubber.css("left", g);
            if (b.duration > 0) {
                b.position == 0 ? $("#player_elapsed").text("0:00") : $("#player_elapsed").text(_.millisToMinutesSeconds(b.position));
                b.duration == 0 ? $("#player_duration").text("0:00") : $("#player_duration").text(_.millisToMinutesSeconds(b.duration))
            } else {
                $("#player_elapsed").text("0:00");
                $("#player_duration").text("0:00")
            }
            b.currentStreamServer && b.currentStreamServer !==
                    this.lastStatus.currentStreamServer && $.publish("gs.player.streamserver", {streamServer:b.currentStreamServer});
            this.powerModeEnabled && b.position > 6E4 && this.nextSong();
            g = b.activeSong ? b.activeSong.SongID : false;
            switch (b.status) {
                case a.PLAY_STATUS_NONE:
                    this.lastStatus !== b.status && GS.guts.logEvent("playStatusUpdate", {playStatus:"NONE",activeSong:g,streamServer:b.currentStreamServer});
                    a.isPlaying = false;
                    a.isPaused = false;
                    a.isLoading = false;
                    a.seek.slider("disable");
                    $("#player_play_pause").addClass("play").removeClass("pause").removeClass("buffering");
                    $("#queue_list li.queue-item.queue-item-active a.play").addClass("paused");
                    $.publish("gs.player.stopped", b.activeSong);
                    break;
                case a.PLAY_STATUS_INITIALIZING:
                    a.isPlaying = true;
                    a.isPaused = false;
                    a.isLoading = true;
                    if (this.lastStatus !== b.status) {
                        GS.guts.logEvent("playStatusUpdate", {playStatus:"INITIALIZING",activeSong:g,streamServer:b.currentStreamServer});
                        this.lastStatus == a.PLAY_STATUS_COMPLETED && GS.guts.gaTrackEvent("player", "continueInterrupted", b.currentSongID)
                    }
                    if ((gsConfig.isPreview || GS.airbridge &&
                            GS.airbridge.isDesktop) && !GS.user.IsPremium) {
                        this.stopSong();
                        GS.lightbox.open("login", {premiumRequired:true})
                    }
                    break;
                case a.PLAY_STATUS_LOADING:
                    if (this.lastStatus !== b.status) {
                        GS.guts.logEvent("playStatusUpdate", {playStatus:"LOADING",activeSong:g,streamServer:b.currentStreamServer});
                        a.isPlaying = true;
                        a.isPaused = false;
                        a.isLoading = true;
                        a.updateSongOnPlayer(b.activeSong);
                        $("#player_play_pause").is(".buffering") || $("#player_play_pause").removeClass("play").removeClass("pause").addClass("buffering");
                        GS.guts.gaTrackEvent("player",
                                "loading", b.currentStreamServer);
                        a.lastLoadingQueueSongID = b.activeSong ? b.activeSong.queueSongID : false;
                        a.lastLoadingTime = (new Date).getTime()
                    }
                    if (this.pauseNextQueueSongID && b.activeSong && this.pauseNextQueueSongID === b.activeSong.queueSongID) {
                        this.pauseNextQueueSongID = false;
                        this.pauseSong()
                    }
                    $("#queue_list li.queue-item.queue-item-active a.play").removeClass("paused");
                    break;
                case a.PLAY_STATUS_PLAYING:
                    if (this.lastStatus !== b.status) {
                        GS.guts.logEvent("playStatusUpdate", {playStatus:"PLAYING",activeSong:g,
                            streamServer:b.currentStreamServer});
                        a.isPlaying = true;
                        a.isPaused = false;
                        a.isLoading = false;
                        a.seek.slider("enable");
                        $("#player_play_pause").is(".pause") || $("#player_play_pause").removeClass("play").addClass("pause").removeClass("buffering");
                        $.publish("gs.player.playing", b);
                        if (b.activeSong && this.lastPlayedQueueSongID !== b.activeSong.queueSongID) {
                            this.lastStatus == a.PLAY_STATUS_COMPLETED && GS.guts.gaTrackEvent("player", "continueNextSong", g);
                            GS.guts.gaTrackEvent("player", "play", g);
                            this.trackAutoplayEvent("play");
                            this.lastPlayedQueueSongID = b.activeSong ? b.activeSong.queueSongID : false
                        }
                        this.lastStatus == a.PLAY_STATUS_LOADING ? GS.guts.gaTrackEvent("player", "loadingTime", b.currentStreamServer, (new Date).getTime() - this.lastLoadingTime) : GS.guts.gaTrackEvent("player", "loadingTime", b.currentStreamServer, 0)
                    }
                    if (this.pauseNextQueueSongID && b.activeSong && this.pauseNextQueueSongID === b.activeSong.queueSongID) {
                        this.pauseNextQueueSongID = false;
                        this.pauseSong()
                    }
                    $("#queue_list li.queue-item.queue-item-active a.play").removeClass("paused");
                    $.publish("gs.player.playing.continue", b);
                    break;
                case a.PLAY_STATUS_PAUSED:
                    if (this.lastStatus !== b.status) {
                        GS.guts.logEvent("playStatusUpdate", {playStatus:"PAUSED",activeSong:g,streamServer:b.currentStreamServer});
                        a.isPlaying = false;
                        a.isPaused = true;
                        a.isLoading = false;
                        $("#player_play_pause").is(".play") || $("#player_play_pause").addClass("play").removeClass("pause").removeClass("buffering");
                        $.publish("gs.player.paused", b.activeSong)
                    }
                    $("#queue_list li.queue-item.queue-item-active a.play").addClass("paused");
                    break;
                case a.PLAY_STATUS_BUFFERING:
                    this.lastStatus !== b.status && GS.guts.logEvent("playStatusUpdate", {playStatus:"BUFFERING",activeSong:g,streamServer:b.currentStreamServer});
                    a.isPlaying = true;
                    a.isPaused = false;
                    a.isLoading = true;
                    $("#player_play_pause").is(".buffering") || $("#player_play_pause").removeClass("play").removeClass("pause").addClass("buffering");
                    $("#queue_list li.queue-item.queue-item-active a.play").removeClass("paused");
                    break;
                case a.PLAY_STATUS_FAILED:
                    this.lastStatus !== b.status && GS.guts.logEvent("playStatusUpdate",
                            {playStatus:"FAILED",activeSong:g,streamServer:b.currentStreamServer});
                    a.isPlaying = false;
                    a.isPaused = false;
                    a.isLoading = false;
                    a.seek.slider("disable");
                    $("#player_play_pause").addClass("play").removeClass("pause").removeClass("buffering");
                    $("#queue_list li.queue-item.queue-item-active a.play").addClass("paused");
                    break;
                case a.PLAY_STATUS_COMPLETED:
                    this.lastStatus !== b.status && GS.guts.logEvent("playStatusUpdate", {playStatus:"COMPLETED",activeSong:g,streamServer:b.currentStreamServer});
                    a.isPlaying = false;
                    a.isPaused = false;
                    a.isLoading = false;
                    a.seek.slider("disable");
                    $("#player_play_pause").addClass("play").removeClass("pause").removeClass("buffering");
                    $("#queue_list li.queue-item.queue-item-active a.play").addClass("paused");
                    a.$seekBuffer.width("0%");
                    a.$seekProgress.width("0%");
                    a.$seekScrubber.css("left", 0);
                    $.publish("gs.player.stopped", b.activeSong);
                    $.publish("gs.player.completed", b.activeSong);
                    break
            }
            this.lastStatus = b.status;
            $.publish("gs.player.playstatus", b)
        },pauseNextQueueSongID:false,pauseNextSong:function() {
            var b =
                    this.getCurrentQueue(true);
            this.pauseNextQueueSongID = b && b.nextSong && b.nextSong.queueSongID ? b.nextSong.queueSongID : false
        },propertyChange:function(b) {
            if (b.isMuted) {
                $("#player_volume").addClass("muted");
                $("#volumeSlider").slider("value", 0)
            } else {
                $("#player_volume").removeClass("muted");
                $("#volumeSlider").slider("value", b.volume)
            }
            b.crossfadeEnabled ? $("#player_crossfade").addClass("active") : $("#player_crossfade").removeClass("active")
        },queueChange:function(b) {
            var c = b.fullQueue;
            if (a.player)c.hasRestoreQueue =
                    a.player.getQueueIsRestorable();
            a.queue = false;
            switch (b.type) {
                case "queueReset":
                    c.activeSong = c.activeSong ? GS.Models.Song.wrapQueue([c.activeSong])[0] : null;
                    c.activeSong && this.updateSongOnPlayer(c.activeSong, true);
                    c.songs = GS.Models.Song.wrapQueue(c.songs);
                    a.queue = c;
                    a.updateQueueDetails(c);
                    a.updateQueueSongs(c);
                    if (b.details.hasOwnProperty("autoplayEnabled"))if (b.details.autoplayEnabled == true) {
                        GS.player.getCurrentQueue();
                        GS.guts.logEvent("autoplayOn", {tagID:b.details.currentAutoplayTagID});
                        GS.guts.beginContext({autoplay:b.details.currentAutoplayTagID})
                    } else GS.guts.endContext("autoplay");
                    break;
                case "propertyChange":
                    if (b.details.hasOwnProperty("autoplayEnabled"))if (b.details.autoplayEnabled == true) {
                        c = a.getCurrentQueue().songs;
                        var g = {tagID:b.fullQueue.currentAutoplayTagID};
                        if (c) {
                            for (var h = "",k = 0; k < c.length; k++)h = k == 0 ? c[k].SongID : h + "," + c[k].SongID;
                            g.seedSongs = h
                        }
                        GS.guts.logEvent("autoplayOn", g);
                        GS.guts.beginContext({autoplay:b.fullQueue.currentAutoplayTagID,autoplaySeedSongs:h})
                    } else GS.guts.handleAutoplayOff();
                    a.updateQueueDetails();
                    break;
                case "contentChange":
                    a.gsQueue.setActive(a.getCurrentQueue().activeSong.index,
                            false);
                    a.gsQueue.setItems(a.getCurrentQueue().songs);
                    a.updateQueueWidth();
                    a.updateQueueDetails();
                    break
            }
            $.publish("gs.player.queue.change")
        },songChange:function(b) {
            var c = ["parentQueueID","queueSongID","autoplayVote","source","sponsoredAutoplayID"],g,h,k = a.player ? a.player.getCurrentQueue() : {activeSong:false};
            b instanceof GS.Models.Song || (b = GS.Models.Song.wrapQueue([b])[0]);
            h = a.getCurrentQueue().songs;
            for (g = 0; g < h.length; g++)if (h[g].SongID === b.SongID)for (var m in b)if (b.hasOwnProperty(m) && (h[g].queueSongID ===
                    b.queueSongID || c.indexOf(m) == -1))h[g][m] = b[m];
            a.gsQueue.setItems(h);
            a.updateQueueDetails();
            k.activeSong && b.queueSongID === k.activeSong.queueSongID && a.updateSongOnPlayer(b, true);
            $.publish("gs.player.song.change", b)
        },updateWithLocalSettings:function(b) {
            if (this.player) {
                b = b || GS.user.settings.local;
                b.crossfadeEnabled != this.getCrossfadeEnabled() && this.setCrossfadeEnabled(b.crossfadeEnabled);
                b.crossfadeAmount != this.getCrossfadeAmount() && this.setCrossfadeAmount(b.crossfadeAmount);
                b.lowerQuality != this.getLowerQuality() &&
                this.setLowerQuality(b.lowerQuality);
                !b.noPrefetch != this.getPrefetchEnabled() && this.setPrefetchEnabled(!b.noPrefetch);
                b.playPauseFade != this.getPlayPauseFade() && this.setPlayPauseFade(b.playPauseFade);
                this.setPersistShuffle(b.persistShuffle);
                b.persistShuffle && b.lastShuffle != this.getShuffle() && this.setShuffle(b.lastShuffle)
            }
        },getEverything:function() {
            if (a.player)return a.player.getEverything();
            return{}
        },getPlaybackStatus:function() {
            if (a.player)return a.player.getPlaybackStatus();
            return{}
        },getSongDetails:function(b, c) {
            var g;
            b = _.orEqual(b, 0);
            if (typeof c === "number" || typeof c === "string")c = [c];
            if (a.player) {
                g = a.player.getSongDetails(b, c);
                return GS.Models.Song.wrapQueue(g)
            }
            return GS.Models.Song.wrap({})
        },getCurrentSong:function() {
            if (a.player)return a.getCurrentQueue().activeSong
        },setActiveSong:function(b) {
            if (b && a.player)return a.player.setActiveSong(b);
            return false
        },addSongsToQueueAt:function(b, c, g, h, k) {
            c = _.orEqual(c, this.INDEX_DEFAULT);
            g = _.orEqual(g, false);
            h = _.orEqual(h, {type:this.PLAY_CONTEXT_UNKNOWN});
            k = _.orEqual(k,
                    false);
            $.isArray(b) || (b = isNaN(b) ? b.split(",") : [b]);
            var m,n = [];
            for (m = 0; m < b.length; m++)b[m] > 0 && GS.Models.Song.getSong(b[m], this.callback(function(o) {
                o = o.dupe();
                o.songs = {};
                o.fanbase = {};
                n[m] = o
            }), false, false, {async:false});
            if (a.player) {
                if (c == -4) {
                    c = -1;
                    this.clearQueue()
                }
                a.player.addSongsToQueueAt(n, c, g, h, k);
                GS.guts.logEvent("songsQueued", {songIDs:b})
            }
        },playSong:function(b) {
            GS.isPlaying = true;
            a.player && a.player.playSong(b)
        },eventPlaySong:function(b) {
            if (b && b.songID) {
                GS.notice.feedbackOnNextSong = _.orEqual(b.getFeedback,
                        false);
                a.addSongAndPlay(b.songID)
            }
        },eventPlayAlbum:function(b) {
            if (b && b.albumID) {
                GS.notice.feedbackOnNextSong = _.orEqual(b.getFeedback, false);
                GS.Models.Album.getAlbum(b.albumID, this.callback("playAlbum", b), null, false)
            }
        },playAlbum:function(b, c) {
            console.log("player.playAlbum", b, c);
            var g = _.orEqual(b.index, -1),h = _.orEqual(b.playOnAdd, false);
            c.play(g, h)
        },eventPlayPlaylist:function(b) {
            if (b && b.playlistID) {
                GS.notice.feedbackOnNextSong = _.orEqual(b.getFeedback, false);
                GS.Models.Playlist.getPlaylist(b.playlistID,
                        this.callback("playPlaylist", b), null, false)
            }
        },playPlaylist:function(b, c) {
            console.log("player.playPlaylist", b, c);
            var g = _.orEqual(b.index, -1),h = _.orEqual(b.playOnAdd, false);
            c.play(g, h)
        },eventPlayStation:function(b) {
            if (b && b.tagID) {
                console.log("play station", b.tagID);
                a.setAutoplay(true, b.tagID)
            }
        },addSongAndPlay:function(b, c) {
            a.player && a.addSongsToQueueAt([b], a.INDEX_DEFAULT, true, c)
        },pauseSong:function() {
            a.isPlaying = false;
            a.isPaused = true;
            if (a.player) {
                a.player.pauseSong();
                $.publish("gs.player.paused")
            }
            GS.guts.gaTrackEvent("player",
                    "pauseSong")
        },resumeSong:function() {
            a.isPlaying = true;
            a.isPaused = false;
            a.player && a.player.resumeSong();
            GS.guts.gaTrackEvent("player", "resumeSong")
        },stopSong:function() {
            a.isPlaying = false;
            a.isPaused = false;
            a.player && a.player.stopSong();
            GS.guts.gaTrackEvent("player", "stopSong")
        },previousSong:function(b) {
            b = b ? true : false;
            if (a.videoModeEnabled)a.youtubePrevSong(); else a.player && a.player.previousSong(b);
            GS.guts.logEvent("prevSong", {});
            GS.guts.gaTrackEvent("player", "prevSong");
            a.trackAutoplayEvent("prev")
        },
        nextSong:function() {
            if (a.videoModeEnabled)a.youtubeNextSong(); else a.player && a.player.nextSong();
            GS.guts.logEvent("nextSong", {});
            GS.guts.gaTrackEvent("player", "nextSong");
            a.trackAutoplayEvent("next")
        },seekTo:function(b) {
            a.player && a.player.seekTo(b);
            GS.guts.gaTrackEvent("player", "seekTo")
        },clearQueue:function() {
            if (a.player) {
                a.queue = null;
                a.player.stopSong();
                a.player.clearQueue();
                a.playerStatus(a.player.getPlaybackStatus());
                a.updateQueueWidth();
                a.gsQueue.setActive(0, false);
                a.gsQueue.setItems([]);
                $("#playerDetails_nowPlaying").html("");
                GS.guts.logEvent("queueCleared", {});
                GS.guts.handleAutoplayOff()
            }
            GS.guts.gaTrackEvent("player", "clearQueue")
        },restoreQueue:function() {
            a.player && a.player.restoreQueue();
            GS.guts.gaTrackEvent("player", "restoreQueue")
        },saveQueue:function() {
            for (var b = a.getCurrentQueue().songs,c = [],g = 0; g < b.length; g++)c.push(b[g].SongID);
            GS.lightbox.open("newPlaylist", c);
            GS.guts.logEvent("queueSaveInitiated", {});
            GS.guts.gaTrackEvent("player", "saveQueue")
        },getCurrentQueue:function(b) {
            b = _.orEqual(b, false);
            if (!b && a.queue)return a.queue;
            if (a.player) {
                b = a.player.getCurrentQueue();
                if (b.activeSong) {
                    b.activeSong = GS.Models.Song.wrapQueue([b.activeSong])[0];
                    this.updateSongOnPlayer(b.activeSong, true)
                }
                if (b.songs && b.songs.length)b.songs = GS.Models.Song.wrapQueue(b.songs);
                b.hasRestoreQueue = a.player.getQueueIsRestorable();
                return a.queue = b
            }
        },getPreviousQueue:function() {
            a.player && a.player.getPreviousQueue();
            GS.guts.gaTrackEvent("player", "previousQueue")
        },moveSongsTo:function(b, c) {
            if (typeof b === "number" || typeof b === "string")b = [b];
            a.player && a.player.moveSongsTo(b,
                    c)
        },removeSongs:function(b) {
            if (typeof b === "number" || typeof b === "string")b = [b];
            if (a.player) {
                for (queueSongID in b);
                a.player.removeSongs(b);
                a.updateQueueWidth()
            }
            a.queue = false;
            a.queue = a.getCurrentQueue();
            $.publish("gs.player.queue.change");
            GS.guts.gaTrackEvent("player", "removeSongs");
            a.trackAutoplayEvent("removeSongs")
        },lastAutoplayInfo:false,setAutoplay:function(b, c) {
            var g = a.getCurrentQueue();
            b = b ? true : false;
            c = parseInt(c, 10);
            if (isNaN(c))c = 0;
            if (c > 0 && g && g.songs.length > 0)GS.lightbox.open("radioClearQueue",
                    c); else {
                if (a.player) {
                    if (b) {
                        $("#player button.radio").addClass("active");
                        GS.guts.beginContext({autoplay:c})
                    } else {
                        $("#player button.radio").removeClass("active");
                        GS.guts.endContext("autoplay")
                    }
                    $("#queue_radio_button").toggleClass("active", b);
                    a.player.setAutoplay(b, c)
                }
                GS.guts.gaTrackEvent("player", b ? "enableRadio" : "disableRadio", c)
            }
        },trackLastAutoplayInfo:function(b, c) {
            if (a.lastAutoplayInfo && (!b || a.lastAutoplayInfo.tagID != c)) {
                var g = (new Date).getTime() - a.lastAutoplayInfo.time;
                GS.guts.gaTrackEvent("player",
                        "autoplayDuration", a.lastAutoplayInfo.tagID, g)
            }
            if (b) {
                if (!a.lastAutoplayInfo || a.lastAutoplayInfo && a.lastAutoplayInfo.tagID !== c)a.lastAutoplayInfo = {tagID:c,time:(new Date).getTime()}
            } else a.lastAutoplayInfo = false
        },trackAutoplayEvent:function(b) {
            b = "" + b;
            a.lastAutoplayInfo && b && GS.guts.gaTrackEvent("player", "autoplay" + _.ucwords(b), a.lastAutoplayInfo.tagID)
        },voteSong:function(b, c) {
            var g;
            if (a.player) {
                a.player.voteSong(b, c);
                g = this.getSongDetails(a.queue.queueID, [b])[0].SongID;
                switch (c) {
                    case -1:
                        GS.guts.logEvent("songDownVoted",
                                {songID:g});
                        GS.guts.gaTrackEvent("player", "voteSongDown");
                        break;
                    case 0:
                        GS.guts.logEvent("songVotedNeutral", {songID:g});
                        GS.guts.gaTrackEvent("player", "voteSongNeutral");
                        break;
                    case 1:
                        GS.guts.logEvent("songUpVoted", {songID:g});
                        GS.guts.gaTrackEvent("player", "voteSongUp");
                        break
                }
            }
        },flagSong:function(b, c) {
            if (a.player) {
                a.player.flagSong(b, c);
                $.publish("gs.notification", {message:$.localize.getString("SUCCESS_FLAG_SONG")})
            }
            GS.guts.gaTrackEvent("player", "flagSong", c)
        },getVolume:function() {
            if (a.player)return a.player.getVolume()
        },
        setVolume:function(b) {
            b = Math.max(0, Math.min(100, parseInt(b, 10)));
            a.player && a.player.setVolume(b);
            GS.guts.gaTrackEvent("player", "setVolume", b)
        },getCrossfadeAmount:function() {
            if (a.player)return a.player.getCrossfadeAmount()
        },getCrossfadeEnabled:function() {
            if (a.player)return a.player.getCrossfadeEnabled()
        },setCrossfadeAmount:function(b) {
            b = parseInt(b, 10);
            a.player && a.player.setCrossfadeAmount(b);
            GS.guts.gaTrackEvent("player", "setCrossfade", b)
        },setCrossfadeEnabled:function(b) {
            b = b && GS.user.IsPremium ? true :
                    false;
            a.player && a.player.setCrossfadeEnabled(b);
            GS.user.settings.changeLocalSettings({crossfadeEnabled:b ? 1 : 0});
            GS.guts.gaTrackEvent("player", b ? "enableCrossfade" : "disableCrossfade")
        },setPrefetchEnabled:function(b) {
            b = b ? true : false;
            a.player && a.player.setPrefetchEnabled(b);
            GS.guts.gaTrackEvent("player", b ? "enablePrefetch" : "disablePrefetch")
        },getPrefetchEnabled:function() {
            if (a.player)return a.player.getPrefetchEnabled()
        },setLowerQuality:function(b) {
            b = b ? true : false;
            a.player && a.player.setLowerQuality(b);
            GS.guts.gaTrackEvent("player",
                    b ? "enableLowerQuality" : "disableLowerQuality")
        },getLowerQuality:function() {
            if (a.player)return a.player.getLowerQuality()
        },getIsMuted:function() {
            if (a.player)return a.player.getIsMuted()
        },setIsMuted:function(b) {
            b = b ? true : false;
            a.player && a.player.setIsMuted(b);
            GS.guts.gaTrackEvent("player", b ? "enableMuted" : "disableMuted")
        },getPlayPauseFade:function() {
            if (a.player)return a.player.getPlayPauseFade()
        },setPlayPauseFade:function(b) {
            b = b ? true : false;
            a.player && a.player.setPlayPauseFade(b);
            GS.user.settings.changeLocalSettings({playPauseFade:b ?
                    1 : 0});
            GS.guts.gaTrackEvent("player", b ? "enablePlayPauseFade" : "disablePlayPauseFade")
        },setRepeat:function(b) {
            a.repeat = b;
            a.player && a.player.setRepeat(b);
            GS.guts.gaTrackEvent("player", "setRepeat", b)
        },getRepeat:function() {
            if (a.player && a.player.getRepeat)return a.player.getRepeat();
            return a.repeat
        },setShuffle:function(b) {
            if (!(a.queue && a.queue.autoplayEnabled)) {
                b = b ? true : false;
                a.player && a.player.setShuffle(b);
                GS.user.settings.changeLocalSettings({lastShuffle:b ? 1 : 0});
                GS.guts.gaTrackEvent("player", "shuffle",
                        b ? "on" : "off")
            }
        },getShuffle:function() {
            if (a.player)return a.player.getShuffle();
            return false
        },setPersistShuffle:function(b) {
            b = b ? true : false;
            a.player && a.player.setPersistShuffle(b);
            GS.guts.gaTrackEvent("player", "persistShuffle", b ? "on" : "off")
        },prefetchStreamKeys:function(b) {
            if (a.player)return a.player.prefetchStreamKeys(b)
        },getAPIVersion:function() {
            if (a.player)return a.player.getAPIVersion()
        },getApplicationVersion:function() {
            if (a.player)return a.player.getApplicationVersion()
        },updateSongOnPlayer:function(b, c) {
            c = _.orEqual(c, false);
            if (!(!c && a.currentSong && b && a.currentSong.queueSongID === b.queueSongID)) {
                a.currentSong = b && !(b instanceof GS.Models.Song) ? GS.Models.Song.wrapQueue([b])[0] : b;
                if (a.currentSong instanceof GS.Models.Song) {
                    a.videoIndex = a.currentSong.index;
                    $.publish("gs.player.nowplaying", a.currentSong);
                    $("#queue_list li.queue-item.queue-item-active").removeClass("active");
                    $("#queue_list #" + a.currentSong.queueSongID).addClass("active");
                    $("#playerDetails_nowPlaying").html(a.view("currentSongDetails")).attr("rel",
                            a.currentSong.SongID).attr("qsid", a.currentSong.queueSongID);
                    _.defined(a.currentSong.index && a.currentSong.index >= 0) && a.gsQueue.setActive(a.currentSong.index, !a.isMouseDown)
                }
            }
        },updateQueueDetails:function(b) {
            b || (b = a.getCurrentQueue());
            a.queueIsVisible = $("#queue").is(":visible");
            if (b.hasOwnProperty("songs")) {
                b.songs.length && !a.queueIsVisible && !a.userChangedQueueVisibility && a.toggleQueue();
                if (b.songs.length > 0) {
                    $("#seeking_wrapper .scrubber").show();
                    $("#player_previous").removeAttr("disabled").removeClass("disabled")
                } else {
                    $("#seeking_wrapper .scrubber").hide();
                    $("#player_previous").attr("disabled", "disabled").addClass("disabled")
                }
            }
            $("#playerDetails_queue").html(a.view("queueDetails"));
            a.songCountString.hookup("#player_songCount");
            if (b.hasOwnProperty("nextSong"))if (b.nextSong) {
                $("#player_next").removeAttr("disabled").removeClass("disabled");
                if (a.pauseNextQueueSongID && b.nextSong.hasOwnProperty("queueSongID"))a.pauseNextQueueSongID = b.nextSong.queueSongID
            } else $("#player_next", a.element).attr("disabled", "disabled").addClass("disabled");
            if (b.hasOwnProperty("activeSong"))if (b.activeSong) {
                $("#player_play_pause").removeAttr("disabled").removeClass("disabled");
                a.updateSongOnPlayer(b.activeSong, true)
            } else $("#player_play_pause").attr("disabled", "disabled").addClass("disabled");
            if (b.hasOwnProperty("repeatMode")) {
                a.repeatMode = b.repeatMode;
                if (a.repeatMode === a.REPEAT_ALL)$("#player_loop").removeClass("none").addClass("all").addClass("active"); else if (a.repeatMode === a.REPEAT_ONE)$("#player_loop").removeClass("all").addClass("one").addClass("active"); else a.repeatMode === a.REPEAT_NONE && $("#player_loop").removeClass("one").addClass("none").removeClass("active")
            }
            if (b.hasOwnProperty("autoplayEnabled")) {
                if (b.autoplayEnabled) {
                    $("#queue_list").addClass("autoplay");
                    $("#player_shuffle").removeClass("active");
                    $("#playerDetails button.radio").addClass("active");
                    if (b.currentAutoplayTagID > 0) {
                        var c = $.localize.getString(GS.Models.Station.TAG_STATIONS[b.currentAutoplayTagID]);
                        c || (c = GS.theme.extraStations[b.currentAutoplayTagID]);
                        $("#playerDetails_queue .queueType").html(c)
                    } else $("#playerDetails_queue .queueType").text($.localize.getString("NOW_PLAYING"))
                } else {
                    $("#queue_list").removeClass("autoplay");
                    b.activeSong && b.activeSong.context && b.activeSong.context.type === "playlist" &&
                            b.activeSong.context.data.playlistName ? $("#playerDetails_queue .queueType").html(b.activeSong.context.data.playlistName) : $("#playerDetails_queue .queueType").text($.localize.getString("NOW_PLAYING"));
                    $("#playerDetails button.radio").removeClass("active");
                    b.shuffleEnabled ? $("#player_shuffle").addClass("active") : $("#player_shuffle").removeClass("active")
                }
                a.trackLastAutoplayInfo(b.autoplayEnabled, b.currentAutoplayTagID)
            }
        },updateQueueSongs:function(b) {
            if (b.hasOwnProperty("songs"))if (b.songs.length) {
                a.currentSong =
                        b.activeSong;
                a.songs = b.songs;
                a.gsQueue.setActive(b.activeSong.index, false);
                a.gsQueue.setItems(b.songs)
            } else {
                a.activeSong = b.activeSong;
                a.songs = b.songs;
                $("#playerDetails_nowPlaying").html("");
                a.gsQueue.setActive(0, false);
                a.gsQueue.setItems([])
            }
        },updateQueueWidth:function() {
            var b,c,g = a.getCurrentQueue();
            if (g) {
                parseInt($("#queue_list_window").css("padding-left"), 10);
                b = $("#queue").width();
                c = $("#queue").height();
                if (g && g.songs && g.songs.length > 0) {
                    b = a.songWidth * (g.songs.length - 1) + a.activeSongWidth;
                    $("#queue_list").removeClass("empty")
                } else {
                    b =
                            b;
                    $("#queue_list").addClass("empty").width("")
                }
                c !== $("#queue").height() && a.lastQueueWidth !== b && $(window).resize();
                a.lastQueueWidth = b
            }
        },autoScrollWaitDuration:300,beginDragDrop:function() {
            function b(k, m) {
                var n = $("#queue_songGuide");
                if (c.within(k.clientX, k.clientY).length > 0) {
                    m.queueLength = _.orEqual(m.queueLength, a.getCurrentQueue().songs.length);
                    var o = c.parent(),r = a.activeSongWidth - a.songWidth,t = 0;
                    t = c.offset().left;
                    var w = g.scrollLeft() - 10 - (k.clientX > parseInt($("#queue_list .queue-item-active").css("left"),
                            10) + a.activeSongWidth ? r : 0),y = parseInt(g.width(), 10) * 0.05;
                    c.children();
                    r = a.getCurrentQueue().activeSong ? _.orEqual(a.getCurrentQueue().activeSong.index, 0) : 0;
                    stopIndex = Math.max(0, Math.min(m.queueLength, Math.round((k.clientX + w) / a.songWidth)));
                    guideLeft = stopIndex * a.songWidth + t - n.width() / 2;
                    if (o.offset().left + 200 > k.clientX) {
                        t = Math.max(0, w - y);
                        g.scrollLeft(t);
                        a.gsQueue.updateScrollbar();
                        clearInterval(m.queueAutoScrollInterval);
                        m.queueAutoScrollInterval = setInterval(function() {
                            var u = g.scrollLeft();
                            g.scrollLeft(Math.max(0,
                                    u - y));
                            a.gsQueue.updateScrollbar()
                        }, a.autoScrollWaitDuration)
                    } else if (o.width() - 200 < k.clientX) {
                        t = Math.min(c.width(), w + y);
                        g.scrollLeft(t);
                        a.gsQueue.updateScrollbar();
                        clearInterval(m.queueAutoScrollInterval);
                        m.queueAutoScrollInterval = setInterval(function() {
                            var u = g.scrollLeft();
                            u = Math.min(c.width(), u + y);
                            g.scrollLeft(u);
                            a.gsQueue.updateScrollbar()
                        }, a.autoScrollWaitDuration)
                    } else clearInterval(m.queueAutoScrollInterval);
                    if (stopIndex > r)guideLeft += a.activeSongWidth - a.songWidth;
                    n.css("left", guideLeft);
                    n.show()
                } else {
                    clearInterval(m.queueAutoScrollInterval);
                    n.hide()
                }
            }

            var c = $("#queue_list"),g = $("#queue_list_window"),h = $("#queue");
            $footer = $("#footer");
            c.bind("draginit",
                    function(k, m) {
                        var n = $(k.target).closest(".queue-item");
                        if (n.length === 0)return false;
                        m.draggedQueueItem = n;
                        m.proxyOffsetX = k.clientX - n.offset().left;
                        m.proxyOffsetY = k.clientY - n.offset().top
                    }).bind("dragstart",
                    function(k, m) {
                        m.draggedItems = [GS.Models.Song.getOneFromCache($(m.draggedQueueItem).find(".queueSong").attr("rel"))];
                        m.draggedItemsType = "song";
                        m.draggedItemSource = "queue";
                        return $(m.draggedQueueItem).clone().prepend('<div class="status"></div>').css("position",
                                "absolute").css("zIndex", "99999").addClass("queue-item-drag").appendTo("body").mousewheel(function(n, o) {
                                    var r = $("#queue_list_window"),t = $("#sidebar .container_inner_wrapper"),w = $("#grid .slick-viewport");
                                    r.within(n.clientX, n.clientY).length > 0 && r.scrollLeft(r.scrollLeft() - 82 * o);
                                    t.within(n.clientX, n.clientY).length > 0 && t.scrollTop(t.scrollTop() - 82 * o);
                                    w.within(n.clientX, n.clientY).length > 0 && w.scrollTop(w.scrollTop() - 82 * o)
                                })
                    }).bind("drag",
                    function(k, m) {
                        $(m.proxy).css("top", k.clientY - m.proxyOffsetY).css("left",
                                k.clientX - m.proxyOffsetX);
                        var n = false;
                        _.forEach(m.drop, function(o) {
                            $.isFunction(o.updateDropOnDrag) && o.updateDropOnDrag(k, m);
                            if (!n)if ($(o).within(k.clientX, k.clientY).length > 0)n = true
                        });
                        n ? $(m.proxy).addClass("valid").removeClass("invalid") : $(m.proxy).addClass("invalid").removeClass("valid")
                    }).bind("dragend", function(k, m) {
                        $(m.proxy).remove();
                        GS.guts.gaTrackEvent("player", "dragSuccess")
                    });
            $footer.bind("dropinit",
                    function() {
                        this.updateDropOnDrag = b
                    }).bind("dropstart",
                    function(k, m) {
                        if (!m.draggedItems) {
                            this.updateDropOnDrag =
                                    null;
                            return false
                        }
                        $(".queue-item").length && $("<div id='queue_songGuide'/>").addClass("size_" + GS.player.queueSize).css("position", "absolute").css("zIndex", "99998").css("height", $(".queue-item").outerHeight(true)).css("width", 10).css("top", $(".queue-item").offset().top + 5).hide().appendTo("body")
                    }).bind("dropend",
                    function(k, m) {
                        $("#queue_songGuide").remove();
                        clearInterval(m.queueAutoScrollInterval)
                    }).bind("drop", function(k, m) {
                        $(this).offset();
                        var n = $footer.within(k.clientX, k.clientY).length > 0,o = h.within(k.clientX,
                                k.clientY).length > 0,r = a.activeSongWidth - a.songWidth;
                        r = $("#queue_list_window").scrollLeft() - 10 - (k.clientX > parseInt($("#queue_list .queue-item-active").css("left"), 10) + a.activeSongWidth ? r : 0);
                        r = Math.max(0, Math.min(m.queueLength, Math.round((k.clientX + r) / a.songWidth)));
                        if (m.draggedItemSource == "queue") {
                            if (!($(".queue-item", c).length < 2)) {
                                queueSongID = m.draggedQueueItem.find(".queueSong").attr("id");
                                a.moveSongsTo([queueSongID], r)
                            }
                        } else {
                            var t = [],w,y,u;
                            if (n)if (!(!o && c.is(":visible")))if (!(k.clientX === 0 && k.layerX ===
                                    0 && k.offsetX === 0 && k.screenX === 0)) {
                                m.draggedItemsType = m.draggedItemsType || _.guessDragType(m.draggedItems);
                                switch (m.draggedItemsType) {
                                    case "song":
                                        w = [];
                                        for (y = 0; y < m.draggedItems.length; y++)w.push(m.draggedItems[y].SongID);
                                        t.push({songIDs:w,context:m.draggedItemsContext});
                                        var E,H = [],A = [];
                                        if ($("#grid").controller()) {
                                            var x = $("#grid").controller().dataView.rows;
                                            $('#grid .slick-row.selected[id!="showQueue"]').each(function(B, D) {
                                                E = parseInt($(D).attr("row"), 10);
                                                if (!isNaN(E)) {
                                                    H.push(E + 1);
                                                    var F = x[E].ppVersion;
                                                    F && A.push(F)
                                                }
                                            })
                                        }
                                        n = {ranks:H,songIDs:w};
                                        if (A.length > 0)n.ppVersions = A.join();
                                        GS.guts.logEvent("OLSongsDraggedToQueue", n);
                                        break;
                                    case "album":
                                        for (y = 0; y < m.draggedItems.length; y++) {
                                            w = [];
                                            m.draggedItems[y].getSongs(function(B) {
                                                B.sort(GS.Models.Album.defaultSongSort);
                                                for (u = 0; u < B.length; u++)w.push(B[u].SongID)
                                            }, null, false, {async:false});
                                            t.push({songIDs:w,context:new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ALBUM, m.draggedItems[y])})
                                        }
                                        break;
                                    case "artist":
                                        for (y = 0; y < m.draggedItems.length; y++) {
                                            w = [];
                                            m.draggedItems[y].getSongs(function(B) {
                                                B.sort(GS.Models.Artist.defaultSongSort);
                                                for (u = 0; u < B.length; u++)w.push(B[u].SongID)
                                            }, null, false, {async:false});
                                            t.push({songIDs:w,context:new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ARTIST, m.draggedItems[y])})
                                        }
                                        break;
                                    case "playlist":
                                        for (y = 0; y < m.draggedItems.length; y++) {
                                            w = [];
                                            m.draggedItems[y].getSongs(function(B) {
                                                for (u = 0; u < B.length; u++)w.push(B[u].SongID)
                                            }, null, false, {async:false});
                                            t.push({songIDs:w,context:new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST, m.draggedItems[y])})
                                        }
                                        break;
                                    case "user":
                                        for (y = 0; y < m.draggedItems.length; y++) {
                                            w =
                                                    [];
                                            m.draggedItems[y].getFavoritesByType("Song", function(B) {
                                                for (u = 0; u < B.length; u++)w.push(B[u].SongID)
                                            }, null, false, {async:false});
                                            t.push({songIDs:w,context:new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_USER, m.draggedItems[y])})
                                        }
                                        break;
                                    default:
                                        console.error("queue drop, invalid drag type", m.draggedItemsType);
                                        return
                                }
                                o = h.within(k.clientX, k.clientY).length > 0 || a.getCurrentQueue().songs.length > 0 ? false : true;
                                for (y = 0; y < t.length; y++) {
                                    w = t[y].songIDs;
                                    n = _.orEqual(t[y].context, new GS.Models.PlayContext);
                                    a.addSongsToQueueAt(w,
                                            r, o, n);
                                    r += w.length;
                                    o = false
                                }
                                GS.guts.gaTrackEvent("player", "dropSuccess")
                            }
                        }
                    });
            $.drop({tolerance:function(k, m, n) {
                return this.contains(n, [k.clientX,k.clientY])
            }})
        },addQueueSeek:function() {
            this.seek = $("#seeking_wrapper");
            this.scrubber = $("#seeking_wrapper .scrubber").addClass("ui-slider-handle").supersleight();
            $(".bar.buffer .cap_right").supersleight();
            $(".bar.buffer .cap_right .cap_left").supersleight();
            $(".bar.buffer .cap_right .cap_left .inner").supersleight();
            $(".bar.buffer .cap_right").supersleight();
            $(".bar.buffer .cap_right .cap_left").supersleight();
            $(".bar.buffer .cap_right .cap_left .inner").supersleight();
            $(".bar.progress .cap_right").supersleight();
            $(".bar.progress .cap_right .cap_left").supersleight();
            $(".bar.progress .cap_right .cap_left .inner").supersleight();
            this.seek.slider({disabled:true,max:1E3,start:function() {
                GS.player.SCRUB_LOCK = true
            },stop:function() {
                GS.player.SCRUB_LOCK = false
            },change:function(b, c) {
                var g = c.value / 1E3,h = a.player.getPlaybackStatus();
                a.seekTo(g * h.duration)
            }})
        },addQueueMousewheel:function() {
            $("#queue_list_window").mousewheel(function(b, c) {
                $(this).scrollLeft($(this).scrollLeft() - 82 * c)
            })
        },addShortcuts:function() {
            a.volumeSliderTimeout = null;
            a.volumeSliderDuration = 300;
            $(document).bind("keyup", "space",
                    function(b) {
                        $(b.target).is("button") && b.preventDefault()
                    }).bind("keydown", "space",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.togglePlayPause();
                            GS.guts.gaTrackEvent("player", "playPauseShortcut");
                            return false
                        }
                    }).bind("keydown", "ctrl+right",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") &&
                                $(b.target).val().length > 0)) {
                            a.nextSong();
                            GS.guts.gaTrackEvent("player", "nextShortcut");
                            return false
                        }
                    }).bind("keydown", "meta+right",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.nextSong();
                            GS.guts.gaTrackEvent("player", "nextShortcut");
                            return false
                        }
                    }).bind("keydown", "ctrl+left",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.previousSong();
                            GS.guts.gaTrackEvent("player", "prevShortcut");
                            return false
                        }
                    }).bind("keydown",
                    "meta+left",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.previousSong();
                            GS.guts.gaTrackEvent("player", "prevShortcut");
                            return false
                        }
                    }).bind("keydown", "ctrl+up",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.setVolume(Math.min(100, a.getVolume() + 5));
                            $("#volumeSlider").slider("value", a.getVolume());
                            $("#volumeControl").show();
                            clearTimeout(a.volumeSliderTimeout);
                            a.volumeSliderTimeout = setTimeout(function() {
                                        $("#volumeControl").hide()
                                    },
                                    a.volumeSliderDuration);
                            GS.guts.gaTrackEvent("player", "volumeUpShortcut", a.getVolume());
                            return false
                        }
                    }).bind("keydown", "meta+up",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.setVolume(Math.min(100, a.getVolume() + 5));
                            $("#volumeSlider").slider("value", a.getVolume());
                            $("#volumeControl").show();
                            clearTimeout(a.volumeSliderTimeout);
                            a.volumeSliderTimeout = setTimeout(function() {
                                $("#volumeControl").hide()
                            }, a.volumeSliderDuration);
                            GS.guts.gaTrackEvent("player", "volumeUpShortcut",
                                    a.getVolume());
                            return false
                        }
                    }).bind("keydown", "ctrl+down",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.setVolume(Math.max(0, a.getVolume() - 5));
                            $("#volumeSlider").slider("value", a.getVolume());
                            $("#volumeControl").show();
                            clearTimeout(a.volumeSliderTimeout);
                            a.volumeSliderTimeout = setTimeout(function() {
                                $("#volumeControl").hide()
                            }, a.volumeSliderDuration);
                            GS.guts.gaTrackEvent("player", "volumeDownShortcut", a.getVolume());
                            return false
                        }
                    }).bind("keydown", "meta+down",
                    function(b) {
                        if (!($(b.target).is("input,textarea,select") && $(b.target).val().length > 0)) {
                            a.setVolume(Math.max(0, a.getVolume() - 5));
                            $("#volumeSlider").slider("value", a.getVolume());
                            $("#volumeControl").show();
                            clearTimeout(a.volumeSliderTimeout);
                            a.volumeSliderTimeout = setTimeout(function() {
                                $("#volumeControl").hide()
                            }, a.volumeSliderDuration);
                            GS.guts.gaTrackEvent("player", "volumeDownShortcut", a.getVolume());
                            return false
                        }
                    })
        },addVolumeSlider:function() {
            var b = function(c, g) {
                var h = "full";
                h = g.value > 75 ? "full" : g.value >
                        50 ? "threeQuarter" : g.value > 25 ? "half" : g.value > 0 ? "quarter" : "off";
                $("#player_volume").attr("class", "player_control").addClass(h);
                g.value == 0 && a.getIsMuted() ? $("#player_volume").addClass("muted") : a.setVolume(g.value)
            };
            $("#volumeSlider").slider({orientation:"vertical",range:"min",min:0,max:100,slide:b,change:b})
        },".queueSong a.play click":function(b, c) {
            c.stopImmediatePropagation();
            var g = a.getCurrentQueue();
            if (g.activeSong && b.attr("rel") == g.activeSong.queueSongID)if (a.isPlaying)a.pauseSong(); else a.isPaused ?
                    a.resumeSong() : a.playSong(g.activeSong.queueSongID); else a.playSong(b.attr("rel"));
            return false
        },".queueSong a.remove click":function(b, c) {
            c.stopImmediatePropagation();
            var g = a.getCurrentQueue().activeSong,h = a.getSongDetails(a.getCurrentQueue().queueID, b.parents(".queueSong").attr("id"))[0];
            a.removeSongs([h.queueSongID]);
            a.queue = false;
            a.queue = a.getCurrentQueue();
            a.updateQueueWidth();
            a.gsQueue.setItems(a.queue.songs);
            if (a.queue.activeSong)a.gsQueue.setActive(a.queue.activeSong.index, false); else g &&
                    g.index && g.index > 0 && a.gsQueue.setActive(g.index - 1, false);
            GS.guts.gaTrackEvent("player", "removeSong", h.SongID);
            return false
        },".queueSong a.add click":function(b, c) {
            c.stopImmediatePropagation();
            var g = a.getCurrentQueue(),h = b.is(".inLibrary"),k = b.parents(".queueSong").attr("id");
            g = a.getSongDetails(g.queueID, [k])[0];
            if (a.currentSong && a.currentSong.queueSongID === g.queueSongID)g = a.currentSong;
            if (h) {
                b.removeClass("inLibrary").removeClass("isFavorite");
                GS.user.removeFromLibrary(g.SongID);
                GS.guts.logEvent("playerRemoveFromLibrary",
                        {songID:g.SongID})
            } else {
                b.addClass("inLibrary");
                GS.user.addToLibrary(g.SongID);
                GS.guts.logEvent("playerAddToLibrary", {songID:g.SongID})
            }
            return false
        },".queueSong a.favorite click":function(b, c) {
            c.stopImmediatePropagation();
            var g = a.getCurrentQueue(),h = b.is(".isFavorite"),k = b.parents(".queueSong").attr("id");
            g = a.getSongDetails(g.queueID, [k])[0];
            if (a.currentSong && a.currentSong.queueSongID === g.queueSongID)g = a.currentSong;
            if (h) {
                b.removeClass("isFavorite");
                GS.user.removeFromSongFavorites(g.SongID);
                GS.guts.logEvent("playerRemoveFromSongFavorites",
                        {songID:g.SongID})
            } else {
                b.addClass("isFavorite");
                GS.user.addToSongFavorites(g.SongID);
                GS.guts.logEvent("playerAddToSongFavorites", {songID:g.SongID})
            }
            return false
        },".queueSong a.options click":function(b, c) {
            c.stopImmediatePropagation();
            var g = this.getCurrentQueue(),h = b.parents(".queueSong").attr("id");
            g = this.getSongDetails(g.queueID, [h])[0];
            var k = {isQueue:true,flagSongCallback:function(m) {
                GS.player.flagSong(h, m)
            }};
            if ($("div.qsid" + h).is(":visible")) {
                $("div.qsid" + h).hide();
                b.removeClass("active-context")
            } else {
                $(b).jjmenu(c,
                        g.getContextMenu(k), null, {xposition:"auto",yposition:"top",orientation:"top",show:"show",className:"queuemenu qsid" + h});
                GS.guts.gaTrackEvent("player", "songMenu", g.SongID)
            }
            return false
        },".queueSong .smile click":function(b, c) {
            c.stopImmediatePropagation();
            console.log("player.smile click", b, c);
            var g = b.parents(".queueSong").attr("id");
            b.siblings(".frown").removeClass("active");
            if (b.is(".active")) {
                this.voteSong(g, 0);
                b.removeClass("active");
                GS.guts.gaTrackEvent("player", "unsmile", b.parents(".queueSong").attr("id"));
                this.trackAutoplayEvent("unsmile")
            } else {
                this.voteSong(g, 1);
                b.addClass("active");
                GS.guts.gaTrackEvent("player", "smile", b.parents(".queueSong").attr("id"));
                this.trackAutoplayEvent("smile")
            }
            return false
        },".queueSong .frown click":function(b, c) {
            c.stopImmediatePropagation();
            console.log("player.frown click", b.get(), c);
            var g = b.parents(".queueSong").attr("id");
            b.siblings(".smile").removeClass("active");
            if (b.is(".active")) {
                this.voteSong(g, 0);
                b.removeClass("active");
                GS.guts.gaTrackEvent("player", "unfrown",
                        b.parents(".queueSong").attr("id"));
                this.trackAutoplayEvent("unfrown")
            } else {
                this.voteSong(g, -1);
                b.addClass("active");
                GS.guts.gaTrackEvent("player", "frown", b.parents(".queueSong").attr("id"));
                this.trackAutoplayEvent("frown")
            }
            return false
        },".queueSong, .currentSongLink click":function(b, c) {
            c.stopImmediatePropagation();
            if (!$(c.target).is("a[href]")) {
                var g = b.attr("rel"),h = GS.Models.Song.getOneFromCache(g);
                if (h = h && $.isFunction(h.toUrl) ? h.toUrl() : false) {
                    location.hash = h;
                    GS.guts.gaTrackEvent("player", "songItemLink",
                            g)
                }
                return false
            }
        },".queueSong mousedown":function(b, c) {
            c.stopImmediatePropagation();
            if (c.button === 2) {
                var g = GS.Models.Song.getOneFromCache(b.attr("rel")),h = b.attr("id");
                b.jjmenu(c, g.getContextMenu({isQueue:true,flagSongCallback:function(k) {
                    GS.player.flagSong(h, k)
                }}), null, {xposition:"mouse",yposition:"mouse",show:"show",className:"queuemenu"});
                GS.guts.gaTrackEvent("player", "songMenu", g.SongID)
            }
            return false
        },"#playerDetails_nowPlaying .add click":function(b) {
            var c = $("#playerDetails_nowPlaying").attr("rel");
            b = b.is(".selected");
            if (this.getCurrentSong())if (b) {
                GS.user.removeFromLibrary(c);
                GS.guts.logEvent("playerRemoveFromLibrary", {songID:c})
            } else {
                GS.user.addToLibrary(c);
                GS.guts.logEvent("playerAddToLibrary", {songID:c})
            }
            return false
        },"#playerDetails_nowPlaying .favorite click":function(b) {
            var c = $("#playerDetails_nowPlaying").attr("rel");
            b = b.is(".selected");
            if (this.getCurrentSong())if (b) {
                GS.user.removeFromSongFavorites(c);
                GS.guts.logEvent("playerRemoveFromSongFavorites", {songID:c})
            } else {
                GS.user.addToSongFavorites(c);
                GS.guts.logEvent("playerAddToSongFavorites", {songID:c})
            }
            return false
        },"#playerDetails_nowPlaying .share click":function(b, c) {
            console.log("nowplaying share click", b.get(), c);
            this.getCurrentSong() && GS.lightbox.open("share", {service:"email",type:"song",id:this.getCurrentSong().SongID});
            return false
        },"#playerDetails_nowPlaying .options click":function(b, c) {
            console.log("nowplaying options click", b.get(), c);
            var g = $("#playerDetails_nowPlaying").attr("rel"),h = this.getCurrentSong().queueSongID,k = GS.Models.Song.getOneFromCache(g),
                    m = {isQueue:true,flagSongCallback:function(n) {
                        GS.player.flagSong(h, n)
                    }};
            if ($("div.jjplayerNowPlaying").is(":visible")) {
                $("div.jjplayerNowPlaying").hide();
                b.removeClass("active-context")
            } else {
                $(b).jjmenu(c, k.getContextMenu(m), null, {xposition:"left",yposition:"top",orientation:"top",show:"show",className:"queuemenu jjplayerNowPlaying"});
                GS.guts.gaTrackEvent("player", "nowPlayingMenu", g)
            }
        },"#playerDetails_queue .toggleQueue click":function() {
            this.toggleQueue();
            this.userChangedQueueVisibility = true;
            return false
        },
        toggleQueue:function() {
            $("#queue").height();
            $("#footer").height();
            $("#queue").is(":visible");
            $("#queue").toggle();
            if (this.queueIsVisible = $("#queue").is(":visible"))$("#showQueue").addClass("selected"); else {
                $("#showQueue").removeClass("selected");
                $("div.queuemenu,div.radiomenu").length && $("div.jjmenu").remove()
            }
            $(window).resize();
            GS.guts.gaTrackEvent("player", "toggleQueue", this.queueIsVisible ? "visible" : "hidden")
        },togglePlayPause:function() {
            var b = this.player.getPlaybackStatus();
            if (b) {
                switch (b.status) {
                    case this.PLAY_STATUS_NONE:
                    case this.PLAY_STATUS_FAILED:
                    case this.PLAY_STATUS_COMPLETED:
                    default:
                        b.activeSong &&
                        this.playSong(b.activeSong.queueSongID);
                        break;
                    case this.PLAY_STATUS_INITIALIZING:
                    case this.PLAY_STATUS_LOADING:
                        this.stopSong();
                        break;
                    case this.PLAY_STATUS_PLAYING:
                    case this.PLAY_STATUS_BUFFERING:
                        this.pauseSong();
                        break;
                    case this.PLAY_STATUS_PAUSED:
                        this.resumeSong();
                        break
                }
                $.publish("gs.player.queue.change")
            }
        },"#player_play_pause click":function() {
            this.togglePlayPause();
            return false
        },"#player_previous click":function() {
            this.previousSong();
            return false
        },"#player_next click":function() {
            this.nextSong();
            return false
        },"#player_shuffle click":function(b) {
            if (!a.queue.autoplayEnabled) {
                b.toggleClass("active");
                b = b.is(".active") ? true : false;
                a.setShuffle(b);
                return false
            }
        },"#player_loop click":function(b) {
            var c;
            if (b.is(".none")) {
                c = a.REPEAT_ALL;
                b.removeClass("none").addClass("all").addClass("active")
            } else if (b.is(".all")) {
                c = a.REPEAT_ONE;
                b.removeClass("all").addClass("one").addClass("active")
            } else {
                c = a.REPEAT_NONE;
                b.removeClass("one").addClass("none").removeClass("active")
            }
            a.setRepeat(c);
            return false
        },"#player_crossfade click":function(b) {
            if (GS.user.UserID >
                    0 && GS.user.IsPremium) {
                b.toggleClass("active");
                b = b.is(".active") ? true : false;
                a.setCrossfadeEnabled(b)
            } else GS.lightbox.open("vipOnlyFeature", {callback:this.callback(function() {
                this.setCrossfadeEnabled(true)
            })});
            return false
        },"#player_fullscreen click":function() {
            return false
        },"#player_volume click":function(b) {
            console.log("player_volume toggle", this.getIsMuted());
            if (this.getIsMuted()) {
                this.setIsMuted(false);
                $(b).removeClass("muted");
                $("#volumeSlider").slider("value", a.player.getVolume())
            } else {
                this.setIsMuted(true);
                $(b).addClass("muted");
                $("#volumeSlider").slider("value", 0)
            }
            return false
        },"#player_volume mouseenter":function() {
            clearTimeout(this.volumeSliderTimeout);
            $("#volumeControl").show();
            return false
        },"#player_volume mouseleave":function() {
            clearTimeout(this.volumeSliderTimeout);
            this.volumeSliderTimeout = setTimeout(this.callback(function() {
                $("#volumeControl").hide()
            }), this.volumeSliderDuration);
            return false
        },"#volumeControl mouseenter":function() {
            clearTimeout(this.volumeSliderTimeout);
            return false
        },"#volumeControl mouseleave":function() {
            clearTimeout(this.volumeSliderTimeout);
            if (this.isMouseDown) {
                var b = this,c = function() {
                    $("body").unbind("mouseup", c);
                    $("body").unbind("mouseleave", c);
                    b.isMouseDown = 0;
                    b.volumeSliderTimeout = setTimeout(b.callback(function() {
                        $("#volumeControl").hide()
                    }), b.volumeSliderDuration)
                };
                $("body").bind("mouseup", c);
                $("body").bind("mouseleave", c)
            } else this.volumeSliderTimeout = setTimeout(this.callback(function() {
                $("#volumeControl").hide()
            }), this.volumeSliderDuration);
            return false
        },isMouseDown:0,mousedown:function() {
            this.isMouseDown = 1
        },mouseup:function() {
            this.isMouseDown =
                    0
        },"#queue_songs_button click":function(b, c) {
            c.stopPropagation();
            var g = this.getCurrentQueue(),h = this,k = [],m = [],n = GS.Models.Playlist.getPlaylistsMenu([], function(r) {
                var t = [],w = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST, r);
                r.getSongs(function(y) {
                    for (j = 0; j < y.length; j++)t.push(y[j].SongID);
                    GS.player.addSongsToQueueAt(t, h.INDEX_REPLACE, true, w)
                }, null, false, {async:false})
            }, true, false);
            if (g && g.songs && g.songs.length > 0)k = [
                {title:$.localize.getString("CONTEXT_ADD_TO_LIBRARY"),customClass:"addLibrary jj_menu_item_hasIcon jj_menu_item_music",
                    action:{type:"fn",callback:function() {
                        var r,t = [];
                        for (r = 0; r < g.songs.length; r++) {
                            t.push(g.songs[r].SongID);
                            GS.guts.logEvent("playerAddToLibrary", {songID:g.songs[r].SongID})
                        }
                        GS.user.addToLibrary(t)
                    }}},
                {customClass:"separator"}
            ];
            n.length > 0 && k.push({title:$.localize.getString("QUEUE_LOAD_PLAYLIST"),customClass:"playlist jj_menu_item_hasIcon jj_menu_item_playlist",type:"sub",src:n});
            if (g && g.songs && g.songs.length > 0) {
                _.forEach(g.songs, function(r) {
                    m.push(r.SongID)
                });
                n = GS.Models.Playlist.getPlaylistsMenu(m,
                        function(r) {
                            GS.lightbox.open("confirm", {message:$.localize.getString("POPUP_ARE_YOU_SURE_OVERWRITE_PLAYLIST"),data:r,callback:function(t) {
                                t.overwriteWithSongs(m, true)
                            }})
                        }, false, true);
                var o = GS.Models.Playlist.getPlaylistsMenu(m, function(r) {
                    r.addSongs(m, r.length, true)
                }, false, false);
                k.push({title:$.localize.getString("QUEUE_SAVE_PLAYLIST"),customClass:"jj_menu_item_hasIcon jj_menu_item_replace_playlist saveQueue",type:"sub",src:n});
                k.push({title:$.localize.getString("QUEUE_ADD_TO_PLAYLIST"),customClass:"saveQueue jj_menu_item_hasIcon jj_menu_item_add_playlist",
                    type:"sub",src:o});
                k.length && k.push({customClass:"separator"});
                k.push({title:$.localize.getString("QUEUE_EMBED_SONGS"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_widget shareSongs",action:{type:"fn",callback:function() {
                    var r,t = [];
                    for (r = 0; r < g.songs.length; r++)t.push(g.songs[r].SongID);
                    GS.lightbox.open("share", {service:"widget",type:"manySongs",id:t})
                }}});
                k.push({title:$.localize.getString("QUEUE_VIEW_SONGS"),customClass:"jj_menu_item_hasIcon jj_menu_item_now_playing viewSongs",action:{type:"fn",
                    callback:function() {
                        window.location.hash = "#/now_playing"
                    }}})
            }
            n = [
                {title:$.localize.getString("QUEUE_NORMAL"),customClass:this.queueIsVisible && GS.player.queueSize == "m" ? "jj_menu_item_hasIcon jj_menu_item_tick" : "jj_menu_item_hasIcon jj_menu_item_blank",action:{type:"fn",callback:function() {
                    h.queueIsVisible || h.toggleQueue();
                    GS.player.setQueue("m")
                }}},
                {title:$.localize.getString("QUEUE_SMALL"),customClass:this.queueIsVisible && GS.player.queueSize == "s" ? "jj_menu_item_hasIcon jj_menu_item_tick" : "jj_menu_item_hasIcon jj_menu_item_blank",
                    action:{type:"fn",callback:function() {
                        h.queueIsVisible || h.toggleQueue();
                        GS.player.setQueue("s")
                    }}},
                {title:$.localize.getString("QUEUE_HIDE"),customClass:this.queueIsVisible ? "jj_menu_item_hasIcon jj_menu_item_blank" : "jj_menu_item_hasIcon jj_menu_item_tick",action:{type:"fn",callback:function() {
                    h.toggleQueue()
                }}}
            ];
            k.length && k.push({customClass:"separator"});
            k.push({title:$.localize.getString("QUEUE_SIZES"),type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_queue",src:n});
            if (g && g.songs && g.songs.length) {
                k.length &&
                k.push({customClass:"separator"});
                k.push({title:$.localize.getString("PLAYER_SHOW_VISUALIZER"),customClass:"jj_menu_item_hasIcon jj_menu_item_visualizer",action:{type:"fn",callback:function() {
                    if (GS.user.IsPremium)$("#lightbox .lbcontainer:visible").is(".gs_lightbox_visualizer") || GS.lightbox.open("visualizer", {showPlayerControls:true}); else GS.lightbox.open("vipOnlyFeature", {callback:h.callback(function() {
                        $("#lightbox .lbcontainer:visible").is(".gs_lightbox_visualizer") || GS.lightbox.open("visualizer",
                                {showPlayerControls:true})
                    })})
                }}});
                h.videoModeEnabled ? k.push({title:$.localize.getString("PLAYER_DISABLE_VIDEO_MODE"),customClass:"jj_menu_item_hasIcon jj_menu_item_video",action:{type:"fn",callback:function() {
                    h.disableVideoMode()
                }}}) : k.push({title:$.localize.getString("PLAYER_ENABLE_VIDEO_MODE"),customClass:"jj_menu_item_hasIcon jj_menu_item_video",action:{type:"fn",callback:function() {
                    GS.user.IsPremium ? h.enableVideoMode() : GS.lightbox.open("vipOnlyFeature", {callback:h.callback(function() {
                        this.enableVideoMode()
                    })})
                }}});
                h.powerModeEnabled ? k.push({title:$.localize.getString("PLAYER_DISABLE_POWER_MODE"),customClass:"jj_menu_item_hasIcon jj_menu_item_clock",action:{type:"fn",callback:function() {
                    h.disablePowerMode()
                }}}) : k.push({title:$.localize.getString("PLAYER_ENABLE_POWER_MODE"),customClass:"jj_menu_item_hasIcon jj_menu_item_clock",action:{type:"fn",callback:function() {
                    GS.user.IsPremium ? h.enablePowerMode() : GS.lightbox.open("vipOnlyFeature", {callback:h.callback(function() {
                        this.enablePowerMode()
                    })})
                }}})
            }
            if ($("div.jjQueueMenu").is(":visible")) {
                $("div.jjQueueMenu").hide();
                b.removeClass("active-context")
            } else {
                $(b).jjmenu(c, k, null, {xposition:"right",yposition:"top",orientation:"top",spill:"left",show:"show",className:"radiomenu jjQueueMenu"});
                GS.guts.gaTrackEvent("player", "queueSongMenu")
            }
            return false
        },"#queue_radio_button click":function(b, c) {
            if (!$(b).is(".active-context")) {
                var g = this.getCurrentQueue(),h = this,k = [];
                k.push({title:$.localize.getString("QUEUE_LOAD_STATION"),customClass:"stations jj_menu_item_hasIcon jj_menu_item_station",type:"sub",src:GS.Models.Station.getStationsStartMenu()});
                if (g.autoplayEnabled) {
                    k.push({customClass:"separator"});
                    k.push({title:$.localize.getString("QUEUE_TURN_OFF_RADIO"),customClass:"jj_menu_item_hasIcon jj_menu_item_radio",action:{type:"fn",callback:function() {
                        if (h.player)if (h.player.getCurrentQueue().autoplayEnabled) {
                            h.player.setAutoplay(false);
                            GS.guts.endContext("autoplay")
                        }
                    }}})
                } else if (g && g.songs && g.songs.length > 0) {
                    k.push({customClass:"separator"});
                    k.push({title:$.localize.getString("QUEUE_TURN_ON_RADIO"),customClass:"jj_menu_item_hasIcon jj_menu_item_radio",
                        action:{type:"fn",callback:function() {
                            if (h.player)if (!h.player.getCurrentQueue().autoplayEnabled) {
                                h.player.setAutoplay(true);
                                GS.guts.beginContext({autoplay:0})
                            }
                        }}})
                }
                $(b).jjmenu(c, k, null, {xposition:"right",yposition:"top",orientation:"top",spill:"left",show:"show",className:"radiomenu jjRadioMenu"});
                GS.guts.gaTrackEvent("player", "radioMenu");
                return false
            }
        },videoIndex:0,enableVideoMode:function() {
            this.videoModeEnabled = true;
            this.showVideoLightbox();
            if (this.powerModeEnabled) {
                clearInterval(this.powerModeInterval);
                this.powerModeInterval = setInterval(this.callback("youtubeCheckPowerMode"), 1E3)
            }
            GS.guts.gaTrackEvent("player", "enableVideoMode")
        },disableVideoMode:function() {
            this.videoModeEnabled = false;
            this.hideVideoLightbox();
            this.playSong();
            this.powerModeEnabled && clearInterval(this.powerModeInterval);
            GS.guts.gaTrackEvent("player", "disableVideoMode")
        },showVideoLightbox:function() {
            var b = this.currentSong;
            if (b) {
                GS.lightbox.open("video", {isLoading:true,sidebarHeader:"POPUP_VIDEO_ALTERNATE"});
                var c = [b.SongName || "",b.ArtistName ||
                        ""].join(" ");
                GS.youtube.search(c, this.callback(function(g) {
                    var h,k,m = [];
                    if (g && g[0] && g[0].VideoID) {
                        for (var n = 0; n < g.length; n++) {
                            k = GS.Models.Video.wrapYoutube(g[n], b.ArtistName + " - " + b.SongName);
                            h || (h = k);
                            m.push(k)
                        }
                        m = m.splice(0, 6);
                        GS.lightbox.close();
                        a.videoModeEnabled = true;
                        GS.lightbox.open("video", {video:h,videos:m,showVideoControls:true,isVideoMode:true,sidebarHeader:"POPUP_VIDEO_ALTERNATE"});
                        GS.lightbox.positionLightbox()
                    } else console.warn("bad youtube search items", g, c, g)
                }))
            } else $.publish("gs.notification",
                    {type:"error",message:$.localize.getString("NOTIF_FEATURE_REQUIREMENT_SONGS")})
        },hideVideoLightbox:function() {
            $("div.lbcontainer.gs_lightbox_video").is(":visible") && GS.lightbox.close()
        },youtubePrevSong:function() {
            var b = a.getCurrentQueue(),c = b.activeSong.index,g = b.songs[c - 1] || {},h = [g.SongName || "",g.ArtistName || ""].join(" ");
            if (b.songs[c - 1]) {
                a.setActiveSong(g.queueSongID);
                GS.youtube.search(h, a.callback(function(k) {
                    var m,n,o = [];
                    if (k && k[0] && k[0].VideoID) {
                        for (var r = 0; r < k.length; r++) {
                            n = GS.Models.Video.wrapYoutube(k[r],
                                    g.ArtistName + " - " + g.SongName);
                            m || (m = n);
                            o.push(n)
                        }
                        o = o.splice(0, 4);
                        this.youtubeRetries = 0;
                        GS.youtube.loadVideoById(m.VideoID);
                        $("#lightbox .gs_lightbox_video #lightbox_nav .videos").html(this.view("/shared/videos", {videos:o,startIndex:0}));
                        $("#lightbox .gs_lightbox_video #lightbox_header h3.title").text(m.title);
                        k = $("div.lbcontainer.gs_lightbox_video").controller();
                        k.video = m;
                        k.videos = o;
                        k.startIndex = 0;
                        GS.lightbox.positionLightbox()
                    } else console.warn("bad youtube search items", k, h, k)
                }))
            }
        },youtubeNextSong:function() {
            var b =
                    a.getCurrentQueue(),c = b.songs[b.activeSong.index + 1] || {},g = [c.SongName || "",c.ArtistName || ""].join(" ");
            a.setActiveSong(c.queueSongID);
            GS.youtube.search(g, a.callback(function(h) {
                var k,m,n = [];
                if (h && h[0] && h[0].VideoID) {
                    for (var o = 0; o < h.length; o++) {
                        m = GS.Models.Video.wrapYoutube(h[o], c.ArtistName + " - " + c.SongName);
                        k || (k = m);
                        n.push(m)
                    }
                    n = n.splice(0, 4);
                    this.youtubeRetries = 0;
                    GS.youtube.loadVideoById(k.VideoID);
                    $("#lightbox .gs_lightbox_video #lightbox_nav .videos").html(this.view("/shared/videos", {videos:n,startIndex:0}));
                    $("#lightbox .gs_lightbox_video #lightbox_header h3.title").text(k.title);
                    h = $("div.lbcontainer.gs_lightbox_video").controller();
                    h.video = k;
                    h.videos = n;
                    h.startIndex = 0;
                    GS.lightbox.positionLightbox()
                } else console.warn("bad youtube search items", h, g, h)
            }))
        },youtubeStateChange:function(b) {
            console.log("youtubeStateChange", b);
            switch (b) {
                case 0:
                    GS.player.videoModeEnabled ? a.youtubeNextSong() : $(".lbcontainer:visible").controller().setNextVideo();
                    break;
                case 5:
                    GS.player.videoModeEnabled && GS.youtube.playVideo();
                    break;
                case 1:
                    if (this.powerModeEnabled) {
                        clearInterval(this.powerModeInterval);
                        this.powerModeInterval = setInterval(this.callback("youtubeCheckPowerMode"), 1E3)
                    }
                    break
            }
        },youtubeError:function(b) {
            console.warn("youtubeError", b);
            if (a.youtubeRetries >= 3) {
                a.youtubeNextSong();
                console.warn("youtube error, try next video, but if maxRetries (3), go to next song")
            } else {
                b = $("#lightbox .gs_lightbox_video #lightbox_nav .videos a.video.active").parent();
                if (b.length && b.next().length) {
                    GS.youtubeRetries++;
                    b.next().children("a").click()
                } else a.youtubeNextSong()
            }
        },
        searchForVideosBySong:function(b, c, g) {
            b = [b.SongName || "",b.ArtistName || "",b.AlbumName || ""].join(" ");
            GS.youtube.search(b, c, g)
        },togglePowerMode:function() {
            this.powerModeEnabled ? this.disablePowerMode() : this.enablePowerMode()
        },enablePowerMode:function() {
            this.powerModeEnabled = true;
            if (this.videoModeEnabled) {
                clearInterval(this.powerModeInterval);
                this.powerModeInterval = setInterval(this.callback("youtubeCheckPowerMode"), 1E3)
            }
            GS.guts.gaTrackEvent("player", "enablePowerMode")
        },disablePowerMode:function() {
            this.powerModeEnabled =
                    false;
            this.videoModeEnabled && clearInterval(this.powerModeInterval);
            GS.guts.gaTrackEvent("player", "disablePowerMode")
        },youtubeCheckPowerMode:function() {
            GS.youtube.getCurrentTime() > 60 && this.nextSong()
        },"#queue_clear_button click":function() {
            var b = this.getCurrentQueue();
            if (b.hasRestoreQueue)a.restoreQueue(); else b && b.songs && b.songs.length > 0 && a.clearQueue()
        },queueSongToHtml:function(b, c, g) {
            var h = "paused",k = [],m = a.getCurrentQueue(),n = "",o = b.fromLibrary ? "inLibrary" : "",r = b.isFavorite ? "isFavorite" : "",t = "",
                    w = "";
            if (m.activeSong && b.queueSongID === m.activeSong.queueSongID) {
                n += " active";
                if (a.isPlaying)h = ""
            }
            if (m.autoplayEnabled) {
                if (b.autoplayVote === -1 || c === g - 1 && b.source !== "user")n += " greyOut";
                if (b.autoplayVote === 1 || b.autoplayVote === 0 && b.source === "user") {
                    t = "active";
                    w = ""
                } else if (b.autoplayVote === -1) {
                    w = "active";
                    t = ""
                }
            }
            k.push('<div id="', b.queueSongID, '" rel="', b.SongID, '" class="', n, ' queueSong">', '<a class="remove" title="', $.localize.getString("removeSong"), '"></a>', '<div class="albumart">', '<div class="radio_options ',
                    m && m.autoplayEnabled ? "active" : "", '">', '<a class="smile ', t, '" title="', $.localize.getString("QUEUE_ITEM_SMILE"), '"></a>', '<a class="frown ', w, '" title="', $.localize.getString("QUEUE_ITEM_FROWN"), '"></a>', "</div>", '<div class="song_options ', o, " ", r, '">', '<a class="options selectbox" title="', $.localize.getString("QUEUE_ITEM_OPTIONS"), '"></a>', '<a class="favorite ', r, ' textToggle" title="', $.localize.getString("QUEUE_ADD_SONG_FAVORITE_TITLE"), '"></a>', "</div>", '<a class="play ', h, '" rel="', b.queueSongID,
                    '"></a>', '<img src="', b.getImageURL("s"), '" height="100%" width="100%" />', "</div>", '<a title="', _.cleanText(b.SongName), '" class="queueSong_name song ellipsis">', _.cleanText(b.SongName), "</a>", '<a href="', _.cleanUrl(b.ArtistName, b.ArtistID, "artist"), '" title="', _.cleanText(b.ArtistName), '" class="queueSong_artist artist ellipsis">', _.cleanText(b.ArtistName), "</a>", "</div>");
            return k.join("")
        },smallQueueSongToHtml:function(b, c, g) {
            var h = "paused",k = [],m = a.getCurrentQueue(),n = "",o = b.fromLibrary ? "inLibrary" :
                    "",r = b.isFavorite ? "isFavorite" : "",t = "",w = "";
            if (m.activeSong && b.queueSongID === m.activeSong.queueSongID) {
                n += " active";
                if (a.isPlaying)h = ""
            }
            if (m.autoplayEnabled) {
                if (b.autoplayVote === -1 || c === g - 1 && b.source !== "user")n += " greyOut";
                if (b.autoplayVote === 1 || b.autoplayVote === 0 && b.source === "user") {
                    t = "active";
                    w = ""
                } else if (b.autoplayVote === -1) {
                    w = "active";
                    t = ""
                }
            }
            k.push('<div id="', b.queueSongID, '" rel="', b.SongID, '" class="', n, ' queueSong">', '<a class="remove" title="', $.localize.getString("removeSong"), '"></a>', '<div class="radio_options ',
                    m && m.autoplayEnabled ? "active" : "", '">', '<a class="smile ', t, '" title="', $.localize.getString("QUEUE_ITEM_SMILE"), '"></a>', '<a class="frown ', w, '" title="', $.localize.getString("QUEUE_ITEM_FROWN"), '"></a>', "</div>", '<div class="song_options ', o, " ", r, '">', '<a class="play ', h, '" rel="', b.queueSongID, '"></a>', '<a class="favorite ', r, ' textToggle" title="', $.localize.getString("QUEUE_ADD_SONG_FAVORITE_TITLE"), '"></a>', '<a class="options selectbox" title="', $.localize.getString("QUEUE_ITEM_OPTIONS"), '"></a>',
                    "</div>", '<a title="', _.cleanText(b.SongName), '" class="queueSong_name song ellipsis">', _.cleanText(b.SongName), "</a>", '<a href="', _.cleanUrl(b.ArtistName, b.ArtistID, "artist"), '" title="', _.cleanText(b.ArtistName), '" class="queueSong_artist artist ellipsis">', _.cleanText(b.ArtistName), "</a>", "</div>");
            return k.join("")
        }})
})();
(function() {
    var a;
    GS.Controllers.BaseController.extend("GS.Controllers.YoutubeController", {onDocument:true}, {youtube:false,youtubeWrapper:false,init:function() {
        a = this;
        this._super()
    },userChange:function() {
    },attachPlayer:function(b, c, g) {
        var h = "http://www.youtube.com/v/" + b + "?version=3&enablejsapi=1&version=3&fs=1",k = {},m = {allowScriptAccess:"always",allowFullScreen:"true"},n = {id:"youtube_player",name:"youtube_player",allowFullScreen:"true"};
        if (!b || _.notDefined(b))return false;
        c = c || 480;
        g = g || 385;
        window.onYouTubePlayerReady =
                function() {
                    a.youtube = $("#youtube_player").get(0);
                    a.youtubeWrapper = $("#youtube_player_wrapper");
                    window.playerYoutubeStateChange = GS.player.youtubeStateChange;
                    window.playerYoutubeError = GS.player.youtubeError;
                    a.youtube.addEventListener("onStateChange", "playerYoutubeStateChange");
                    a.youtube.addEventListener("onError", "playerYoutubeError");
                    a.playVideo();
                    GS.lightbox.positionLightbox()
                };
        $("#videoPlayer").length ? swfobject.embedSWF(h, "videoPlayer", c, g, "8", null, k, m, n) : swfobject.embedSWF(h, "youtube_player", c,
                g, "8", null, k, m, n)
    },cueVideoById:function(b, c, g) {
        if (a.youtube)if (c && g)a.youtube.cueVideoById(b, c, g); else c ? a.youtube.cueVideoById(b, c) : a.youtube.cueVideoById(b)
    },loadVideoById:function(b, c, g) {
        if (a.youtube) {
            if (c && g)a.youtube.loadVideoById(b, c, g); else c ? a.youtube.loadVideoById(b, c) : a.youtube.loadVideoById(b);
            GS.guts.gaTrackEvent("youtube", "loadVideoById", b)
        }
    },cueVideoByUrl:function(b, c) {
        a.youtube && a.youtube.cueVideoByUrl(b, c)
    },loadVideoByUrl:function(b, c) {
        a.youtube && a.youtube.loadVideoByUrl(b, c)
    },playVideo:function() {
        if (a.youtube) {
            a.youtube.playVideo();
            GS.guts.gaTrackEvent("youtube", "playVideo")
        }
    },pauseVideo:function() {
        a.youtube && a.youtube.pauseVideo()
    },stopVideo:function() {
        a.youtube && a.youtube.stopVideo()
    },seekTo:function(b, c) {
        a.youtube && a.youtube.seekTo(b, c)
    },clearVideo:function() {
        a.youtube && a.youtube.clearVideo()
    },mute:function() {
        a.youtube && a.youtube.mute()
    },unMute:function() {
        a.youtube && a.youtube.unMute()
    },isMuted:function() {
        a.youtube && a.youtube.isMuted()
    },setVolume:function(b) {
        a.youtube && a.youtube.setVolume(b)
    },getVolume:function() {
        if (a.youtube)return a.youtube.getVolume()
    },
        setSize:function(b, c) {
            a.youtube && a.youtube.setSize(b, c)
        },getVideoBytesLoaded:function() {
            if (a.youtube)return a.youtube.getVideoBytesLoaded()
        },getVideoBytesTotal:function() {
            if (a.youtube)return a.youtube.getVideoBytesTotal()
        },getVideoStartBytes:function() {
            if (a.youtube)return a.youtube.getVideoStartBytes()
        },getPlayerState:function() {
            if (a.youtube)return a.youtube.getPlayerState()
        },getCurrentTime:function() {
            if (a.youtube)return a.youtube.getCurrentTime()
        },getPlaybackQuality:function() {
            if (a.youtube)return a.youtube.getPlaybackQuality()
        },
        setPlaybackQuality:function(b) {
            a.youtube && a.youtube.setPlaybackQuality(b)
        },getAvailableQualityLevels:function() {
            if (a.youtube)return a.youtube.getAvailableQualityLevels()
        },getDuration:function() {
            if (a.youtube)return a.youtube.getDuration()
        },getVideoUrl:function() {
            if (a.youtube)return a.youtube.getVideoUrl()
        },getVideoEmbedCode:function() {
            if (a.youtube)return a.youtube.getVideoEmbedCode()
        },addEventListener:function(b, c) {
            if (a.youtube)return a.youtube.addEventListener(b, c)
        },cache:{},search:function(b, c, g) {
            b =
                    $.trim(_.orEqual(b, ""));
            if (!b || b == "")return false;
            this.cache[b] && $.isFunction(c) && c(this.cache[b]);
            GS.service.getYoutubeSearchResults(b, {"max-results":7}, "", this.callback("onSearchSuccess", b, c), g);
            GS.guts.gaTrackEvent("youtube", "search", b)
        },onSearchSuccess:function(b, c, g) {
            this.cache[b] = g;
            $.isFunction(c) && c(g)
        }})
})();
(function() {
    GS.Controllers.BaseController.extend("GS.Controllers.VimeoController", {onDocument:true}, {vimeo:false,init:function() {
        this._super()
    },userChange:function() {
    },attachPlayer:function(a, b, c, g) {
        var h = "http://player.vimeo.com/video/" + b + "?api=1&player_id=vimeo_player&autoplay=1";
        if (!b || _.notDefined(b))return false;
        c = c || 480;
        g = g || 385;
        b = $("<iframe />").width(c).height(g).attr("src", h).attr("id", "vimeo_player");
        $("#" + a).html(b);
        a = document.querySelectorAll("#vimeo_player");
        $f(a[0]).addEvent("ready",
                function(k) {
                    var m = $f(k);
                    (function() {
                        m.removeEvent("loadProgress");
                        m.removeEvent("playProgress");
                        m.removeEvent("play");
                        m.removeEvent("pause");
                        (function() {
                            m.addEvent("finish", function() {
                                $(".lbcontainer:visible").controller().setNextVideo()
                            })
                        })();
                        m.removeEvent("seek")
                    })()
                })
    }})
})();
(function() {
    function a(k) {
        return"<span class='slick-column-name' data-translate-text='" + k.name + "'>" + $.localize.getString(k.name) + "</span>"
    }

    function b(k, m, n, o, r) {
        k = _.ucwords(o.name);
        m = $("#grid").controller();
        return r.isVerified == 0 ? o.name == "ARTIST" ? m.filter.hasOwnProperty("onlyVerified") && !m.filter.onlyVerified ? '<div class="showMore showingMore" data-translate-text="SEARCH_RESULTS_SHOW_LESS">' + $.localize.getString("SEARCH_RESULTS_SHOW_LESS") + "</div>" : '<div class="showMore" data-translate-text="SEARCH_RESULTS_SHOW_MORE">' +
                $.localize.getString("SEARCH_RESULTS_SHOW_MORE") + "</div>" : "" : ['<a class="field" href="',o.name == "SONG" ? "javascript:_.redirectSong(" + r.SongID + ", event)" : o.name == "USER" ? _.cleanUrl(r.Name, r.UserID, "user") : _.cleanUrl(r[k + "Name"], r[k + "ID"], o.name.toLowerCase()),'" class="ellipsis" title="',n,'">',n,"</a>"].join("")
    }

    function c(k, m, n) {
        return['<span class="filter field ellipsis" title="',n,'">',n,"</span>"].join("")
    }

    function g(k, m, n, o, r) {
        if (r.isVerified == 0)return""; else {
            k = r.isFavorite ? " isFavorite" : "";
            m =
                    r.fromLibrary ? " inLibrary" : "";
            o = r.isFavorite ? "SONG_ROW_REMOVE_SONG_FAVORITE_TITLE" : "SONG_ROW_ADD_SONG_FAVORITE_TITLE";
            var t = GS.player.getCurrentQueue(),w = "SONG_ROW_ADD_SONG_PLAY_TITLE";
            if (t && t.songs && t.songs.length > 0)w = "SONG_ROW_ADD_SONG_ADD_TO_PLAYING_TITLE";
            return['<a class="play" data-translate-title="',w,'" title="',$.localize.getString(w),'" rel="',r.SongID,'"></a><div class="options"><a class="favorite option',k,'" data-translate-title="',o,'" title="',$.localize.getString(o),'" rel="',r.SongID,
                '"></a><a class="more option grid_song_more',m,'" data-translate-title="OPTIONS" title="',$.localize.getString("OPTIONS"),'" rel="',r.SongID,'"></a></div><span class="songName"><a class="songLink ellipsis" title="',n,'" rel="',r.SongID,'">',n,"</a></span>"].join("")
        }
    }

    function h(k, m, n) {
        n = n == "0" ? "&nbsp;" : n;
        return['<span class="track">',n,"</span>"].join("")
    }

    GS.Controllers.BaseController.extend("GS.Controllers.GridController", {columns:{song:[
        {id:"song",name:"SONG",field:"SongName",cssClass:"song",formatter:g,
            behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"artist",name:"ARTIST",field:"ArtistName",cssClass:"artist",formatter:b,behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"album",name:"ALBUM",field:"AlbumName",cssClass:"album",formatter:b,behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"track",name:"TRACK_NUM",field:"TrackNum",cssClass:"track",maxWidth:50,formatter:h,behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],albumSongs:[
        {id:"song",name:"SONG",
            field:"SongName",cssClass:"song",formatter:g,behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"artist",name:"ARTIST",field:"ArtistName",cssClass:"artist",formatter:b,behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"track",name:"TRACK_NUM",field:"TrackNum",cssClass:"track",maxWidth:50,formatter:h,behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],queuesong:[
        {id:"song",name:"SONG",field:"SongName",cssClass:"song",formatter:function(k, m, n, o, r) {
            return['<a class="play ',
                GS.player.isPlaying ? "" : "paused",'" rel="',r.SongID,'"><span>Play</span></a><div class="options"><a class="favorite option',r.isFavorite ? " isFavorite" : "",'" rel="',r.SongID,'"></a><a class="more option',r.fromLibrary ? " inLibrary" : "",'" rel="',r.SongID,'"></a></div><span class="songName"><a class="songLink ellipsis" title="',n,'" rel="',r.SongID,'">',n,"</a></span>"].join("")
        },behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"artist",name:"ARTIST",field:"ArtistName",cssClass:"artist",formatter:function(k, m, n, o, r) {
            k = r.autoplayVote == 1 || r.autoplayVote == 0 && r.source === "user" ? "selected" : "";
            m = r.autoplayVote == -1 ? "selected" : "";
            var t = _.ucwords(o.name);
            o = _.cleanUrl(r[t + "Name"], r[t + "ID"], o.name.toLowerCase());
            return['<ul class="options"><li class="smile ',k,'"><a></a></li><li class="frown ',m,'"><a></a></li></ul><a class="field ellipsis" href="',o,'" title="',n,'">',n,"</a>"].join("")
        },behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"album",name:"ALBUM",field:"AlbumName",cssClass:"album",formatter:b,
            behavior:"selectAndMove",sortable:true,columnFormatter:a},
        {id:"track",name:"TRACK_NUM",field:"TrackNum",cssClass:"track",maxWidth:50,formatter:h,behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],album:[
        {id:"album",name:"ALBUM",field:"AlbumName",cssClass:"albumDetail",formatter:function(k, m, n, o, r) {
            k = '<a href="' + r.toArtistUrl() + '">' + r.ArtistName + "</a>";
            k = $("<span></span>").localeDataString("BY_ARTIST", {artist:k});
            return['<a href="',r.toUrl(),'" class="image"><img src="',r.getImageURL("m"),
                '" width="40" height="40" class="avatar" /></a><a href="',r.toUrl(),'" class="title ellipsis">',r.AlbumName,'</a><span class="byline">',k.render(),"</span>"].join("")
        },behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],artist:[
        {id:"artist",name:"ARTIST",field:"ArtistName",cssClass:"artist-row",formatter:b,behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],playlist:[
        {id:"playlist",name:"PLAYLIST",field:"PlaylistName",cssClass:"playlist",formatter:function(k, m, n, o, r) {
            k = r.isFavorite ?
                    " subscribed" : "";
            m = r && r.NumSongs && r.Artists ? true : false;
            n = r.isFavorite ? "Unsubscribe" : "Subscribe";
            k = r.UserID === GS.user.UserID ? "" : ['<a class="subscribe ',k,'" rel="',r.PlaylistID,'"><span>',n,"</span></a>"].join("");
            if (m) {
                m = r.Artists.split(",");
                n = m.length;
                m.splice(3, m.length);
                n = n > m.length ? "..." : "";
                return['<a href="',_.cleanUrl(r.PlaylistName, r.PlaylistID, "playlist"),'" class="image"><img src="',r.getImageURL(),'" width="40" height="40" class="albumart" /></a>',k,'<a href="',_.cleanUrl(r.PlaylistName,
                        r.PlaylistID, "playlist"),'">',_.cleanText(r.PlaylistName)," (",r.NumSongs,' Songs) </a><span class="artists"><span data-translate-text="includes">includes</span>: ',m.join(", "),n,"</span></span>"].join("")
            } else return['<a href="',_.cleanUrl(r.PlaylistName, r.PlaylistID, "playlist"),'" class="image"><img src="',r.getImageURL(),'" width="40" height="40" class="albumart" /></a>',k,'<a href="',_.cleanUrl(r.PlaylistName, r.PlaylistID, "playlist"),'">',_.cleanText(r.PlaylistName),'</a><span class="author">by <a href="',
                _.cleanUrl(r.UserName, r.UserID, "user"),'">',r.UserName,"</a></span>"].join("")
        },behavior:"selectAndMove",sortable:true,columnFormatter:a}
    ],user:[
        {id:"username",name:"USER",field:"Name",cssClass:"user",formatter:function(k, m, n, o, r) {
            k = r.isFavorite ? " following" : "";
            m = r.isFavorite ? "UNFOLLOW" : "FOLLOW";
            k = r.UserID === GS.user.UserID ? "" : ['<a class="follow ',k,'" data-follow-userid="',r.UserID,'"><span data-translate-text="' + m + '">',$.localize.getString(m),"</span></a>"].join("");
            m = _.cleanUrl(r.Name, r.UserID,
                    "user");
            n = '<div class="status ' + r.getVipPackage() + '"></div>';
            return['<a href="',m,'" class="who image">',n,'<img src="',r.getImageURL(),'" width="40" height="40" class="avatar" /></a>',k,'<a href="',m,'">',r.Name,'</a><span class="location">',r.Country,"</span>"].join("")
        },behavior:"selectAndMove",sortable:true}
    ],albumFilter:[
        {id:"album",name:"ALBUM",field:"AlbumName",cssClass:"cell-title",formatter:c,behavior:"selectAndMove",sortable:false,collapsable:true,columnFormatter:a}
    ],artistFilter:[
        {id:"artist",
            name:"ARTIST",field:"ArtistName",cssClass:"cell-title",formatter:c,behavior:"selectAndMove",sortable:false,collapsable:true,columnFormatter:a}
    ],event:[
        {id:"artist",name:"ARTIST",field:"ArtistName",cssClass:"cell-title",formatter:function(k, m, n) {
            k = (n || "").split(", ");
            m = "";
            n = [];
            for (var o = 0; o < k.length; o++) {
                m = o === k.length - 1 ? "" : ",&nbsp;";
                n.push(['<a title="',_.cleanText(k[o]),'" data-searchquery="',_.cleanText(k[o]),'" class="searchLink">',k[o],m," </a>"].join(""))
            }
            return['<div class="filter"><span class="field ellipsis artist">',
                n.join(""),"</span></div>"].join("")
        },behavior:"none",sortable:false,columnFormatter:a},
        {id:"location",name:"LOCATION",field:"Location",cssClass:"cell-title",formatter:function(k, m, n, o, r) {
            return['<div class="filter"><span class="field ellipsis venue" title="',r.VenueName,'">',r.VenueName,'</span><span class="field ellipsis city" title="',r.City,'">',r.City,"</span></div>"].join("")
        },behavior:"none",sortable:false,columnFormatter:a},
        {id:"date",name:"DATE",field:"StartTime",cssClass:"cell-title",formatter:function(k, m, n, o, r) {
            k = r.StartTime.split(" ");
            m = k[1] ? k[1].split(":") : "00:00:00";
            k = k[0].split("-");
            newDate = (new Date(parseInt(k[0], 10), parseInt(k[1], 10) - 1, parseInt(k[2], 10), parseInt(m[0], 10), parseInt(m[1], 10), parseInt(m[2], 10))).format("D M j Y");
            return['<div class="filter dateTicket"><span class="field ellipsis date" title="',newDate,'">',newDate,'</span><span class="icons ticket"><a class="field ellipsis url" title="',$.localize.getString("BUY_TICKETS"),'">',$.localize.getString("BUY_TICKETS"),"</a></div>"].join("")
        },
            behavior:"none",sortable:false,columnFormatter:a}
    ]},options:{enableCellNavigation:true,enableCellRangeSelection:true,onCellRangeSelected:function() {
        console.log("cell range select", arguments)
    },onSelectedRowChanged:function() {
        console.log("selectd row change", arguments)
    },forceFitColumns:true,rowHeight:25,editable:false,enableAddRow:false,rowCssClasses:function(k) {
        var m = "";
        if (k && k.isVerified == 1)m = "verified"; else if (k && k.isVerified == 0)m = "verifiedDivider";
        return m
    },isSelectable:function(k) {
        return k.isVerified ===
                0 ? false : true
    },dragProxy:function(k) {
        var m = k;
        if (k.length > 1)if (k[0]instanceof GS.Models.Song)m = _.getString("SELECTION_SONGS_COUNT", {count:k.length}); else if (k[0]instanceof GS.Models.Playlist)m = _.getString("SELECTION_PLAYLIST_COUNT", {count:k.length}); else if (k[0]instanceof GS.Models.Artist)m = _.getString("SELECTION_ARTIST_COUNT", {count:k.length});
        return['<div class="status"></div><span class="info">',m,"</span>"].join("")
    }},rowHeights:{song:25,album:50,artist:35,playlist:50,user:50,event:50},columnsByName:{song:"song",
        SongName:"song",album:"album",AlbumName:"album",artist:"artist",ArtistName:"artist",playlist:"playlist",PlaylistName:"playlist",user:"user",Name:"user",TrackNum:"track",tracknum:"track",track:"track",event:"user",Event:"user"},defaultSort:{song:"ArtistName",album:"TrackNum",artist:"Popularity",user:"Name",playlist:"PlaylistName"},defaultMultiSorts:{SongName:["isVerified","SongName","SongID","GridKey"],ArtistName:["isVerified","ArtistName","AlbumName","TrackNum","SongName","SongID","GridKey"],AlbumName:["isVerified",
        "AlbumName","TrackNum","SongName","SongID","GridKey"],TrackNum:["isVerified","TrackNum","SongName","SongID"],Popularity:["isVerified","Popularity","Weight","NumPlays","ArtistName","AlbumName","TrackNum","SongName","SongID"]},numericColumns:{Rank:true,Sort:true,TrackNum:true,Popularity:true,Weight:true,NumPlays:true,Score:true,isVerified:true,GridKey:true,GeoDist:true},forcedSortDirections:{TSAdded:false,TSFavorited:false,Popularity:false,TrackNum:true}}, {dataView:null,grid:null,idProperty:null,selectedRowIDs:[],
        currentRow:0,filter:{artistIDs:false,albumIDs:false,onlyVerified:false},sortCol:"",sortCols:[],sortDir:1,origSortDir:1,sortNumeric:false,pastSorts:{},searchString:"",data:null,columns:null,options:null,type:null,SMALL_GRID_WIDTH:600,resize:function() {
            var k = 0,m = _.orEqual(this.element.attr("data-profile-view"), "0"),n = false;
            if (this.element)if (this.element.hasClass("songList"))this.element.css({height:Math.min(200, Math.max(25, (this.data || []).length * this.options.rowHeight)),width:this.element.parent().innerWidth()});
            else {
                var o = GS.Controllers.GridController.columns.song.concat();
                if ($("#search_side_pane").length) {
                    k = $("#search_side_pane").width() + 38;
                    if (n = $(this.element).width() < this.SMALL_GRID_WIDTH && o.length > 2)k += 4
                }
                m === "1" ? this.element.css({"overflow-y":"hidden",height:"auto",width:this.element.parent().width() - k}) : this.element.css({height:$("#page").height() - $("#page_header").height() - $("#theme_page_header:visible").height(),width:this.element.parent().width() - k});
                if (this.grid && this.grid.setColumns && $("#grid").is(".song.everything")) {
                    k =
                            [o[0],o[1],o[2]];
                    this.element.toggleClass("noAlbums", n);
                    if (n)k = [o[0],o[1]];
                    if (this.lastColumnLength !== k.length) {
                        this.grid.setColumns(k);
                        this.lastColumnLength = k.length
                    }
                }
            }
        },init:function(k, m, n, o, r, t) {
            function w(A, x) {
                var B,D,F,p,q = 1,s = false,v = false;
                if (u.options.isFilter)u.sortCols = ["isVerified",u.sortCol];
                for (F = 0; F < u.sortCols.length; F++) {
                    p = u.sortCols[F];
                    q = p === "isVerified" ? u.sortDir ? -1 : 1 : 1;
                    try {
                        if (u.Class.numericColumns[p]) {
                            B = parseFloat(A[p], 10);
                            D = parseFloat(x[p], 10);
                            if (isNaN(B))B = 0;
                            if (isNaN(D))D = 0;
                            if (p ===
                                    "TrackNum") {
                                if (B !== 0 && D === 0)return u.sortDir ? -1 : 1;
                                if (D !== 0 && B === 0)return u.sortDir ? 1 : -1
                            }
                        } else {
                            B = A[p].toString().toLowerCase();
                            D = x[p].toString().toLowerCase()
                        }
                        if (B !== D)return(B > D ? 1 : -1) * q
                    } catch(C) {
                        if (_.notDefined(A) || isNaN(A))s = true;
                        if (_.notDefined(x) || isNaN(x))v = true;
                        if (s && !v)return-1;
                        if (!s && v)return 1;
                        return 0
                    }
                }
                return 0
            }

            r = _.orEqual(r, "song");
            o = _.orEqual(o, {});
            o.rowHeight = _.orEqual(o.rowHeight, GS.Controllers.GridController.rowHeights[r]);
            o.allowDragSort = _.orEqual(o.allowDragSort, false);
            o.allowDuplicates =
                    _.orEqual(o.allowDuplicates, false);
            o = $.extend({}, GS.Controllers.GridController.options, o);
            if (o.allowDragSort)o.autoDragScroll = true;
            $(window).resize();
            this.subscribe("gs.auth." + r + ".update", this.callback(r + "Change"));
            this.subscribe("gs.auth.favorites." + r + "s.update", this.callback(r + "FavoritesChange"));
            this.subscribe("gs.player.queue.change", this.callback("queueChange"));
            var y = GS.player.getCurrentQueue();
            this.element.toggleClass("hasSongs", y && y.songs && y.songs.length > 0);
            this.data = m;
            this.columns = n;
            this.options =
                    o;
            this.type = r;
            this.idProperty = this.grid = this.dataView = null;
            this.selectedRowIDs = [];
            this.currentRow = 0;
            this.filter = _.orEqual(o.filters, {artistIDs:false,albumIDs:false,onlyVerified:false});
            this.sortCol = _.orEqual(o.sortCol, GS.Controllers.GridController.defaultSort[r]);
            this.sortCols = _.orEqual(GS.Controllers.GridController.defaultMultiSorts[this.sortCol], $.makeArray(this.sortCol));
            this.origSortDir = this.sortDir = (this.sortDir = _.orEqual(o.sortDir, 1)) ? true : false;
            this.sortNumeric = GS.Controllers.GridController.numericColumns[this.sortCol] ?
                    true : false;
            this.pastSorts = {};
            this.searchString = "";
            this.allowDragSort = _.orEqual(o.allowDragSort, false);
            var u = this;
            this.idProperty = _.orEqual(t, _.ucwords(r) + "ID");
            this.dataView = new Slick.Data.DataView;
            this.grid = new Slick.Grid($(k), this.dataView.rows, this.columns, this.options);
            this.dataView.setAllowDuplicates(this.options.allowDuplicates);
            this.grid.onContextMenu = function(A, x) {
                A.stopPropagation();
                var B = u.grid.getSelectedRows().sort(function(p, q) {
                    return p - q
                }),D = [];
                if (!(B.length > 1)) {
                    u.currentRow = x;
                    u.grid.setSelectedRows([x]);
                    u.grid.onSelectedRowsChanged()
                }
                switch (u.type) {
                    case "artist":
                        D = GS.Models.Artist.getOneFromCache(u.dataView.rows[x].ArtistID).getContextMenu();
                        break;
                    case "song":
                        if (B.length > 1) {
                            D = [];
                            for (var F = 0; F < B.length; F++)D.push(u.dataView.rows[B[F]].SongID);
                            D = u.getContextMenuMultiselectForSong(D)
                        } else D = u.getContextMenuForSong(u.dataView.rows[x].SongID);
                        break;
                    case "playlist":
                        D = GS.Models.Playlist.getOneFromCache(u.dataView.rows[x].PlaylistID).getContextMenu();
                        break
                }
                $(A.target).jjmenu(A, D, null, {xposition:"mouse",
                    yposition:"mouse",show:"show",className:"contextmenu"});
                return false
            };
            this.grid.onDblClick = function(A, x) {
                var B = u.dataView.rows[x];
                if (!($(A.target).parents(".options").length > 0))if (!$(A.target).is("a.play"))if (u.options.isNowPlaying && B.queueSongID)GS.player.playSong(B.queueSongID); else if (B.SongID) {
                    var D = GS.Controllers.PageController.getActiveController().getPlayContext();
                    GS.player.addSongAndPlay(B.SongID, D);
                    D = {songID:B.songID,rank:parseInt(x, 10) + 1};
                    if (B.ppVersion)D.ppVersion = B.ppVersion;
                    GS.guts.logEvent("doubleClickToPlay",
                            D)
                }
            };
            this.grid.onKeyDown = function(A) {
                if (A.which === 65 && (A.ctrlKey || A.metaKey)) {
                    A = [];
                    u.selectedRowIDs = [];
                    for (var x = 0; x < u.dataView.rows.length; x++) {
                        A.push(x);
                        u.selectedRowIDs.push(u.dataView.rows[x].id)
                    }
                    u.currentRow = u.dataView.rows.length - 1;
                    u.grid.setSelectedRows(_.arrUnique(A));
                    u.grid.onSelectedRowsChanged();
                    return true
                }
                if (u.handleKeyPress(A))return true;
                return $(A.target).is("input,textarea,select") ? true : false
            };
            this.grid.onSelectedRowsChanged = function() {
                u.selectedRowIDs = [];
                var A,x,B = u.grid.getSelectedRows().sort(function(F, p) {
                    return F - p
                }),D = {};
                if (u.options.isFilter) {
                    if (B.length === 1 && B[0] === 0 && u.dataView.getItemByIdx(0)[u.idProperty] === -1)B = [];
                    A = B.indexOf(0);
                    if (A > -1) {
                        B.splice(A, 1);
                        u.grid.setSelectedRows(B);
                        u.grid.onSelectedRowsChanged();
                        return
                    }
                    B.length === 0 ? $(".slick-row[row=0]", u.element).addClass("selected") : $(".slick-row[row=0]", u.element).removeClass("selected")
                }
                A = 0;
                for (l = B.length; A < l; A++)if (x = u.dataView.rows[B[A]]) {
                    u.selectedRowIDs.push(x[u.idProperty]);
                    D[x[u.idProperty]] = true
                }
                u.selectedRowIDs = _.arrUnique(u.selectedRowIDs);
                if (u.options.isFilter)if (u.type === "album") {
                    if (B.length === 0)$(".gs_grid.songs").controller().filter.albumIDs = false; else $(".gs_grid.songs").controller().filter.albumIDs = D;
                    $(".gs_grid.songs").controller().dataView.refresh()
                } else if (u.type === "artist") {
                    if (B.length === 0) {
                        $(".gs_grid.songs").controller().filter.artistIDs = false;
                        $(".gs_grid.albums").controller().filter.artistIDs = false
                    } else {
                        $(".gs_grid.songs").controller().filter.artistIDs = D;
                        $(".gs_grid.albums").controller().filter.artistIDs = D
                    }
                    $(".gs_grid.songs").controller().dataView.refresh();
                    $(".gs_grid.albums").controller().dataView.refresh();
                    $(".gs_grid.albums").controller().grid.onSelectedRowsChanged()
                }
                u.currentRow = _.orEqual(u.grid.getSelectedRows()[B.length - 1], 0);
                $.publish("gs.grid.selectedRows", {len:u.selectedRowIDs.length,type:u.type})
            };
            $(".slick-header-column").click(function() {
                $(this).addClass("selected");
                $(this).siblings().removeClass("selected")
            });
            this.grid.onSort = function(A, x) {
                var B;
                u.sortCol = A.field ? A.field : A;
                if (_.notDefined(x))x = _.defined(u.pastSorts[u.sortCol]) ? !u.pastSorts[u.sortCol] :
                        true;
                u.sortCols = _.orEqual(GS.Controllers.GridController.defaultMultiSorts[u.sortCol], $.makeArray(u.sortCol));
                u.sortDir = x ? true : false;
                u.element.find(".slick-sort-indicator").removeClass("slick-sort-indicator-asc").removeClass("slick-sort-indicator-desc");
                B = GS.Controllers.GridController.columnsByName[u.sortCol];
                forcedDir = GS.Controllers.GridController.forcedSortDirections[u.sortCol];
                if (_.defined(B))u.grid.setSortColumn(B, u.sortDir); else u.sortDir = _.defined(forcedDir) ? forcedDir : u.origSortDir;
                u.pastSorts[u.sortCol] =
                        u.sortDir;
                u.sortNumeric = GS.Controllers.GridController.numericColumns[u.sortCol] ? true : false;
                u.dataView.sort(w, u.sortDir);
                if (!u.options.isFilter) {
                    B = $("a[name=sort][rel=" + u.sortCol + "]");
                    B.parent().parent().parent().siblings("button").find("span.label").html(B.find("span").text());
                    u.options.sortStoreKey && $.publish("gs.grid.onsort", {sortCol:u.sortCol,sortDir:u.sortDir,sortStoreKey:u.options.sortStoreKey})
                }
            };
            u.dataView.onRowCountChanged.subscribe(function() {
                u.grid.updateRowCount();
                u.grid.render();
                u.grid.autosizeColumns()
            });
            u.dataView.onRowsChanged.subscribe(function(A) {
                u.grid.removeRows(A);
                u.grid.render();
                if (u.selectedRowIDs.length > 0) {
                    A = [];
                    for (var x,B = 0,D = u.selectedRowIDs.length; B < D; B++) {
                        x = u.dataView.getRowById(u.selectedRowIDs[B]);
                        x !== undefined && A.push(x)
                    }
                    u.currentRow = _.orEqual(x, 0);
                    u.grid.setSelectedRows(_.arrUnique(A));
                    u.grid.onSelectedRowsChanged()
                }
            });
            u.grid.onBeforeMoveRows = function() {
                if (u.allowDragSort)return true;
                return false
            };
            u.grid.onMoveRows = function(A, x) {
                var B = [],D = [],F = [],p = u.dataView.getItems(),q,s,v;
                if (!(!u.allowDragSort ||
                        u.sortCol !== "Sort"))if (u.options.playlistID)(B = GS.Models.Playlist.getOneFromCache(u.options.playlistID)) && B.moveSongsTo(A, x); else {
                    q = p.slice(0, x);
                    s = p.slice(x, p.length);
                    for (v = 0; v < A.length; v++) {
                        p[A[v]].Sort = v;
                        B.push(p[A[v]])
                    }
                    A.sort().reverse();
                    for (v = 0; v < A.length; v++) {
                        p = A[v];
                        p < x ? q.splice(p, 1) : s.splice(p - x, 1)
                    }
                    p = q.concat(B.concat(s));
                    for (v = 0; v < p.length; v++)p[v].Sort = v + 1;
                    u.data = p;
                    for (v = 0; v < A.length; v++)D.push(q.length + v);
                    D = _.arrUnique(D);
                    u.currentRow = D[D.length - 1];
                    u.dataView.beginUpdate();
                    u.grid.setSelectedRows(D);
                    u.grid.onSelectedRowsChanged();
                    u.dataView.setItems(u.data, u.idProperty);
                    u.dataView.endUpdate();
                    u.dataView.refresh();
                    if (u.options.isNowPlaying) {
                        q = x;
                        for (v = 0; v < B.length; v++) {
                            F.push(B[v].queueSongID);
                            D = $("#queue .queueSong:nth-child(" + x + ")");
                            D.after($("#" + B[v].queueSongID).remove());
                            x += 1
                        }
                        GS.player.moveSongsTo(F, q)
                    }
                }
            };
            if (u.allowDragSort) {
                k = $("#grid");
                var E = $("#grid .slick-viewport"),H = function(A, x) {
                    var B = A.clientY - E.find(".grid-canvas").offset().top,D = u.grid.getOptions();
                    B = Math.max(0, Math.min(Math.round(B /
                            D.rowHeight), m ? m.length : 0));
                    if (B !== x.gridInsertIndex) {
                        if (u.onBeforeMoveRows && u.onBeforeMoveRows(u.grid.getSelectedRows(), B) === false) {
                            $("div.slick-reorder-guide").css("top", -1000);
                            x.canMove = false
                        } else {
                            $("div.slick-reorder-guide").css("top", B * D.rowHeight + D.padding);
                            x.canMove = true
                        }
                        x.gridInsertIndex = B
                    }
                    var F;
                    B = E.within(A.clientX, A.clientY).length > 0;
                    if (D.autoDragScroll && B) {
                        if (!x.gridAutoScrollWaitTimeout)x.gridAutoScrollWaitTimeout = setTimeout(function() {
                            x.gridAutoScrollHasWaited = true;
                            x.gridAutoScrollWaitTimeout =
                                    false
                        }, 500);
                        D.autoScrollBuffer = D.autoScrollBuffer || Math.ceil(E.height() * 0.2);
                        D.autoScrollWaitDuration = D.autoScrollBuffer || 300;
                        if (E.offset().top + D.autoScrollBuffer > A.clientY) {
                            if (x.gridAutoScrollHasWaited) {
                                F = Math.max(0, E.scrollTop() - 82);
                                E.scrollTop(F)
                            }
                            clearInterval(x.gridAutoScrollInterval);
                            x.gridAutoScrollInterval = setInterval(function() {
                                if (x.gridAutoScrollHasWaited) {
                                    F = Math.max(0, E.scrollTop() - 82);
                                    E.scrollTop(F)
                                }
                            }, D.autoScrollWaitDuration)
                        } else if (E.offset().top + E.height() - D.autoScrollBuffer < A.clientY) {
                            if (x.gridAutoScrollHasWaited) {
                                F =
                                        Math.min(D.rowHeight * (m ? m.length : 0), E.scrollTop() + 82);
                                E.scrollTop(F)
                            }
                            clearInterval(x.gridAutoScrollInterval);
                            x.gridAutoScrollInterval = setInterval(function() {
                                if (x.gridAutoScrollHasWaited) {
                                    F = Math.min(D.rowHeight * (m ? m.length : 0), E.scrollTop() + 82);
                                    E.scrollTop(F)
                                }
                            }, D.autoScrollWaitDuration)
                        } else {
                            clearTimeout(x.gridAutoScrollWaitTimeout);
                            clearInterval(x.gridAutoScrollInterval);
                            x.gridAutoScrollWaitTimeout = false;
                            x.gridAutoScrollHasWaited = false
                        }
                    } else {
                        clearInterval(x.gridAutoScrollInterval);
                        clearTimeout(x.gridAutoScrollWaitTimeout);
                        x.gridAutoScrollHasWaited = false;
                        x.gridAutoScrollWaitTimeout = false
                    }
                };
                k.bind("dropinit",
                        function() {
                            this.updateDropOnDrag = H
                        }).bind("dropstart",
                        function(A, x) {
                            if (!x.draggedItems) {
                                this.updateDropOnDrag = null;
                                return false
                            }
                            $("<div class='slick-reorder-guide'/>").css("position", "absolute").css("zIndex", "99998").css("width", $(this).innerWidth()).css("top", -1000).appendTo(E);
                            x.gridInsertIndex = -1;
                            x.gridAutoScrollHasWaited = false;
                            x.gridAutoScrollWaitTimeout = false
                        }).bind("dropend",
                        function(A, x) {
                            E.find(".slick-reorder-guide").remove();
                            clearInterval(x.gridAutoScrollInterval)
                        }).bind("drop", function(A, x) {
                            function B(F, p, q) {
                                q = _.orEqual(q, new GS.Models.PlayContext);
                                p = GS.Models.Playlist.getOneFromCache(u.options.playlistID);
                                var s = [],v;
                                for (v = 0; v < F.length; v++)s.push(F[v].SongID);
                                if (u.options.playlistID) {
                                    F = x.gridInsertIndex !== -1 ? x.gridInsertIndex : null;
                                    p.addSongs(s, F)
                                } else {
                                    F = x.gridInsertIndex !== -1 ? x.gridInsertIndex : GS.player.INDEX_DEFAULT;
                                    GS.player.addSongsToQueueAt(s, F, false, q)
                                }
                            }

                            var D;
                            if (E.within(A.clientX, A.clientY).length > 0)if (x.draggedItemsSource ==
                                    "grid" && u.grid.onMoveRows && x.canMove) {
                                u.grid.onMoveRows(u.grid.getSelectedRows(), x.gridInsertIndex);
                                GS.guts.gaTrackEvent("grid", "dragSuccess")
                            } else {
                                x.draggedItemsType = x.draggedItemsType || _.guessDragType(x.draggedItems);
                                switch (x.draggedItemsType) {
                                    case "song":
                                        B(x.draggedItems, x.draggedItemsContext);
                                        break;
                                    case "album":
                                        for (D = 0; D < x.draggedItems.length; D++)x.draggedItems[D].getSongs(function(F) {
                                                    F.sort(GS.Models.Album.defaultSongSort);
                                                    B(F, new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ALBUM, x.draggedItems[D]))
                                                },
                                                null, false, {async:false});
                                        break;
                                    case "artist":
                                        for (D = 0; D < x.draggedItems.length; D++)x.draggedItems[D].getSongs(function(F) {
                                            F.sort(GS.Models.Artist.defaultSongSort);
                                            B(F, new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ARTIST, x.draggedItems[D]))
                                        }, null, false, {async:false});
                                        break;
                                    case "playlist":
                                        for (D = 0; D < x.draggedItems.length; D++)x.draggedItems[D].getSongs(function(F) {
                                            B(F, new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST, x.draggedItems[D]))
                                        }, null, false, {async:false});
                                        break;
                                    case "user":
                                        for (D = 0; D <
                                                x.draggedItems.length; D++)x.draggedItems[D].getFavoritesByType("Song", function(F) {
                                            B(F, new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_USER, x.draggedItems[D]))
                                        }, null, false, {async:false});
                                        break;
                                    default:
                                        console.error("grid drop, invalid drag type", x.draggedItemsType);
                                        return
                                }
                            }
                        })
            }
            u.dataView.beginUpdate();
            u.dataView.setItems(u.data, u.idProperty);
            u.dataView.setFilter(function(A) {
                if (u.options.isFilter && A.isFilterAll)return true;
                if (u.searchString != "" && A.searchText.indexOf(u.searchString) == -1)return false;
                if (u.filter.hasOwnProperty("onlyVerified") && u.filter.onlyVerified && A.isVerified === -1)return false;
                if (u.filter.artistIDs && !u.filter.artistIDs[A.ArtistID])return false;
                if (u.filter.albumIDs && !u.filter.albumIDs[A.AlbumID])return false;
                return true
            });
            u.dataView.endUpdate();
            u.sortCol !== "" && u.grid.onSort(u.sortCol, u.sortDir);
            if (u.options.isFilter) {
                u.grid.setSelectedRows([0]);
                u.grid.onSelectedRowsChanged()
            }
            setTimeout(function() {
                $(window).resize()
            }, 500)
        },update:function() {
        },songChange:function(k) {
            var m = $("#page").is(".gs_page_playlist") ?
                    $("#page").controllers(GS.Controllers.Page.PlaylistController)[0] : false;
            m = m ? m.playlist.songIDLookup[k.SongID] : this.dataView.getItemById(k[this.idProperty]);
            if (!m)return false;
            var n = ["isVerified","TSAdded","TSFavorited","Sort","Popularity"];
            for (var o in k)if (k.hasOwnProperty(o) && n.indexOf(o) == -1)m[o] = k[o];
            this.dataView.updateItem(m[this.idProperty], m)
        },albumChange:function(k) {
            var m = this.dataView.getItemById(k[this.idProperty]);
            if (!m)return false;
            for (var n in k)if (k.hasOwnProperty(n))m[n] = k[n];
            this.dataView.updateItem(m.AlbumID,
                    m)
        },artistChange:function(k) {
            var m = this.dataView.getItemById(k[this.idProperty]);
            if (!m)return false;
            for (var n in k)if (k.hasOwnProperty(n))m[n] = k[n];
            this.dataView.updateItem(m.ArtistID, m)
        },playlistChange:function(k) {
            var m = this.dataView.getItemById(k[this.idProperty]);
            if (m) {
                for (var n in k)if (k.hasOwnProperty(n))m[n] = k[n];
                this.dataView.updateItem(m.PlaylistID, m)
            }
        },userChange:function(k) {
            var m = this.dataView.getItemById(k[this.idProperty]);
            if (!m)return false;
            for (var n in k)if (k.hasOwnProperty(n))m[n] =
                    k[n];
            this.dataView.updateItem(m.UserID, m)
        },songFavoritesChange:function() {
            this.data = this.dataView.getItems();
            for (var k = 0; k < this.data.length; k++)if (GS.user.favorites.songs[this.data[k].SongID]) {
                this.data[k].isFavorite = 1;
                this.data[k].fromLibrary = 1;
                this.dataView.updateItem(this.data[k].SongID, this.data[k])
            }
            this.dataView.beginUpdate();
            this.dataView.setItems(this.data, "SongID");
            this.dataView.endUpdate()
        },albumFavoritesChange:function() {
            this.data = this.dataView.getItems();
            for (var k = 0; k < this.data.length; k++)if (GS.user.favorites.albums[this.data[k].AlbumID]) {
                this.data[k].isFavorite =
                        1;
                this.dataView.updateItem(this.data[k].SongID, this.data[k])
            }
            this.dataView.beginUpdate();
            this.dataView.setItems(this.data, "AlbumID");
            this.dataView.endUpdate()
        },artistFavoritesChange:function() {
            this.data = this.dataView.getItems();
            for (var k = 0; k < this.data.length; k++)if (GS.user.favorites.artists[this.data[k].ArtistID])this.data[k].isFavorite = 1;
            this.dataView.beginUpdate();
            this.dataView.setItems(this.data, "ArtistID");
            this.dataView.endUpdate()
        },playlistFavoritesChange:function() {
            this.data = this.dataView.getItems();
            for (var k = 0; k < this.data.length; k++)if (GS.user.favorites.playlists[this.data[k].PlaylistID])this.data[k].isFavorite = 1;
            this.dataView.beginUpdate();
            this.dataView.setItems(this.data, "PlaylistID");
            this.dataView.endUpdate()
        },userFavoritesChange:function() {
            this.data = this.dataView.getItems();
            for (var k = 0; k < this.data.length; k++)if (GS.user.favorites.users[this.data[k].UserID])this.data[k].isFavorite = 1
        },queueChange:function(k) {
            k || (k = GS.player.getCurrentQueue());
            if (this.element) {
                this.element.toggleClass("hasSongs",
                        k && k.songs && k.songs.length > 0);
                k && k.songs && k.songs.length > 0 ? $(".grid-canvas a.play").attr("data-translate-title", "SONG_ROW_ADD_SONG_ADD_TO_PLAYING_TITLE").attr("title", $.localize.getString("SONG_ROW_ADD_SONG_ADD_TO_PLAYING_TITLE")) : $(".grid-canvas a.play").attr("data-translate-title", "SONG_ROW_ADD_SONG_PLAY_TITLE").attr("title", $.localize.getString("SONG_ROW_ADD_SONG_PLAY_TITLE"))
            }
        },getContextMenuForSong:function(k) {
            var m = GS.Controllers.PageController.getActiveController().getPlayContext(),n = GS.Models.Song.getOneFromCache(k),
                    o = parseInt(this.grid.getSelectedRows()) + 1,r = this.data[o - 1].ppVersion;
            o = {songID:k,rank:o};
            if (r)o.ppVersion = r;
            GS.guts.logEvent("rightClickSongItem", o);
            r = [
                {title:$.localize.getString("CONTEXT_PLAY_SONG_NOW"),action:{type:"fn",callback:function() {
                    GS.player.addSongAndPlay(k, m)
                }},customClass:"last jj_menu_item_hasIcon jj_menu_item_play"},
                {title:$.localize.getString("CONTEXT_PLAY_SONG_NEXT"),action:{type:"fn",callback:function() {
                    GS.player.addSongsToQueueAt([k], GS.player.INDEX_NEXT, false, m)
                }},customClass:"last jj_menu_item_hasIcon jj_menu_item_play_next"},
                {title:$.localize.getString("CONTEXT_PLAY_SONG_LAST"),action:{type:"fn",callback:function() {
                    GS.player.addSongsToQueueAt([k], GS.player.INDEX_LAST, false, m)
                }},customClass:"last jj_menu_item_hasIcon jj_menu_item_play_last"},
                {customClass:"separator"}
            ];
            if (n)r = r.concat(n.getContextMenu());
            return r
        },getContextMenuMultiselectForSong:function(k) {
            var m = this,n = GS.Controllers.PageController.getActiveController().getPlayContext(),o = this.grid.getSelectedRows().sort(_.numSortA),r = [],t = [];
            _.forEach(o, function(y, u) {
                r[u] =
                        o[u] + 1;
                var E = m.dataView.rows[y].ppVersion;
                E && t.push(E)
            });
            var w = {songIDs:k,ranks:r};
            if (t.length > 0)w.ppVersions = t.join();
            GS.guts.logEvent("rightClickSongItems", w);
            return[
                {title:$.localize.getString("CONTEXT_PLAY_SONGS_NOW"),customClass:"jj_menu_item_hasIcon jj_menu_item_play",action:{type:"fn",callback:function() {
                    GS.player.addSongsToQueueAt(k, GS.player.INDEX_DEFAULT, true, n)
                }}},
                {title:$.localize.getString("CONTEXT_PLAY_SONGS_NEXT"),customClass:"jj_menu_item_hasIcon jj_menu_item_play_next",action:{type:"fn",
                    callback:function() {
                        GS.player.addSongsToQueueAt(k, GS.player.INDEX_NEXT, false, n)
                    }}},
                {title:$.localize.getString("CONTEXT_PLAY_SONGS_LAST"),customClass:"jj_menu_item_hasIcon jj_menu_item_play_last",action:{type:"fn",callback:function() {
                    GS.player.addSongsToQueueAt(k, GS.player.INDEX_LAST, false, n)
                }}},
                {customClass:"separator"},
                {title:$.localize.getString("CONTEXT_ADD_TO_LIBRARY"),customClass:"jj_menu_item_hasIcon jj_menu_item_music",action:{type:"fn",callback:function() {
                    GS.user.addToLibrary(k)
                }}},
                {customClass:"separator"},
                {title:$.localize.getString("CONTEXT_ADD_TO_PLAYLIST"),type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_playlists",src:GS.Models.Playlist.getPlaylistsMenu(k, function(y) {
                    y.addSongs(k, null, true)
                })},
                {title:$.localize.getString("CONTEXT_SHARE_SONG"),type:"sub",customClass:"jj_menu_item_hasIcon jj_menu_item_share",src:[
                    {title:$.localize.getString("SHARE_WIDGET"),customClass:"jj_menu_item_hasIcon jj_menu_item_share_widget",action:{type:"fn",callback:function() {
                        GS.lightbox.open("share", {service:"widget",
                            type:"manySongs",id:k})
                    }}}
                ]},
                {customClass:"separator"},
                {title:$.localize.getString("CONTEXT_REPLACE_ALL_SONGS"),customClass:"jj_menu_item_hasIcon jj_menu_item_now_playing",action:{type:"fn",callback:function() {
                    GS.player.addSongsToQueueAt(k, GS.player.INDEX_REPLACE, GS.player.isPlaying, n)
                }}}
            ]
        },"input.search keyup":function(k) {
            Slick.GlobalEditorLock.cancelCurrentEdit();
            if (e.which == 27)k.value = "";
            this.searchString = k.value.toLowerCase();
            this.dataView.refresh()
        },".grid-canvas click":function(k, m) {
            if ($(m.target).parents(".slick-row").length ===
                    0) {
                self.currentRow = 0;
                this.grid.setSelectedRows([]);
                this.grid.onSelectedRowsChanged()
            }
        },"* keydown":function(k, m) {
            this.handleKeyPress(m)
        },".slick-collapse-indicator click":function(k, m) {
            m.preventDefault();
            $(k).parents("div.page_column").toggleClass("collapsed");
            $(k).parents("div.page_column").addClass("suppressAutoCollapse");
            if ($(k).parents("div.page_column").hasClass("collapsed")) {
                $(k).parents("div.page_column").addClass("manualCollapse").removeClass("manualOpen");
                $(".page_column_fixed.collapsed").width(this.grid.getScrollWidth())
            } else {
                $(k).parents("div.page_column").addClass("manualOpen").removeClass("manualCollapse");
                $(".page_column_fixed").width(175)
            }
            $(window).resize();
            $(".gs_grid:visible").resize()
        },handleKeyPress:function(k) {
            if ((k.which === 38 || k.which === 40) && k.shiftKey) {
                var m = this.grid.getSelectedRows().sort(function(r, t) {
                    return r - t
                });
                _.orEqual(m[m.length - 1], 1);
                var n,o;
                n = this.currentRow + (k.which === 38 ? -1 : 1);
                n = Math.max(0, Math.min(this.dataView.rows.length - 1, n));
                if ($.inArray(n, m) === -1) {
                    m.push(n);
                    this.selectedRowIDs.push(this.dataView.getItemByIdx(n).SongID);
                    this.currentRow = n;
                    this.grid.setSelectedRows(_.arrUnique(m));
                    this.grid.onSelectedRowsChanged()
                } else if (k.which === 38) {
                    if (n < this.currentRow) {
                        o = $.inArray(this.currentRow, m);
                        _.arrRemove(m, o, o);
                        this.currentRow = n;
                        o = $.inArray(this.currentRow, m);
                        _.arrRemove(m, o, o);
                        m.push(this.currentRow);
                        this.grid.setSelectedRows(_.arrUnique(m));
                        this.grid.onSelectedRowsChanged()
                    }
                } else if (n > this.currentRow) {
                    o = $.inArray(this.currentRow, m);
                    _.arrRemove(m, o, o);
                    this.currentRow = n;
                    o = $.inArray(this.currentRow, m);
                    _.arrRemove(m, o, o);
                    m.push(this.currentRow);
                    this.grid.setSelectedRows(_.arrUnique(m));
                    this.grid.onSelectedRowsChanged()
                }
                k.preventDefault();
                return true
            }
            return false
        },"a.field,a.songLink click":function(k) {
            k = k.attr("href") || "";
            var m = parseInt(this.grid.getSelectedRows()[0]) + 1,n = $("#grid .slick-row.selected ul.options").attr("rel");
            GS.guts.handleFieldClick(k, m, n, this.data[m - 1].ppVersion)
        },"a.songLink click":function(k, m) {
            var n = parseInt($(k).attr("rel"), 10),o = false;
            if (this.selectedRowIDs.length == 0 || n == this.selectedRowIDs[0] && this.selectedRowIDs.length == 1)o = true;
            if (n && _.defined(m.which) &&
                    (!m.shiftKey && !m.ctrlKey && !m.metaKey || o)) {
                (o = $(k).data("clickCount")) || (o = 0);
                o++;
                o == 1 && setTimeout(function() {
                    $(k).data("clickCount") == 1 && GS.Models.Song.getSong(n, function(r) {
                        if (r)location.hash = r.toUrl()
                    });
                    $(k).data("clickCount", 0)
                }, 300);
                $(k).data("clickCount", o)
            }
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.AdController", {onDocument:true}, {rotateTimer:0,rotationTime:45E3,defaultRotationTime:45E3,maxRotationTime:36E4,lastActive:null,lastRotation:null,useTestAds:false,rotationCount:0,campaignArtists:{},campaignsByCampaignID:{},userCampaigns:[],init:function() {
    this.subscribe("gs.auth.update", this.callback(this.update));
    this.subscribe("gs.player.nowplaying", this.callback(this.onSongPlay));
    this.lastActive = new Date;
    var a = this;
    $("body").bind("mousemove",
            function() {
                a.lastActive = new Date
            });
    this._super()
},appReady:function() {
    this.update()
},update:function() {
    this.user = GS.user;
    this.parseCampaignsForUser();
    GS.user.IsPremium ? this.hideAdBar() : this.showAdBar();
    $(window).resize()
},onSongPlay:function(a) {
    if (this.campaignArtists && this.campaignArtists[a.ArtistID]instanceof Array)for (var b = 0; b < this.campaignArtists[a.ArtistID].length; b++) {
        var c = this.campaignArtists[a.ArtistID][b];
        if (c) {
            var g = this.campaignsByCampaignID[c];
            if (!g) {
                g = {id:c,count:1};
                this.campaignsByCampaignID[c] =
                        g;
                this.userCampaigns.push(g)
            }
        }
    }
},parseCampaignsForUser:function() {
    this.userCampaigns = [];
    this.campaignsByCampaignID = {};
    var a = store.get("artistsPlayed" + (this.user ? this.user.UserID : -1));
    if (this.campaignArtists && a)for (var b = 0; b < a.length; b++) {
        var c = a[b];
        if (c && this.campaignArtists[c]instanceof Array)for (var g = 0; g < this.campaignArtists[c].length; g++) {
            var h = this.campaignArtists[c][g];
            if (h) {
                var k = this.campaignsByCampaignID[h];
                if (k)k.count++; else {
                    k = {id:h,count:1};
                    this.campaignsByCampaignID[h] = k;
                    this.userCampaigns.push(k)
                }
            }
        }
    }
},
    showAdBar:function() {
        $("#capital").show();
        $("#application").css("margin-right", "180px");
        $("#capitalFrameWrapper").children("iframe").attr("src", "");
        this.startAdTimer()
    },startAdTimer:function() {
        if (GS.theme.themeIsReady) {
            clearInterval(this.rotateTimer);
            this.rotateTimer = setInterval(this.callback("onRotateTimer"), this.defaultRotationTime);
            this.chooseAd()
        }
    },hideAdBar:function() {
        $("#capital").hide();
        $("#application").css("margin-right", 0);
        $("#capitalFrameWrapper").children("iframe").attr("src", "");
        GS.player &&
        GS.player.updateQueueWidth();
        clearInterval(this.rotateTimer)
    },onRotateTimer:function() {
        if (this.lastActive && !GS.user.IsPremium) {
            var a = (new Date).valueOf(),b = a - this.lastActive.valueOf();
            a = a - this.lastRotation.valueOf();
            if (b <= this.defaultRotationTime) {
                this.rotationTime = this.defaultRotationTime;
                this.chooseAd()
            } else if (a >= this.rotationTime && this.rotationTime <= this.maxRotationTime) {
                this.rotationTime += this.rotationTime;
                this.chooseAd()
            }
        }
    },chooseAd:function() {
        var a = new Date;
        this.rotationCount++;
        this.lastRotation =
                a;
        this.setAd("/sidebar.php" + this.buildParams());
        GS.guts.logEvent("adRotation", {})
    },buildParams:function(a) {
        a = a instanceof Array ? a : [];
        if (GS.theme && GS.theme.currentTheme) {
            var b = parseInt(GS.theme.currentTheme.themeID, 10);
            b && a.push("ThemeID=" + b)
        }
        GS.player && GS.player.getCurrentSong() && a.push("CurArtist=" + GS.player.getCurrentSong().ArtistID);
        if (this.userCampaigns && this.userCampaigns.length) {
            this.userCampaigns.sort(function(k, m) {
                return m.count - k.count
            });
            (b = campaigns[0].id) && a.push("Bucket=" + b)
        }
        if (GS.user.isLoggedIn) {
            GS.user.Sex &&
            a.push("Gender=" + GS.user.Sex);
            if (GS.user.TSDOB) {
                b = GS.user.TSDOB.split("-");
                if (b.length == 3) {
                    var c = new Date,g = c.getFullYear() - parseInt(b[0], 10);
                    if (parseInt(b[1], 10) > c.month)g -= 1; else if (parseInt(b[1], 10) == c.month && parseInt(b[2], 10) > c.date)g -= 1;
                    var h;
                    if (g >= 13 && g < 18)h = "13-17"; else if (g >= 18 && g < 25)h = "18-24"; else if (g >= 25 && g < 35)h = "25-34"; else if (g >= 35 && g < 50)h = "35-49"; else if (g >= 50)h = "50-";
                    g >= 21 && a.push("a=1");
                    h && a.push("AgeRange=" + h)
                }
            }
        }
        a.push("3=" + Math.round(((new Date).getTime() - GS.theme.sessionStart) /
                1E3));
        a.push("4=" + this.rotationCount);
        a.push("5=" + ((GS.user.settings.local.themeFlags & GS.theme.THEME_FLAG_FAMILY_FRIENDLY) == GS.theme.THEME_FLAG_FAMILY_FRIENDLY ? 1 : 0));
        GS.theme.currentTheme && GS.theme.currentTheme.sections.indexOf("#theme_page_header") >= 0 && a.push("6=1");
        if (GS.Controllers.PageController.activePageName && GS.Controllers.PageController.activePageName.toLowerCase() == "home")a.push("9=1"); else GS.Controllers.PageController.activePageName && GS.Controllers.PageController.activePageName.toLowerCase() ==
                "search" && (!GS.search.type || GS.search.type == "" || GS.search.type == "everything") ? a.push("9=2") : a.push("9=0");
        this.useTestAds && a.push("testAds=1");
        if (!GS.user.IsPremium && !GS.user.isLoggedIn && store.get("webvisit") && store.get("webvisit").sidebar)a = a.concat(store.get("webvisit").sidebar);
        a = a.concat(this.getLocaleParams());
        return"?" + a.join("&")
    },loadPixel:function() {
        if (GS.user.isLoggedIn) {
            var a = [];
            if (GS.user.TSDOB) {
                var b = GS.user.TSDOB.split("-");
                if (b.length == 3) {
                    var c = new Date,g = c.getFullYear() - parseInt(b[0],
                            10);
                    if (parseInt(b[1], 10) > c.month)g -= 1; else if (parseInt(b[1], 10) == c.month && parseInt(b[2], 10) > c.date)g -= 1
                }
                a.push("100=" + g)
            }
            GS.user.Sex && a.push("200=" + GS.user.Sex);
            if (GS.user.Email) {
                a.push("300=" + hex_md5(GS.user.Email));
                a.push("400=" + hex_sha1(GS.user.Email))
            }
            this.setPixel("/pixels.php" + ("?" + a.join("&")))
        }
    },setAd:function(a) {
        var b = $("#capitalFrameWrapper").children("iframe");
        if (b.length > 1) {
            for (var c = b.length - 1; c > 0; c--)b.eq(c).unbind("load").remove();
            b = b.eq(0)
        }
        var g = b.clone();
        g.css("visibility", "hidden");
        g.bind("load", function() {
            b.unbind("load").remove();
            g.css("visibility", "visible").width(0);
            _.wait(10).then(function() {
                g.width(160)
            })
        });
        g.attr("src", a);
        $("#capitalFrameWrapper").append(g)
    },setPixel:function(a) {
        var b = $("#pixelFrameWrapper").children("iframe");
        if (b.length > 1) {
            for (var c = b.length - 1; c > 0; c--)b.eq(c).unbind("load").remove();
            b = b.eq(0)
        }
        c = b.clone();
        c.css("visibility", "hidden");
        c.bind("load", function() {
            b.unbind("load").remove()
        });
        c.attr("src", a);
        $("#pixelFrameWrapper").append(c)
    },getLocaleParams:function() {
        var a =
                "0=";
        switch (GS.locale.locale) {
            case "en":
                a += "1";
                break;
            case "bg":
                a += "2";
                break;
            case "ca":
                a += "3";
                break;
            case "cs":
                a += "4";
                break;
            case "da":
                a += "5";
                break;
            case "de":
                a += "6";
                break;
            case "es":
                a += "7";
                break;
            case "eu":
                a += "8";
                break;
            case "fi":
                a += "9";
                break;
            case "fr":
                a += "10";
                break;
            case "it":
                a += "11";
                break;
            case "ja":
                a += "12";
                break;
            case "lt":
                a += "13";
                break;
            case "nb":
                a += "14";
                break;
            case "nl":
                a += "15";
                break;
            case "pl":
                a += "16";
                break;
            case "pt":
                a += "17";
                break;
            case "ro":
                a += "18";
                break;
            case "ru":
                a += "19";
                break;
            case "sk":
                a += "20";
                break;
            case "sl":
                a += "21";
                break;
            case "sv":
                a += "22";
                break;
            case "tr":
                a += "23";
                break;
            case "zh":
                a += "24";
                break;
            default:
                a += "1";
                break
        }
        return[a]
    }});
GS.Controllers.BaseController.extend("GS.Controllers.GUTSController", {onDocument:true}, {shouldLog:false,server:"/guts",appID:"html",context:false,bufferLength:10,localLogs:[],init:function() {
    this.shouldLog = _.orEqual(gsConfig.shouldUseGuts, 0);
    this.server = _.orEqual(gsConfig.gutsServer, false);
    this.context = {};
    this.currentPage = {};
    this.currentPage.pageType = "home";
    this.currentPage.section = "";
    this.currentPage.subpage = "";
    this.currentPage.id = "";
    this.beginContext({sessionID:GS.service.sessionID});
    this.beginContext({initTime:(new Date).getTime()});
    this.logEvent("init", {});
    GS.user && GS.user.UserID && GS.user.UserID > 0 && this.beginContext({userID:GS.user.UserID});
    window.chrome && window.chrome.app.isInstalled ? this.gaTrackEvent("chromeApp", "isInstalled") : this.gaTrackEvent("chromeApp", "notInstalled");
    this._super()
},beginContext:function(a) {
    _.forEach(a, function(b, c) {
        if (a.hasOwnProperty(c))this.context[c] = a[c]
    }, this)
},endContext:function(a) {
    _.defined(this.context[a]) && delete this.context[a]
},doLogEvent:function(a, b) {
    var c = {time:(new Date).getTime(),lpID:a,
        state:{},context:{}};
    currentContext = this.context;
    _.forEach(currentContext, function(g, h) {
        if (currentContext.hasOwnProperty(h))if ($.isArray(currentContext[h])) {
            this.context[h] = [];
            _.forEach(currentContext[h], function(k, m) {
                this.push(m)
            }, this.context[h])
        } else this.context[h] = _.orEqual(currentContext[h], "").toString()
    }, c);
    _.forEach(b, function(g, h) {
        if (b.hasOwnProperty(h))c.state[h] = _.orEqual(g, "").toString()
    }, c);
    this.localLogs.push(c);
    this.checkSendCondition() && this.sendLogs()
},logEvent:function(a, b) {
    this.shouldLog &&
    this.doLogEvent(a, b)
},forceLogEvent:function(a, b) {
    this.doLogEvent(a, b)
},checkSendCondition:function() {
    return this.localLogs.length >= this.bufferLength
},forceSend:function() {
    this.sendLogs(true)
},sendLogsTimeout:false,sendLogsWait:3E4,sendLogs:function(a) {
    clearTimeout(this.sendLogsTimeout);
    if (a)this._internalSend(false); else this.sendLogsTimeout = setTimeout(this.callback(this._internalSend), this.sendLogsWait)
},_internalSend:function(a) {
    a = _.orEqual(a, true);
    if (this.localLogs.length > 0) {
        var b = this.toTransmissionFormat(this.localLogs);
        $.ajax({contentType:"text/xml",type:"POST",data:b,url:this.server,cache:false,async:a,success:function() {
        },error:function() {
        }});
        this.localLogs = []
    }
},toTransmissionFormat:function(a) {
    var b = {result:(new Date).getTime() + "\n",appID:this.appID};
    _.forEach(a, function(c, g) {
        var h = /\:/g,k = /\\/g,m = a[g];
        this.result += this.appID + "\t";
        this.result += m.lpID + "\t";
        var n = m.context;
        _.forEach(n, function(r, t) {
            if (n.hasOwnProperty(t))this.result += t + ":" + n[t].replace(k, "\\\\").replace(h, "\\:") + "\t"
        }, this);
        var o = m.state;
        _.forEach(o,
                function(r, t) {
                    if (o.hasOwnProperty(t))this.result += t + ":" + o[t].replace(k, "\\\\").replace(h, "\\:") + "\t"
                }, this);
        this.result += m.time + "\n"
    }, b);
    return b.result
},handlePageLoad:function(a, b) {
    var c = {};
    c.destinationPageType = a;
    switch (a) {
        case "home":
            if (b.redeemingPromoCard)c.reason = "redeem";
            break;
        case "user":
            switch (b.length) {
                case 2:
                    c.destinationPageID = b.id;
                    break;
                case 3:
                    c.destinationPageID = b.id;
                    c.destinationSubpageType = b.section;
                    break;
                case 4:
                    c.destinationPageID = b.id;
                    c.destinationSubpageType = b.subpage;
                    break;
                default:
                    break
            }
            c.destinationSubpageType =
                    _.orEqual(c.destinationSubpageType, "profile");
            break;
        case "playlist":
        case "album":
        case "artist":
            c.destinationPageID = b.id;
            c.destinationSubpageType = a == "album" && b.subpage == "music" ? "tracklist" : b.subpage;
            break;
        case "search":
            c.destinationSubpageType = b.type == "everything" ? "everything" : b.type;
            break;
        case "popular":
            c.destinationSubpageType = b.length == 2 ? "monthly" : "today";
            break;
        case "song":
            c.destinationPageID = b.token;
            c.destinationSubpageType = b.subpage;
            break;
        case "notFound":
            this.logEvent("pageNotFound", {pageSought:b.page});
            c.destinationPageType = "home";
            c.reason = "pageNotFound";
            break;
        case "settings":
            c.destinationSubpageType = _.orEqual(b.type, "profile");
            break;
        case "surveys":
            if (b.subpage)c.destinationSubpageType = b.subpage;
            break;
        default:
            c.destinationPageType = a;
            break
    }
    this.logEvent("loadPage", c);
    this.beginContext({currentPageType:c.destinationPageType});
    c.destinationSubpageType ? this.beginContext({currentSubpage:c.destinationSubpageType}) : this.endContext("currentSubpage");
    c.destinationPageID ? this.beginContext({currentPageID:c.destinationPageID}) :
            this.endContext("currentPageID")
},updateCurrentPage:function(a) {
    this.currentPage.pageType = a.type;
    this.currentPage.id = a.id;
    this.currentPage.section = a.section;
    this.currentPage.subpage = a.subpage
},logPageLoad:function(a) {
    a.id ? this.logEvent("loadPage", {type:a.type,id:a.id}) : this.logEvent("loadPage", {type:a.type});
    this.beginContext({currentPageType:a.type});
    this.endContext("currentSubpage")
},logSubpageLoad:function(a) {
    this.logEvent("loadSubpage", {type:a.type});
    this.beginContext({currentSubpage:a.type})
},
    handleFieldClick:function(a, b, c, g) {
        b = {songID:c,rank:b};
        if (g != null && g.length > 0)b.ppVersion = g;
        g = "";
        g = a.indexOf("artist") > -1 ? "OLartistPageLoad" : a.indexOf("album") > -1 ? "OLalbumPageLoad" : "OLSongPageLoad";
        GS.guts.logEvent(g, b)
    },handleFeedEventClick:function(a) {
        var b = {};
        switch ($(a).attr("tagName")) {
            case "A":
                feedEvent = $(a).parents(".event");
                if ($(a).attr("href")) {
                    var c = $(a).attr("href").split("/");
                    b.clickedType = c[1];
                    b.clickedID = c[3]
                } else b.clickedType = $(a).attr("class");
                break;
            case "LI":
                feedEvent = $(a).parents(".event");
                a = $(a).attr("class").split(" ");
                a = a[a.length - 1];
                if (a == "option")b.clickedType = "playSongs"; else if (a == "show")b.clickedType = "showSongs";
                break;
            default:
                break
        }
        b.rank = $(feedEvent).index() + 1;
        var g = $(feedEvent).attr("class");
        c = g.split(" ");
        b.whoseFeed = c[2].split("user")[1];
        _.forEach(c, function(n, o) {
            if (c[o].indexOf("type") > -1)b.eventType = c[o].substring(4, c[o].length)
        }, b);
        var h = {};
        $('.what>a[class!="showSongs"]', feedEvent).each(function() {
            var n = $(this).attr("href");
            if (n !== undefined) {
                n = n.split("/");
                var o = n[1];
                if (h[o])h[o] += 1; else h[o] = 1;
                b[o + h[o]] = n[3]
            }
        });
        var k = {};
        $("#feed>li").each(function() {
            g = $(this).attr("class");
            c = g.split(" ");
            var n = c[1].substring(4, c[1].length);
            if (k[n])k[n] += 1; else k[n] = 1
        });
        var m = "";
        _.forEach(k, function(n, o) {
            m = m + o + ";" + n + ","
        }, m);
        m = m.slice(0, m.length - 1);
        b.counts = m;
        this.logEvent("feedEventClick", b)
    },objectListPlayAdd:function(a, b, c) {
        var g,h;
        switch (c) {
            case "play":
                g = "OLPlayClick";
                break;
            case "add":
                g = "OLAddClick";
                break;
            default:
                break
        }
        var k;
        b = $("#grid .slick-row.selected", b);
        if (b.length > 0) {
            h =
                    "";
            $(b).each(function() {
                k = parseInt($(this).attr("row"), 10);
                isNaN(k) || (h = h + (k + 1) + ",")
            });
            h = h.slice(0, h.length - 1)
        } else h = "all";
        this.logEvent(g, {songIDs:a,ranks:h})
    },songItemLibraryClick:function(a) {
        this.logEvent("OLlibraryClick", a)
    },songItemFavoriteClick:function(a) {
        this.logEvent("OLfavoriteClick", a)
    },songsRemovedFromQueue:function(a) {
        var b = a.details.items;
        if (a) {
            var c = "";
            _.forEach(b, function(g, h) {
                c = c + h[g].songID + ","
            }, c);
            c = c.slice(0, c.length - 1);
            GS.guts.logEvent("songsRemovedFromQueue", {songIDs:c})
        }
    },
    handleSearchSidebarClick:function(a, b, c) {
        if (b = a.attr("href")) {
            b = b.substr(0, b.indexOf("?"));
            var g = b.split("/");
            b = g[1];
            g = g[3];
            $(a).attr("class") == "image" ? this.logEvent("searchSidebarClick", {section:c,linkType:b,id:g,imageClick:"true"}) : this.logEvent("searchSidebarClick", {section:c,linkType:b,id:g})
        } else if (a.hasClass("searchLink")) {
            b = "seeAll";
            this.logEvent("searchSidebarClick", {section:c,linkType:b})
        }
    },handleAutoplayOff:function() {
        this.logEvent("autoplayOff", {});
        this.endContext("autoplay");
        this.endContext("autoplaySeedSongs")
    },
    gaTrackEvent:function(a, b, c, g) {
        if (_.notDefined(a) || _.notDefined(b))console.warn("guts.gaTrackEvent: bad category or action", a, b); else {
            c = "" + _.orEqual(c, "");
            g = parseFloat("" + _.orEqual(g, ""), 10);
            if (isNaN(g) || g == "")g = null;
            setTimeout(function() {
                if (window._gaq && window._gaq.push)if (c && g)window._gaq.push(["_trackEvent",a,b,c,g]); else if (c)window._gaq.push(["_trackEvent",a,b,c]); else g ? window._gaq.push(["_trackEvent",a,b,null,g]) : window._gaq.push(["_trackEvent",a,b])
            }, Math.random() * 5E3)
        }
    }});
GS.Controllers.BaseController.extend("GS.Controllers.LocaleController", {onWindow:true}, {locale:"en",init:function() {
    var a = this,b = (store.get("gs.locale") || gsConfig.lang || this.detectLangauge() || this.locale).substring(0, 2);
    $("[data-translate-text]").localize("gs", {language:b});
    $("[data-translate-title]").localize("gs", {language:b,callback:"titleCallback"});
    this.subscribe("gs.locale.update", function(c) {
        a.locale = c;
        $("[data-translate-text]").localize("gs", {language:c});
        $("[data-translate-title]").localize("gs",
                {language:c,callback:"titleCallback"});
        store.set("gs.locale", c)
    });
    this.locale = b
},detectLangauge:function() {
    var a = window.navigator;
    return a.language || a.browserLanguage || a.systemLanguage || a.userLanguage
}});
GS.Controllers.BaseController.extend("GS.Controllers.FacebookController", {onDocument:true}, {APPLICATION_ID:"111132365592157",SERVICE_ID:4,FACEBOOK_ONLY_SERVICE_ID:16,PERMISSIONS:"offline_access,publish_stream,email,rsvp_event,read_stream,user_about_me,user_likes,user_interests,user_location,user_birthday",WALL_FAVORITES:1,WALL_PLAYLIST_CREATE:2,WALL_PLAYLIST_SUBSCRIBE:4,RATE_LIMIT:3E5,profile:null,friends:null,registeredWithFacebook:false,flags:0,lastPost:0,lastPostParams:null,lastError:null,facebookLoaded:false,
    connectStatus:"unknown",connected:false,onLoginSaveData:null,init:function() {
        this.subscribe("gs.auth.update", this.callback("update"));
        this.LISTEN_APPLICATION_ID = "111132365592157";
        if (window.location.host.indexOf("grooveshark.com") > -1 && this.APPLICATION_ID !== this.LISTEN_APPLICATION_ID || !this.APPLICATION_ID) {
            console.error("Resetting Facebook Application ID to listen");
            this.APPLICATION_ID = this.LISTEN_APPLICATION_ID
        }
        this._super()
    },initFacebook:function() {
        if (window.FB && window.FB.init) {
            FB.init({appId:this.APPLICATION_ID,
                status:false,cookie:false,xfbml:false});
            var a = _.browserDetect();
            if (a.browser == "chrome" && (a.version < 11 || a.version >= 13)) {
                FB.XD._origin = window.location.protocol + "//" + document.domain + "/" + FB.guid();
                FB.XD.Flash.init();
                FB.XD._transport = "flash"
            } else if (a.browser == "opera") {
                FB.XD._transport = "fragment";
                FB.XD.Fragment._channelUrl = window.location.protocol + "//" + window.location.host + "/"
            } else if (a.browser == "msie" && a.version == 8) {
                FB.XD._origin = window.location.protocol + "//" + document.domain + "/" + FB.guid();
                FB.XD.Flash.init();
                FB.XD._transport = "flash"
            }
            FB.getLoginStatus(this.callback(this.onFacebookLoginStatus));
            FB.Event.subscribe("auth.statusChange", this.callback(this.onFacebookLoginStatus));
            this.facebookLoaded = true;
            GS.user && GS.user.isLoggedIn && this.update()
        }
    },appReady:function() {
        this.update()
    },update:function() {
        if (this.facebookLoaded && GS.user && GS.user.isLoggedIn && (GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID)) {
            this.registeredWithFacebook = GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID;
            GS.service.getUserFacebookData(this.callback("onUserFacebookData",
                    null, null))
        } else if (this.facebookLoaded)GS.user && GS.user.isLoggedIn && this.onLoginSaveData && this.onLoginSaveData == GS.user.Email ? this.save(0, null, function() {
            GS.facebook.clearInfo()
        }) : this.clearInfo()
    },cleanSession:function(a) {
        var b = a.session_key.split("-");
        a = a.access_token.split("|");
        var c = {};
        c.facebookUserID = b[1];
        c.sessionKey = b[0];
        c.accessToken1 = a[0];
        c.accessToken3 = a[2];
        return c
    },onFacebookLoginStatus:function(a) {
        this.connectStatus = a.status;
        switch (this.connectStatus) {
            case "connected":
                break;
            case "notConnected":
                break;
            case "unknown":
            default:
                break
        }
        $.publish("gs.facebook.status")
    },onUserFacebookData:function(a, b, c) {
        try {
            var g = {};
            if (window.FB && c && c.FacebookUserID) {
                g.session_key = c.SessionKey + "-" + c.FacebookUserID;
                g.access_token = c.AccessToken1 + "|" + g.session_key + "|" + c.AccessToken3;
                g.expires = 0;
                g.uid = c.FacebookUserID;
                g.sig = null;
                g.secret = null;
                var h = FB.getSession();
                if (h && h.uid && h.uid == g.uid)if (h.session_key != g.session_key || h.access_token != g.access_token) {
                    g = h;
                    this.save(c.Flags)
                }
                this.flags = c.Flags;
                this.connected = true;
                FB.init({appId:this.APPLICATION_ID,
                    status:false,cookie:false,xfbml:true,session:g});
                FB.api("/me", this.callback("getMyProfile", a, b));
                a && a()
            } else {
                GS.user.Flags = (GS.user.Flags | this.SERVICE_ID) - this.SERVICE_ID;
                if (this.registeredWithFacebook)GS.user.Flags = (GS.user.Flags | this.FACEBOOK_ONLY_SERVICE_ID) - this.FACEBOOK_ONLY_SERVICE_ID;
                this.connected = false;
                b && b()
            }
        } catch(k) {
            this.connected = false;
            b && b()
        }
    },gsLogin:function(a, b) {
        if (!GS.user.isLoggedIn)if (this.connectStatus == "connected" && window.FB) {
            var c = FB.getSession();
            if (c) {
                c = this.cleanSession(c);
                GS.service.authenticateFacebookUser(c.facebookUserID, c.sessionKey, c.accessToken1, c.accessToken3, this.callback("onAuthFacebookUser", a, b), b)
            } else this.connectStatus == "notConnected" ? this.register(a, b) : b({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"})
        } else this.login(this.callback(this.gsLogin, a, b), b)
    },onAuthFacebookUser:function(a, b, c) {
        if (c)if (c.userID == 0)this.register(a, b); else {
            this.connected = true;
            a(c)
        } else b && b(c)
    },register:function(a, b) {
        if (window.FB && FB.getSession())FB.Data.query("select {0} from user where uid={1}",
                "uid,name,first_name,last_name,profile_url,username,about_me,birthday_date,profile_blurb,sex,email,locale,profile_update_time,pic", FB.getSession().uid).wait(function(c) {
                    c && c[0] ? GS.facebook.gotProfileForRegister(b, c[0].username ? c[0].username : "", {id:c[0].uid,name:c[0].name,first_name:c[0].first_name,last_name:c[0].last_name,link:c[0].profile_url,bio:c[0].about_me,birthday:c[0].birthday_date,about:c[0].profile_blurb,gender:c[0].sex,email:c[0].email,locale:c[0].locale,updated_time:c[0].profile_update_time,
                        picture:c[0].pic}) : GS.facebook.gotProfileForRegister(b)
                }); else b && b({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"})
    },gotProfileForRegister:function(a, b, c) {
        if (c && !c.error)GS.service.getUsernameSuggestions(b, c.name ? c.name : "", c.id, this.callback("usernameSuggestSuccess", c), this.callback("usernameSuggestFailed", c)); else a && a({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"})
    },usernameSuggestSuccess:function(a, b) {
        var c = "";
        if (b && b.length > 0)c = b[0];
        this.openRegisterLightbox(c, a)
    },usernameSuggestFailed:function(a) {
        this.openRegisterLightbox("",
                a)
    },openRegisterLightbox:function(a, b) {
        var c = {isFacebook:true,username:a,session:window.FB ? this.cleanSession(FB.getSession()) : null,message:$.localize.getString("POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_NOT_FOUND")};
        if (b) {
            var g = b.birthday.split("/");
            c.month = parseInt(g[0]);
            c.day = parseInt(g[1]);
            c.year = parseInt(g[2]);
            c.fname = b.name ? b.name : "";
            if (b.gender == "female")c.sex = "F"; else if (b.gender == "male")c.sex = "M";
            c.email = b.email ? b.email : "";
            GS.user.defaultFromService = c
        }
        GS.lightbox.close();
        location.hash = "#/signup"
    },
    login:function(a, b) {
        if (window.FB && window.FB.login)GS.airbridge && GS.airbridge.isDesktop ? FB.login(this.callback("onAIRLogin", a, b), {perms:this.PERMISSIONS}) : FB.login(this.callback("onLogin", a, b), {perms:this.PERMISSIONS}); else b && b({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"})
    },onAIRLogin:function(a, b, c) {
        window.setTimeout(function() {
            GS.facebook.onLogin(a, b, c)
        }, 300)
    },onLogin:function(a, b, c) {
        if (c.session)if (c.perms) {
            var g = this.PERMISSIONS.split(",");
            _.forEach(g, function(k) {
                c.perms.indexOf(k) == -1 && b &&
                b({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_DISALLOW_ERROR"})
            });
            g = c.session.session_key.split("-");
            var h = c.session.access_token.split("|");
            if (GS.user.isLoggedIn)GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID ? GS.service.updateUserFacebookData(g[1], g[0], h[0], h[2], this.flags, this.callback("onSaveUserFacebookData", a, b), b) : GS.service.saveUserFacebookData(g[1], g[0], h[0], h[2], this.flags, this.callback("onSaveUserFacebookData", a, b), b); else {
                this.onFacebookLoginStatus(c);
                a ? a() : GS.service.authenticateFacebookUser(g[1],
                        g[0], h[0], h[2], this.callback("onAuthFacebookUser", a, b), b)
            }
        } else b({error:"POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_DISALLOW_ERROR"})
    },save:function(a, b, c) {
        if (window.FB && FB.getSession() && GS.user.isLoggedIn) {
            var g = FB.getSession().session_key.split("-"),h = FB.getSession().access_token.split("|");
            GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID ? GS.service.updateUserFacebookData(g[1], g[0], h[0], h[2], a, this.callback("onSaveUserFacebookData", b, c), c) : GS.service.saveUserFacebookData(g[1], g[0],
                    h[0], h[2], a, this.callback("onSaveUserFacebookData", b, c), c);
            this.flags = a
        }
    },onSaveUserFacebookData:function(a, b, c) {
        if (c == 1 && window.FB) {
            this.connected = true;
            FB.api("/me", this.callback("getMyProfile", a, b));
            GS.user.Flags & this.SERVICE_ID && !(GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID) || $.publish("gs.facebook.notification.findFriends", "NOTIF_FACEBOOK_FINDFRIENDS")
        } else if (c == -1)if (GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.FACEBOOK_ONLY_SERVICE_ID)GS.service.getUserFacebookData(this.callback("onUserFacebookData",
                a, function() {
                    b("FACEBOOK_PROBLEM_CONNECTING_ERROR_MSG")
                })); else b && b("FACEBOOK_DUPLICATE_ACCOUNT_ERROR_MSG"); else b && b("POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR")
    },getMyProfile:function(a, b, c) {
        if (c && c.id) {
            this.profile = c;
            $.publish("gs.facebook.profile.update");
            a && a()
        } else {
            this.connected = false;
            this.lastError = c;
            GS.user && GS.user.isLoggedIn && c.error && c.error.type == "OAuthException" && this.APPLICATION_ID == this.LISTEN_APPLICATION_ID && GS.lightbox.open("reAuthFacebook");
            b && b()
        }
    },onSaveSession:function() {
    },logout:function(a) {
        GS.service.removeUserFacebookData(this.callback("onLogout",
                a))
    },onLogout:function(a) {
        this.clearInfo();
        $.publish("gs.facebook.profile.update");
        this.registeredWithFacebook && GS.auth.logout();
        a && a()
    },clearInfo:function() {
        this.friends = this.profile = null;
        this.connected = false;
        this.flags = 0;
        if (window.FB && window.FB.init) {
            FB.init({appId:this.APPLICATION_ID,status:false,cookie:false,xfbml:true});
            FB.getLoginStatus(this.callback(this.onFacebookLoginStatus))
        }
        $.publish("gs.facebook.profile.update")
    },postToFeed:function(a, b, c, g, h, k) {
        if (this.connectStatus === "connected" && window.FB &&
                FB.getSession()) {
            var m = {};
            a = _.orEqual(a, "me") + "/feed";
            m.link = b;
            m.message = c;
            m.access_token = FB.getSession().access_token;
            m.type = g;
            m.hideUndo = true;
            GS.service.makeFacebookRequest(a, m, "POST", this.callback("onFeedPost", m, h), this.callback("onFailedPost", k))
        } else $.isFunction(k) && k("No facebook session.")
    },onFeedPost:function(a, b) {
        a.type && $.publish("gs.facebook.notification.sent", {params:a,data:{},notifData:{}});
        this.lastError = false;
        b && b()
    },postLink:function(a, b, c, g, h, k) {
        if (this.connectStatus === "connected" &&
                window.FB && FB.getSession()) {
            var m = {};
            a = _.orEqual(a, "me") + "/links";
            m.link = b;
            m.message = c;
            m.access_token = FB.getSession().access_token;
            m.type = _.orEqual(g, "song");
            m.hideUndo = true;
            GS.service.makeFacebookRequest(a, m, "POST", this.callback("onFeedPost", m, h), this.callback("onFailedPost", k))
        } else $.isFunction(k) && k("No facebook session.")
    },onFailedPost:function(a, b) {
        this.lastError = b;
        $.isFunction(a) && a(b)
    },onFavoriteSong:function(a, b) {
        if (this.connectStatus === "connected" && window.FB && FB.getSession() && !(this.flags &
                this.WALL_FAVORITES)) {
            var c = {access_token:FB.getSession().access_token};
            c.message = b;
            c.type = "favorite";
            c.hideUndo = true;
            if ($.isFunction(a.toUrl)) {
                c.link = "http://grooveshark.com" + a.toUrl().substr(1);
                this.postEvent(c, false, a)
            } else GS.Models.Song.getSong(_.orEqual(a.SongID, a.songID), this.callback(function(g) {
                c.link = "http://grooveshark.com" + g.toUrl().substr(1);
                this.postEvent(c, false, g)
            }), this.onFailedPostEvent)
        }
    },onPlaylistCreate:function(a, b) {
        if (this.connectStatus === "connected" && window.FB && FB.getSession() &&
                !(this.flags & this.WALL_PLAYLIST_CREATE)) {
            var c = {access_token:FB.getSession().access_token};
            c.message = b;
            c.link = "http://grooveshark.com" + a.toUrl().substr(1);
            c.type = "playlist";
            c.hideUndo = true;
            this.postEvent(c, false, a)
        }
    },onSubscribePlaylist:function(a, b) {
        if (this.connectStatus === "connected" && window.FB && FB.getSession() && !(this.flags & this.WALL_PLAYLIST_SUBSCRIBE)) {
            var c = {access_token:FB.getSession().access_token};
            c.message = b;
            c.link = "http://grooveshark.com" + a.toUrl().substr(1);
            c.type = "playlist";
            c.hideUndo =
                    true;
            this.postEvent(c, false, a)
        }
    },onFollowUser:function(a, b) {
        if (this.connectStatus === "connected" && window.FB && FB.getSession() && !(this.flags & this.WALL_FAVORITES)) {
            var c = {access_token:FB.getSession().access_token};
            c.message = b;
            c.link = "http://grooveshark.com" + a.toUrl().substr(1);
            c.type = "user";
            c.hideUndo = true;
            this.postEvent(c, false, a)
        }
    },postEvent:function(a, b, c) {
        var g = new Date;
        if ((b = true) || !this.lastPost || g.getTime() > this.lastPost + this.RATE_LIMIT) {
            this.lastPost = g.getTime();
            GS.service.makeFacebookRequest("me/links",
                    a, "POST", this.callback("onPostEvent", a, c), this.callback("onFailedPost", this.callback("onFailedPostEvent")))
        } else $.publish("gs.facebook.notification.override", a)
    },onPostEvent:function(a, b, c) {
        $.publish("gs.facebook.notification.sent", {params:a,data:c,notifData:b})
    },onFailedPostEvent:function(a) {
        GS.facebook.lastError = a;
        $.publish("gs.facebook.notification.sent", {params:{type:"error",hideUndo:true},data:{},notifData:{}})
    },removeEvent:function(a) {
        if (window.FB && FB.getSession() && a && a.result) {
            var b = JSON.parse(a.result);
            a = {access_token:FB.getSession().access_token,method:"delete"};
            b = FB.getSession().uid + "_" + b.id;
            GS.service.makeFacebookRequest(b, a, "GET", this.callback("onRemoveEvent"))
        }
    },onRemoveEvent:function(a) {
        $.publish("gs.facebook.notification.removed", a);
        this.lastPost = false
    },getFriends:function(a) {
        if (this.friends)a(this.friends); else this.connectStatus === "connected" && window.FB && FB.getSession() ? FB.api("me/friends", this.callback("onFacebookGetFriends", a)) : a(null)
    },onFacebookGetFriends:function(a, b) {
        if (b.data) {
            var c =
                    [];
            $.each(b.data, function(g, h) {
                c.push(h)
            });
            c.sort(function(g, h) {
                var k = (g.name || "").toLowerCase(),m = (h.name || "").toLowerCase();
                if (k < m)return-1; else if (k > m)return 1;
                return 0
            });
            this.friends = c
        } else if (b.error)this.lastError = b.error;
        a(this.friends)
    },getFacebookDetails:function(a, b) {
        if (a.toUrl) {
            var c = "http://listen.grooveshark.com/" + a.toUrl().replace("#/", "");
            GS.service.makeFacebookRequest("?ids=" + encodeURIComponent(c) + "&limit=100", null, "GET", function(g) {
                try {
                    if (g) {
                        g = JSON.parse(g);
                        _.forEach(g, function(k) {
                            b(k)
                        })
                    } else b({})
                } catch(h) {
                }
            })
        }
    },
    getGroovesharkUsersFromFriends:function() {
        this.getFriends(this.callback(function(a) {
            if (a) {
                var b = [],c = [];
                $.each(a, function(g, h) {
                    if (h && h.id) {
                        b.push(h.id);
                        c[h.id] = h.name
                    }
                });
                GS.service.getGroovesharkUsersFromFacebookUserIDs(b, this.callback("onGetGroovesharkUsers", c))
            }
        }))
    },onGetGroovesharkUsers:function(a, b) {
        var c = [],g = false;
        if (b) {
            $.each(b, function(h, k) {
                if (k && k.UserID && k.FacebookUserID && GS.user.favorites.users && !GS.user.favorites.users[k.UserID]) {
                    k.FacebookName = a[k.FacebookUserID];
                    c.push(k)
                } else if (GS.user.favorites.users &&
                        GS.user.favorites.users[k.UserID])g = true; else k.FacebookUserID || console.error("Missing a FacebookUserID:", k)
            });
            if (c && c.length > 0)GS.lightbox.open("gsUsersFromFacebook", c, a); else g ? $.publish("gs.facebook.notification.findFriends", "NOTIF_FACEBOOK_FINDFRIENDS_ALREADY") : $.publish("gs.facebook.notification.findFriends", "NOTIF_FACEBOOK_FINDFRIENDS_NONE", true)
        }
    }});
GS.Controllers.BaseController.extend("GS.Controllers.LastfmController", {onDocument:true}, {SERVICE_ID:2,API_KEY:"b1ecfd8a5f8ec4dbb4cdacb8f3638f6d",API_SECRET:"f8ed9c4ea2f1b981e61e1d0df1a98406",P_VERSION:"1.2.1",URL_USER_AUTH:"http://www.last.fm/api/auth/",URL_AUDIOSCROBBLER:"http://ws.audioscrobbler.com/2.0/",CLIENT_ID:"gvs",CLIENT_VERSION:"1",MINIMUM_DURATION:240,authToken:null,sessionKey:null,username:null,sessionID:null,flags:0,enabled:false,nowPlaying:null,lastPlayed:null,currentListening:null,
    lastError:null,init:function() {
        this.subscribe("gs.auth.update", this.callback(this.update));
        this.subscribe("gs.auth.favorite.song", this.callback(this.onFavoriteSong));
        this.subscribe("gs.player.nowplaying", this.callback(this.onNowPlaying));
        this.subscribe("gs.player.playing.continue", this.callback(this.onSongPlaying));
        this._super()
    },appReady:function() {
        this.update()
    },update:function() {
        GS.user.isLoggedIn && GS.user.Flags & this.SERVICE_ID && GS.service.getLastfmService(this.callback("onGetService"), this.callback("onGetService"))
    },
    onGetService:function(a) {
        if (a.Session) {
            this.username = a.Username;
            this.sessionKey = a.Session;
            this.authToken = a.Token;
            this.flags = a.Flags;
            this.enabled = Boolean(this.flags)
        }
    },authorize:function() {
        this.sessionKey = null;
        this.getJSON(this.URL_AUDIOSCROBBLER, {method:"auth.getToken",api_key:this.API_KEY}, this.callback("onGetToken"))
    },onGetToken:function(a) {
        if (a && a.token) {
            this.authToken = a.token;
            GS.lightbox.open("lastfmApproval")
        } else $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_FAIL_COMMUNICATE_LASTFM")})
    },
    saveSession:function() {
        this.sessionID || this.getJSON(this.URL_AUDIOSCROBBLER, {api_key:this.API_KEY,method:"auth.getSession",token:this.authToken}, this.callback("onGetSession"))
    },onGetSession:function(a) {
        if (a.session) {
            this.sessionKey = a.session.key;
            this.username = a.session.name;
            GS.service.updateLastfmService(this.sessionKey, this.authToken, this.username, 1, 0, this.callback("onUpdateService"), this.callback("onUpdateService"))
        } else {
            this.lastError = a;
            $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_FAIL_COMMUNICATE_LASTFM")})
        }
    },
    onUpdateService:function(a) {
        if (a && a.success) {
            this.enabled = true;
            $.publish("gs.lastfm.profile.update")
        } else $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_UNABLE_SAVE_LASTFM")})
    },logout:function(a) {
        this.authToken = this.sessionKey = this.username = this.sessionID = null;
        this.enabled = false;
        GS.service.removeLastfmService(a);
        $.publish("gs.lastfm.profile.update")
    },onNowPlaying:function(a) {
        if (!this.currentListening || a.SongID != this.currentListening.songID) {
            this.currentListening = {songID:a.SongID,
                secondsListened:0,scrobbled:false};
            if (this.enabled && a) {
                this.nowPlaying = {track:a.SongName,artist:a.ArtistName,album:a.AlbumName,duration:a.EstimateDuration ? Math.round(a.EstimateDuration / 1E3) : 0,method:"track.updateNowPlaying",sk:this.sessionKey,api_key:this.API_KEY};
                if (a.TrackNum)this.nowPlaying.trackNumber = String(a.TrackNum);
                a = $.extend(true, {api_sig:this.createSignature(this.nowPlaying)}, this.nowPlaying);
                GS.service.lastfmNowPlaying(a, this.callback("onNowPlayingComplete"), this.callback("onNowPlayingFailed"))
            }
        }
    },
    onNowPlayingComplete:function() {
    },onNowPlayingFailed:function(a) {
        this.lastError = a
    },onSongPlaying:function(a) {
        var b = a.activeSong;
        a = Math.round(a.duration / 1E3);
        if (!this.currentListening || b.SongID != this.currentListening.songID)this.currentListening = {songID:b.SongID,secondsListened:0,scrobbled:false}; else this.currentListening.secondsListened += 0.5;
        if (this.enabled && b && a >= 30 && (this.currentListening.secondsListened >= this.MINIMUM_DURATION || this.currentListening.secondsListened >= a / 2) && !this.currentListening.scrobbled) {
            this.lastPlayed =
            {artist:b.ArtistName,track:b.SongName,timestamp:Math.round((new Date).getTime() / 1E3),duration:b.EstimateDuration ? Math.round(b.EstimateDuration / 1E3) : 0,album:b.AlbumName,method:"track.scrobble",sk:this.sessionKey,api_key:this.API_KEY};
            if (b.TrackNum)this.lastPlayed.trackNumber = String(b.TrackNum);
            this.currentListening.scrobbled = true;
            b = $.extend(false, {api_sig:this.createSignature(this.lastPlayed)}, this.lastPlayed);
            GS.service.lastfmSongPlay(b, this.callback("onSongPlayingComplete"), this.callback("onNowPlayingFailed"))
        }
    },
    onSongPlayingComplete:function() {
    },onFavoriteSong:function() {
    },getJSON:function(a, b, c) {
        if (a && b && c) {
            b.api_sig = this.createSignature(b);
            b.format = "json";
            $.ajax({url:a,data:b,success:c,error:c,dataType:"jsonp",cache:true})
        }
    },createSignature:function(a) {
        var b = [];
        _.forEach(a, function(g, h) {
            b.push(h)
        });
        b.sort();
        var c = "";
        _.forEach(b, function(g) {
            c += g + a[g]
        });
        c += this.API_SECRET;
        return c = hex_md5(c)
    }});
GS.Controllers.BaseController.extend("GS.Controllers.GoogleController", {onDocument:true}, {SERVICE_ID:64,GOOGLE_ONLY_SERVICE_ID:32,REQUIRED:"email,firstname,lastname",EXTENSIONS:{"openid.ns.ax":"http://openid.net/srv/ax/1.0","openid.ax.mode":"fetch_request","openid.ax.type.email":"http://axschema.org/contact/email","openid.ax.type.firstname":"http://axschema.org/namePerson/first","openid.ax.type.lastname":"http://axschema.org/namePerson/last","openid.ax.required":"email,firstname,lastname","openid.ui.icon":"true"},
    googleOpener:null,googleOpenerWindow:null,googleOpenerInterval:null,connected:false,registeredWithGoogle:false,email:"",firstname:"",lastname:"",lastError:"",onLoginSaveData:null,loginSuccessCallback:null,loginFailedCallback:null,init:function() {
        this.subscribe("gs.auth.update", this.callback("update"));
        this.googleOpener = googleOpenIDPopup.createPopupOpener({realm:"http://*.grooveshark.com",opEndpoint:"https://www.google.com/accounts/o8/ud",returnToUrl:(window.location.protocol ? window.location.protocol :
                "http:") + "//" + (window.location.hostname ? window.location.hostname : "grooveshark.com") + "/googleCallback.php",shouldEncodeUrls:true,extensions:this.EXTENSIONS});
        if (!window.confirmGoogleConnection)window.confirmGoogleConnection = function(a) {
            if (GS.google.googleOpenerInterval) {
                window.clearInterval(GS.google.googleOpenerInterval);
                GS.google.googleOpenerInterval = null
            }
            this.googleOpenerWindow && this.googleOpenerWindow.close();
            try {
                a = JSON.parse(a)
            } catch(b) {
                this.lastError = "parseError";
                GS.google.loginFailedCallback();
                return
            }
            if (a.mode == "cancel" || a.error == "cancel") {
                this.lastError = "cancel";
                GS.google.onCancelledLogin()
            } else GS.airbridge && GS.airbridge.isDesktop ? window.setTimeout(function() {
                GS.google.onLogin(a)
            }, 300) : GS.google.onLogin(a)
        };
        if (!window.gsGoogleStorageEvent && (window.localStorage || typeof localStorage != "undefined")) {
            window.gsGoogleStorageEvent = function(a) {
                if (!a && window.event)a = window.event;
                if (window.localStorage && typeof b == "undefined")var b = window.localStorage; else if (!window.localStorage)return;
                if (a.key &&
                        a.key == "googleOpenIDData" && a.newVal && a.newVal != "") {
                    window.confirmGoogleConnection(a.newVal);
                    if (b) {
                        if (b.setItem)b.setItem("googleOpenIDData", ""); else b.googleOpenIDData = "";
                        b.removeItem && b.removeItem("googleOpenIDData")
                    }
                } else if (b && b.getItem && b.getItem("googleOpenIDData") && b.getItem("googleOpenIDData") != "" || b.googleOpenIDData && b.googleOpenIDData != "") {
                    a = b.getItem ? "" + b.getItem("googleOpenIDData") : "" + b.googleOpenIDData;
                    if (b.setItem)b.setItem("googleOpenIDData", ""); else b.googleOpenIDData = "";
                    window.confirmGoogleConnection(a);
                    b.removeItem && b.removeItem("googleOpenIDData")
                }
            };
            if (window.addEventListener)window.addEventListener("storage", window.gsGoogleStorageEvent, false); else document.attachEvent && document.attachEvent("onstorage", window.gsGoogleStorageEvent)
        }
        this._super()
    },appReady:function() {
        this.update()
    },update:function() {
        if (GS.user && GS.user.isLoggedIn && (GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.GOOGLE_ONLY_SERVICE_ID)) {
            this.registeredWithGoogle = (GS.user.Flags & this.GOOGLE_ONLY_SERVICE_ID) > 0;
            GS.service.getUserGoogleData(this.callback("onUserGoogleData",
                    null, null))
        } else GS.user && GS.user.isLoggedIn && this.onLoginSaveData && this.onLoginSaveData == GS.user.Email ? GS.service.saveUserGoogleData(this.callback("onSaveUserGoogleData", null, null), function() {
            GS.google.clearInfo()
        }) : this.clearInfo()
    },onUserGoogleData:function(a, b, c) {
        try {
            if (c && c.GoogleEmailAddress) {
                this.email = c.GoogleEmailAddress;
                this.connected = true;
                $.publish("gs.google.profile.update");
                a && a()
            } else if (c && c.GoogleEmailAddress == "")GS.lightbox.open("reAuthGoogle"); else {
                GS.user.Flags = (GS.user.Flags | this.SERVICE_ID) -
                        this.SERVICE_ID;
                if (this.registeredWithGoogle)GS.user.Flags = (GS.user.Flags | this.GOOGLE_ONLY_SERVICE_ID) - this.GOOGLE_ONLY_SERVICE_ID;
                this.clearInfo();
                b && b()
            }
        } catch(g) {
            this.connected = false;
            b && b()
        }
    },gsLogin:function(a, b) {
        GS.user.isLoggedIn ? GS.service.saveUserGoogleData(this.callback("onSaveUserGoogleData", a, b), b) : GS.service.authenticateGoogleUser(this.callback("onAuthGoogleUser", a, b), b)
    },onAuthGoogleUser:function(a, b, c) {
        if (c)if (c.userID == 0)this.register(); else {
            a(c);
            $.publish("gs.google.profile.update")
        } else b &&
        b(c)
    },onSaveUserGoogleData:function(a, b, c) {
        if (c == 1) {
            this.connected = true;
            $.publish("gs.google.profile.update");
            a && a()
        } else if (c == -1)if (GS.user.Flags & this.SERVICE_ID || GS.user.Flags & this.GOOGLE_ONLY_SERVICE_ID)GS.service.getUserGoogleData(this.callback("onUserGoogleData", a, function() {
            b("GOOGLE_PROBLEM_CONNECTING_ERROR_MSG")
        })); else b && b({error:"GOOGLE_DUPLICATE_ACCOUNT_ERROR_MSG"}); else if (c == -2)b && b({error:"GOOGLE_MISSING_LOGIN_INFO_ERROR_MSG"}); else b && b({error:"POPUP_SIGNUP_LOGIN_FORM_GOOGLE_ERROR"})
    },
    register:function() {
        GS.lightbox.close();
        var a = this.email.split("@")[0];
        if (a) {
            a = a.replace(/^[\.\-_]|[^a-zA-Z0-9\.\-_]|[\.\-_]$/g, "");
            a = a.replace(/([\.\-_]){2,}/g, "$1")
        }
        var b = this.firstname + " " + this.lastname,c = Math.floor(Math.random() * 997508) + 1005;
        b || a ? GS.service.getUsernameSuggestions(a, b, c, this.callback("usernameSuggestSuccess"), this.callback("usernameSuggestFailed")) : this.usernameSuggestFailed("")
    },usernameSuggestSuccess:function(a) {
        var b = "";
        if (a && a.length > 0)b = a[0];
        this.openRegisterLightbox(b)
    },
    usernameSuggestFailed:function() {
        this.openRegisterLightbox("")
    },openRegisterLightbox:function(a) {
        a = {isGoogle:true,username:a,email:this.email,fname:this.firstname + " " + this.lastname,message:$.localize.getString("POPUP_SIGNUP_LOGIN_FORM_GOOGLE_NOT_FOUND")};
        GS.user.defaultFromService = a;
        location.hash = "/signup"
    },login:function(a, b) {
        this.googleOpenerWindow = this.googleOpener.popup(450, 400);
        this.loginSuccessCallback = a;
        this.loginFailedCallback = b;
        if (GS.airbridge && GS.airbridge.isDesktop) {
            this.googleOpenerInterval =
                    window.setInterval(this.callback(function() {
                        try {
                            if (this.googleOpenerWindow)if (this.googleOpenerWindow.location && this.googleOpenerWindow.location.host == window.location.host)this.googleOpenerWindow.opener = {confirmGoogleConnection:window.confirmGoogleConnection}
                        } catch(g) {
                        }
                    }), 120);
            var c = function() {
                setTimeout(this.callback(function() {
                    if (this.googleOpenerWindow.location && this.googleOpenerWindow.location.href == "about:blank") {
                        window.clearInterval(this.googleOpenerInterval);
                        this.googleOpenerInterval = null
                    } else this.googleOpenerWindow.onunload =
                            this.callback(c)
                }), 200)
            };
            this.googleOpenerWindow.onunload = this.callback(c)
        }
    },onLogin:function(a) {
        if (a.error) {
            this.lastError = a.error;
            this.loginFailedCallback()
        } else {
            if (a.firstName)this.firstname = a.firstName;
            if (a.lastName)this.lastname = a.lastName;
            if (a.email)this.email = a.email;
            this.gsLogin(this.loginSuccessCallback, this.loginFailedCallback)
        }
    },onCancelledLogin:function() {
    },onLogout:function(a) {
        this.clearInfo();
        $.publish("gs.google.profile.update");
        a && a()
    },clearInfo:function() {
        this.identity = null;
        this.lastname =
                this.firstname = this.email = "";
        this.registeredWithGoogle = this.connected = false;
        this.onLoginSaveData = null
    },logout:function(a) {
        GS.service.removeUserGoogleData(this.callback("onLogout", a))
    }});
GS.Controllers.BaseController.extend("GS.Controllers.ApiController", {onDocument:true}, {_songStatusCallback:"",_statusLookup:{0:"none",1:"loading",2:"loading",3:"playing",4:"paused",5:"buffering",6:"failed",7:"completed"},_protocolActions:["play","add","next"],_lastStatus:null,init:function() {
    this.subscribe("gs.player.playstatus", this.callback(this._doStatusCallback));
    this.subscribe("gs.player.song.change", this.callback(this._onSongChange));
    this._super()
},getApplicationVersion:function() {
    return gsConfig.revision
},
    getAPIVersion:function() {
        return 1.5
    },executeProtocol:function(a) {
        var b = a.toLowerCase();
        if (b.indexOf("gs://") != -1) {
            a = a.substring(5);
            b = b.substring(5)
        }
        if (a.charAt(a.length - 1) == "/") {
            a = a.substring(0, a.length - 1);
            b = b.substring(0, b.length - 1)
        }
        b = b.split("/");
        var c = b.pop();
        if (this._protocolActions.indexOf(c) == -1) {
            b.push(c);
            c = ""
        }
        if (b[0] == "themes")GS.lightbox.open("themes"); else {
            if (c) {
                a = a.substring(0, a.length - c.length - 1);
                var g = GS.player.INDEX_DEFAULT,h = false;
                switch (c) {
                    case "play":
                        h = true;
                        break;
                    case "next":
                        g = GS.player.INDEX_NEXT;
                        break
                }
                if (GS.player)switch (b[0]) {
                    case "s":
                        GS.Models.Song.getSong(b[2], this.callback(function(k) {
                            GS.player.addSongsToQueueAt(k.SongID, g, h)
                        }), null, false);
                        break;
                    case "song":
                        GS.Models.Song.getSongFromToken(b[2], this.callback(function(k) {
                            GS.player.addSongsToQueueAt(k.SongID, g, h)
                        }), null, false);
                        break;
                    case "album":
                        GS.Models.Album.getAlbum(b[2], this.callback(function(k) {
                            k.play(g, h)
                        }), null, false);
                        break;
                    case "playlist":
                        GS.Models.Playlist.getPlaylist(b[2], this.callback(function(k) {
                            k.play(g, h)
                        }), null, false);
                        break
                }
            }
            if (b[0] ==
                    "search") {
                b = b[b.length - 1];
                a = a.substring(0, a.length - b.length);
                a += "?q=" + b
            }
            location.hash = "/" + a
        }
    },getCurrentSongStatus:function() {
        return this._buildCurrentPlayStatus()
    },setSongStatusCallback:function(a) {
        if ($.isFunction(a))this._songStatusCallback = a; else if (_.isString(a)) {
            a = a.split(".");
            a = this._getObjectChain(window, a);
            if ($.isFunction(a))this._songStatusCallback = a
        }
        return this._buildCurrentPlayStatus()
    },_getObjectChain:function(a, b) {
        var c = b.shift();
        return(c = a[c]) ? b.length ? this._getObjectChain(c, b) : c : null
    },
    _doStatusCallback:function(a) {
        if (a && this._lastStatus)if (a.status === this._lastStatus.status)if (!a.activeSong && !this._lastStatus.activeSong) {
            this._lastStatus = a;
            return
        } else if (a.activeSong && this._lastStatus.activeSong)if (a.activeSong.SongID === this._lastStatus.activeSong.SongID && a.activeSong.autoplayVote === this._lastStatus.activeSong.autoplayVote) {
            this._lastStatus = a;
            return
        }
        this._lastStatus = a;
        $.isFunction(this._songStatusCallback) && this._songStatusCallback(this._buildCurrentPlayStatus())
    },_onSongChange:function(a) {
        if (!this._lastStatus ||
                this._lastStatus.activeSong && this._lastStatus.activeSong.SongID === a.SongID && this._lastStatus.activeSong.autoplayVote !== a.autoplayVote) {
            if (this._lastStatus)this._lastStatus.activeSong.autoplayVote = a.autoplayVote;
            $.isFunction(this._songStatusCallback) && this._songStatusCallback(this._buildCurrentPlayStatus())
        }
    },_buildCurrentPlayStatus:function() {
        var a = {song:null,status:"none"};
        if (GS.player) {
            var b = GS.player.getPlaybackStatus();
            if (b)if (b.activeSong) {
                var c = GS.Models.Song.getOneFromCache(b.activeSong.SongID);
                a.song = {songID:b.activeSong.SongID,songName:b.activeSong.SongName.replace(/&amp\;/g, "&"),artistID:b.activeSong.ArtistID,artistName:b.activeSong.ArtistName.replace(/&amp\;/g, "&"),albumID:b.activeSong.AlbumID,albumName:b.activeSong.AlbumName.replace(/&amp\;/g, "&"),trackNum:c ? c.TrackNum : 0,estimateDuration:b.activeSong.EstimateDuration,artURL:c ? c.getImageURL() : gsConfig.assetHost + "/webincludes/images/default/album_250.png",calculatedDuration:b.duration,position:b.position,vote:b.activeSong.autoplayVote};
                a.status = this._statusLookup[b.status]
            }
        }
        return a
    },getPreviousSong:function() {
        var a = null;
        if (GS.player && GS.player.queue && GS.player.queue.previousSong) {
            a = GS.player.queue.previousSong;
            var b = GS.Models.Song.getOneFromCache(a.SongID);
            a = {songID:a.SongID,songName:a.SongName.replace(/&amp\;/g, "&"),artistID:a.ArtistID,artistName:a.ArtistName.replace(/&amp\;/g, "&"),albumID:a.AlbumID,albumName:a.AlbumName.replace(/&amp\;/g, "&"),trackNum:b ? b.TrackNum : 0,estimateDuration:a.EstimateDuration,artURL:b ? b.getImageURL() :
                    gsConfig.assetHost + "/webincludes/images/default/album_250.png",vote:a.autoplayVote}
        }
        return a
    },getNextSong:function() {
        var a = null;
        if (GS.player && GS.player.queue && GS.player.queue.nextSong) {
            a = GS.player.queue.nextSong;
            var b = GS.Models.Song.getOneFromCache(a.SongID);
            a = {songID:a.SongID,songName:a.SongName.replace(/&amp\;/g, "&"),artistID:a.ArtistID,artistName:a.ArtistName.replace(/&amp\;/g, "&"),albumID:a.AlbumID,albumName:a.AlbumName.replace(/&amp\;/g, "&"),trackNum:b ? b.TrackNum : 0,estimateDuration:a.EstimateDuration,
                artURL:b ? b.getImageURL() : gsConfig.assetHost + "/webincludes/images/default/album_250.png",vote:a.autoplayVote}
        }
        return a
    },addSongsByID:function(a, b) {
        GS.player && GS.player.addSongsToQueueAt(a, GS.player.INDEX_DEFAULT, b)
    },addSongByToken:function(a, b) {
        GS.player && GS.Models.Song.getSongFromToken(a, this.callback(function(c) {
            GS.player.addSongsToQueueAt([c.SongID], GS.player.INDEX_DEFAULT, b)
        }), null, false)
    },addAlbumByID:function(a, b) {
        GS.player && GS.Models.Album.getAlbum(a, this.callback(function(c) {
            c.play(GS.player.INDEX_DEFAULT,
                    b)
        }), null, false)
    },addPlaylistByID:function(a, b) {
        GS.player && GS.Models.Playlist.getPlaylist(a, this.callback(function(c) {
            c.play(GS.player.INDEX_DEFAULT, b)
        }), null, false)
    },play:function() {
        if (GS.player && GS.player.queue && GS.player.queue.activeSong)GS.player.isPaused ? GS.player.resumeSong() : GS.player.playSong(GS.player.queue.activeSong.queueSongID)
    },pause:function() {
        GS.player && GS.player.pauseSong()
    },seekToPosition:function(a) {
        GS.player && GS.player.seekTo(a)
    },togglePlayPause:function() {
        if (GS.player)GS.player.isPaused ?
                GS.player.resumeSong() : GS.player.pauseSong()
    },previous:function() {
        GS.player && GS.player.previousSong()
    },next:function() {
        GS.player && GS.player.nextSong()
    },setVolume:function(a) {
        GS.player && GS.player.setVolume(a)
    },getVolume:function() {
        if (GS.player)return GS.player.getVolume();
        return 0
    },setIsMuted:function(a) {
        GS.player && GS.player.setIsMuted(a)
    },getIsMuted:function() {
        if (GS.player)return GS.player.getIsMuted();
        return false
    },voteCurrentSong:function(a) {
        GS.player && GS.player.queue && GS.player.queue.activeSong &&
        GS.player.voteSong(GS.player.queue.activeSong.queueSongID, a)
    },getVoteForCurrentSong:function() {
        if (GS.player && GS.player.queue && GS.player.queue.activeSong)return GS.player.queue.activeSong.autoplayVote
    },favoriteCurrentSong:function() {
        GS.player && GS.player.queue && GS.player.queue.activeSong && GS.user.addToSongFavorites(GS.player.queue.activeSong.SongID)
    },addCurrentSongToLibrary:function() {
        GS.player && GS.player.queue && GS.player.queue.activeSong && GS.user.addToLibrary([GS.player.queue.activeSong.SongID])
    },
    removeCurrentSongFromQueue:function() {
        GS.player && GS.player.queue && GS.player.queue.activeSong && GS.player.removeSongs([GS.player.queue.activeSong.queueSongID])
    }});
(function() {
    GS.Controllers.BaseController.extend("GS.Controllers.PageController", {activePage:null,activePageName:null,activePageIdentifier:null,_element:null,activate:function(a, b) {
        if (!this._element)this._element = $("#page");
        if (this.activePageName === a && this.activePageIdentifier === b)return this.activePage;
        var c = GS.Controllers.Page,g = a;
        g = g.replace(/\_/g, " ");
        g = _.ucwords(g);
        g = g.replace(/\s/g, "");
        c = c[g + "Controller"];
        if (_.defined(c)) {
            this.activePage && this.activePage.destroy();
            this.activePage = new c(this._element);
            this.activePageName = a;
            this.activePageIdentifier = b;
            if (a === "home") {
                $("#theme_home *").show();
                $("#theme_page_header").hide()
            } else if (a === "signup") {
                $("#theme_home *").hide();
                $("#theme_page_header").hide()
            } else {
                $("#theme_home *").hide();
                GS.theme.currentTheme && GS.theme.currentTheme.pageTracking ? $("#theme_page_header.active").show() : $("#theme_page_header").hide();
                $("ul.ui-autocomplete").remove();
                $.publish("gs.page.page.view", a)
            }
            $("#theme_page_header_expandable").height(0);
            $.publish("gs.page.view", a);
            return this.activePage
        }
    },
        setFromSidebar:function(a) {
            this.fromSidebar = a
        },isFromSidebar:function() {
            if (this.fromSidebar === 2)return true; else return this.fromSidebar = false
        },titlePrepend:"Grooveshark - ",titlePostpend:" - Grooveshark",title:function(a, b) {
            b = typeof b === "undefined" ? true : b;
            document.title = b ? a + this.titlePostpend : this.titlePrepend + a
        },ALLOW_LOAD:true,justDidConfirm:false,lastPage:"",confirmMessage:$.localize.getString("ONCLOSE_PAGE_CHANGES"),checkLock:function() {
            if (GS.Controllers.PageController.justDidConfirm || !GS.Controllers.PageController.ALLOW_LOAD &&
                    !confirm($.localize.getString("ONCLOSE_SAVE_PLAYLIST"))) {
                GS.Controllers.PageController.justDidConfirm = true;
                location.replace([location.protocol,"//",location.host,location.pathname,GS.Controllers.PageController.lastPage].join(""));
                setTimeout(function() {
                    GS.Controllers.PageController.justDidConfirm = false
                }, 500);
                return false
            } else {
                GS.Controllers.PageController.justDidConfirm = false;
                GS.Controllers.PageController.ALLOW_LOAD = true;
                GS.Controllers.PageController.lastPage = location.hash;
                GS.Controllers.PageController.confirmMessage =
                        $.localize.getString("ONCLOSE_PAGE_CHANGES");
                $.publish("gs.router.before");
                return true
            }
        },getActiveController:function() {
            return this.activePage
        },fromSidebar:0,fromCorrectUrl:false}, {url:false,type:false,id:false,subpage:false,fromSidebar:false,pageSearchHasFocus:false,slickbox:null,header:{name:false,breadcrumbs:[],imageUrl:false,subpages:[],options:[],labels:[]},list:{doPlayAddSelect:false,doSearchInPage:false,sortOptions:[],gridOptions:{data:[],columns:{},options:{}}},cache:{},init:function() {
        this.subscribe("gs.page.loading.page",
                this.callback("showPageLoading"));
        this.subscribe("gs.page.loading.grid", this.callback("showGridLoading"));
        this.subscribe("gs.grid.selectedRows", this.callback("changeSelectionCount"));
        this.subscribe("gs.router.before", this.callback("handleFromSidebar"));
        this.subscribe("gs.grid.onsort", this.callback("gridOnSort"));
        this._super()
    },destroy:function() {
        this.searchTimeout && clearTimeout(this.searchTimeout);
        this._super()
    },lastView:null,resizeTimer:null,view:function(a, b, c, g) {
        if (this.lastView !== a && GS.resize) {
            clearTimeout(this.resizeTimer);
            this.resizeTimer = setTimeout(function() {
                GS.resize()
            }, 50)
        }
        this.lastView = a;
        return this._super(a, b, c, g)
    },index:function() {
        this.url = location.hash;
        this.element.html(this.view("index"))
    },notFound:function() {
        GS.Controllers.PageController.activate("home", null).notFound()
    },showPageLoading:function() {
        this.element.html(this.view("/shared/pageLoading"));
        var a = this.element.find(".page_loading");
        a.css("marginLeft", a.width() / 2 * -1 + "px")
    },showGridLoading:function() {
        $("#grid").html(this.view("/shared/loadingIndicator"));
        var a = this.element.find(".page_loading");
        a.css("marginLeft", a.width() / 2 * -1 + "px")
    },changeSelectionCount:function(a) {
        if (a.type === "album" || a.type === "artist")$("input.search", this.element).val("").trigger("keyup");
        if (a.type === "song") {
            var b = _.isNumber(a.len) && a.len > 0 ? a.len : 0;
            if (b) {
                $('#page_header .play.count span[class="label"]').localeDataString("SELECTION_PLAY_COUNT", {count:b});
                $('#page_header .addSongs.count span[class="label"]').localeDataString("SELECTION_ADD_COUNT", {count:b});
                $('#page_header .deleteSongs.count span[class="label"]').localeDataString("SELECTION_DELETE_COUNT",
                        {count:b})
            } else {
                $('#page_header .play.count span[class="label"]').localeDataString("SELECTION_PLAY_ALL");
                $('#page_header .addSongs.count span[class="label"]').localeDataString("SELECTION_ADD_ALL");
                $('#page_header .deleteSongs.count span[class="label"]').localeDataString("SELECTION_DELETE_ALL")
            }
            $("#page_header .music_options").toggleClass("hide", b === 0);
            var c = $("#page").attr("class").split("_")[2];
            c = a.len > 0 ? "song" : c;
            $("#page_header a[name=share]").parent().hide();
            var g = GS.Controllers.Lightbox.ShareController.allowed[c];
            if (g) {
                $("#page_header button.share").parent().show();
                $.each(g, function(h, k) {
                    $("#page_header a[name=share][rel=" + k + "]").show().parent().show().removeClass("hide")
                })
            } else $("#page_header button.share").parent().hide();
            if (c === "song")b > 1 ? $('#page_header .share span[class="label"]').localeDataString("SHARE_SONGS") : $('#page_header .share span[class="label"]').localeDataString("SHARE_SONG"); else $('#page_header .share span[class="label"]').localeDataString("SHARE_" + c.toUpperCase());
            if (a.len != 1)c === "playlist" ?
                    $("#page_header li.shareOptions").show() : $("#page_header li.shareOptions .share_single").hide(); else {
                $("#page_header li.shareOptions").show();
                $("#page_header li.shareOptions share_single").show()
            }
            a.len <= 0 ? $("#page_header button.deleteSongs").parent().hide() : $("#page_header button.deleteSongs").parent().show();
            if ($("#page").attr("class") == "gs_page_now_playing")a.len <= 0 ? $("#page_header button.delete").hide() : $("#page_header button.delete").show()
        }
    },"a.fromSidebar click":function(a, b) {
        b.stopImmediatePropagation();
        GS.page.setFromSidebar(1);
        location.hash = a.attr("href");
        return false
    },handleFromSidebar:function() {
        if (GS.page.fromCorrectUrl === true)GS.page.fromCorrectUrl = false; else if (GS.page.fromSidebar === 1)GS.page.fromSidebar = 2; else if (GS.page.fromSidebar === 2)GS.page.fromSidebar = 0
    },correctUrl:function(a, b) {
        if (a) {
            var c = function() {
                if ($.isFunction(a.toUrl)) {
                    var g = a.toUrl(b);
                    if (location.hash !== g)if (location.hash.replace(/src=\d/, "") !== g.replace(/src=\d/, "")) {
                        GS.page.fromCorrectUrl = true;
                        location.replace(g)
                    }
                }
            };
            $.isFunction(a.getPathName) ?
                    a.getPathName(c) : c()
        } else console.warn("invalid page.correctUrl obj", a, b)
    },gridOnSort:function(a) {
        a && a.sortStoreKey && store.set(a.sortStoreKey, a)
    },getPlayContext:function() {
        var a;
        switch (this.type) {
            case "playlist":
                if (this.hasOwnProperty("playlist") && this.playlist instanceof GS.Models.Playlist)a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_PLAYLIST, this.playlist);
                break;
            case "artist":
                if (this.hasOwnProperty("artist") && this.playlist instanceof GS.Models.Artist)a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ARTIST,
                        this.artist);
                break;
            case "album":
                if (this.hasOwnProperty("album") && this.playlist instanceof GS.Models.Album)a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_ALBUM, this.album);
                break;
            case "user":
                if (this.hasOwnProperty("user") && this.playlist instanceof GS.Models.User)a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_USER, this.user);
                break;
            case "popular":
                a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_POPULAR);
                break;
            default:
                if (this.hasOwnProperty("query"))a = new GS.Models.PlayContext(GS.player.PLAY_CONTEXT_SEARCH,
                        {query:this.query,type:this.type ? this.type : "everything"});
                break
        }
        return _.orEqual(a, new GS.Models.PlayContext)
    },"input focus":function(a) {
        $(a).parent().parent().addClass("active")
    },"textarea focus":function(a) {
        $(a).parent().parent().parent().addClass("active")
    },"input blur":function(a) {
        $(a).parent().parent().removeClass("active")
    },"textarea blur":function(a) {
        $(a).parent().parent().parent().removeClass("active")
    },"#page_header .play.playTop click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.Controllers.PlayerController.INDEX_DEFAULT, true, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "play")
    },"#page_header .upload click":function() {
        window.open("http://grooveshark.com/upload", "_blank")
    },"#page .dropdownButton click":function(a, b) {
        b.stopImmediatePropagation();
        var c = $(a).closest(".btn_group");
        if (c.find(".dropdown").is(":visible"))$("#page .btn_group").removeClass("active"); else {
            $("#page .btn_group").removeClass("active");
            c.addClass("active");
            $("body").click(function() {
                $("#page .btn_group").removeClass("active")
            })
        }
    },"#page_header .dropdownOptions a[name=sort] click":function(a) {
        var b = $("#grid").controller();
        if (b)b.grid.onSort(a.attr("rel")); else this.slickbox && this.renderUsers(this.originalUsers, a.attr("rel"));
        b = a.find("span");
        a.parent().parent().parent().parent().find(".dropdownButton span.label").html(b.html()).attr("rel", b.attr("rel"))
    },"#page_header .dropdownOptions a[name=playNow] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.player.INDEX_DEFAULT, true, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "play")
    },"#page_header .dropdownOptions a[name=playNext] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.player.INDEX_NEXT, false, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "play")
    },"#page_header .dropdownOptions a[name=playLast] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.player.INDEX_LAST, false, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "play")
    },"#page_header .dropdownOptions a[name=replace] click":function() {
        GS.player.clearQueue();
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.player.INDEX_REPLACE, true, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "play")
    },"#page_header .dropdownOptions a[name=addToQueue] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        a.length && GS.player.addSongsToQueueAt(a, GS.player.INDEX_LAST, false, this.getPlayContext());
        GS.guts.objectListPlayAdd(a, this.element, "add")
    },"#page_header .dropdownOptions a[name=addToPlaylist] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        if (a.length) {
            GS.lightbox.open("addSongsToPlaylist", a);
            GS.guts.objectListPlayAdd(a, this.element, "add")
        }
    },"#page_header .dropdownOptions a[name=addToNewPlaylist] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        if (a.length) {
            GS.lightbox.open("newPlaylist",
                    a);
            GS.guts.objectListPlayAdd(a, this.element, "add")
        }
    },"#page_header .dropdownOptions a[name=addToLibrary] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        if (a.length) {
            GS.user.addToLibrary(a);
            GS.guts.objectListPlayAdd(a, this.element, "add")
        }
    },"#page_header .dropdownOptions a[name=addToFavorites] click":function() {
        var a = this.getSongsIDsFromSelectedGridRows();
        if (a.length == 1) {
            GS.user.addToSongFavorites(a[0], true);
            GS.guts.objectListPlayAdd(a, this.element, "add")
        }
    },getSongsIDsFromSelectedGridRows:function() {
        var a =
                $("#grid").controller(),b = [];
        if (a && a.selectedRowIDs.length > 0)b = a.selectedRowIDs; else if (a)for (var c = 0; c < a.dataView.rows.length; c++) {
            if (b.length >= 1E3)break;
            b.push(a.dataView.rows[c].SongID)
        } else this.type === "song" && this.song && b.push(this.song.SongID);
        return b
    },"#page_header .dropdownOptions a[name=share] click":function(a) {
        var b = this.element.find(".gs_grid:last").controller();
        if (!b || b.selectedRowIDs.length === 0)GS.lightbox.open("share", {service:a.attr("rel"),type:this.type,id:this.id}); else if (b.selectedRowIDs.length ===
                1) {
            GS.lightbox.open("share", {service:a.attr("rel"),type:"song",id:this.getSongsIDsFromSelectedGridRows()[0]});
            a = parseInt($("#grid .slick-row.selected").attr("row"), 10) + 1;
            GS.guts.logEvent("OLShare", {songIDs:this.getSongsIDsFromSelectedGridRows()[0],ranks:a})
        } else b.selectedRowIDs.length > 1 && GS.lightbox.open("share", {service:a.attr("rel"),type:"manySongs",id:this.getSongsIDsFromSelectedGridRows()})
    },"#page_search input keydown":function(a, b) {
        var c = $("#page_search_results li.selected");
        switch (b.which) {
            case _.keys.ENTER:
                $("#page_search").submit();
                return;
            case _.keys.ESC:
                $("#page_search_results").hide();
                $("#page_search a.remove").addClass("hide");
                $(a).val("");
                this.inpageSearch();
                return;
            case _.keys.UP:
                c.is(":first-child") ? $("#page_search_results li:last").addClass("selected") : c.prev().addClass("selected");
                c.removeClass("selected");
                return;
            case _.keys.DOWN:
                c.is(":last-child") ? $("#page_search_results li:first").addClass("selected") : c.next().addClass("selected");
                c.removeClass("selected");
                return
        }
        $("#page_search a.remove").toggleClass("hide", !$(a).val().length);
        this.inpageSearch()
    },searchTimeout:false,searchTimeoutWait:100,inpageSearch:function() {
        var a = $("#page_search input");
        clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(this.callback(function() {
            if (this.element) {
                var b = this.element.find(".gs_grid:last").controller(),c = $.trim($(a).val().toLowerCase());
                if (b) {
                    var g = c;
                    if ($("#page").is(".gs_page_search") && _.isString(this.query))if (c.indexOf(this.query.toLowerCase()) === 0)g = c.substring(this.query.length);
                    b.searchString = $.trim(g);
                    b.dataView.refresh()
                } else if ($("#feed.events").length)if (c ==
                        "")$("#feed.events .event").show(); else {
                    (new Date).getTime();
                    $("#feed.events .event").each(function() {
                        var h = $(this);
                        h.text().toLowerCase().indexOf(c) !== -1 ? h.show() : h.hide()
                    });
                    (new Date).getTime()
                } else this.slickbox && this.filterUsers(c);
                c.length > 0 ? GS.service.getArtistAutocomplete(c, this.callback("autocompleteSuccess"), this.callback("autocompleteFail")) : $("#page_search_results").hide()
            }
        }), this.searchTimeoutWait)
    },"#page_search input focus":function() {
        this.pageSearchHasFocus = true
    },"#page_search input blur":function() {
        setTimeout(this.callback(function() {
            this.pageSearchHasFocus ||
            $("#page_search_results").hide()
        }), 500);
        this.pageSearchHasFocus = false
    },"#page_search .search-item a click":function(a) {
        $("#page_search_results li.selected").removeClass("selected");
        $(a).parent().addClass("selected");
        $(a).is(".search-item") && $("#page_search input").val($(a).text());
        $("#page_search").submit()
    },"#page_search a.icon click":function() {
        $("#page_search input").focus().select()
    },"#page_search a.remove click":function(a) {
        $(a).addClass("hide");
        $("#page_search_results").hide();
        $("#page_search input").val("").focus();
        this.inpageSearch()
    },"#page_search submit":function(a, b) {
        b.preventDefault();
        GS.search = _.orEqual(GS.search, {});
        GS.search.type = $(a).attr("data-search-type") || "";
        var c = $("#page_search_results li.selected");
        GS.search.query = c.is(".search-item-result") ? c.find("a").text() : $("input[name=q]", a).val();
        if (GS.search.query && GS.search.query.length) {
            this.pageSearchHasFocus = false;
            GS.router.performSearch(GS.search.type, GS.search.query)
        }
    },autocompleteSuccess:function(a) {
        this.autocompleteResults = a;
        $("#page_search_results").html(this.view("/shared/pageSearchResults"));
        this.pageSearchHasFocus && $("#page_search_results").show()
    },autocompleteFail:function() {
        $("#page_search_results").remove(".search_result").hide()
    },addAutocomplete:function(a) {
        a = _.orEqual(a, $("#page").attr("class"));
        a.match(".gs_page_") || (a = ".gs_page_" + a);
        $("input.search.autocomplete", this.element).autocomplete({scroll:true,matchSubset:false,selectFirst:false,source:function(b, c) {
            if (b = $.trim(b.term || b)) {
                var g = [];
                GS.service.getArtistAutocomplete(b, function(h) {
                    if ($("#page").is(a)) {
                        h.Artists && $.each(h.Artists,
                                function(k, m) {
                                    g.push(m.Name)
                                });
                        c(g)
                    }
                }, function() {
                })
            }
        },select:function(b, c) {
            $("#searchBar_input input").val(c.item.value);
            $("#homeSearch").submit()
        }})
    },"#feed.events button[name=play] click":function(a) {
        $(a).closest(".event").data("event").playSongs(-1, true)
    },"#feed.events .event a[name=play] click":function(a) {
        var b = $(a).closest(".event").data("event");
        a = _.defined($(a).attr("rel")) ? parseInt($(a).attr("rel"), 10) : -1;
        b.playSongs(a, a == -1 || a == -4 ? true : false)
    },"#feed.events .event .songLink click":function(a) {
        var b =
                $(a).closest(".event");
        b = $(b).data("event");
        b = GS.Models.Song.wrapCollection(b.data.songs);
        a = _.defined($(a).attr("data-song-index")) ? parseInt($(a).attr("data-song-index"), 10) : 0;
        if (b.length > 0)if (a = (a = b[a]) && $.isFunction(a.toUrl) ? a.toUrl() : false)location.hash = a;
        return false
    },"#feed.events .event button.subscribe click":function(a) {
        var b = $(a).closest(".event").data("event");
        GS.Models.Playlist.getPlaylist(b.data.playlist.playlistID, this.callback("subscribePlaylist", a), this.callback("subscribePlaylistError"),
                false)
    },subscribePlaylist:function(a, b) {
        if (b.isSubscribed()) {
            GS.user.removeFromPlaylistFavorites(b.PlaylistID);
            a.find("span").localeDataString("PLAYLIST_SUBSCRIBE")
        } else {
            GS.user.addToPlaylistFavorites(b.PlaylistID);
            a.find("span").localeDataString("PLAYLIST_UNSUBSCRIBE")
        }
    },subscribePlaylistError:function() {
        $.publish("gs.notification", {type:"error",message:$.localize.getString("NOTIF_FAVORITE_ERROR_GENERAL")})
    },"#feed.events .event .showSongs click":function(a) {
        a = $(a).closest(".event");
        var b = $(a).data("event"),
                c = $(a).find(".songWrapper"),g = $(a).find(".songList");
        if (g.children().length)c.toggle(); else {
            var h = GS.Models.Song.wrapCollection(b.data.songs);
            c.css("visibility", "hidden").show();
            oldCols = GS.Controllers.GridController.columns.song.concat();
            b = [oldCols[0],oldCols[1],oldCols[2]];
            g.gs_grid(h, b, {sortCol:"Sort",padding:0});
            $(window).resize();
            c.css("visibility", "visible")
        }
        c = g.is(":visible") ? $.localize.getString("FEED_HIDE_SONGS") : $.localize.getString("FEED_VIEW_SONGS");
        $(a).find("button.showSongs .label").text(c)
    },
        "#feed.events .event .feedControl click":function(a) {
            var b = $(a).closest(".event"),c = $(b).data("event");
            switch ($(a).attr("rel")) {
                case "remove":
                    b.remove();
                    c.remove();
                    break
            }
        },".slick-row .song .options .favorite click":function(a) {
            var b = a.parent().attr("rel"),c = parseInt($(a).parents(".slick-row").attr("row")),g = c + 1,h = "";
            if ($("#grid").controller())h = $("#grid").controller().data[c].ppVersion;
            c = {songID:b,rank:g};
            if (h)c.ppVersion = h;
            if (a.is(".isFavorite")) {
                GS.user.removeFromSongFavorites(b);
                a.removeClass("isFavorite")
            } else {
                GS.user.addToSongFavorites(b);
                a.addClass("isFavorite");
                GS.guts.songItemFavoriteClick(c)
            }
        },".slick-row .song .options .library click":function(a) {
            var b = a.parent().attr("rel"),c = parseInt($(a).parents(".slick-row").attr("row")),g = c + 1,h = "";
            if ($("#grid").controller())h = $("#grid").controller().data[c].ppVersion;
            c = {songID:b,rank:g};
            if (h)c.ppVersion = h;
            if (a.parent().is(".inLibrary")) {
                GS.user.removeFromLibrary(b);
                a.parent().removeClass("inLibrary")
            } else {
                GS.user.addToLibrary(b);
                a.parent().addClass("inLibrary");
                GS.guts.songItemLibraryClick(c)
            }
        },
        ".slick-row .playlist .subscribe click":function(a) {
            var b = a.attr("rel");
            if (GS.Models.Playlist.getOneFromCache(b).isSubscribed()) {
                GS.user.removeFromPlaylistFavorites(b);
                a.removeClass("subscribed").find("span").text($.localize.getString("PLAYLIST_SUBSCRIBE"))
            } else {
                GS.user.addToPlaylistFavorites(b);
                a.addClass("subscribed").find("span").text($.localize.getString("PLAYLIST_UNSUBSCRIBE"))
            }
        },".slick-cell.song a.more click":function(a, b) {
            var c = $(a).attr("rel"),g = GS.Models.Song.getOneFromCache(c),h = $(a).parents(".slick-row").attr("row"),
                    k = $(a).parents(".gs_grid").controller(),m = {},n;
            rank = parseInt(h) + 1;
            var o = parseInt(h, 10);
            if ($("#page").is(".gs_page_now_playing")) {
                n = g.queueSongID;
                m = {isQueue:true,flagSongCallback:function(r) {
                    GS.player.flagSong(n, r)
                }}
            }
            if ($("div.gridrow" + h).is(":visible")) {
                $("div.gridrow" + h).hide();
                a.removeClass("active-context")
            } else {
                $(a).jjmenu(b, g.getContextMenu(m), null, {xposition:"left",yposition:"auto",show:"show",className:"rowmenu gridrow" + h});
                g = k.data[o].ppVersion;
                c = {songID:c,rank:rank};
                if (g)c.ppVersion = g;
                GS.guts.logEvent("songOptionMenuClicked",
                        c)
            }
            k.currentRow = h;
            k.grid.setSelectedRows([h]);
            k.grid.onSelectedRowsChanged()
        },playClickSongID:false,".slick-cell.song a.play click":function(a, b) {
            var c = parseInt(a.attr("rel"), 10),g = GS.player.getCurrentQueue(),h = GS.player.isPlaying;
            isPaused = GS.player.isPaused;
            if (this.playClickSongID != c) {
                this.playClickSongID = c;
                row = $(a).parents(".slick-row").attr("row");
                rank = parseInt(row) + 1;
                this.playClickSongID = c;
                row = parseInt($(a).parents(".slick-row").attr("row"), 10);
                rank = row + 1;
                var k = "";
                if ($("#grid").controller())k =
                        $("#grid").controller().data[rank - 1].ppVersion;
                gutsInfo = k ? {songID:c,rank:rank,ppVersion:k} : {songID:c,rank:rank};
                row = $(a).parents(".slick-row").attr("row");
                rank = parseInt(row) + 1;
                if (a.parents(".slick-row.active").length && g.activeSong.SongID == c)if (!h && !isPaused) {
                    $(a).removeClass("paused");
                    GS.player.playSong(c)
                } else if (h) {
                    $(a).addClass("paused");
                    GS.player.pauseSong()
                } else {
                    $(a).removeClass("paused");
                    GS.player.resumeSong()
                } else if ($("#page").is(".gs_page_now_playing")) {
                    b.stopImmediatePropagation();
                    GS.player.playSong($(a).parents(".slick-row").attr("rel"))
                } else if ($(a).parents(".gs_grid.hasSongs").length) {
                    GS.player.addSongsToQueueAt([c],
                            GS.player.INDEX_DEFAULT, false, this.getPlayContext());
                    GS.guts.logEvent("songItemAddButton", gutsInfo)
                } else {
                    GS.player.addSongAndPlay(c, this.getPlayContext());
                    GS.guts.logEvent("songItemPlayButton", gutsInfo)
                }
                setTimeout(this.callback(function() {
                    this.playClickSongID = false
                }), 500);
                return false
            }
        },".slick-row.event click":function(a, b) {
            var c = a.attr("row");
            c = $("#grid").controller().dataView.getItemByIdx(c);
            if (!$(b.target).is("a[href]") && c && c.TicketsURL) {
                window.open(c.TicketsURL, "_blank");
                GS.guts.gaTrackEvent("grid",
                        "eventClick", c.TicketsURL);
                return false
            }
        },"#searchForm, #homeSearch submit":function(a, b) {
            b.preventDefault();
            var c = $("input[name=q]", a).val();
            if (c.substring(0, 2).toLowerCase() == "gs")switch (c.toLowerCase()) {
                case "gs.google.lasterror":
                    alert(JSON.stringify(GS.google.lastError));
                    return false;
                case "gs.facebook.lasterror":
                    alert(JSON.stringify(GS.facebook.lastError));
                    return false;
                case "gs.lastfm.lasterror":
                    alert(JSON.stringify(GS.lastfm.lastError));
                    return false
            }
            GS.search = _.orEqual(GS.search, {});
            GS.search.query =
                    c;
            GS.search.type = $(a).attr("data-search-type") || "";
            GS.search.query && GS.search.query.length && GS.router.performSearch(GS.search.type, GS.search.query);
            return false
        },"a.searchLink click":function(a) {
            var b = a.data("searchtype");
            a = a.data("searchquery");
            b = b ? b : "";
            a = a ? a : "";
            GS.router.performSearch(b, a);
            return false
        },"#feed .what>a click":function(a, b) {
            GS.guts.handleFeedEventClick(a, b)
        },"#feed li.option click":function(a, b) {
            GS.guts.handleFeedEventClick(a, b)
        },"#feed li.show click":function(a, b) {
            GS.guts.handleFeedEventClick(a,
                    b)
        },"#searchArtists a click":function(a, b) {
            GS.guts.handleSearchSidebarClick(a, b, "artist")
        },"#searchAlbums a click":function(a, b) {
            GS.guts.handleSearchSidebarClick(a, b, "album")
        },"#searchPlaylists a click":function(a, b) {
            GS.guts.handleSearchSidebarClick(a, b, "playlist")
        },"#searchUsers a click":function(a, b) {
            GS.guts.handleSearchSidebarClick(a, b, "user")
        },"a.follow, button.follow click":function(a) {
            var b = parseInt($(a).attr("data-follow-userid"), 10),c = "";
            if (a.is(".following")) {
                GS.user.removeFromUserFavorites(b);
                a.removeClass("following").addClass("add");
                c = "FOLLOW"
            } else {
                GS.user.addToUserFavorites(b);
                a.addClass("following").removeClass("add");
                c = "UNFOLLOW"
            }
            a.find("span").attr("data-translate-text", c).text($.localize.getString(c))
        },"a.signup, button.signup click":function() {
            location.hash = "#/signup"
        },"a.uploadMusic, button.uploadMusic click":function() {
            window.open("http://" + location.host + "/upload", "_blank")
        },"a.saveQueue, button.saveQueue click":function() {
            GS.player.saveQueue()
        },"a.newPlaylist, button.newPlaylist click":function() {
            GS.lightbox.open("newPlaylist")
        },
        "a.inviteFriends, button.inviteFriends click":function() {
            GS.lightbox.open("invite")
        },"select.launchStation change":function(a) {
            (a = $(a).val()) && GS.player.setAutoplay(true, a)
        },"select change":function(a) {
            $(a).prev("span").text($(a).find("option:selected").html())
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.RapLeafController", {onDocument:true}, {personalizeMapTheme:{"4097253982":"0=18-24","4097253968":"0=18-24","4097253992":"0=25-34","4097253999":"0=35-44","4097254011":"0=50-","4097254001":"0=50-","4097254007":"0=50-","4097253897":"1=0","4097253890":"1=1"},personalizeMapSidebar:{"4097253982":"AgeRange=18-24","4097253968":"AgeRange=18-24","4097253992":"AgeRange=25-34","4097253999":"AgeRange=35-44","4097254011":"AgeRange=50-","4097254001":"AgeRange=50-",
    "4097254007":"AgeRange=50-","4097253897":"Gender=M","4097253890":"Gender=F"},init:function() {
    this.subscribe("gs.auth.update", this.callback(this.update));
    this._super()
},appReady:function() {
    this.onPersonalize()
},update:function() {
    this.onPersonalize()
},onPersonalize:function() {
    if (!GS.user.IsPremium && !GS.user.isLoggedIn)store.get("webvisit") || $.getScript("http://rd.rlcdn.com/rd?type=js&site=108574", this.callback("onPersonalizeCallback"))
},onPersonalizeCallback:function() {
    if (_rlcdnsegs && _rlcdnsegs.length) {
        for (var a =
        {theme:[],sidebar:[]},b = 0; b < _rlcdnsegs.length; b++)try {
            a.theme.push(this.personalizeMapTheme[_rlcdnsegs[b].toString()]);
            a.sidebar.push(this.personalizeMapSidebar[_rlcdnsegs[b].toString()])
        } catch(c) {
            console.warn("[ Personalize Out of Bounds ]")
        }
        store.set("webvisit", a);
        b = {};
        b.params = a.sidebar.toString();
        jQuery.isEmptyObject(b) || GS.guts.logEvent("rapleafCollectedData", b)
    } else store.set("webvisit", null)
}});
GS.Controllers.BaseController.extend("GS.Controllers.LogController", {onDocument:true}, {eventLog:null,currentSongID:null,init:function() {
    this.subscribe("gs.player.playing", this.callback(this.logSongPlay));
    this.subscribe("gs.page.page.view", this.callback(this.logPageSeen));
    this.subscribe("gs.page.home.view", this.callback(this.logPageSeen));
    this.subscribe("gs.auth.update", this.callback(this.update));
    this._super()
},appReady:function() {
    this.update()
},update:function() {
    this.eventLog = store.get("eventLog" +
            GS.user.UserID);
    if (!this.eventLog) {
        this.eventLog = {};
        this.saveLog()
    }
},logSongPlay:function() {
    if (this.currentSongID != GS.player.currentSong.SongID) {
        this.currentSongID = GS.player.currentSong.SongID;
        if (this.eventLog.songPlayCount)this.eventLog.songPlayCount++; else {
            this.eventLog.songPlayCount = 1;
            if (!this.eventLog.pageSeen || !this.eventLog.pageSeen.song)$.publish("gs.facebook.notification.songComment", {})
        }
        this.saveLog()
    }
},logPageSeen:function() {
    if (this.eventLog) {
        if (!this.eventLog.pageSeen)this.eventLog.pageSeen =
                [];
        var a = new Date,b = null;
        if (!window.location.hash || window.location.hash == "#/" || window.location.hash == "")b = "home"; else if (window.location.hash == "#/popular")b = "popular"; else if (window.location.hash == "#/settings")b = "settings"; else if (window.location.hash == "#/now_playing")b = "nowplaying"; else if (window.location.hash.toString().indexOf("#/search") >= 0)b = "search"; else if (window.location.hash.toString().indexOf("#/s/") >= 0)b = "song"; else if (window.location.hash.toString().indexOf("#/album") >= 0)b = "album"; else if (window.location.hash.toString().indexOf("#/user/") >=
                0)b = window.location.hash.toString().indexOf("/favorites") >= 0 ? "favorites" : window.location.hash.toString().indexOf("/playlists") >= 0 ? "playlists" : window.location.hash.toString().indexOf("/community") >= 0 ? "community" : "mymusic";
        if (b) {
            this.eventLog.pageSeen[b] = a.getTime();
            this.saveLog()
        }
    }
},saveLog:function() {
    store.set("eventLog" + GS.user.UserID, this.eventLog)
}});
GS.Controllers.BaseController.extend("GS.Controllers.InviteInterface", {onDocument:false}, {userInfo:{},googleContacts:null,facebookFriends:[],fbIDs:{},slickbox:false,peopleError:null,people:null,onFollowersSuccess:function(a) {
    var b = [];
    $.each(a, this.callback(function(c, g) {
        b.push([g.Email,g.Name + " " + g.Email,g.Name,g.Name]);
        this.userInfo[g.UserID] = g;
        this.userInfo[g.Email] = g
    }));
    a = new $.TextboxList("#emails", {addOnBlur:true,bitsOptions:{editable:{growing:true,growingOptions:{maxWidth:$("#emails").innerWidth() -
            10}}},plugins:{autocomplete:{placeholder:$.localize.getString("SHARE_EMAIL_PLACEHOLDER")}},encode:this.callback(function(c) {
        for (var g = [],h = 0; h < c.length; h++)if (c[h][0])this.userInfo[c[h][0]] ? g.push(this.userInfo[c[h][0]].Email) : g.push(c[h][0]); else if (c[h][1])this.userInfo[c[h][1]] ? g.push(this.userInfo[c[h][1]].Email) : g.push(c[h][1]);
        return g.join(",")
    })});
    a.plugins.autocomplete.setValues(b);
    a.addEvent("bitAdd", this.callback(function(c) {
        c.getValue()[1] === "" && c.hide();
        if (this.userInfo[c.getValue()[1]] &&
                _.notDefined(c.getValue()[0])) {
            var g = this.userInfo[c.getValue()[1]];
            c.setValue([g.Email,g.Name + " " + g.Email,g.Name,g.Name]);
            c.show()
        }
    }));
    $("#services_content input.textboxlist-bit-editable-input").focus()
},extractInviteEmails:function(a) {
    var b,c = [],g,h = $.trim(a).split(",");
    for (a = 0; a < h.length; a++) {
        g = $.trim(h[a]).split(" ");
        for (b = 0; b < g.length; b++) {
            g[b] = $.trim(g[b]);
            g[b] && c.push(g[b])
        }
    }
    return c
},onFollowersFailed:function(a) {
    console.warn("failed grabbing contact info for followers", autocompleteTerms,
            a);
    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_FAIL_FANS_EMAIL_ONLY")})
},onFacebookFriends:function(a) {
    this.facebookFriends = a || [];
    if (this.facebookFriends.length != 0) {
        var b = [];
        $.each(this.facebookFriends, this.callback(function(c, g) {
            b.push([g.id,g.name,g.name])
        }));
        a = new $.TextboxList("#facebook_invite_list", {addOnBlur:true,bitsOptions:{editable:{growing:true,growingOptions:{maxWidth:$("#facebook_invite_list").innerWidth() - 10}}},plugins:{autocomplete:{placeholder:$.localize.getString("SHARE_FACEBOOK_PLACEHOLDER")}},
            encode:this.callback(function(c) {
                var g = [];
                if (c.length) {
                    for (var h = 0; h < c.length; h++)c[h][0] && g.push(c[h][0]);
                    this.element.find(".submit span").attr("data-translate-text", "SHARE_FACEBOOK_FRIENDS").html($.localize.getString("SHARE_FACEBOOK_FRIENDS"))
                } else this.element.find(".submit span").attr("data-translate-text", "SHARE_FACEBOOK_WALL").html($.localize.getString("SHARE_FACEBOOK_WALL"));
                return g.join(",")
            })});
        a.plugins.autocomplete.setValues(b);
        a.addEvent("bitAdd", function(c) {
            if (c.getValue()[1] === "")c.hide();
            else {
                var g = $("#facebook_invite_list").val().split(",");
                if (g) {
                    var h = g.indexOf(c.getValue()[0]);
                    c.getValue()[0] && h >= 0 && h != g.length - 1 && c.hide()
                }
            }
        });
        $("#services_content input.textboxlist-bit-editable-input").focus()
    }
},formSubmit:function() {
    var a = this,b = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    this.peopleError = [];
    this.people = [];
    switch (this.submitType) {
        case "email":
            var c;
            c = $.trim($("textarea[name=emails]", this.element).val());
            var g = $("div.textboxlist", this.element).find(".textboxlist-bit").not(".textboxlist-bit-box-deletable").filter(":last").text();
            if (c !== "") {
                c = this.extractInviteEmails(c);
                _.forEach(c, function(m) {
                    m.match(b) ? a.people.push(m) : a.peopleError.push(m)
                })
            }
            if (g) {
                g = this.extractInviteEmails(g);
                for (c = 0; c < g.length; c++)g[c].match(b) ? this.people.push(g[c]) : this.peopleError.push(g[c])
            }
            if (this.people.length)GS.service.sendInvites(this.people, this.callback("sendInviteSuccess"), this.callback("sendInviteFailed")); else this.peopleError.length && this.invalidInviteEmail();
            break;
        case "googleLogin":
            g = $("input[name=google_username]", this.element).val();
            c = $("input[name=google_password]", this.element).val();
            GS.service.getGoogleAuthToken(g, c, this.callback("googAuthSuccess"), this.callback("googAuthFailed"));
            break;
        case "googleContacts":
            var h = [];
            $(".contactsContainer input:checked", this.element).each(function() {
                h.push(this.value)
            });
            h.length && GS.service.sendInvites(h, this.callback("sendInviteSuccess"), this.callback("sendInviteFailed"));
            break;
        case "facebook":
            g = $("#facebook_invite_list").val() ? $("#facebook_invite_list").val().split(",") : [];
            var k = _.orEqual($("textarea[name=facebookMessage]",
                    this.element).val(), "");
            if (g.length > 0) {
                GS.facebook.lastError = false;
                _.forEach(g, this.callback(function(m) {
                    GS.facebook.lastError || GS.facebook.postToFeed(m, "http://grooveshark.com/", k, null, null, this.callback("facebookFailed"))
                }));
                if (!GS.facebook.lastError) {
                    g.length > 1 ? $.publish("gs.facebook.notification.sent", {params:{type:"invites",hideUndo:true},data:{},notifData:{}}) : $.publish("gs.facebook.notification.sent", {params:{type:"invite",hideUndo:true},data:{},notifData:{}});
                    this.facebookSuccess()
                }
            } else if (GS.facebook.connectStatus ==
                    "connected" && window.FB && FB.getSession())GS.facebook.postToFeed("me", "http://grooveshark.com/", k, "fbwall", this.callback("facebookSuccess"), this.callback("facebookFailed")); else {
                window.open("http://www.facebook.com/sharer.php?u=http://grooveshark.com&t=Grooveshark");
                this.facebookSuccessCallback()
            }
            break
    }
    return false
},sendInviteSuccess:function(a) {
    var b = [],c = [],g = [],h = [],k = "";
    if (a)for (var m in a)switch (a[m].status) {
        case "error":
            a[m].errorCode == -3 ? h.push(m) : b.push(m);
            break;
        case "followed":
            c.push(a[m].Username ||
                    a[m].FName);
            break;
        case "invited":
            g.push(m);
            break
    }
    if (c.length) {
        k = (new GS.Models.DataString($.localize.getString("POPUP_INVITE_FORM_RESPONSE_FOLLOWING"), {list:c.join(", ")})).render();
        $.publish("gs.notification", {type:"info",message:k})
    }
    if (g.length) {
        k = g.length > 5 ? (new GS.Models.DataString($.localize.getString("POPUP_INVITE_FORM_RESPONSE_INVITED_SUM"), {sum:String(g.length)})).render() : (new GS.Models.DataString($.localize.getString("POPUP_INVITE_FORM_RESPONSE_INVITED_LIST"), {list:g.join(", ")})).render();
        $.publish("gs.notification", {type:"info",message:k})
    }
    if (h.length) {
        k = (new GS.Models.DataString($.localize.getString("POPUP_INVITE_FORM_RESPONSE_ALREADY_SENT"), {list:h.join(", ")})).render();
        $.publish("gs.notification", {type:"info",message:k})
    }
    if (b.length) {
        k = (new GS.Models.DataString($.localize.getString("POPUP_INVITE_FORM_RESPONSE_ERROR"), {list:b.join(", ")})).render();
        $.publish("gs.notification", {type:"error",message:k})
    }
    if (this.peopleError.length)this.invalidInviteEmail(); else if (b.length + c.length +
            g.length + h.length == 0) {
        this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_FORM_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_FORM_RESPONSE_UNKNOWN_ERROR"));
        this.element.find(".error").show()
    } else this.sendInviteSuccessCallback()
},sendInviteFailed:function(a) {
    console.warn("invite failed", a);
    this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_FORM_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_FORM_RESPONSE_UNKNOWN_ERROR"));
    this.element.find(".error").show()
},invalidInviteEmail:function() {
    console.warn("invalid invite email");
    var a = $("div.textboxlist", this.element).find(".textboxlist-bit").not(".textboxlist-bit-box-deletable").filter(":last").text();
    a && this.people.indexOf(a) >= 0 && $("div.textboxlist", this.element).find(".textboxlist-bit").not(".textboxlist-bit-box-deletable").remove();
    _.forEach(this.people, function(b) {
        $("li.textboxlist-bit:contains('" + b + "')").remove()
    });
    this.element.find(".message").attr("data-translate-text",
            "POPUP_INVITE_FORM_RESPONSE_INVALID_EMAIL_ERROR").html($.localize.getString("POPUP_INVITE_FORM_RESPONSE_INVALID_EMAIL_ERROR"));
    this.element.find(".error").show()
},googAuthSuccess:function(a) {
    switch (parseInt(a.result.statusCode)) {
        case 1:
            a = String(a.result.rawResponse);
            a = a.substr(a.indexOf("Auth=") + 5);
            GS.service.getGoogleContacts(a, this.callback("googContactsSuccess"), this.callback("googContactsFailed"));
            break;
        case 2:
            this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_AUTH_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_AUTH_ERROR"));
            this.element.find(".error").show();
            break;
        default:
            this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR"));
            this.element.find(".error").show();
            break
    }
},googAuthFailed:function() {
    this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR"));
    this.element.find(".error").show()
},
    googContactsSuccess:function(a) {
        switch (parseInt(a.result.statusCode, 10)) {
            case 1:
                this.googleContacts = a.result.parsedResult;
                this.showOnlyNamedContacts = true;
                this.googContactsSuccessCallback();
                break;
            case 2:
                this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_AUTH_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_AUTH_ERROR"));
                this.element.find(".error").show();
                break;
            default:
                this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR"));
                this.element.find(".error").show();
                break
        }
    },googContactsFailed:function(a) {
        console.warn("goog contacts failed", a);
        this.element.find(".message").attr("data-translate-text", "POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR").html($.localize.getString("POPUP_INVITE_GOOGAUTH_RESPONSE_UNKNOWN_ERROR"));
        this.element.find(".error").show()
    },facebookSuccess:function() {
        this.facebookSuccessCallback()
    },facebookFailed:function(a) {
        console.warn("facebook invite failed", a);
        this.element.find(".message").attr("data-translate-text",
                "POPUP_INVITE_FACEBOOK_POST_ERROR").html($.localize.getString("POPUP_INVITE_FACEBOOK_POST_ERROR"));
        this.element.find(".error").show()
    },"input keydown":function(a, b) {
        b.keyCode && b.keyCode == 13 && a.is("[name*=google]") && this.formSubmit()
    },"input.googleContact click":function(a) {
        $(a).is(":checked") ? $(a).closest("li.contact").addClass("selected") : $(a).closest("li.contact").removeClass("selected")
    },"button.uncheckAll click":function() {
        if (this.submitType == "facebook")this.facebookClearSelected(); else this.submitType ==
                "googleContacts" && $(".google_contacts input", this.element).attr("checked", false)
    },"button.checkAll click":function() {
        if (this.submitType == "facebook") {
            this.element.find(".submit span").attr("data-translate-text", "SEND_INVITE").html($.localize.getString("SEND_INVITE"));
            _.forEach(this.facebookFriends, function(a, b) {
                this.facebookFriends[b].selected = true;
                this.fbIDs[a.id] = a.id
            }, this);
            this.slickbox.setItems(this.facebookFriends)
        } else this.submitType == "googleContacts" && $(".google_contacts input", this.element).attr("checked",
                true)
    },updateFacebookForm:function() {
        $("#settings_facebook_form").html(this.view("/shared/inviteFacebook"));
        $("#settings_facebook_form .error").addClass("hide");
        $(window).resize()
    },updateFacebookFormWithError:function(a) {
        if (typeof a == "object" && a.error)a = a.error;
        $("#settings_facebook_form .error").html($.localize.getString(a));
        $("#settings_facebook_form .error").removeClass("hide");
        $(window).resize()
    },"#fbConnect-btn click":function() {
        GS.facebook.login(this.callback("updateFacebookForm"), this.callback("updateFacebookFormWithError"))
    },
    "a.fb-logout click":function() {
        GS.facebook.logout(this.callback("updateFacebookForm"))
    },"form#settings_facebook_form submit":function(a, b) {
        b.preventDefault();
        var c = 0;
        $("#settings_facebook_form").find("input:checkbox").not(":checked").each(function(g, h) {
            c |= $(h).val()
        });
        GS.facebook.save(c);
        return false
    }});
GS.Controllers.BaseController.extend("GS.Controllers.VipInterface", {onDocument:false,vipErrorCodes:{"GS-00":"VIP_ERROR_UNKNOWN","GS-01":"VIP_ERROR_LOGIN","GS-02":"VIP_ERROR_ALREADY_VIP","CC-01":"VIP_ERROR_MISSING_NAME","CC-02":"VIP_ERROR_UNKNOWN","CC-03":"VIP_ERROR_MISSING_CC_INFO","CC-04":"VIP_ERROR_ADDRESS","CC-05":"VIP_ERROR_UNKNOWN","CC-06":"VIP_ERROR_PAYMENT_PROCESSOR","CC-07":"VIP_ERROR_SESSION_EXPIRED","CC-08":"VIP_ERROR_INVALID_CC","CC-09":"VIP_ERROR_MISSING_CVD","CC-10":"VIP_ERROR_INVALID_CVD",
    "CC-11":"VIP_ERROR_ADDRESS1_TOO_LONG","CC-000":"VIP_ERROR_GENERIC_PAYMENT_ERROR","CC-000X":"VIP_ERROR_GENERIC_PAYMENT_ERROR","PP-01":"VIP_ERROR_UNKNOWN","PP-02":"VIP_ERROR_UNKNOWN_PAYPAL","PP-03":"VIP_ERROR_UNKNOWN","PP-04":"VIP_ERROR_PAYPAL_CANCEL","PP-000":"VIP_ERROR_PAYPAL_FAIL","PP-000X":"VIP_ERROR_PAYPAL_FAIL","PC-01":"VIP_ERROR_NO_PROMOCODE","PC-02":"VIP_ERROR_CODE_NOT_FOUND","PC-03":"VIP_ERROR_CODE_REDEEMED","RC-01":"VIP_ERROR_NOT_ENOUGH_POINTS"},excludedCreditCardCountries:{AF:true,AL:true,
    AM:true,AO:true,AZ:true,BA:true,BD:true,BG:true,BI:true,BY:true,CD:true,CF:true,CG:true,CK:true,CS:true,CU:true,DZ:true,EG:true,ER:true,ET:true,GE:true,GT:true,HT:true,ID:true,IQ:true,IR:true,KG:true,KH:true,KP:true,KZ:true,LA:true,LR:true,LY:true,MD:true,MK:true,MM:true,MN:true,MY:true,NG:true,NR:true,PH:true,PK:true,RO:true,RU:true,RW:true,SD:true,SL:true,SR:true,SY:true,TJ:true,TM:true,UA:true,UZ:true,VE:true,YE:true,ZW:true}}, {vipPackages:{plus:"plus",anywhere:"anywhere",vip:"vip"},vipPackagePrices:{month:{plus:6,
    anywhere:9,vip:3},year:{plus:60,anywhere:90,vip:30}},showVipErrors:function(a) {
    if (a.errorID && a.message)a.error = [
        {errorID:a.errorID,message:a.message}
    ];
    var b,c = ['<ul class="errors">'];
    this.element.find(".error.response .message").html("");
    this.element.find(".error.response").hide();
    if (a.error && a.error.length) {
        _.forEach(a.error, this.callback(function(g) {
            if (b = $.trim($.localize.getString(GS.Controllers.VipInterface.vipErrorCodes[g.errorID])))c.push("<li>" + b + "</li>"); else {
                console.warn("unknown error in arr",
                        g.errorID, g.message, GS.Controllers.VipInterface.vipErrorCodes[g.errorID]);
                b = _.isString(g.message) ? g.message : g.message[0];
                if (b.match("AVS"))b = $.localize.getString("VIP_ERROR_AVS"); else if (b.match("invalid XML"))b = $.localize.getString("VIP_ERROR_XML"); else if (b.match("invalid card number"))b = $.localize.getString("VIP_ERROR_CARD_NUMBER"); else if (b.match("CVD check"))b = $.localize.getString("VIP_ERROR_CVD");
                b && c.push("<li>" + b + "</li>")
            }
        }));
        c.push("</ul>");
        a = this.element.find(".error").show().find(".message");
        a.html("<strong>" + $.localize.getString("POPUP_VIP_ERROR_MESSAGE") + "</strong> " + c.join(""))
    } else {
        this.element.find(".message").attr("data-translate-text", "VIP_ERROR_UNKNOWN").html($.localize.getString("VIP_ERROR_UNKNOWN"));
        this.element.find(".error").show()
    }
}});
GS.Controllers.PageController.extend("GS.Controllers.Page.HomeController", {}, {init:function(a, b) {
    this.update(b);
    this.subscribe("window.resize", this.callback("resize"));
    $(document).keydown(this.callback(function(c) {
        if (!($(c.target).is("input,textarea,select,object") && !$(c.target).is("#searchBar_input input"))) {
            this.toggleHint({}, c);
            var g = _.orEqual(c.keyCode, c.which),h = String.fromCharCode(g).replace(/\s+/g, ""),k = {17:true,37:true,38:true,39:true,40:true};
            $("#page").is(".gs_page_home") && !$(c.target).is("input,textarea,select,object") &&
                    h.length && h != "" && !k[g] && $("input.search.autocomplete", this.element).focus();
            if (String.fromCharCode(g) == " " && $(c.target).val().length == 0)return false
        }
    }))
},update:function() {
    if (!GS.lightbox || !GS.lightbox.isOpen)$("input.search.autocomplete", this.element).focus();
    !GS.user.isLoggedIn || GS.user.IsPremium ? $(".home_upgrade").addClass("hide") : $(".home_upgrade").removeClass("hide");
    $.publish("gs.page.home.update")
},index:function() {
    this._super();
    this.addAutocomplete("home");
    this.resize();
    this.subscribe("window.resize",
            this.callback("resize"));
    this.subscribe("gs.auth.update", this.callback("update"));
    GS.Controllers.PageController.title("Listen to Free Music Online - Internet Radio - Free MP3 Streaming", false);
    $.publish("gs.page.home.view")
},resize:function() {
    var a = $("#homeSearch"),b = 500;
    if (a.length) {
        b = Math.max(250, Math.min(500, $(this.element).width() - 200));
        a.width(b).css("marginLeft", -Math.round(b / 2))
    }
},toggleHint:function(a, b) {
    if (b.type == "mousedown")$("#searchBar_input input").val() == "" && b.button != 2 ? $("#searchBar_hint").show().addClass("faded") :
            $("#searchBar_hint").hide(); else if (b.type == "keyup" || b.type == "keydown") {
        var c = String.fromCharCode(_.orEqual(b.keyCode, b.which)).replace(/[\b]/g, "");
        if (String.fromCharCode(_.orEqual(b.keyCode, b.which)).replace(/[\s]/g, "").length > 0)$("#searchBar_input input").val() == "" && c.length < 1 ? $("#searchBar_hint").show().addClass("faded") : $("#searchBar_hint").hide()
    } else $("#searchBar_input input").val() == "" ? $("#searchBar_hint").show().removeClass("faded") : $("#searchBar_hint").hide()
},"#homeSearch submit":function(a, b) {
    if ($("input[name=q]", a).val() === "") {
        b.stopImmediatePropagation();
        return false
    }
    return true
},"#searchButton click":function() {
    $("#homeSearch").submit()
},"#searchBar_input span click":function() {
    $("input.search.autocomplete", this.element).focus();
    $("#searchBar_hint").addClass("faded")
},"#homePage keydown":function() {
    $("input.search.autocomplete", this.element).focus()
},"input.search.autocomplete mousedown":function(a, b) {
    return this.toggleHint(a, b)
},"input.search.autocomplete keyup":function(a, b) {
    return this.toggleHint(a,
            b)
},"input.search.autocomplete focusout":function(a, b) {
    if ($("#searchBar_input input").hasClass("focused")) {
        setTimeout(function() {
            $("input.search.autocomplete", "#page").focus()
        }, 0);
        $("#searchBar_input input").removeClass("focused");
        return true
    } else return this.toggleHint(a, b)
},"a.themes click":function() {
    GS.lightbox.open("themes")
},"a.upgrade click":function() {
    GS.lightbox.open("vipPerks")
},notFound:function() {
    this.element.html(this.view("not_found"));
    this.addAutocomplete("home");
    this.resize();
    this.subscribe("window.resize",
            this.callback("resize"));
    this.subscribe("gs.auth.update", this.callback("update"));
    GS.Controllers.PageController.title("Unable To Find What You're Looking For")
}});
GS.Controllers.PageController.extend("GS.Controllers.Page.NowPlayingController", {}, {index:function() {
    GS.Controllers.PageController.title("Now Playing");
    this.element.html(this.view("index"));
    $("input.search").select();
    this.list.doSearchInPage = true;
    this.loadGrid(GS.player.getCurrentQueue());
    this.subscribe("gs.player.queue.change", this.callback("loadGrid"))
},loadGrid:function(a) {
    if (!a) {
        a = GS.player.getCurrentQueue();
        if (!a) {
            this.element.find(".gs_grid").html(this.view("noResults"));
            $("#searchForm input").select();
            this.addAutocomplete("now_playing");
            return
        }
    }
    this.queue = a;
    var b = a.songs.length > 0 && a.songs[0]instanceof GS.Models.Song ? a.songs : GS.Models.Song.wrapQueue(a.songs),c = this.element.find(".gs_grid").controller(),g = {sortCol:"Sort",sortDir:1,sortStoreKey:"gs.sort.nowPlaying.songs"};
    g = $.extend(g, {allowDuplicates:true,allowDragSort:true,isNowPlaying:true});
    for (var h = 1; h < b.length; h++)b[h].Sort = h;
    if (c) {
        g = c.dataView;
        var k = c.grid;
        if (g) {
            g.beginUpdate();
            var m = b.concat(),n = g.getItems().concat(),o;
            for (h = 0; h < n.length; h++) {
                song =
                        n[h];
                o = m.indexOf(song);
                o != -1 && m.splice(o, 1);
                g.getIdxById(song.SongID);
                curInd = b.indexOf(song);
                curInd == -1 ? g.deleteItem(song.SongID) : g.updateItem(song.GridKey, song)
            }
            m.length && g.addItems(m, "SongID");
            g.endUpdate();
            g.refresh()
        }
        k && k.onSort(c.sortCol, c.sortDir)
    } else if (b.length) {
        g.rowCssClasses = this.callback(function(r) {
            var t = "";
            a = GS.player.getCurrentQueue();
            if (a.activeSong && a.activeSong.queueSongID == r.queueSongID)t += "active";
            if (a.autoplayEnabled)t += " autoplay";
            return t
        });
        g.rowAttrs = function(r) {
            return["rel='",
                r.queueSongID,"' rel2='",r.SongID,"'"].join("")
        };
        this.element.find(".gs_grid").gs_grid(b, GS.Controllers.GridController.columns.queuesong, g, "song")
    } else {
        this.element.find(".gs_grid").html(this.view("noResults"));
        $("#searchForm input").select();
        this.addAutocomplete("now_playing")
    }
    a.hasRestoreQueue ? $("#page_header button.clearRestore .restore").show().siblings().hide() : $("#page_header button.clearRestore .clears").show().siblings().hide();
    $("#grid .slick-row.active").removeClass("active");
    if (a.activeSong) {
        $("#grid .slick-row[rel=" +
                a.activeSong.queueSongID + "]").addClass("active");
        GS.player.isPlaying ? $("#grid .slick-row.active a.play").removeClass("paused") : $("#grid .slick-row.active a.play").addClass("paused")
    }
},"button.delete click":function() {
    var a = [],b = this.element.find(".gs_grid").controller();
    if (b) {
        var c = b.grid.getSelectedRows();
        if (c.length !== 0) {
            for (var g = 0; g < c.length; g++)a.push(b.dataView.rows[c[g]].queueSongID);
            GS.player.removeSongs(a);
            b.grid.setSelectedRows([]);
            b.selectedRowIDs = [];
            $.publish("gs.grid.selectedRows", {len:0,
                type:"song"})
        }
    }
},"button.clearRestore click":function(a) {
    if (GS.player.getCurrentQueue().hasRestoreQueue) {
        GS.player.restoreQueue();
        a.find(".restore").show().siblings().hide()
    } else {
        GS.player.clearQueue();
        a.find(".clears").show().siblings().hide()
    }
},".slick-row .smile click":function(a, b) {
    b.stopImmediatePropagation();
    var c = a.parents(".slick-row").attr("row");
    c = $("#grid").controller().dataView.getItemByIdx(c).queueSongID;
    GS.player.voteSong(c, 1);
    $(a).addClass("selected").siblings(".frown").removeClass("selected")
},
    ".slick-row .frown click":function(a, b) {
        b.stopImmediatePropagation();
        var c = a.parents(".slick-row").attr("row");
        c = $("#grid").controller().dataView.getItemByIdx(c).queueSongID;
        GS.player.voteSong(c, -1);
        $(a).addClass("selected").siblings(".smile").removeClass("selected")
    }});
GS.Controllers.PageController.extend("GS.Controllers.Page.PopularController", {}, {index:function(a) {
    this.pageType = a = _.orEqual(a, "daily");
    this.type = "popular";
    GS.Controllers.PageController.title("Popular Music: " + _.ucwords(a));
    this.element.html(this.view("index"));
    $("input.search").select();
    this.list.doSearchInPage = true;
    this.popular = GS.Models.Popular.getType(a);
    this.popular.getSongs(this.callback("loadGrid"))
},loadGrid:function(a) {
    var b,c = {sortCol:"Popularity",sortDir:true,sortStoreKey:"gs.sort.popular"};
    if (a.length) {
        b = GS.Controllers.GridController.columns.song.concat();
        b = [b[0],b[1],b[2]];
        this.element.find(".gs_grid").gs_grid(a, b, c, "song")
    } else {
        this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"song"}));
        $("#searchForm input").select();
        this.addAutocomplete("popular")
    }
}});
(function() {
    GS.Controllers.PageController.extend("GS.Controllers.Page.SettingsController", {}, {user:null,settings:null,desktopPrefs:null,index:function(a) {
        this.pageType = a || "profile";
        if (!GS.user.isLoggedIn)if (this.pageType !== "preferences" && this.pageType !== "subscriptions") {
            this.pageType = "preferences";
            window.location.hash = "/settings/preferences"
        }
        GS.user.settings.getUserSettings(this.callback("loadSettings"), GS.router.notFound);
        this.subscribe("gs.auth.update", this.callback("index", a));
        this.subscribe("gs.auth.favorites.users.update",
                this.callback("updateActivityUsersForm"));
        this.subscribe("gs.facebook.profile.update", this.callback("updateFacebookForm"));
        this.subscribe("gs.lastfm.profile.update", this.callback("updateLastfmForm"));
        this.subscribe("gs.google.profile.update", this.callback("updateGoogleForm"));
        this.subscribe("gs.settings.upload.onload", this.callback("iframeOnload"))
    },loadSettings:function() {
        if (this.element) {
            this.user = GS.user;
            this.settings = GS.user.settings;
            this.desktopPrefs = GS.airbridge.getDesktopPreferences();
            this.element.html(this.view("index"));
            switch (this.pageType) {
                case "profile":
                    GS.Controllers.PageController.title("Settings");
                    this.showProfile();
                    break;
                case "password":
                    GS.Controllers.PageController.title("Change Password");
                    this.showPassword();
                    break;
                case "preferences":
                    GS.Controllers.PageController.title("Preferences");
                    this.showPreferences();
                    break;
                case "services":
                    GS.Controllers.PageController.title("Services Settings");
                    this.showServices();
                    break;
                case "activity":
                    GS.Controllers.PageController.title("Activity Settings");
                    this.showActivity();
                    break;
                case "subscriptions":
                    GS.Controllers.PageController.title("Subscriptions Settings");
                    GS.user.isLoggedIn ? GS.service.getSubscriptionDetails(this.callback("showSubscriptions"), this.callback("showSubscriptions")) : this.showSubscriptions(false);
                    break
            }
        }
    },showProfile:function() {
        this.today = new Date;
        this.dob = new Date;
        if (this.settings.TSDOB) {
            var a = this.settings.TSDOB.split("-");
            this.dob = new Date(parseInt(a[0], 10), parseInt(a[1], 10) - 1, parseInt(a[2], 10))
        }
        this.months = $.localize.getString("MONTHS").split(",");
        this.countries =
                _.countries;
        GS.user.UserID > 0 && GS.user.getPathName(this.callback("loadProfile"))
    },loadProfile:function() {
        if (GS.user.UserID > 0 && this.pageType == "profile") {
            this.element.find("#page_pane").html(this.view("profile"));
            $(".settings_selectbox_country span").html($("select.country option:selected").html());
            $(".selectbox.month span").html($("select.month option:selected").html())
        }
    },showPassword:function() {
        this.element.find("#page_pane").html(this.view("password"));
        $(window).resize()
    },showServices:function() {
        this.element.find("#page_pane").html(this.view("services"));
        this.updateFacebookForm();
        this.updateLastfmForm();
        this.updateGoogleForm();
        $(window).resize()
    },showPreferences:function() {
        $(window).resize();
        this.element.find("#page_pane").html(this.view("preferences"));
        if (this.desktopPrefs) {
            $("#desktop_selected_notifDuration", this.element).localeDataString("NUM_SECONDS", {seconds:this.desktopPrefs.notifications.duration});
            $("option.notifDuration", this.element).each(function() {
                $(this).localeDataString("NUM_SECONDS", {seconds:$(this).val()})
            })
        }
    },showActivity:function() {
        this.settings.privacy =
                GS.service.privacy;
        this.element.find("#page_pane").html(this.view("activity"));
        this.hideUsers = new $.TextboxList("#settings_usersToHide", {addOnBlur:false,plugins:{autocomplete:{placeholder:$.localize.getString("SETTINGS_USER_HIDE_PLACEHOLDER")}},encode:this.callback(function(a) {
            for (var b = [],c = 0; c < a.length; c++)a[c][0] ? b.push(a[c][0]) : b.push(a[c][1]);
            return b.join(",")
        })});
        this.hideUsers.addEvent("bitAdd", this.callback("bitCheck"));
        this.updateActivityUsersForm();
        $(window).resize()
    },showSubscriptions:function(a) {
        this.data =
                a;
        this.noData = true;
        this.recurring = this.bVip = this.bAnywhere = this.bPlus = this.hasSpecialVip = false;
        this.billingAmount = this.nextBillingDate = this.paymentType = this.subscriptionType = "";
        this.anywhereMonthPrice = 9;
        this.plusMonthPrice = 6;
        if (a === false || a.fault || a.code || a.bVip && _.notDefined(a.paymentType)) {
            this.noData = true;
            this.recurring = _.orEqual(a.bRecurring, false);
            this.bAnywhere = this.bPlus = false;
            if (GS.user.IsPremium)this.hasSpecialVip = true;
            if (a && a.bVip)this.bVip = parseInt(a.bVip, 10)
        } else {
            this.noData = false;
            switch (a.paymentType) {
                case "OPTIMAL_PAYMENTS":
                    this.paymentMethod =
                            $.localize.getString("CREDIT_CARD");
                    break;
                case "PAYPAL":
                    this.paymentMethod = $.localize.getString("PAYPAL");
                    break;
                case "FREE_TRIAL":
                    this.paymentMethod = $.localize.getString("FREE_TRIAL");
                    break;
                case "ZONG":
                    this.paymentMethod = $.localize.getString("ZONG");
                    break;
                case "ALLOPASS":
                    this.paymentMethod = $.localize.getString("ALLOPASS");
                    break;
                case "GWALLET":
                    this.paymentMethod = $.localize.getString("GWALLET");
                    break;
                case "TRIAL_PAY":
                    this.paymentMethod = $.localize.getString("TRIAL_PAY");
                    break;
                default:
                    this.paymentMethod =
                            _.orEqual(a.paymentType, "")
            }
            this.subscriptionType = a.subscriptionType;
            this.paymentType = a.paymentType;
            this.billingAmount = "$" + a.amount;
            this.recurring = a.bRecurring;
            this.bVip = parseInt(a.bVip, 10);
            this.bAnywhere = (GS.user.Flags & GS.Models.User.FLAG_ANYWHERE) > 0;
            this.bPlus = (GS.user.Flags & GS.Models.User.FLAG_PLUS) > 0;
            try {
                var b = this.recurring ? a.dateNextCheck.split("-") : a.dateEnd.split("-");
                this.nextBillingDate = (new Date(parseInt(b[0], 10), parseInt(b[1], 10) - 1, parseInt(b[2], 10))).format("F j, Y")
            } catch(c) {
                console.warn("subPage error:",
                        c);
                this.nextBillingDate = $.localize.getString("UNKNOWN")
            }
        }
        if (this.bVip)this.plusMonthPrice = this.anywhereMonthPrice = 3;
        this.element.find("#page_pane").html(this.view("subscriptions"));
        $(window).resize()
    },paymentTypeToString:function(a) {
        var b = "";
        switch (a) {
            case "FREE_TRIAL":
                break;
            default:
                b = $.localize.getString("SUBSCRIPTIONS_UNKNOWN_PAYMENT_TYPE")
        }
        return b
    },bitCheck:function(a) {
        this.userInfo[a.getValue()[1]] || a.hide()
    },updateActivityUsersForm:function() {
        if (this.element) {
            this.hiddenUsers = GS.user.filterFriends(1);
            this.visibleUsers = GS.user.filterOutFriends(1);
            this.element.find("#hiddenUsers").html(this.view("hiddenUsers"));
            this.element.find("#settings_usersToHide").val("");
            this.element.find(".textboxlist-bit-box-deletable").remove();
            this.userInfo = {};
            var a = [];
            $.each(this.visibleUsers, this.callback(function(b, c) {
                a.push([c.UserID,c.Name,c.Name,c.Name]);
                this.userInfo[c.UserID] = c;
                this.userInfo[c.Name] = c
            }));
            _.defined(this.hideUsers) && this.hideUsers.plugins && this.hideUsers.plugins.autocomplete.setValues(a)
        }
    },"#settings_userInfo submit":function(a, b) {
        b.preventDefault();
        var c = $.trim($("input[name=fname]", a).val()),g = $.trim($("input[name=username]", a).val()),h = $.trim($("input[name=email]", a).val()),k = $("select[name=country]", a).val(),m = $("input[name=zip]", a).val(),n = $("input[name=sex]:checked", a).val(),o = parseInt($("select[name=month]", this.element).val(), 10),r = parseInt($("select[name=year]", this.element).val(), 10),t = parseInt($("select[name=day]", this.element).val(), 10),w = new Date(r, o - 1, t);
        o = o.toString().length == 1 ? "0" + o : o;
        t = t.toString().length ==
                1 ? "0" + t : t;
        tsdob = [r,o,t].join("-");
        c = {FName:c,Email:h,Country:k,Zip:m,Sex:n,TSDOB:tsdob,PageName:g};
        if (Math.floor((+new Date - +w) / 864E5 / 365.24) < 13)this._userInfoFailed({statusCode:0,message:$.localize.getString("POPUP_SIGNUP_FORM_TOO_YOUNG_ACCOUNT")}); else h.match(_.emailRegex) ? GS.user.settings.updateProfile(c, this.callback(this._userInfoSuccess), this.callback(this._userInfoFailed)) : this._userInfoFailed({statusCode:-2});
        return false
    },checkUsernameTimer:null,"#user_customURL keyup":function(a) {
        a = a.val();
        $(".settings_usernameURL .status", this.element).removeClass("verified alert error");
        clearTimeout(this.checkUsernameTimer);
        if (a !== "" && a.length && a != GS.user.PathName)this.checkUsernameTimer = setTimeout(this.callback("checkUsername", a), 500)
    },checkUsername:function(a) {
        var b = 0,c = /^([a-zA-Z0-9]+[\.\-_]?)+[a-zA-Z0-9]+$/;
        $(".settings_usernameURL .status", this.element).removeClass("verified alert error");
        if (a.length && (a.length < 5 || a.length > 32 || !a.match(c))) {
            b |= 128;
            $(".settings_usernameURL .status", this.element).addClass("alert").attr("title",
                    $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_INVALID"))
        } else a.length && a != GS.user.PathName && GS.service.getItemByPageName(a, this.callback(function(g) {
            if (!g || g.type) {
                b |= 4;
                $(".settings_usernameURL .status", this.element).addClass("error").attr("title", $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_UNAVAILABLE"))
            } else $(".settings_usernameURL .status", this.element).addClass("verified").attr("title", $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_AVAILABLE"))
        }), null, {async:false});
        return b
    },_userInfoSuccess:function() {
        $("#settings_userInfo .form_buttons .status").addClass("success").removeClass("failure")
    },
        _userInfoFailed:function(a) {
            $("#settings_userInfo .form_buttons .status").addClass("failure").removeClass("success");
            switch (a.statusCode) {
                case -2:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_EMAIL_INVALID")});
                    break;
                case -3:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_NAME_CANNOT_BE_EMPTY")});
                    break;
                case -4:
                    $.publish("gs.notification", {displayDuration:1E4,type:"error",message:$.localize.getString("POPUP_EMAIL_TAKEN")});
                    break;
                case -7:
                case -9:
                    $.publish("gs.notification",
                            {type:"error",message:$.localize.getString("POPUP_INCORRECT_PASSWORD")});
                    break;
                case -10:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_USERNAME_INVALID_CHARACTERS")});
                    break;
                case -11:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_USERNAME_INVALID_LENGTH")});
                    break;
                case -12:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_USERNAME_RATE_LIMIT")});
                    break;
                case -13:
                    $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_USERNAME_TAKEN")});
                    break;
                default:
                    a = _.orEqual(a.message, $.localize.getString("POPUP_UNABLE_SAVE_SETTINGS"));
                    $.publish("gs.notification", {type:"error",message:a});
                    break
            }
        },"#uploadPath change":function(a) {
            a = $(a).val();
            a = a.replace(/.+\\/g, "");
            if (a.length > 20)a = a.substr(0, 20) + "&hellip;";
            $("#uploadLabel").html(a)
        },"#settings_profilePicture .browse click":function() {
            $("#uploadPath").click()
        },isFormOnload:false,"#settings_profilePicture submit":function() {
            $("#settings_profilePicture .form_buttons .status").text($.localize.getString("LOADING...")).show();
            return this.isFormOnload = true
        },iframeOnload:function(a, b) {
            console.log("iframe.upload.onload", a, b);
            $("#settings_profilePicture .form_buttons .status").text("");
            var c = a.contentWindow || a.get().contentDocument,g;
            if (c.document)c = c.document;
            c = c.body.innerHTML;
            console.log("iframe.upload.resp str", c);
            if (c) {
                try {
                    g = $.parseJSON(c)
                } catch(h) {
                    g = {}
                }
                if (!g || !g.success || !g.filename) {
                    g = g || {};
                    g.error && g.error.code && (g.error.code == 1 || g.error.code == 2) ? $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_UPLOAD_IMAGE_TOO_BIG")}) :
                            $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_UNABLE_UPLOAD_IMAGE")});
                    $("#settings_profilePicture .form_buttons .status").addClass("failure")
                } else {
                    $("#settings_profilePicture .form_buttons .status").addClass("success");
                    c = $("#settings_profilePicture").find("img");
                    GS.user.Picture = g.filename;
                    c.attr("src", GS.user.getImageURL() + "?r=" + (new Date).getTime())
                }
            } else if (this.isFormOnload) {
                $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_UNABLE_UPLOAD_IMAGE")});
                $("#settings_profilePicture .form_buttons .status").addClass("failure")
            }
            return this.isFormOnload = false
        },"#settings_changePassword submit":function(a, b) {
            b.preventDefault();
            var c = $("input[name=oldPass]", a).val(),g = $("input[name=newPass]", a).val(),h = $("input[name=confirmPass]", a).val();
            g == h && c.length > 4 && g.length > 4 ? GS.user.changePassword(c, g, this.callback(this._passwordSuccess), this.callback(this._passwordFailed)) : $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_SIGNUP_FORM_PASSWORD_INVALID_NO_MATCH")});
            return false
        },_passwordSuccess:function() {
            $("#settings_changePassword .form_buttons .status").addClass("success")
        },_passwordFailed:function() {
            $("#settings_changePassword .form_buttons .status").addClass("failure")
        },"#settings_changePassword a.forgot click":function() {
            GS.lightbox.open("forget")
        },"#settings_notifications submit":function(a, b) {
            b.preventDefault();
            var c = {userFollow:$("#settings_notifications_userFollow").is(":checked"),inviteSignup:$("#settings_notifications_userSignup").is(":checked"),
                playlistSubscribe:$("#settings_notifications_userSubscribe").is(":checked"),newFeature:$("#settings_notifications_newFeature").is(":checked")};
            GS.user.settings.changeNotificationSettings(c, this.callback(this._notificationsSuccess), this.callback(this._notificationsFailed));
            return false
        },_notificationsSuccess:function() {
            $("#settings_notifications .form_buttons .status").addClass("success")
        },_notificationsFailed:function() {
            $("#settings_notifications .form_buttons .status").addClass("failure");
            $.publish("gs.notification",
                    {type:"error",message:$.localize.getString("POPUP_UNABLE_SAVE_NOTIFICATION")})
        },"select blur":function(a) {
            a.change()
        },"select keydown":function(a) {
            a.change()
        },"li.settings_genderOrientation mousedown":function(a) {
            $(a).data("previous", $("#settings_userInfo input[name=sex]:checked").val())
        },"li.settings_genderOrientation click":function(a, b) {
            var c = $("input", a);
            if ($(c).val() === $(a).data("previous")) {
                $("#gender_none").attr("checked", "checked");
                b.preventDefault();
                $(c).blur();
                return false
            }
        },"form :input change":function(a) {
            $(a).closest("form").find(".form_buttons .status").removeClass("success failure")
        },
        "#settings_localSettings button.clearLocal click":function(a, b) {
            b.preventDefault();
            store && store.clear && store.clear();
            $("#settings_localSettings .form_buttons .status").addClass("success");
            return false
        },"#settings_localSettings submit":function(a, b) {
            b.preventDefault();
            var c = GS.theme.THEME_FLAG_DEFAULT;
            c |= ($("input[name=familyFriendly]:checked", a).length ? 1 : 0) * GS.theme.THEME_FLAG_FAMILY_FRIENDLY;
            c = {restoreQueue:$("input[name=restoreQueue]:checked", a).length ? 1 : 0,persistShuffle:$("input[name=persistShuffle]:checked",
                    a).length ? 1 : 0,lowerQuality:$("input[name=lowerQuality]:checked", a).length ? 1 : 0,noPrefetch:$("input[name=noPrefetch]:checked", a).length ? 1 : 0,playPauseFade:$("input[name=doCrossfade]:checked", a).length ? 1 : 0,crossfadeAmount:$("select[name=crossfadeSecs]", a).val() * 1E3,tooltips:$("input[name=tooltips]:checked", a).length ? 1 : 0,themeFlags:c};
            GS.user.settings.changeLocalSettings(c, this.callback(this._localSettingSuccess), this.callback(this._localSettingFailed));
            return false
        },_localSettingSuccess:function() {
            $("#settings_localSettings .form_buttons .status").addClass("success").removeClass("failure")
        },
        _localSettingFailed:function() {
            $("#settings_localSettings .form_buttons .status").addClass("failure").removeClass("success")
        },"#settings_activity_privacy submit":function(a, b) {
            b.preventDefault();
            switch ($(a).find("input:checked").val()) {
                case "-1":
                    GS.service.privacy = 1;
                    $("#settings_activity_privacy .form_buttons .status").addClass("success");
                    break;
                case "0":
                    GS.service.privacy = GS.user.Privacy = 0;
                    GS.service.changePrivacySettings(0, this.callback("changePrivacySuccess"), this.callback("changePrivacyFailure"));
                    break;
                case "1":
                    GS.service.privacy = GS.user.Privacy = 1;
                    GS.service.changePrivacySettings(1, this.callback("changePrivacySuccess"), this.callback("changePrivacyFailure"));
                    break
            }
            return false
        },changePrivacySuccess:function(a) {
            if (!a || a.statusCode !== 1)this.changePrivacyFailed(a); else {
                $("#settings_activity_privacy .form_buttons .status").addClass("success");
                GS.service.reportUserChange(GS.user.UserID, GS.user.Email, GS.user.Privacy)
            }
        },changePrivacyFailed:function() {
            $("#settings_activity_privacy .form_buttons .status").addClass("failure")
        },
        "#settings_activity_users submit":function(a, b) {
            b.preventDefault();
            var c = ($("#settings_usersToHide").val() || "").split(","),g = [];
            for (i = 0; i < c.length; i++)this.userInfo[c[i]] && g.push({userID:this.userInfo[c[i]].UserID,flags:1});
            GS.user.changeFollowFlags(g);
            return false
        },"#settings_activity_users button.showUser click":function(a) {
            a = [
                {userID:parseInt($(a).attr("data-userID"), 10),flags:0}
            ];
            GS.user.changeFollowFlags(a)
        },updateFacebookForm:function() {
            $("#settings_facebook_form").html(this.view("facebook_form"));
            $("#settings_facebook_form .error").addClass("hide");
            $(window).resize()
        },updateFacebookFormWithError:function(a) {
            if (typeof a == "object" && a.error)a = a.error;
            $("#settings_facebook_form .error").html($.localize.getString(a));
            $("#settings_facebook_form .error").removeClass("hide");
            $(window).resize()
        },"#fbConnect-btn click":function() {
            GS.facebook.login(this.callback("updateFacebookForm"), this.callback("updateFacebookFormWithError"))
        },"a.fb-logout click":function() {
            GS.facebook.logout(this.callback("updateFacebookForm"))
        },
        "form#settings_facebook_form submit":function(a, b) {
            b.preventDefault();
            var c = 0;
            $("#settings_facebook_form").find("input:checkbox").not(":checked").each(function(g, h) {
                c |= $(h).val()
            });
            GS.facebook.save(c);
            return false
        },"a.fb-findfriends click":function() {
            GS.facebook.getGroovesharkUsersFromFriends()
        },updateGoogleForm:function() {
            this.element.find("#settings_google_form").html(this.view("google_form"));
            this.element.find("#settings_google_form .error").addClass("hide");
            $(window).resize()
        },updateGoogleFormWithError:function(a) {
            if (!a ||
                    !a.error)a = {error:"POPUP_SIGNUP_LOGIN_FORM_GOOGLE_ERROR"};
            this.element.find("#settings_google_form .error").html($.localize.getString(a.error)).removeClass("hide");
            $(window).resize()
        },"#googleLogin-btn click":function() {
            GS.google.login(this.callback("updateGoogleForm"), this.callback("updateGoogleFormWithError"))
        },"a.google-logout click":function() {
            GS.google.logout(this.callback("updateGoogleForm"))
        },updateLastfmForm:function() {
            this.element.find("#settings_lastfm_form").html(this.view("lastfm_form"));
            $(window).resize()
        },"#lastfmConnect-btn click":function(a, b) {
            b.preventDefault();
            GS.user.UserID > 0 && GS.user.IsPremium ? GS.lastfm.authorize(this.callback("updateLastfmForm")) : GS.lightbox.open("vipOnlyFeature", {callback:function() {
                GS.lastfm.authorize(this.callback("updateLastfmForm"))
            }});
            return false
        },"a.lastfm-logout click":function() {
            GS.lastfm.logout(this.callback("updateLastfmForm"))
        },"#settings_userSubscriptions button.upgrade click":function(a, b) {
            b.preventDefault();
            var c,g = !this.noData && !this.recurring ?
                    1 : 0;
            if (GS.user.isLoggedIn)if (a.is(".plus")) {
                c = this.bVip ? "vip" : "plus";
                GS.lightbox.open("vipSignup", {vipPackage:c,bExtend:g})
            } else if (a.is(".anywhere")) {
                c = this.bVip ? "vip" : "anywhere";
                GS.lightbox.open("vipSignup", {vipPackage:c,bExtend:g})
            } else {
                c = this.bVip ? "vip" : "anywhere";
                GS.lightbox.open("vipSignup", {initOffers:true,vipPackage:c,bExtend:g})
            } else location.hash = "/signup";
            return false
        },"#settings_userSubscriptions button.extend click":function(a, b) {
            b.preventDefault();
            var c;
            c = this.subscriptionType.match("Anywhere") ?
                    "anywhere" : this.subscriptionType.match("Plus") ? "plus" : this.bVip == true || this.bVip == 1 ? "vip" : "plus";
            if (c === "vip" || c === "anywhere")GS.lightbox.open("vipSignup", {bExtend:1,vipPackage:this.bVip ? "vip" : c}); else location.hash = "/signup/upgrade"
        },"#settings_userSubscriptions button.cancel click":function(a, b) {
            b.preventDefault();
            GS.lightbox.open("vipCancel");
            return false
        },"a.feedback click":function() {
            GS.user.IsPremium && GS.lightbox.open("feedback")
        },"p.form_finePrint a.login click":function() {
            GS.lightbox.open("login")
        },
        "p.form_finePrint a.signup click":function() {
            location.hash = "/signup"
        },"#init_deactivate_account click":function(a, b) {
            b.preventDefault();
            GS.lightbox.open("deactivateAccount")
        },"#settings_desktop submit":function(a, b) {
            b.preventDefault();
            var c = {onClose:$("#settings_desktop input[name=settings_desktop_onClose]:checked").val(),onMinimize:$("#settings_desktop input[name=settings_desktop_onMinimize]:checked").val(),externalControlEnabled:$("#settings_desktop_globalKeyboard").is(":checked"),notifications:{songNotifications:$("#settings_desktop_songNotifications").is(":checked"),
                position:parseInt($("select[name=settings_desktop_notifPosition]", a).val(), 10),duration:parseInt($("select[name=settings_desktop_notifDuration]", a).val(), 10)}};
            this.desktopPrefs = c;
            GS.airbridge.setDesktopPreferences(c);
            $("#settings_desktop .form_buttons .status").addClass("success");
            return false
        }})
})();
GS.Controllers.PageController.extend("GS.Controllers.Page.SongController", {}, {type:"song",index:function(a, b) {
    this.url = location.hash;
    this.token = a || "";
    this.subpage = b || "comments";
    this.token ? GS.Models.Song.getSongFromToken(this.token, this.callback("loadSong")) : GS.router.notFound()
},loadSong:function(a) {
    if (a.validate()) {
        this.song = a;
        this.correctUrl(this.song, this.subpage === "comments" ? "" : this.subpage);
        this.id = this.song.SongID;
        this.fbCommentsUrl = "http://listen.grooveshark.com/" + this.song.toUrl().replace("#/",
                "");
        this.fbUrl = "http://grooveshark.com/" + this.song.toUrl().replace("#/", "");
        this.header.name = this.song.SongName;
        this.header.breadcrumbs = [
            {text:this.song.ArtistName,url:_.cleanUrl(this.song.ArtistName, this.song.ArtistID, "artist")},
            {text:this.song.AlbumName,url:_.cleanUrl(this.song.AlbumName, this.song.AlbumID, "album")}
        ];
        this.header.subpages = ["comments","related","fans"];
        this.header.options = false;
        this.list.doPlayAddSelect = true;
        this.list.doSearchInPage = true;
        this.list.sortOptions = [
            {text:"Track",column:"TrackNum"},
            {text:"Popularity",column:"Popularity"},
            {text:"Song Name",column:"Name"},
            {text:"Artist Name",column:"ArtistName"}
        ];
        this.list.useGrid = true;
        switch (this.subpage) {
            case "fans":
                this.element.html(this.view("fans"));
                $("input.search").select();
                $.publish("gs.page.loading.grid");
                GS.Controllers.PageController.title(this.song.getTitle() + " - fans");
                this.song.fanbase.getFans(this.callback("loadGridFans"), this.callback("loadGridFans"));
                break;
            case "related":
                this.element.html(this.view("related"));
                $("input.search").select();
                $.publish("gs.page.loading.grid");
                this.song.album = GS.Models.Album.getOneFromCache(this.song.AlbumID);
                this.triedUnverified = this.song.album ? this.song.album.songsLoaded && this.song.album.songsUnverifiedLoaded : false;
                GS.Controllers.PageController.title(this.song.getTitle() + " - related");
                this.song.getRelatedSongs(this.callback("loadRelatedGrid"));
                break;
            case "comments":
            default:
                this.song.album = GS.Models.Album.getOneFromCache(this.song.AlbumID);
                this.triedUnverified = this.song.album ? this.song.album.songsLoaded &&
                        this.song.album.songsUnverifiedLoaded : false;
                GS.Controllers.PageController.title(this.song.getTitle());
                this.element.html(this.view("index"));
                $("input.search").select();
                $("#page_header button.share").parent().show();
                if (window.FB && FB.XFBML && this.fbUrl) {
                    a = null;
                    if (FB._session && GS.facebook.connected) {
                        a = FB._session;
                        FB._session = {}
                    }
                    FB.XFBML.parse(window.document.getElementById("page_content"), function() {
                        $("#page_content .comments").removeClass("loadingFBComments");
                        $(window).resize()
                    });
                    if (a && GS.facebook.connected)FB._session =
                            a
                }
                this.songFans = [];
                this.relatedSongs = [];
                this.song.fanbase.getFans(this.callback("loadSidebarFans"), this.callback("loadSidebarFans"));
                this.song.getRelatedSongs(this.callback("loadSidebarRelated"));
                break
        }
        window.FB && FB.XFBML && FB.XFBML.parse(window.document.getElementById("page_header"))
    } else GS.router.notFound()
},loadSidebarFans:function(a) {
    if (this.subpage === "comments")if (a) {
        var b = [];
        for (var c in a)if (a.hasOwnProperty(c)) {
            if (b.length >= 4)break;
            if (a[c].Picture) {
                b.push(a[c]);
                a.splice(c, 1)
            }
        }
        this.songFans =
                b = b.concat(a);
        $("#song_fans").html(this.view("song_fans"));
        this.relatedSongs.length && $("#song_fans .bottomRule").show();
        $(window).resize()
    }
},loadSidebarRelated:function(a) {
    if (this.subpage === "comments")if ((!a || a.length < 4) && !this.triedUnverified) {
        this.triedUnverified = true;
        this.song.getRelatedSongs(this.callback("loadSidebarRelated"), null, false)
    } else {
        var b = 0;
        for (var c in a)if (a.hasOwnProperty(c)) {
            if (b++ >= 4)break;
            if (this.id == a[c].SongID) {
                a.splice(c, 1);
                break
            }
        }
        if (a.length) {
            this.relatedSongs = a;
            $("#song_related").html(this.view("song_related"));
            $("#song_fans .bottomRule").show();
            $(window).resize()
        }
    }
},loadGridFans:function(a) {
    if (this.subpage === "fans") {
        var b = store.get("gs.sort.song.fans") || {sortCol:"Name",sortDir:1,sortStoreKey:"gs.sort.song.fans"};
        if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.user, b, "user"); else {
            this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"user"}));
            $("#searchForm input").select();
            this.addAutocomplete("song")
        }
        $(window).resize()
    }
},loadRelatedGrid:function(a) {
    if (this.subpage ===
            "related") {
        var b = this.element.find(".gs_grid").controller(),c = store.get("gs.sort.song.related") || {sortCol:"TrackNum",sortStoreKey:"gs.sort.song.related"};
        c.filters = {artistIDs:false,albumIDs:false,onlyVerified:false};
        if (b) {
            c = b.dataView;
            var g = b.grid;
            if (c) {
                c.beginUpdate();
                c.addItems(a, "SongID");
                c.endUpdate();
                c.refresh()
            }
            g && g.onSort(b.sortCol, b.sortDir)
        } else if (a.length) {
            if (a.length < 5 && !this.triedUnverified) {
                this.triedUnverified = true;
                _.forEach(a, function(h) {
                    h.isVerified = -1
                });
                this.song.getRelatedSongs(this.callback("loadRelatedGrid"),
                        null, false)
            } else if (!this.triedUnverified) {
                b = GS.Models.Song.getVerifiedDivider();
                c.filters.onlyVerified = 1;
                a.push(b)
            }
            this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.song, c, "song");
            setTimeout(this.callback("selectCurrentSong"), 500)
        } else if (this.triedUnverified) {
            this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"song"}));
            $("#searchForm input").select();
            this.addAutocomplete("song")
        } else {
            this.triedUnverified = true;
            this.song.getRelatedSongs(this.callback("loadRelatedGrid"),
                    null, false)
        }
        $(window).resize()
    }
},selectCurrentSong:function() {
    var a = this.element.find(".gs_grid").controller();
    if (a) {
        var b = a.dataView.getIdxById(this.song.SongID),c = a.grid.getSelectedRows();
        c.push(b);
        a.selectedRowIDs.push(this.song.SongID);
        a.grid.setSelectedRows(c);
        a.grid.onSelectedRowsChanged()
    }
},".slick-row.verifiedDivider click":function(a, b) {
    b.stopPropagation();
    var c = c = $("#grid").controller(),g;
    if (c) {
        if (!this.triedUnverified) {
            this.triedUnverified = true;
            this.song.getRelatedSongs(this.callback("loadRelatedGrid"),
                    null, false)
        }
        if (c.filter.onlyVerified) {
            a.find(".showMore").addClass("showingMore").attr("data-translate-text", "SEARCH_RESULTS_SHOW_LESS").html($.localize.getString("SEARCH_RESULTS_SHOW_LESS"));
            c.filter.onlyVerified = false
        } else {
            a.find(".showMore").removeClass("showingMore").attr("data-translate-text", "SEARCH_RESULTS_SHOW_MORE").html($.localize.getString("SEARCH_RESULTS_SHOW_MORE"));
            c.filter.onlyVerified = 1
        }
        (g = c.grid) && g.onSort(c.sortCol, c.sortDir)
    }
},"a.songLink click":function(a) {
    (a = parseInt($(a).attr("rel"),
            10)) && GS.Models.Song.getSong(a, function(b) {
        if (b)location.hash = b.toUrl()
    })
}});
GS.Controllers.PageController.extend("GS.Controllers.Page.AlbumController", {}, {type:"album",index:function(a, b, c) {
    this.url = location.hash;
    this.id = parseInt(a, 10) || 0;
    this.subpage = b || "music";
    this.playOnView = c || false;
    this.id < 0 ? GS.router.notFound() : GS.Models.Album.getAlbum(this.id, this.callback("loadAlbum"))
},loadAlbum:function(a) {
    this.album = a;
    this.correctUrl(this.album, this.subpage === "music" ? "" : this.subpage);
    this.fbUrl = "http://grooveshark.com/" + this.album.toUrl().replace("#/", "");
    this.header.name = this.album.AlbumName;
    this.header.breadcrumbs = [
        {text:this.album.ArtistName,url:_.cleanUrl(this.album.ArtistName, this.album.ArtistID, "artist")},
        {text:"Albums",url:_.cleanUrl(this.album.ArtistName, this.album.ArtistID, "artist") + "/albums"}
    ];
    this.header.imageUrl = "http://beta.grooveshark.com/static/amazonart/s" + this.album.CoverArtFileName;
    this.header.subpages = ["music","fans"];
    this.header.options = false;
    this.list.doPlayAddSelect = true;
    this.list.doSearchInPage = true;
    this.list.useGrid = true;
    this.element.html(this.view("index"));
    $.publish("gs.page.loading.grid");
    $("input.search").select();
    if (this.subpage === "fans") {
        GS.Controllers.PageController.title(this.album.getTitle() + " - fans");
        this.album.fanbase.getFans(this.callback("loadGridFans"));
        $(".page_controls", this.element).hide()
    } else {
        this.triedUnverified = this.album.songsLoaded && this.album.songsUnverifiedLoaded;
        GS.Controllers.PageController.title(this.album.getTitle());
        this.album.getSongs(this.callback("loadGrid"), null, true);
        $(".page_controls", this.element).show()
    }
    window.FB && FB.XFBML && FB.XFBML.parse(window.document.getElementById("page_header"))
},
    loadGridFans:function(a) {
        if (this.subpage === "fans") {
            var b = store.get("gs.sort.album.fans") || {sortCol:"Name",sortDir:1,sortStoreKey:"gs.sort.albums.fans"};
            if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.user, b, "user"); else {
                this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"user"}));
                $("#searchForm input").select();
                this.addAutocomplete("album")
            }
        }
    },loadGrid:function(a) {
        if (this.subpage === "music") {
            var b = this.element.find(".gs_grid").controller(),
                    c = store.get("gs.sort.album.songs") || {sortCol:"TrackNum",sortStoreKey:"gs.sort.albums.songs"};
            c.autoHeight = true;
            c.padding = 0;
            c.filters = {artistIDs:false,albumIDs:false,onlyVerified:false};
            $("#grid").attr("data-profile-view", 1);
            if (b) {
                c = b.dataView;
                var g = b.grid;
                if (c) {
                    c.beginUpdate();
                    c.addItems(a, "SongID");
                    c.endUpdate();
                    c.refresh()
                }
                g && g.onSort(b.sortCol, b.sortDir)
            } else if (a.length) {
                if (a.length < 5 && !this.triedUnverified) {
                    this.triedUnverified = true;
                    _.forEach(a, function(h) {
                        h.isVerified = -1
                    });
                    this.album.getSongs(this.callback("loadGrid"),
                            null, false)
                } else if (!this.triedUnverified) {
                    b = GS.Models.Song.getVerifiedDivider();
                    a.push(b);
                    c.filters.onlyVerified = 1
                }
                if (this.playOnView && (a.length >= 5 || this.triedUnverified))this.album.play({playOnAdd:true});
                this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.albumSongs, c, "song")
            } else if (this.triedUnverified) {
                this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"song"}));
                $("#searchForm input").select();
                this.addAutocomplete("album")
            } else {
                this.triedUnverified =
                        true;
                this.album.getSongs(this.callback("loadGrid"), null, false)
            }
        }
    },".slick-row.verifiedDivider click":function(a, b) {
        b.stopPropagation();
        var c = c = $("#grid").controller(),g;
        if (c) {
            if (!this.triedUnverified) {
                this.triedUnverified = true;
                this.album.getSongs(this.callback("loadGrid"), null, false)
            }
            if (c.filter.onlyVerified) {
                a.find(".showMore").addClass("showingMore").attr("data-translate-text", "SEARCH_RESULTS_SHOW_LESS").html($.localize.getString("SEARCH_RESULTS_SHOW_LESS"));
                c.filter.onlyVerified = false
            } else {
                a.find(".showMore").removeClass("showingMore").attr("data-translate-text",
                        "SEARCH_RESULTS_SHOW_MORE").html($.localize.getString("SEARCH_RESULTS_SHOW_MORE"));
                c.filter.onlyVerified = 1
            }
            (g = c.grid) && g.onSort(c.sortCol, c.sortDir)
        }
    }});
GS.Controllers.PageController.extend("GS.Controllers.Page.ArtistController", {}, {type:"artist",index:function(a, b) {
    this.url = location.hash;
    this.id = parseInt(a, 10) || 0;
    this.subpage = b || "music";
    this.id < 0 ? GS.router.notFound() : GS.Models.Artist.getArtist(this.id, this.callback("loadArtist"))
},loadArtist:function(a) {
    this.artist = a;
    this.correctUrl(this.artist, this.subpage === "music" ? "" : this.subpage);
    this.fbUrl = "http://grooveshark.com/" + this.artist.toUrl().replace("#/", "");
    this.fbCommentsUrl = "http://grooveshark.com/" +
            this.artist.toUrl().replace("#/", "");
    this.element.html(this.view("index"));
    $("input.search").select();
    switch (this.subpage) {
        case "fans":
            $("#albumGrid").parent().remove();
            GS.Controllers.PageController.title(this.artist.getTitle() + " - Fans");
            this.artist.fanbase.getFans(this.callback("loadGridFans"));
            break;
        case "comments":
            $("#albumGrid").parent().remove();
            GS.Controllers.PageController.title(this.artist.getTitle() + " - Comments");
            this.element.html(this.view("index"));
            if (window.FB && FB.XFBML && this.fbUrl) {
                a =
                        null;
                if (FB._session && GS.facebook.connected) {
                    a = FB._session;
                    FB._session = {}
                }
                FB.XFBML.parse(window.document.getElementById("page_content"), function() {
                    $("#page_content .fullComments").removeClass("loadingFBComments");
                    $(window).resize()
                });
                if (a && GS.facebook.connected)FB._session = a
            }
            break;
        case "similar":
            $("#albumGrid").parent().remove();
            GS.Controllers.PageController.title(this.artist.getTitle() + " - Similar");
            GS.service.artistGetSimilarArtists(this.artist.ArtistID, this.callback("loadGridSimilar"), this.callback("loadGridSimilarFailed"));
            break;
        case "events":
            $("#albumGrid").parent().remove();
            GS.Controllers.PageController.title(this.artist.getTitle() + " - Events");
            GS.service.artistGetSongkickEvents(this.artist.ArtistID, this.artist.ArtistName, this.callback("loadGridEvents"), this.callback("loadGridEventsFailed"));
            break;
        default:
            this.triedUnverified = this.artist.songsLoaded && this.artist.songsUnverifiedLoaded;
            GS.Controllers.PageController.title(this.artist.getTitle());
            $.publish("gs.page.loading.grid");
            this.artist.getTunipopID().then(this.callback("loadTunipop"),
                    this.callback("loadTunipop"));
            this.artist.getSongs(this.callback("loadGrid"))
    }
    GS.facebook.getFacebookDetails(this.artist, function(b) {
        b.comments && $("#commentsCount").html(" (" + b.comments + ")")
    });
    window.FB && FB.XFBML && FB.XFBML.parse(window.document.getElementById("page_header"))
},loadTunipop:function(a) {
    if (a && a > 0) {
        this.tunipopID = parseInt(a, 10);
        $(".page_nav_option_merch").removeClass("hide")
    } else {
        this.tunipopID = 0;
        $(".page_nav_option_merch").addClass("hide")
    }
    $(window).resize()
},albumsSeen:{},loadGrid:function(a) {
    this.subpage ===
            "music" && setTimeout(this.callback(function() {
        var b,c = [],g = store.get("gs.sort.artist.songs") || {sortCol:"Popularity",sortDir:0,sortStoreKey:"gs.sort.artist.songs"},h = this.element.find(".gs_grid.songs").controller(),k = this.element.find(".gs_grid.albums").controller();
        g = $.extend(g, {filters:{artistIDs:false,albumIDs:false,onlyVerified:false}});
        if (a.length) {
            this.albumsSeen = {};
            for (b = 0; b < a.length; b++)if (!this.albumsSeen[a[b].SongID] && a[b].AlbumName && a[b].AlbumName.length) {
                var m = GS.Models.Album.wrap({AlbumName:a[b].AlbumName,
                    AlbumID:a[b].AlbumID,ArtistName:a[b].ArtistName,ArtistID:a[b].ArtistID,CoverArtFilename:a[b].CoverArtFilename}).dupe();
                m.isVerified = -1;
                c.push(m);
                this.albumsSeen[a[b].AlbumID] = true
            }
            b = GS.Models.Album.getFilterAll(this.artist.ArtistName);
            c.push(b)
        }
        $("#albumFilters").resizable({handles:{e:$("#albumFilter-resize")},minWidth:30,maxWidth:350,animate:false,resize:function() {
            $(window).resize()
        }});
        if (h) {
            g = h.dataView;
            c = h.grid;
            if (g) {
                g.beginUpdate();
                k.dataView.beginUpdate();
                g.addItems(a, "SongID");
                k.dataView.addItems(a,
                        "SongID");
                g.endUpdate();
                k.dataView.endUpdate();
                g.refresh();
                k.dataView.refresh();
                g = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:g.rows.length})).render();
                $("#gridNumItems").text(g).show()
            }
            if (c) {
                c.onSort(h.sortCol, h.sortDir);
                k.grid.onSort(k.sortCol, k.sortDir)
            }
        } else if (a.length) {
            if (a.length < 3E3 && !this.triedUnverified) {
                this.triedUnverified = true;
                this.artist.getSongs(this.callback("loadGrid"), null, false)
            }
            this.element.find(".gs_grid.songs").gs_grid(a, GS.Controllers.GridController.columns.song,
                    g, "song");
            this.element.find(".gs_grid.albums").gs_grid(c, GS.Controllers.GridController.columns.albumFilter, {rowHeight:25,sortCol:"AlbumName",isFilter:true}, "album");
            g = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:a.length})).render();
            $("#gridNumItems").text(g).show()
        } else if (this.triedUnverified) {
            this.element.find(".gs_grid.songs").html(this.view("/shared/noResults", {type:"song"}));
            $("#searchForm input").select();
            this.addAutocomplete("artist");
            g = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"),
                    {numSongs:"0"})).render();
            $("#gridNumItems").text(g).show()
        } else {
            this.triedUnverified = true;
            this.artist.getSongs(this.callback("loadGrid"), null, false)
        }
    }), 100)
},loadGridFans:function(a) {
    if (this.subpage === "fans") {
        var b = store.get("gs.sort.artist.fans") || {sortCol:"Name",sortDir:1,sortStoreKey:"gs.sort.artist.fans"};
        if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.user, b, "user"); else {
            this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"user"}));
            $("#searchForm input").select();
            this.addAutocomplete("artist")
        }
    }
},loadGridSimilar:function(a) {
    if (this.subpage === "similar") {
        a = GS.Models.Artist.wrapCollection(a.SimilarArtists, {USE_INDEX:"Sort"});
        if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.artist, {}, "artist"); else {
            this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"artist"}));
            $("#searchForm input").select();
            this.addAutocomplete("artist")
        }
    }
},loadGridSimilarFailed:function() {
    if (this.subpage ===
            "similar") {
        this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"artist"}));
        $("#searchForm input").select();
        this.addAutocomplete("artist")
    }
},loadGridEvents:function(a) {
    if (this.subpage === "events") {
        var b = {sortCol:"StartTime",sortDir:1,rowCssClasses:function() {
            return"event"
        }};
        a = GS.Models.Event.wrapCollection(a, {USE_INDEX:"EventID",ArtistName:this.artist.ArtistName});
        if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.event, b, "event"); else {
            this.element.find(".gs_grid").html(this.view("/shared/noResults",
                    {type:"event"}));
            $("#searchForm input").select();
            this.addAutocomplete("artist")
        }
    }
},loadGridEventsFailed:function() {
    if (this.subpage === "events") {
        this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"event"}));
        $("#searchForm input").select();
        this.addAutocomplete("artist")
    }
},".slick-row.verifiedDivider click":function(a, b) {
    b.stopImmediatePropagation();
    var c = $("#grid").controller(),g;
    if (c) {
        if (!this.triedUnverified) {
            this.triedUnverified = true;
            this.artist.getSongs(this.callback("loadGrid"),
                    null, false)
        }
        if (c.filter.onlyVerified) {
            a.find(".showMore").addClass("showingMore").attr("data-translate-text", "SEARCH_RESULTS_SHOW_LESS").html($.localize.getString("SEARCH_RESULTS_SHOW_LESS"));
            c.filter.onlyVerified = false
        } else {
            a.find(".showMore").removeClass("showingMore").attr("data-translate-text", "SEARCH_RESULTS_SHOW_MORE").html($.localize.getString("SEARCH_RESULTS_SHOW_MORE"));
            c.filter.onlyVerified = 1
        }
        (g = c.grid) && g.onSort(c.sortCol, c.sortDir)
    }
},"a.tunipop click":function(a) {
    a = parseInt($(a).attr("rel"),
            10);
    if (this.tunipopID)GS.lightbox.open("tunipop", {tunipopID:this.tunipopID}); else a && GS.lightbox.open("tunipop", {artistID:this.artistID})
}});
GS.Controllers.PageController.extend("GS.Controllers.Page.UserController", {}, {correctUrl:function(a, b, c) {
    this._super(a, b + (b && c ? "/" : "") + c)
},index:function(a) {
    this.UserID = parseInt(a, 10);
    GS.user.UserID == this.UserID ? this.loadMyProfile() : GS.Models.User.getUser(this.UserID, this.callback("loadProfile"));
    this.subscribe("gs.auth.user.update", this.callback("userUpdated"));
    this.subscribe("gs.auth.favorite.user", this.callback("userUpdated"));
    this.subscribe("gs.auth.favorites.users.update", this.callback("userFavoritesUpdated"))
},
    userChangeTimeout:false,userChangeWaitDuration:100,userFavoritesUpdated:function() {
        clearTimeout(this.userChangeTimeout);
        this.userChangeTimeout = setTimeout(this.callback(function() {
            if (this.user) {
                var a = GS.user.favorites.users[this.user.UserID];
                if (a)GS.user.UserID == this.user.UserID ? this.loadMyProfile() : this.loadProfile(a)
            }
        }), this.userChangeWaitDuration)
    },userUpdated:function(a) {
        clearTimeout(this.userChangeTimeout);
        this.userChangeTimeout = setTimeout(this.callback(function() {
            if (this.user && this.user.UserID ===
                    a.UserID)GS.user.UserID == this.user.UserID ? this.loadMyProfile() : this.loadProfile(a)
        }), this.userChangeWaitDuration)
    },loadMyProfile:function() {
        this.user = GS.user;
        this.UserID = this.user.UserID;
        this.subpage = this.section = "";
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle());
        this.element.html(this.view("profile"));
        $("input.search").select();
        $.publish("gs.page.loading.grid");
        this.user.getProfileFeed(this.callback("loadGridProfileFeed", this.user));
        this.user.getPlaylists(this.callback("loadProfilePlaylists", this.user));
        this.user.getFavoritesByType("Users", this.callback("loadProfileCommunity", this.user))
    },loadProfile:function(a) {
        this.user = a;
        this.UserID = this.user.UserID;
        this.subpage = this.section = "";
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle());
        this.element.html(this.view("profile"));
        $("input.search").select();
        $.publish("gs.page.loading.grid", this.user);
        this.user.getProfileFeed(this.callback("loadGridProfileFeed",
                this.user));
        this.user.getPlaylists(this.callback("loadProfilePlaylists", this.user));
        this.user.getFavoritesByType("Users", this.callback("loadProfileCommunity", this.user))
    },loadProfileCommunity:function(a) {
        if (!(this.subpage !== "" || this.section !== "")) {
            this.user = a;
            this.UserID = this.user.UserID;
            this.correctUrl(this.user, this.section, this.subpage);
            this.following = this.user.favorites.users;
            $("#profile_community").html(this.view("profile_community"))
        }
    },loadProfilePlaylists:function(a) {
        if (!(this.subpage !== "" ||
                this.section !== "")) {
            this.user = a;
            this.UserID = this.user.UserID;
            this.correctUrl(this.user, this.section, this.subpage);
            this.topPlaylists = _.toArray(this.user.playlists).sort(function(b, c) {
                return c.TSAdded > b.TSAdded
            });
            $("#profile_playlists").html(this.view("profile_playlists"))
        }
    },loadGridProfileFeed:function() {
        if (!(this.subpage !== "" || this.section !== "")) {
            if (!this.user.profileFeed.isLoaded)return false;
            this.activity = this.user.profileFeed.events;
            this.noFriends = false;
            if (this.activity.length) {
                this.element.find(".gs_grid").html(this.view("activity"));
                $("input.search").select()
            } else {
                this.element.find(".gs_grid").html(this.view("noActivityResults"));
                $("#searchForm input").select()
            }
            this.element.find(".event").each(this.callback(function(a, b) {
                $(b).data("event", this.activity[a]);
                this.activity[a].dataString.hookup($(b).find("p.what"))
            }));
            $(window).resize()
        }
    },music:function(a, b) {
        this.UserID = parseInt(a, 10);
        this.section = "music";
        this.subpage = _.orEqual(b, "");
        this.fromSidebar = GS.page.isFromSidebar();
        if (GS.user.UserID == this.UserID) {
            this.user = GS.user;
            this.UserID =
                    this.user.UserID;
            this.correctUrl(this.user, this.section, this.subpage);
            if (this.subpage === "favorites") {
                GS.Controllers.PageController.title(GS.user.getTitle() + " - Favorites");
                this.subscribe("gs.auth.favorites.songs.add", this.callback("addToGrid"));
                this.subscribe("gs.auth.favorites.songs.remove", this.callback("removeFromGrid"));
                this.subscribe("gs.auth.favorites.songs.update", this.callback("loadMySongFavorites"));
                this.loadMySongFavorites()
            } else {
                GS.Controllers.PageController.title(GS.user.getTitle() + " - Music");
                this.subscribe("gs.auth.library.add", this.callback("addToGrid"));
                this.subscribe("gs.auth.library.remove", this.callback("removeFromGrid"));
                this.subscribe("gs.auth.library.update", this.callback("loadGridMusic"));
                this.loadMyMusic()
            }
            this.element.find("#page_header button.opts").show()
        } else GS.Models.User.getUser(this.UserID, this.callback("loadMusic"))
    },redirectUser:function(a) {
        this.user = a;
        this.UserID = this.user.UserID;
        location.hash = this.user.toUrl();
        return false
    },loadMyMusic:function() {
        this.user = GS.user;
        this.UserID = this.user.UserID;
        this.section = "music";
        this.correctUrl(this.user, this.section, this.subpage);
        this.element.html(this.view("music"));
        $("input.search").select();
        var a = [];
        for (var b in GS.user.library.songs)if (GS.user.library.songs.hasOwnProperty(b)) {
            GS.user.library.songs[b].fromLibrary = 1;
            a.push(GS.user.library.songs[b])
        }
        this.loadGridMusic(a, true)
    },addToGrid:function(a) {
        if (this.UserID === GS.user.UserID) {
            a.isDeleted = false;
            var b = this.element.find(".gs_grid.songs").controller();
            if (b) {
                var c = this.element.find(".gs_grid.artists").controller(),
                        g = this.element.find(".gs_grid.albums").controller(),h = b.grid,k = b.dataView;
                if (k) {
                    k.beginUpdate();
                    k.addItem(a);
                    k.endUpdate();
                    k = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:k.rows.length})).render();
                    $("#gridNumItems").text(k).show()
                }
                h && h.onSort(b.sortCol, b.sortDir);
                if (!this.albumsSeen[a.AlbumID] && a.AlbumName && a.AlbumName.length) {
                    g.dataView.beginUpdate();
                    b = GS.Models.Album.wrap({AlbumName:a.AlbumName,AlbumID:a.AlbumID,ArtistName:a.ArtistName,ArtistID:a.ArtistID}).dupe();
                    b.isVerified = -1;
                    g.dataView.addItem(b);
                    g.dataView.endUpdate();
                    this.albumsSeen[a.AlbumID] = true;
                    g.grid && g.grid.onSort(g.sortCol, g.sortDir)
                }
                if (!this.artistsSeen[a.ArtistID] && a.ArtistName && a.ArtistName.length) {
                    c.dataView.beginUpdate();
                    g = GS.Models.Artist.wrap({ArtistName:a.ArtistName,ArtistID:a.ArtistID,CoverArtFilename:a.CoverArtFilename}).dupe();
                    g.isVerified = -1;
                    c.dataView.addItem(g);
                    c.dataView.endUpdate();
                    this.artistsSeen[a.ArtistID] = true;
                    c.grid && c.grid.onSort(c.sortCol, c.sortDir)
                }
            } else this.loadMyMusic()
        }
    },
    removeFromGrid:function(a) {
        a.isDeleted = true;
        var b = this.element.find(".gs_grid.songs").controller(),c = b.grid,g = b.dataView;
        if (g) {
            g.beginUpdate();
            g.updateItem(a.SongID, a);
            g.endUpdate()
        }
        c && c.onSort(b.sortCol, b.sortDir)
    },loadMySongFavorites:function() {
        this.user = GS.user;
        this.UserID = this.user.UserID;
        this.section = "music";
        this.correctUrl(this.user, this.section, this.subpage);
        this.element.html(this.view("music"));
        $("input.search").select();
        var a = [];
        for (var b in GS.user.favorites.songs)GS.user.favorites.songs.hasOwnProperty(b) &&
        a.push(GS.user.favorites.songs[b]);
        this.loadGridMusic(a)
    },loadMusic:function(a) {
        this.user = a;
        this.UserID = this.user.UserID;
        this.fromSidebar = false;
        this.element.html(this.view("music"));
        $("input.search").select();
        this.section = "music";
        this.correctUrl(this.user, this.section, this.subpage);
        if (this.subpage === "favorites") {
            GS.Controllers.PageController.title(this.user.getTitle() + " - Favorites");
            this.user.getFavoritesByType("Songs", this.callback("loadGridSongFavorites", true))
        } else {
            GS.Controllers.PageController.title(this.user.getTitle() +
                    " - Music");
            this.user.library.getSongs(this.callback("loadGridMusic"));
            this.user.getFavoritesByType("Songs", this.callback("loadGridSongFavorites", false))
        }
    },loadGridSongFavorites:function(a) {
        var b = [];
        for (var c in this.user.favorites.songs)this.user.favorites.songs.hasOwnProperty(c) && b.push(this.user.favorites.songs[c]);
        this.loadGridMusic(b, a)
    },albumsSeen:{},artistsSeen:{},loadGridMusic:function(a, b) {
        setTimeout(this.callback(function() {
            var c,g,h = [],k = [],m;
            g = store.get("gs.sort.user.music") || {sortCol:"TSAdded",
                sortDir:0,sortStoreKey:"gs.sort.user.music"};
            m = this.element.find(".gs_grid.songs").controller();
            artistController = this.element.find(".gs_grid.artists").controller();
            albumController = this.element.find(".gs_grid.albums").controller();
            b = _.orEqual(b, false);
            this.albumsSeen = {};
            this.artistsSeen = {};
            g.rowCssClasses = function(o) {
                return o.isDeleted ? "strikethrough" : ""
            };
            if (a)for (c = 0; c < a.length; c++) {
                if (!this.albumsSeen[a[c].AlbumID] && a[c].AlbumName && a[c].AlbumName.length) {
                    var n = GS.Models.Album.wrap({AlbumName:a[c].AlbumName,
                        AlbumID:a[c].AlbumID,ArtistName:a[c].ArtistName,ArtistID:a[c].ArtistID}).dupe();
                    n.isVerified = -1;
                    h.push(n);
                    this.albumsSeen[a[c].AlbumID] = true
                }
                if (!this.artistsSeen[a[c].ArtistID]) {
                    n = GS.Models.Artist.wrap({ArtistName:a[c].ArtistName,ArtistID:a[c].ArtistID,CoverArtFilename:a[c].CoverArtFilename}).dupe();
                    n.isVerified = -1;
                    k.push(n);
                    this.artistsSeen[a[c].ArtistID] = true
                }
            }
            $("#artistFilters").resizable({handles:{e:$("#artistFilter-resize")},minWidth:30,maxWidth:350,animate:false,resize:function() {
                $(window).resize()
            }});
            $("#albumFilters").resizable({handles:{e:$("#albumFilter-resize")},minWidth:30,maxWidth:350,animate:false,resize:function() {
                $(window).resize()
            }});
            c = GS.Models.Album.getFilterAll();
            h.push(c);
            c = GS.Models.Artist.getFilterAll();
            k.push(c);
            if (m) {
                c = m.dataView;
                g = m.grid;
                if (c) {
                    c.beginUpdate();
                    albumController.dataView.beginUpdate();
                    artistController.dataView.beginUpdate();
                    if (b) {
                        c.setItems(a, "SongID");
                        albumController.dataView.setItems(h, "AlbumID");
                        artistController.dataView.setItems(k, "ArtistID")
                    } else {
                        c.addItems(a,
                                "SongID");
                        albumController.dataView.addItems(h, "AlbumID");
                        artistController.dataView.addItems(k, "ArtistID")
                    }
                    c.endUpdate();
                    albumController.dataView.endUpdate();
                    artistController.dataView.endUpdate();
                    c.refresh();
                    albumController.dataView.refresh();
                    artistController.dataView.refresh();
                    h = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:c.rows.length})).render();
                    $("#gridNumItems").text(h).show()
                }
                if (g) {
                    g.onSort(m.sortCol, m.sortDir);
                    albumController.grid.onSort(albumController.sortCol,
                            albumController.sortDir);
                    artistController.grid.onSort(artistController.sortCol, artistController.sortDir)
                }
            } else {
                if (a && a.length) {
                    m = GS.Controllers.GridController.columns.song.concat();
                    m = [m[0],m[1],m[2]];
                    this.element.find(".gs_grid.songs").gs_grid(a, m, g);
                    this.element.find(".gs_grid.albums").gs_grid(h, GS.Controllers.GridController.columns.albumFilter, {rowHeight:25,sortCol:"AlbumName",isFilter:true}, "album");
                    this.element.find(".gs_grid.artists").gs_grid(k, GS.Controllers.GridController.columns.artistFilter,
                            {rowHeight:25,sortCol:"ArtistName",isFilter:true}, "artist");
                    h = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:a.length})).render()
                } else {
                    this.element.find(".grid").html(this.view("noMusicResults"));
                    $("#searchForm input").select();
                    this.addAutocomplete("user");
                    h = (new GS.Models.DataString($.localize.getString("QUEUE_NUM_SONGS"), {numSongs:"0"})).render()
                }
                $("#gridNumItems").text(h).show()
            }
            this.subpage !== "favorites" && !this.user.library.songsLoaded && GS.user.UserID != this.UserID &&
            this.user.library.getSongs(this.callback("loadGridMusic"), null, false)
        }), 100)
    },playlists:function(a, b) {
        this.UserID = a;
        this.section = "playlists";
        this.subpage = b;
        if (b === "subscribed") {
            if (GS.user.UserID == this.UserID) {
                this.user = GS.user;
                this.correctUrl(this.user, this.section, this.subpage);
                this.loadMySubscribedPlaylists(GS.user)
            } else GS.Models.User.getUser(this.UserID, this.callback("loadSubscribedPlaylists"));
            this.subscribe("gs.auth.favorites.playlists.update", this.callback("loadGridSubscribedPlaylists"))
        } else if (GS.user.UserID ==
                this.UserID) {
            this.user = GS.user;
            this.correctUrl(this.user, this.section, this.subpage);
            this.loadMyPlaylists();
            this.subscribe("gs.auth.playlists.update", this.callback("loadGridPlaylists"));
            this.subscribe("gs.auth.favorites.playlists.update", this.callback("loadGridPlaylists"))
        } else GS.Models.User.getUser(this.UserID, this.callback("loadPlaylists"));
        $(window).resize()
    },loadMyPlaylists:function() {
        this.user = GS.user;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() +
                " - Playlists");
        this.element.html(this.view("playlists"));
        this.loadGridPlaylists();
        $("input.search").select()
    },loadMySubscribedPlaylists:function() {
        this.user = GS.user;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Subscribed Playlists");
        this.element.html(this.view("playlists"));
        this.loadGridSubscribedPlaylists();
        $("input.search").select()
    },loadPlaylists:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() +
                " - Playlists");
        this.element.html(this.view("playlists"));
        this.user.getPlaylists(this.callback("loadGridPlaylists"));
        $("input.search").select()
    },loadSubscribedPlaylists:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Subscribed Playlists");
        this.element.html(this.view("playlists"));
        this.user.getFavoritesByType("Playlists", this.callback("loadGridSubscribedPlaylists"));
        $("input.search").select()
    },loadGridPlaylists:function() {
        if (this.user)if (this.subpage !==
                "subscribed") {
            var a = _.toArray(this.user.playlists),b,c;
            b = store.get("gs.sort.user.playlists") || {sortCol:"TSAdded",sortDir:0,sortStoreKey:"gs.sort.user.playlists"};
            var g = this.element.find(".gs_grid.playlists").controller();
            if (g) {
                b = g.dataView;
                c = g.grid;
                if (b) {
                    b.beginUpdate();
                    b.setItems(a, "PlaylistID");
                    b.endUpdate();
                    b.refresh()
                }
                c && c.onSort(g.sortCol, g.sortDir)
            } else if (a.length)this.element.find(".gs_grid.playlists").gs_grid(a, GS.Controllers.GridController.columns.playlist, b, "playlist"); else {
                this.element.find(".gs_grid.playlists").html(this.view("noPlaylistResults"));
                $("#searchForm input").select();
                this.addAutocomplete("user")
            }
        }
    },loadGridSubscribedPlaylists:function() {
        if (this.user)if (!(!this.user || this.subpage !== "subscribed")) {
            var a = _.toArray(this.user.favorites.playlists),b,c;
            b = store.get("gs.sort.user.subscribed") || {sortCol:"TSFavorited",sortDir:0,sortStoreKey:"gs.sort.user.subscribed"};
            var g = this.element.find(".gs_grid").controller();
            if (b.sortCol == "TSAdded") {
                b.sortCol = "TSFavorited";
                store.remove("gs.sort.user.subscribed")
            }
            if (g) {
                b = g.dataView;
                c = g.grid;
                if (b) {
                    b.beginUpdate();
                    b.setItems(a, "PlaylistID");
                    b.endUpdate();
                    b.refresh()
                }
                c && c.onSort(g.sortCol, g.sortDir)
            } else if (a.length)this.element.find(".gs_grid.playlists").gs_grid(a, GS.Controllers.GridController.columns.playlist, b, "playlist"); else {
                this.element.find(".gs_grid.playlists").html(this.view("noPlaylistResults"));
                $("#searchForm input").select();
                this.addAutocomplete("user")
            }
        }
    },myCommunity:false,noFriends:false,community:function(a, b) {
        this.UserID = a;
        this.section = "community";
        this.subpage = b;
        this.currentFilterStr = "";
        if (b ==
                "following")GS.user.UserID == this.UserID ? this.loadFollowing(GS.user) : GS.Models.User.getUser(this.UserID, this.callback("loadFollowing")); else if (b == "fans")GS.user.UserID == this.UserID ? this.loadFans(GS.user) : GS.Models.User.getUser(this.UserID, this.callback("loadFans")); else if (b == "recent")GS.user.UserID == this.UserID ? this.loadRecentActiveFeed(GS.user) : GS.Models.User.getUser(this.UserID, this.callback("loadRecentActiveFeed")); else if (GS.user.UserID == this.UserID) {
            this.loadCommunity(GS.user);
            this.myCommunity =
                    true
        } else GS.Models.User.getUser(this.UserID, this.callback("loadCommunity"))
    },loadCommunity:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Community");
        this.element.html(this.view("community"));
        $.publish("gs.page.loading.grid");
        $("input.search").select();
        _.isEmpty(a.favorites.users) && this.user.UserID > 0 ? this.user.getFavoritesByType("Users", this.callback("loadCommunityFeed")) : this.loadCommunityFeed()
    },loadCommunityFeed:function() {
        this.users =
                this.user.favorites.users;
        this.user.getCommunityFeed(this.callback("loadGridCommunityFeed", this.user))
    },loadGridCommunityFeed:function() {
        if (!this.user.communityFeed.isLoaded)return false;
        this.activity = this.user.communityFeed.events;
        this.noFriends = this.user.communityFeed.fromRecent;
        if (this.user === GS.user) {
            this.myCommunity = true;
            if (this.user.communityFeed.events.length)this.user.lastSeenFeedEvent = this.user.communityFeed.events[0].time;
            this.user.countUnseenFeeds()
        }
        if (this.activity.length) {
            this.element.find(".gs_grid").html(this.view("activity"));
            $("input.search").select()
        } else {
            this.element.find(".gs_grid").html(this.view("noActivityResults"));
            $("#searchForm input").select()
        }
        this.element.find(".event").each(this.callback(function(a, b) {
            $(b).data("event", this.activity[a]);
            this.activity[a].dataString.hookup($(b).find("p.what"))
        }));
        $(window).resize()
    },loadRecentActiveFeed:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Recent Activity");
        this.element.html(this.view("community"));
        $.publish("gs.page.loading.grid");
        this.user.getRecentlyActiveUsersFeed(this.callback("loadGridRecentActiveFeed"));
        $("input.search").select()
    },loadGridRecentActiveFeed:function() {
        this.activity = this.user.recentActiveUsersFeed.events;
        this.noFriends = false;
        if (this.activity.length) {
            this.element.find(".gs_grid").html(this.view("activity"));
            $("input.search").select()
        } else {
            this.element.find(".gs_grid").html(this.view("/shared/noResults", {type:"activity"}));
            $("#searchForm input").select()
        }
        this.element.find(".event").each(this.callback(function(a, b) {
            $(b).data("event", this.activity[a]);
            this.activity[a].dataString.hookup($(b).find("p.what"))
        }));
        $(window).resize()
    },loadFollowing:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Following");
        this.element.html(this.view("community"));
        this.user.getFavoritesByType("Users", this.callback("renderFollows"))
    },renderFollows:function() {
        var a = $("body").width() <= 1024 || $("body").height() <= 700;
        this.followUsers = _.toArray(this.user.favorites.users);
        this.followUsers.sort(this.sortByPictureAlphabet);
        if (this.followUsers.length) {
            var b = this.followUsers.filter(this.callback("filterUsersFunction"));
            $("#grid").html("").css("height", "auto").addClass("userlist");
            this.slickbox = $("#grid").slickbox({scrollPane:"#page_content",padding:15,listClass:a ? "smallUserView" : "",itemRenderer:GS.Models.User.itemRenderer,itemWidth:a ? 175 : 130,itemHeight:a ? 50 : 185,maxHorizontalGap:100,minHorizontalGap:15,verticalGap:15}, b)
        } else $("#grid").html(this.view("noFollowResults"))
    },
    loadFans:function(a) {
        this.user = a;
        this.correctUrl(this.user, this.section, this.subpage);
        GS.Controllers.PageController.title(this.user.getTitle() + " - Fans");
        this.element.html(this.view("community"));
        this.user.fanbase.getFans(this.callback("renderFans"))
    },renderFans:function(a) {
        var b = $("body").width() <= 1024 || $("body").height() <= 700;
        this.fanUsers = a;
        this.fanUsers.sort(this.sortByPictureAlphabet);
        if (this.fanUsers.length) {
            a = this.fanUsers.filter(this.callback("filterUsersFunction"));
            $("#grid").html("").css("height",
                    "auto").addClass("userlist");
            this.slickbox = $("#grid").slickbox({scrollPane:"#page_content",padding:15,listClass:b ? "smallUserView" : "",itemRenderer:GS.Models.User.itemRenderer,itemWidth:b ? 175 : 130,itemHeight:b ? 50 : 185,maxHorizontalGap:15,minHorizontalGap:15,verticalGap:15}, a)
        } else $("#grid").html(this.view("noFanResults"))
    },sortByPictureAlphabet:function(a, b) {
        return!a.Picture && b.Picture ? 1 : a.Picture && !b.Picture ? -1 : a.Name.toLowerCase() < b.Name.toLowerCase() ? -1 : a.Name.toLowerCase() > b.Name.toLowerCase() ? 1 :
                0
    },resize:function() {
        if (this.subpage == "fans")this.fanUsers && this.fanUsers.length && this.renderFans(this.fanUsers); else this.subpage == "following" && this.followUsers && this.followUsers.length && this.renderFollows(this.followUsers)
    },currentFilterStr:null,filterUsers:function(a) {
        if (this.currentFilterStr != a) {
            this.currentFilterStr = a;
            if (this.subpage == "fans")GS.user.UserID == this.UserID && this.fanUsers && this.renderFans(this.fanUsers); else this.subpage == "following" && GS.user.UserID == this.UserID && this.renderFollows(this.followUsers)
        }
    },
    filterUsersFunction:function(a) {
        return(a.Username.toLowerCase() + " " + a.Name.toLowerCase()).indexOf(this.currentFilterStr.toLowerCase()) !== -1
    },"#feed .event .hideUser click":function(a) {
        a = parseInt($(a).attr("rel"), 10);
        this.find("#feed .user" + a).remove();
        GS.user.changeFollowFlags([
            {userID:a,flags:1}
        ])
    },"button.invite click":function() {
        this.UserID == GS.user.UserID && GS.user.UserID > 0 && GS.lightbox.open("invite")
    },"#page_header a[name=delete] click":function() {
        var a = $("#grid").controller();
        if (a) {
            var b,c = a.grid.getSelectedRows();
            if (c.length !== 0) {
                for (var g = 0; g < c.length; g++) {
                    $("#grid").find(".slick-row[row=" + c[g] + "]").addClass("strikethrough");
                    if (b = a.dataView.rows[c[g]])this.subpage === "favorites" ? GS.user.removeFromSongFavorites(b.SongID) : GS.user.removeFromLibrary(b.SongID)
                }
                a.grid.setSelectedRows([]);
                a.selectedRowIDs = [];
                $.publish("gs.grid.selectedRows", {len:0})
            }
        }
    },"#page_header button.newPlaylist, a.newPlaylist click":function() {
        GS.lightbox.open("newPlaylist")
    },".slick-row .playlist .subscribe click":function(a) {
        var b = a.attr("rel");
        b = GS.Models.Playlist.getOneFromCache(b);
        if (a.is(".subscribed")) {
            b.unsubscribe();
            a.removeClass("subscribed").find("a.subscribe span").text("Subscribe")
        } else {
            b.subscribe();
            a.addClass("subscribed").find("a.subscribe span").text("Unsubscribe")
        }
    }});
GS.Controllers.PageController.extend("GS.Controllers.Page.PlaylistController", {}, {type:"playlist",index:function(a, b, c) {
    this.url = location.hash;
    this.id = parseInt(a, 10) || 0;
    this.subpage = b || "music";
    this.playOnView = c || false;
    this.subscribe("gs.playlist.view.update", this.callback("onPlaylistUpdate"));
    GS.Models.Playlist.getPlaylist(this.id, this.callback("loadPlaylist"))
},loadPlaylist:function(a) {
    this.playlist = a;
    this.fromSidebar = GS.page.isFromSidebar();
    this.correctUrl(this.playlist, this.subpage === "music" ? "" :
            this.subpage);
    this.fbUrl = "http://grooveshark.com/" + this.playlist.toUrl().replace("#/", "");
    this.header.name = _.cleanText(this.playlist.PlaylistName);
    this.header.breadcrumbs = [
        {text:this.playlist.UserName,url:_.cleanUrl(this.playlist.UserID, this.playlist.UserName, "user")},
        {text:"Playlists",url:_.cleanUrl(this.playlist.UserID, this.playlist.UserName, "user", null, "playlists")}
    ];
    this.header.subpages = ["music","fans"];
    this.header.options = false;
    this.list.doPlayAddSelect = true;
    this.list.doSearchInPage = true;
    this.list.sortOptions =
            [
                {text:"Popularity",column:"Popularity"},
                {text:"Song Name",column:"Name"},
                {text:"Favorite",column:"Favorite"},
                {text:"Artist Name",column:"ArtistName"},
                {text:"Album Name",column:"AlbumName"}
            ];
    this.list.useGrid = true;
    this.element.html(this.view("index"));
    $("input.search").select();
    switch (this.subpage) {
        case "fans":
            GS.Controllers.PageController.title(this.playlist.getTitle() + " - fans");
            this.playlist.fanbase.getFans(this.callback("loadGridFans"));
            $(".page_controls", this.element).hide();
            break;
        default:
            $("#page_header button.share").parent().show();
            GS.Controllers.PageController.title(this.playlist.getTitle());
            this.playlist.getSongs(this.callback("loadGrid"));
            this.updatePlaylistProps(this.playlist);
            $(".page_controls", this.element).show();
            break
    }
    this.id > 0 && FB.XFBML.parse(window.document.getElementById("page_header"));
    GS.Controllers.PageController.confirmMessage = $.localize.getString("ONCLOSE_SAVE_PLAYLIST")
},updatePlaylistProps:function(a) {
    if (!(!this.playlist || this.playlist.PlaylistID !== a.PlaylistID)) {
        if (this.playlist.hasUnsavedChanges) {
            $("button.save",
                    this.element).show();
            $("button.undo", this.element).show()
        } else {
            $("button.save", this.element).hide();
            $("button.undo", this.element).hide()
        }
        if (this.playlist.isDeleted) {
            $("h3.name", this.element).addClass("strikethrough");
            $("#page_header a[name=delete]").parent().css("display", "none");
            $("#page_header a[name=restore]").parent().css("display", "block")
        } else {
            $("h3.name", this.element).removeClass("strikethrough");
            $("#page_header a[name=delete]").parent().css("display", "block");
            $("#page_header a[name=restore]").parent().css("display",
                    "none")
        }
        if (GS.user.UserID !== this.playlist.UserID)if (this.playlist.isFavorite) {
            $("#page_header button.unsubscribe").show();
            $("#page_header button.subscribe").hide()
        } else {
            $("#page_header button.subscribe").show();
            $("#page_header button.unsubscribe").hide()
        }
        if (this.playlist.isShortcut()) {
            $("#page_header a[name=shortcut]").parent().hide();
            $("#page_header a[name=removeshortcut]").parent().show()
        } else {
            $("#page_header a[name=shortcut]").parent().show();
            $("#page_header a[name=removeshortcut]").parent().hide()
        }
    }
},
    onPlaylistUpdate:function(a) {
        if (!(!this.playlist || this.playlist.PlaylistID !== a.PlaylistID)) {
            this.updatePlaylistProps(a);
            this.subpage != "fans" && this.playlist.getSongs(this.callback("loadGrid"))
        }
    },loadGrid:function(a) {
        if (this.subpage === "music") {
            var b = {sortCol:"Sort",sortDir:1,sortStoreKey:"gs.sort.playlist.songs"},c = this.element.find(".gs_grid").controller();
            if (c) {
                a = c.dataView;
                b = c.grid;
                if (a) {
                    var g,h,k,m,n = this.playlist.songs.concat();
                    inGrid = a.getItems().concat();
                    a.beginUpdate();
                    for (k = 0; k < inGrid.length; k++) {
                        g =
                                inGrid[k];
                        m = n.indexOf(g);
                        m != -1 && n.splice(m, 1);
                        a.getIdxById(g.GridKey);
                        h = this.playlist.songs.indexOf(g);
                        h == -1 ? a.deleteItem(g.GridKey) : a.updateItem(g.GridKey, g)
                    }
                    n.length && a.addItems(n, "GridKey");
                    a.endUpdate();
                    a.refresh()
                }
                b && b.onSort(c.sortCol, c.sortDir)
            } else {
                if (GS.user.UserID === this.playlist.UserID) {
                    b.allowDragSort = true;
                    b.allowDuplicates = true;
                    b.playlistID = this.playlist.PlaylistID
                }
                if (a.length) {
                    this.playOnView && this.playlist.play({playOnAdd:true});
                    b.rowCssClasses = function(r) {
                        return r.isDeleted ? "strikethrough" :
                                ""
                    };
                    $(".grid").unbind("dropend");
                    this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.song, b, "song", "GridKey")
                } else {
                    this.element.find(".gs_grid").html(this.view("noResults"));
                    $("#searchForm input").select();
                    this.addAutocomplete("playlist");
                    var o = this;
                    $(".grid").bind("dropend", function(r, t) {
                        if ($("#grid").controller())return false;
                        var w = [];
                        if (typeof t.draggedItems[0].SongID !== "undefined")for (k = 0; k < t.draggedItems.length; k++)w.push(t.draggedItems[k].SongID); else if (typeof t.draggedItems[0].PlaylistID !==
                                "undefined")for (k = 0; k < t.draggedItems.length; k++)t.draggedItems[k].getSongs(function(y) {
                            for (m = 0; m < y.length; m++)w.push(y[m].SongID)
                        }, null, false, {async:false});
                        w.length && o.playlist.addSongs(w)
                    })
                }
                $(window).resize()
            }
        }
    },loadGridFans:function(a) {
        if (this.subpage === "fans") {
            var b = store.get("gs.sort.playlist.fans") || {sortCol:"Name",sortDir:1,sortStoreKey:"gs.sort.playlist.fans"};
            if (a.length)this.element.find(".gs_grid").gs_grid(a, GS.Controllers.GridController.columns.user, b, "user"); else {
                this.element.find(".gs_grid").html(this.view("/shared/noResults",
                        {type:"user"}));
                $("#searchForm input").select();
                this.addAutocomplete("playlist")
            }
        }
    },getSongsIDsFromSelectedGridRows:function() {
        var a = this.element.find(".gs_grid:last").controller(),b = [],c;
        if (a && a.selectedRowIDs.length > 0)for (c = 0; c < a.selectedRowIDs.length; c++) {
            var g = this.playlist.gridKeyLookup[a.selectedRowIDs[c]];
            g && b.push(g.SongID)
        } else for (c = 0; c < a.dataView.rows.length; c++)b.push(a.dataView.rows[c].SongID);
        return b
    },"#page_header a[name=rename] click":function() {
        GS.lightbox.open("renamePlaylist",
                this.playlist.PlaylistID)
    },"#page_header a[name=delete] click":function() {
        GS.lightbox.open("deletePlaylist", this.playlist.PlaylistID)
    },"#page_header a[name=restore] click":function() {
        this.playlist.restore()
    },"#page_header a[name=shortcut] click":function() {
        this.playlist.addShortcut();
        $("#page_header a[name=shortcut]").parent().hide();
        $("#page_header a[name=removeshortcut]").parent().show()
    },"#page_header a[name=removeshortcut] click":function() {
        this.playlist.removeShortcut();
        $("#page_header a[name=shortcut]").parent().show();
        $("#page_header a[name=removeshortcut]").parent().hide()
    },"#page_header button.deleteSongs click":function() {
        var a = this.element.find(".gs_grid:last").controller(),b = [],c;
        if (a && a.selectedRowIDs.length > 0)for (c = 0; c < a.selectedRowIDs.length; c++) {
            var g = this.playlist.gridKeyLookup[a.selectedRowIDs[c]];
            g && b.push(this.playlist.songs.indexOf(g))
        }
        b.length && this.playlist.removeSongs(b)
    },"#page_header button.save click":function() {
        this.playlist.save()
    },"#page_header button.undo click":function() {
        this.playlist.undo()
    },
    "#page_header button.subscribe click":function() {
        this.playlist.subscribe();
        $("#page_header button.subscribe").hide();
        $("#page_header button.unsubscribe").show()
    },"#page_header button.unsubscribe click":function() {
        this.playlist.unsubscribe();
        $("#page_header button.subscribe").show();
        $("#page_header button.unsubscribe").hide()
    }});
GS.Controllers.PageController.extend("GS.Controllers.Page.SearchController", {cache:{}}, {defaultType:"song",validTypes:{song:true,playlist:true,user:true,event:true,album:true,artist:true},query:"",type:"",ppOverride:false,originalUsers:null,searchUsers:null,startTimes:{},currentFilterStr:null,currentSort:null,everythingSearch:false,adParams:[],wideScreen:false,prefetchSize:3,init:function() {
    this.subscribe("window.resize", this.callback("resize"))
},index:function(a, b) {
    this.ppOverride = _.orEqual(GS.user.searchVersion,
            false);
    if (b.indexOf("ppVersion:", 0) === 0) {
        queryAsArray = b.split(/\s+/);
        this.ppOverride = queryAsArray[0].split(":")[1];
        b = queryAsArray.splice(1, queryAsArray.length).join(" ")
    }
    this.query = _.orEqual(b, "").replace(/\s+/g, " ");
    this.cleanQuery = _.cleanText(this.query);
    this.type = _.orEqual(a, "");
    this.everythingSearch = this.type == "";
    if (this.type && !this.validTypes[this.type])this.type = this.defaultType;
    GS.search.lastSearch = GS.search.search;
    GS.search.lastType = GS.search.type;
    GS.search.search = this.query;
    (GS.search.type =
            this.type) ? GS.Controllers.PageController.title("All " + _.ucwords(this.type) + " Results: " + this.query) : GS.Controllers.PageController.title("Search: " + this.query);
    this.element.html(this.view("index"));
    $("input[name=q]", this.element).val(this.query);
    $("input.search").select();
    if (this.query === "") {
        this.element.find(".gs_grid." + a).html(this.view("noResults"));
        $(".gs_grid input[name=q]", this.element).val(this.query);
        $("#searchForm input").select();
        this.addAutocomplete("search");
        GS.guts.logEvent("search", {type:this.type ||
                "everything",searchString:this.query,searchTime:0,numResults:0});
        GS.guts.beginContext({mostRecentSearch:this.query,mostRecentSearchType:this.type || "everything",mostRecentSearchVersion:""})
    } else {
        $("#page_search a.remove").removeClass("hide");
        $.publish("gs.page.loading.grid");
        if (this.type) {
            this.startTimes[this.type] = (new Date).getTime();
            this.getResults();
            this.suggest()
        } else {
            this.startTimes.song = (new Date).getTime();
            this.getResults(false, "song", this.callback(function() {
                var c = (new Date).getTime();
                this.startTimes.artist =
                        c;
                this.startTimes.album = c;
                this.startTimes.playlist = c;
                this.startTimes.user = c;
                this.getResults(this.callback(function(g) {
                    if ($("#page_content").is(".profile.search")) {
                        this.artists = g && g.length ? g.slice(0, 4) : [];
                        $("#searchArtists").html(this.view("topArtists"))
                    }
                }), "artist", this.callback(function() {
                    if ($("#page_content").is(".profile.search"))if (!GS.user.IsPremium) {
                        this.adParams = ["q=" + this.query,"t=" + (this.type || "song")];
                        this.artists && this.artists[0] && this.adParams.push("7=" + this.artists[0].ArtistID, "8=" + this.artists[0].ArtistName);
                        this.iframeAd()
                    }
                }));
                this.getResults(this.callback(function(g) {
                    if ($("#page_content").is(".profile.search")) {
                        this.albums = g && g.length ? g.slice(0, 4) : [];
                        $("#searchAlbums").html(this.view("topAlbums"))
                    }
                }), "album");
                this.getResults(this.callback(function(g) {
                    if ($("#page_content").is(".profile.search")) {
                        this.playlists = g && g.length ? g.slice(0, 4) : [];
                        $("#searchPlaylists").html(this.view("topPlaylists"))
                    }
                }), "playlist");
                this.getResults(this.callback(function(g) {
                    if ($("#page_content").is(".profile.search")) {
                        this.users =
                                g && g.length ? g.slice(0, 4) : [];
                        $("#searchUsers").html(this.view("topUsers"))
                    }
                }), "user");
                this.suggest()
            }))
        }
    }
},iframeAd:function() {
    var a = 200,b = 200;
    if (GS.wideScreen) {
        a = 300;
        b = 250
    }
    $("#page_content").toggleClass("wideScreen", GS.wideScreen);
    var c = GS.ad.buildParams(this.adParams.concat(["w=" + a,"h=" + b]));
    a = $('<iframe id="searchCapitalFrame" name="searchCapitalFrame" height="' + b + '" width="' + a + '" frameborder="0" ></iframe>');
    a.attr("src", "/dfpSearchAds.php" + c);
    $("#searchCapitalWrapper").show();
    $("#searchCapital").html(a).show()
},
    getResults:function(a, b, c) {
        var g = this.type,h = "",k = this.callback(function(m, n, o) {
            if (m === this.query) {
                var r,t,w = false,y = {sortCol:"Score",sortDir:0};
                GS.Controllers.Page.SearchController.cache[n] = o;
                if ($.isArray(o.result)) {
                    if ($.isArray(g) && g.length === 1)g = g[0];
                    g = g.substring(0, g.length - 1);
                    t = g == "Playlist" ? GS.Models[_.ucwords(g)].wrapCollection(o.result, {ppVersion:""}, false, false, false) : GS.Models[_.ucwords(g)].wrapCollection(o.result, {ppVersion:""})
                } else {
                    t = {};
                    _.forEach(o.result, function(H, A) {
                        var x = A.substring(0,
                                A.length - 1);
                        t[x] = g == "Playlist" ? GS.Models[x].wrapCollection(H, null, false, false, false) : GS.Models[x].wrapCollection(H)
                    })
                }
                if (t && t.length) {
                    g = g.toLowerCase();
                    if (g === "song") {
                        r = GS.Controllers.GridController.columns.song.concat();
                        m = [r[0],r[1],r[2]];
                        if (!this.type) {
                            if (t.length > 50)w = true;
                            t = t.slice(0, 50)
                        }
                        for (var u = [],E = 0; E < t.length && E < this.prefetchSize; E++)u.push(t[E].SongID);
                        GS.player.prefetchStreamKeys(u)
                    } else {
                        m = GS.Controllers.GridController.columns[g];
                        if (g === "event") {
                            y = {sortCol:"StartTime",sortDir:1,rowCssClasses:function() {
                                return"event"
                            }};
                            for (u = 0; u < t.length; u++) {
                                t[u].EventID = u;
                                t[u].StartTime = (new Date(t[u].StartTime * 1E3)).format("Y-m-d G:i:s");
                                t[u].ArtistName = t[u].ArtistName || t[u].Artists
                            }
                        }
                    }
                    if ($.isFunction(a))a(t, n); else {
                        if (!this.type) {
                            y.autoHeight = true;
                            y.padding = 0;
                            $("#grid").attr("data-profile-view", 1).width($("#page").innerWidth() - $("#search_side_pane").width() - 30).height(25 * t.length + y.padding * 2);
                            if ($("#page").width() < 800)m = [r[0],r[1]];
                            w && $(".belowGrid", this.element).show()
                        }
                        if (g == "user") {
                            this.currentFilterStr = this.query;
                            this.originalUsers =
                                    t.concat();
                            this.renderUsers(this.originalUsers, "rank");
                            return
                        }
                        this.element.find(".gs_grid." + g).gs_grid(t, m, y, g)
                    }
                } else if ($.isFunction(a))a(t, n); else {
                    n = (new Date).getTime() - this.startTimes[g.toLowerCase()];
                    g = this.type || "song";
                    this.element.find(".gs_grid." + g.toLowerCase()).html(this.view("noResults"));
                    $(".gs_grid input[name=q]", this.element).val(this.query);
                    $("#searchForm input").select();
                    this.addAutocomplete("search")
                }
                if (this.type || this.type == "" && g == "song") {
                    n = (new Date).getTime() - this.startTimes[g];
                    GS.search.version = o.version;
                    GS.guts.logEvent("search", {type:this.type || "everything",searchString:this.query,searchVersion:o.version,searchTime:n,numResults:t.length});
                    GS.guts.beginContext({mostRecentSearch:this.query,mostRecentSearchType:this.type || "everything",mostRecentSearchVersion:o.version});
                    GS.guts.handlePageLoad("search", {type:this.type || "everything"})
                }
                if (this.type == "" && g == "song" && !GS.user.searchVersion)GS.user.searchVersion = o.assignedVersion;
                $.isFunction(c) && c()
            }
        });
        g = _.orEqual(b, g);
        g = $.isArray(g) ?
                g : _.ucwords(g) + "s";
        h = g + ":" + this.query + ":" + this.ppOverride;
        GS.Controllers.Page.SearchController.cache[h] ? k(this.query, h, GS.Controllers.Page.SearchController.cache[h]) : GS.service.getSearchResultsEx(this.query, g, this.ppOverride, this.callback(k, this.query, h), this.callback(k, this.query, h))
    },suggest:function() {
        if ($("#page_content").is(".search")) {
            if (!window.google)window.google = {};
            if (!window.google.ac)window.google.ac = {};
            window.google.ac.h = this.callback(function(a) {
                var b = false;
                if (a[1].length > 0) {
                    a = a[1];
                    b = a[0][0].replace(/\s(lyrics.*)$/, "")
                }
                this.suggestSuccess("eg", b)
            });
            $.ajax({url:"http://google.com/complete/search?output=json&q=" + this.query + " lyrics",dataType:"jsonp",jsonp:false,jsonpCallback:"window.google.ac.h",success:function() {
            },error:function() {
            }})
        }
    },suggestSuccess:function(a, b) {
        if (b && this.query.toLowerCase() !== b) {
            this.querySuggest = b;
            this.suggestSource = a;
            $("#didYouMean a").text(b).attr("title", b).data({searchquery:b,searchtype:this.type ? this.type : ""});
            $("#page_subheader").removeClass("hide");
            GS.guts.gaTrackEvent("search", "suggest", this.suggestSource);
            GS.guts.logEvent("suggest", {suggest:this.querySuggest,source:this.suggestSource,numSongs:$("#grid").controller().dataView.rows.length})
        }
    },"#didYouMean a click":function() {
        var a = $("#grid").controller();
        a = a && a.dataView ? a.dataView.rows.length : 0;
        GS.guts.gaTrackEvent("search", "suggestClick", this.suggestSource, a);
        GS.guts.logEvent("suggestClick", {suggest:this.querySuggest,source:this.suggestSource,numSongs:a})
    },renderUsers:function(a, b) {
        var c = $("body").width() <=
                1024 || $("body").height() <= 700;
        this.searchUsers = a.concat();
        this.currentSort = b;
        $("#grid").html("").css("height", "auto").addClass("userlist");
        var g;
        if (this.currentSort)g = this.currentSort.toLowerCase() == "rank" ? this.sortByPicture : this.sortByPictureAlphabet;
        this.slickbox = $("#grid").slickbox({sortFunction:g,scrollPane:"#page_content",padding:15,listClass:c ? "smallUserView" : "",itemRenderer:GS.Models.User.itemRenderer,itemWidth:c ? 175 : 130,itemHeight:c ? 50 : 185,maxHorizontalGap:50,minHorizontalGap:15,verticalGap:15},
                this.searchUsers)
    },sortByPictureAlphabet:function(a, b) {
        return!a.Picture && b.Picture ? 1 : a.Picture && !b.Picture ? -1 : a.Name.toLowerCase() < b.Name.toLowerCase() ? -1 : a.Name.toLowerCase() > b.Name.toLowerCase() ? 1 : 0
    },sortByPicture:function(a, b) {
        return!a.Picture && b.Picture ? 1 : a.Picture && !b.Picture ? -1 : 0
    },resize:function() {
        this.type == "user" && this.searchUsers && this.renderUsers(this.searchUsers, this.currentSort);
        $("#page_content.wideScreen").length && !GS.wideScreen && GS.search.type == "" && this.iframeAd()
    },filterUsers:function(a) {
        if (this.currentFilterStr !=
                a) {
            this.currentFilterStr = a;
            this.type == "user" && this.originalUsers && this.renderUsers(this.originalUsers.filter(this.callback("filterUsersFunction")), this.currentSort)
        }
    },filterUsersFunction:function(a) {
        return(a.Username.toLowerCase() + " " + a.Name.toLowerCase()).indexOf(this.currentFilterStr.toLowerCase()) !== -1
    }});
GS.Controllers.PageController.extend("GS.Controllers.Page.SurveysController", {}, {type:"surveys",questionIndex:0,index:function(a, b) {
    this.subpage = a || "index";
    this.id = b || false;
    this.numPointsPerProfiler = GS.Models.Clearvoice.defaultPointsPerProfiler;
    this.neverShowNotice = store.get("gs.surveys.neverShowNotice" + GS.user.UserID);
    if (GS.user.clearvoice && GS.user.clearvoice.MemberGuid)this.loadMember(GS.user.clearvoice); else {
        $.publish("gs.page.loading.page");
        GS.Models.Clearvoice.getMember(this.callback("loadMember"))
    }
    this.subscribe("gs.auth.pointsUpdated",
            this.callback("getUserPoints"));
    this.subscribe("gs.auth.update", this.callback("index"));
    GS.user.isLoggedIn && this.getUserPoints()
},getUserPoints:function() {
    GS.user.getPoints(this.callback(function(a) {
        $("#userPoints").text(a)
    }))
},loadMember:function(a) {
    this.member = a;
    GS.user.clearvoice = a;
    if (GS.user.clearvoice.enabled) {
        if (this.subpage === "profiler")if (GS.user.isLoggedIn) {
            this.questionIndex = 0;
            this.determineNextQuestion()
        } else location.hash = "/surveys"; else {
            this.member.resetProgress();
            this.element.html(this.view("index"))
        }
        $(window).resize()
    } else this.notFound()
},
    determineNextQuestion:function() {
        for (var a; a = this.member.questions[this.questionIndex];)if (this.member.answers && this.member.answers[a.DemographicId])this.questionIndex++; else if (this.member.answers && a.AnswerId && this.member.answers[a.ParentDemographicId] && !this.member.answers[a.ParentDemographicId][a.AnswerId])this.questionIndex++; else {
            if (this.questionIndex < this.member.questions.length) {
                this.member.resetProgress();
                this.element.html(this.view("profiler"))
            } else location.hash = "/surveys";
            $(window).resize();
            return
        }
        location.hash = "/surveys"
    },"button.next.profiler click":function(a, b) {
        b.preventDefault();
        var c;
        switch (this.member.questions[this.questionIndex].DemographicTypeId) {
            case 2:
            case 9:
            case 12:
                var g = $("ul.survey_answers input:checked", this.element);
                if (g.length && this.member.answerLookup[g.val()])c = this.member.answerLookup[$("ul.survey_answers input:checked").val()];
                break;
            case 6:
            case 7:
                var h = this;
                $("ul.survey_answers input:checked", this.element).each(function() {
                    c || (c = []);
                    var k = $(this).val();
                    h.member.answerLookup[k] &&
                    c.push(h.member.answerLookup[k])
                });
                break;
            case 8:
            case 10:
                $(this).attr("data-answerId");
                if (this.member.answerLookup[$("ul.survey_answers textarea", this.element).attr("data-answerId")]) {
                    c = this.member.answerLookup[$("textarea", this.element).attr("data-answerId")];
                    c.LocalizedValue = $("textarea", this.element).val()
                }
                break;
            case 3:
            case 5:
                break
        }
        if (c) {
            this.member.saveAnswers(c, function(k) {
                GS.user.clearvoice.determineValidAnswer(k)
            });
            this.questionIndex++;
            this.determineNextQuestion()
        }
        return false
    },"a.startSurvey click":function(a) {
        a =
                a.attr("data-index");
        (a = GS.user.clearvoice.AvailableSurveys[a]) && GS.lightbox.open("startSurvey", {survey:a})
    },"a.clearvoiceSignup click":function() {
        if (this.member.MemberGuid)location.hash = "/surveys/profiler"; else GS.user.isLoggedIn ? GS.lightbox.open("clearvoiceSignup") : GS.lightbox.open("login")
    },"a.login click":function() {
        GS.lightbox.open("login")
    },"button.pause click":function(a, b) {
        b.preventDefault();
        location.hash = "/surveys";
        return false
    },"button.redeem_button click":function(a) {
        if (GS.user.isLoggedIn)if (GS.user.clearvoice.guid)if ($(a).is(".redeem_plus"))GS.lightbox.open("redeemPoints",
                {type:"plus"}); else $(a).is(".redeem_anywhere") && GS.lightbox.open("redeemPoints", {type:"anywhere"}); else GS.lightbox.open("clearvoiceSignup"); else GS.lightbox.open("login")
    },"button.dontShowAgain click":function() {
        $(".featureBox", this.element).slideUp();
        store.set("gs.surveys.neverShowNotice" + GS.user.UserID, true)
    },"button.hideNotice click":function() {
        $(".featureBox", this.element).slideUp()
    }});
(function() {
    var a = {1:{message:"POPUP_SIGNUP_FORM_UNKNOWN_ERROR"},2:{message:"POPUP_SIGNUP_FORM_DUPLICATE_EMAIL",fields:["#signup_email"]},4:{message:"POPUP_SIGNUP_FORM_DUPLICATE_USERNAME",fields:["#signup_username"]},8:{message:"POPUP_SIGNUP_FORM_INVALID_PASSWORD",fields:["#signup_password"]},16:{message:"POPUP_SIGNUP_FORM_MISSING_GENDER",fields:["#sex_M","#sex_F"]},32:{message:"POPUP_SIGNUP_FORM_MISSING_NAME",fields:["#signup_fname"]},64:{message:"POPUP_SIGNUP_FORM_USERNAME_LENGTH_ERROR",fields:["#signup_username"]},
        128:{message:"POPUP_SIGNUP_FORM_INVALID_USERNAME",fields:["#signup_username"]},256:{message:"POPUP_SIGNUP_FORM_INVALID_EMAIL",fields:["#signup_email"]},512:{message:"POPUP_SIGNUP_FORM_TOO_YOUNG",fields:[]},1024:{message:"POPUP_SIGNUP_FORM_PASSWORD_NO_MATCH",fields:["#signup_password","#signup_password2"]},2048:{message:"POPUP_SIGNUP_FORM_MUST_ACCEPT_TOS",fields:["#signup_tos"]},4096:{message:"POPUP_SIGNUP_FORM_MISSING_DOB",fields:[]},8192:{message:"POPUP_SIGNUP_FORM_FACEBOOK_GENERAL_ERROR",fields:[]},
        16384:{message:"POPUP_SIGNUP_FORM_GOOGLE_GENERAL_ERROR",fields:[]}};
    GS.Controllers.PageController.extend("GS.Controllers.Page.SignupController", {}, {curStage:false,section:false,stages:{profile1:"profile1",profile2:"profile2",connect:"connect",upgrade:"upgrade",complete:"complete"},userInfo:{},googleContacts:null,facebookFriends:[],fbIDs:{},slickbox:false,init:function() {
        this.section = "";
        this.today = new Date;
        this.months = $.localize.getString("MONTHS").split(",");
        this.subscribe("window.resize", this.callback(this.resize));
        this.subscribe("gs.auth.update", this.callback(this.update))
    },index:function(b) {
        this.section = b;
        this._super();
        this.resize();
        GS.Controllers.PageController.title("Signup", false);
        this.update()
    },resize:function() {
        $("#page_signup").css({top:Math.max(30, ($("#page").height() - $("#page_signup").height()) / 2)})
    },update:function() {
        var b = GS.user.defaultFromService;
        if (this.section == "complete" && GS.user.UserID > 0) {
            this.vipPackage = GS.user.getVipPackage();
            this.initComplete(this.vipPackage)
        } else if (this.section == "upgrade" &&
                GS.user.UserID > 0)this.initUpgrade(); else if (this.section == "connect" || GS.user.UserID > 0)this.initConnect(); else this.section == "aboutme" ? this.initProfile2() : this.initProfile1();
        this.isFacebook = false;
        this.fbSession = {};
        this.isGoogle = false;
        if (b) {
            b.username && $("input[name=username]", this.element).val(b.username);
            b.email && $("input[name=email]", this.element).val(b.email);
            b.fname && $("input[name=fname]", this.element).val(b.fname);
            b.month && $("select[name=month]").val(b.month);
            b.day && $("select[name=day]").val(b.day);
            b.year && $("select[name=year]").val(b.year);
            b.sex && $("#sex_" + b.sex).attr("checked", "checked");
            if (b.isFacebook) {
                this.isFacebook = true;
                if (b.session)this.fbSession = b.session;
                $("#page_signup_password").hide();
                $("#page_signup_password2").hide();
                a[1024] = "POPUP_SIGNUP_FORM_FACEBOOK_GENERAL_ERROR";
                a[2048] = "POPUP_SIGNUP_FORM_FACEBOOK_GENERAL_ERROR";
                a[4096] = "FACEBOOK_DUPLICATE_ACCOUNT_ERROR_MSG"
            } else if (b.isGoogle) {
                this.isGoogle = true;
                $("#page_signup_password").hide();
                $("#page_signup_password2").hide();
                a[2048] =
                        "POPUP_SIGNUP_FORM_GOOGLE_GENERAL_ERROR";
                a[4096] = "GOOGLE_DUPLICATE_ACCOUNT_ERROR_MSG"
            }
            b.error && this.element.find(".error").show().find(".message").html(b.error);
            b.message && this.element.find(".intro-message").show().find(".message").html(b.message);
            $(".input_wrapper_selectbox.month span").html($(".input_wrapper_selectbox.month").find("option:selected").html());
            $(".input_wrapper_selectbox.day span").html($(".input_wrapper_selectbox.day").find("option:selected").html());
            $(".input_wrapper_selectbox.year span").html($(".input_wrapper_selectbox.year").find("option:selected").html());
            this.bExtend = GS.user.IsPremium ? 1 : 0;
            this.resumeRedeem = b.resumeRedeem ? true : false
        }
    },initProfile1:function() {
        this.curStage = this.stages.profile1;
        $(".page_signup_form").addClass("hide");
        $("#page_signup_form_profile1").removeClass("hide");
        $("#page_signup_steps").attr("class", "step1");
        $("#signup_email").focus();
        GS.lightbox.trackLightboxView("signup/profile1")
    },initProfile2:function() {
        this.curStage = this.stages.profile2;
        $(".page_signup_form").addClass("hide");
        $("#page_signup_form_profile2").removeClass("hide");
        $("#page_signup_steps").attr("class", "step1");
        $("#signup_username").focus();
        GS.lightbox.trackLightboxView("signup/profile2")
    },initConnect:function() {
        this.curStage = this.stages.connect;
        this.submitType = "facebook";
        $("#page_signup_steps").attr("class", "step2");
        $(".page_signup_form").addClass("hide");
        $("#page_signup_form_connect").html(this.view("connect")).removeClass("hide");
        GS.lightbox.trackLightboxView("signup/invite")
    },initUpgrade:function() {
        this.curStage = this.stages.upgrade;
        $("#page_signup_steps").attr("class",
                "step3");
        $(".page_signup_form").addClass("hide");
        $("#page_signup_form_upgrade").html(this.view("upgrade")).removeClass("hide");
        GS.lightbox.trackLightboxView("signup/upgrade")
    },initComplete:function() {
        if (GS.user.PathName || GS.user.PathNameEmpty) {
            this.curStage = this.stages.complete;
            this.vipPackage = GS.user.getVipPackage();
            $("#page_signup_steps").attr("class", "hide");
            $(".page_signup_form").addClass("hide");
            $("#page_signup_form").html(this.view("complete")).removeClass("hide")
        } else GS.user.getPathName(this.callback("initComplete"));
        GS.lightbox.trackLightboxView("signup/complete")
    },"a.login click":function() {
        GS.lightbox.close();
        GS.lightbox.open("login")
    },"a.perks click":function() {
        GS.lightbox.close();
        GS.lightbox.open("vipPerks")
    },"button.upgrade click":function(b) {
        b = _.orEqual($(b).attr("rel"), this.vipPackage);
        GS.lightbox.close();
        GS.lightbox.open("vipSignup", {vipPackage:b,isSignup:false})
    },"#page_signup_form button.submit click":function(b, c) {
        c.preventDefault();
        this.hideErrors();
        if (this.curStage == this.stages.profile1)this.checkProfile1() &&
        this.initProfile2(); else if (this.curStage == this.stages.profile2)this.profileSubmit(); else if (this.curStage == this.stages.connect)this.initUpgrade(); else if (this.curStage == this.stages.upgrade)this.initComplete(); else if (this.curStage == this.stages.complete)GS.facebook.connected || setTimeout(this.callback(function() {
            $.publish("gs.facebook.notification.connect", {})
        }), 3E3);
        this.resize();
        return false
    },"#page_signup_form button.back click":function(b, c) {
        c.preventDefault();
        this.hideErrors();
        if (this.curStage ==
                this.stages.profile2)this.initProfile1(); else if (this.curStage == this.stages.connect)this.initProfile2(); else if (this.curStage == this.stages.upgrade)this.initConnect(); else this.curStage == this.stages.complete && this.initConnect();
        return false
    },"#signupUpgrade li.upgrade click":function(b) {
        b = b.is(".plus") ? "plus" : "anywhere";
        GS.lightbox.open("vipSignup", {vipPackage:b,isSignup:true,bExtend:this.bExtend})
    },"button.facebookLogin click":function() {
        GS.facebook.login(this.callback("update"), null)
    },"button.googleLogin click":function() {
        GS.google.login(this.callback("update"),
                null)
    },"button.service click":function(b) {
        switch ($(b).attr("rel")) {
            case "facebook":
                GS.facebook.login(function() {
                    $(b).addClass("active")
                }, this.callback("signupFailed", {errorCode:8192}));
                break;
            case "google":
                GS.google.login(function() {
                    $(b).addClass("active")
                }, this.callback("signupFailed", {errorCode:16384}));
                break
        }
        return false
    },"#signup_username keyup":function(b) {
        b = b.val();
        this.hideErrors();
        $("#page_signup_customURL_label .status").removeClass("verified error alert");
        if (b !== "" && b.length) {
            clearTimeout(this.checkUsernameTimer);
            this.checkUsernameTimer = setTimeout(this.callback("checkUsername", b), 500)
        }
    },checkUsernameTimer:null,checkUsername:function(b) {
        var c = 0,g = /^([a-zA-Z0-9]+[\.\-_]?)+[a-zA-Z0-9]+$/;
        if (b.length && (b.length < 5 || b.length > 32 || !b.match(g))) {
            c |= 128;
            $("#page_signup_customURL_label .status").addClass("alert").attr("title", $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_INVALID"))
        } else b.length && GS.service.getItemByPageName(b, this.callback(function(h) {
            if (!h || h.type) {
                c |= 4;
                $("#page_signup_customURL_label .status").addClass("error").attr("title",
                        $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_UNAVAILABLE"))
            } else $("#page_signup_customURL_label .status").addClass("verified").attr("title", $.localize.getString("POPUP_SIGNUP_FORM_USERNAME_AVAILABLE"))
        }), null, {async:false});
        return c
    },"#signup_password change":function(b) {
        var c = b.val(),g = $("#signup_password2").val();
        this.hideErrors();
        if (c !== "" && c.length && !(c.length < 5 || c.length > 32)) {
            b.parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error");
            if (c === g)$("#signup_password2").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error");
            else g !== "" && this.signupFailed({errorCode:1024})
        } else {
            b.parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            this.signupFailed({errorCode:8})
        }
    },"#signup_password2 change":function(b) {
        var c = $("#signup_password").val(),g = b.val();
        this.hideErrors();
        if (g && c === g) {
            b.parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error");
            $("#signup_password").change()
        } else {
            b.parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            $("#signup_password").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            this.signupFailed({errorCode:1024})
        }
    },"#signup_email change":function(b) {
        var c = b.val();
        this.hideErrors();
        if (c.match(_.emailRegex))b.parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error"); else {
            b.parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            this.signupFailed({errorCode:256})
        }
    },"#signup_fname change":function(b) {
        b.val() !== "" ? b.parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : b.parents(".input_wrapper").addClass("error").siblings("label").addClass("error")
    },
        "#signup_tos change":function(b) {
            b.is(":checked") ? b.parent().removeClass("error") : b.parent().addClass("error")
        },"input,select keydown":function(b, c) {
            c.keyCode && c.keyCode == 13 && !b.is("[name*=google]") && $("#lightbox_footer li.submit:visible, #pane_footer li.submit:visible").click()
        },"select focus":function(b) {
            b.parents(".input_wrapper").addClass("active")
        },"select blur":function(b) {
            b.parents(".input_wrapper").removeClass("active");
            b.change()
        },"select keydown":function(b) {
            b.change()
        },"select.year,select.month,select.day change":function() {
            var b =
                    parseInt($("select[name=month]", this.element).val(), 10),c = parseInt($("select[name=year]", this.element).val(), 10),g = parseInt($("select[name=day]", this.element).val(), 10),h = $("select[name=month]", this.element).find("option:selected").val(),k = $("select[name=year]", this.element).find("option:selected").val(),m = $("select[name=day]", this.element).find("option:selected").val();
            this.hideErrors();
            k !== "" && (!c || c < 0) ? $("select[name=year]", this.element).parents(".input_wrapper").addClass("error").parent().siblings("label").addClass("error") :
                    $("select[name=year]", this.element).parents(".input_wrapper").removeClass("error").parent().siblings("label").removeClass("error");
            h !== "" && (!b || b < 0) ? $("select[name=month]", this.element).parents(".input_wrapper").addClass("error").parent().siblings("label").addClass("error") : $("select[name=month]", this.element).parents(".input_wrapper").removeClass("error").parent().siblings("label").removeClass("error");
            m !== "" && (!g || g < 0) ? $("select[name=day]", this.element).parents(".input_wrapper").addClass("error").parent().siblings("label").addClass("error") :
                    $("select[name=day]", this.element).parents(".input_wrapper").removeClass("error").parent().siblings("label").removeClass("error");
            if (c && b && g) {
                b = new Date(c, b - 1, g);
                b = +new Date - +b;
                b = b / 864E5;
                b = Math.floor(b / 365.24);
                b < 13 ? this.signupFailed({errorCode:512}) : $(".input_wrapper.year, .input_wrapper.month, .input_wrapper.day").removeClass("error").parent().siblings("label").removeClass("error")
            }
        },"li.sex_field label mousedown":function(b) {
            $(b).data("previous", $("li.sex_field input[name=sex]:checked").val())
        },
        "li.sex_field label click":function(b, c) {
            var g = $("input", b);
            $(".page_signup_sex_option").removeClass("checked");
            if ($(g).val() === $(b).data("previous")) {
                $("#sex_Deselect").attr("checked", "checked");
                c.preventDefault();
                $(g).blur();
                return false
            } else $(b).addClass("checked")
        },"#page_signup_flags label click":function(b, c) {
            var g = $("input", b);
            c.preventDefault();
            if (g.is(":checked")) {
                g.attr("checked", false);
                $(b).removeClass("checked")
            } else {
                g.attr("checked", "checked");
                $(b).addClass("checked")
            }
            $(g).blur()
        },"#page_signup_flags input change":function(b) {
            $(b).closest("label").toggleClass("checked",
                    $(b).is(":checked"))
        },".error.response a.toggle click":function() {
            this.hideErrors()
        },checkProfile1:function() {
            var b = true,c = $("#page_signup input[name=email]").val(),g = $("#page_signup input[name=fname]").val(),h = $("#page_signup input[name=password]").val(),k = $("#page_signup input[name=password2]").val(),m = $("#page_signup input[name=tos]").is(":checked"),n = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,o = 0;
            GS.service.getIsUsernameEmailAvailable("", c, this.callback(function(r) {
                if (!r.email && c.length)o |= 2
            }),
                    null, {async:false});
            this.hideErrors();
            if (!c.length || !c.match(n))o |= 256;
            g.length || (o |= 32);
            if (!this.isFacebook && !this.isGoogle) {
                if (h.length < 5 || h.length > 32)o |= 8;
                if (h !== k)o |= 1024
            }
            m || (o |= 2048);
            if (o > 0) {
                this.signupFailed({errorCode:o});
                b = false
            } else {
                this.hideErrors();
                this.element.find(".intro-message.response").hide();
                $("#signup_username").change();
                $("#signup_email").change();
                $("#signup_tos").change();
                if (!this.isGoogle && !this.isFacebook) {
                    $("#signup_password").change();
                    $("#signup_password2").change()
                }
                if ($("#signupAccount .input_wrapper.error, #signupAccount p.tos.error").length)b =
                        false
            }
            return b
        },profileSubmit:function() {
            var b = $("#page_signup input[name=username]").val(),c = $("#page_signup input[name=password]").val(),g = $("#page_signup input[name=email]").val(),h = $("#page_signup input[name=fname]").val(),k = $("#page_signup input[name=sex]:checked").val(),m = [$("#page_signup select[name=year]").val(),$("#page_signup select[name=month]").val(),$("#page_signup select[name=day]").val()].join("-");
            $("#page_signup input[name=tos]").is(":checked");
            var n = $("#page_signup input[name=artist]").is(":checked") ?
                    GS.Models.User.FLAG_ISARTIST : 0,o = $("#page_signup input[name=music_business]").is(":checked") ? GS.Models.User.FLAG_MUSIC_BUSINESS : 0;
            n = n | o;
            o = parseInt($("#page_signup select[name=month]", this.element).val(), 10);
            var r = parseInt($("#page_signup select[name=year]", this.element).val(), 10),t = parseInt($("#page_signup select[name=day]", this.element).val(), 10),w = /^([a-zA-Z0-9]+[\.\-_]?)+[a-zA-Z0-9]+$/,y = 0;
            if (b.length)if (b.match(w))y = b.length < 5 || b.length > 32 ? y | 64 : y | this.checkUsername(b); else y |= 128;
            this.element.find(".error.response").hide();
            $("select.year,select.month,select.day", this.element).change();
            $("#signup_fname").change();
            if (r && o && t) {
                birthDate = new Date(r, o - 1, t);
                dateDiff = +new Date - +birthDate;
                ageDays = dateDiff / 864E5;
                ageYears = Math.floor(ageDays / 365.24);
                if (ageYears < 13)y |= 512
            } else {
                $(".input_wrapper.year, .input_wrapper.month, .input_wrapper.day").addClass("error").parent().siblings("label").addClass("error");
                y |= 4096
            }
            k || (k = "");
            if (y > 0 || $("#page_signup .input_wrapper.error, #signupAccount p.tos.error, #signupAccount div.field.error").length) {
                this.signupFailed({errorCode:y});
                return false
            }
            if (this.isFacebook)GS.auth.signupViaFacebook(b, h, g, k, m, n, this.fbSession, this.callback(this.signupSuccess), this.callback(this.signupFailed)); else this.isGoogle ? GS.auth.signupViaGoogle(b, h, g, k, m, n, this.callback(this.signupSuccess), this.callback(this.signupFailed)) : GS.auth.signup(b, c, h, g, k, m, n, true, this.callback(this.signupSuccess), this.callback(this.signupFailed, {errorCode:1}));
            return true
        },signupSuccess:function(b) {
            if (b && b.userID) {
                this.hideErrors();
                this.initConnect()
            } else this.signupFailed(b)
        },
        signupFailed:function(b) {
            var c,g = ['<ul class="errors">'];
            $.each(a, function(m, n) {
                if (b.errorCode & m) {
                    g.push("<li>" + $.localize.getString(n.message) + " </li>");
                    if (n.fields)for (i = 0; i < n.fields.length; i++)$(n.fields[i]).parents(".input_wrapper").addClass("error").siblings("label").addClass("error")
                }
            });
            g.push("</ul>");
            c = this.element.find(".error.response").show().find(".message");
            if (b.errorCode && b.errorCode & 2 && (this.isFacebook || this.isGoogle)) {
                var h = $("#signupAccount input[name=email]").val();
                if (this.isGoogle) {
                    GS.google.onLoginSaveData =
                            h;
                    var k = $.localize.getString("POPUP_SIGNUP_FORM_GOOGLE_EMAIL_INUSE_LINK")
                } else if (this.isFacebook) {
                    GS.facebook.onLoginSaveData = h;
                    k = $.localize.getString("POPUP_SIGNUP_FORM_FACEBOOK_EMAIL_INUSE_LINK")
                }
                for (i = 0; i < g.length; i++)if (g[i].match(/email\saddress/)) {
                    g[i] = g[i].replace(" </li>", k);
                    break
                }
            }
            c.html("<strong>" + $.localize.getString("POPUP_SIGNUP_ERROR_MESSAGE") + "</strong> " + g.join(""));
            this.showErrors()
        },hideErrors:function() {
            this.element.find(".error.response").stop().slideUp(500, function() {
                $(this).hide()
            })
        },
        showErrors:function() {
            this.element.find(".error.response").stop().show().css("height", "auto")
        },"#page_signup_close_errors click":function() {
            this.hideErrors()
        },connectSubmit:function() {
            return true
        },completeSubmit:function() {
            return true
        }})
})();
GS.Controllers.PageController.extend("GS.Controllers.Page.PromotionController", {}, {promotion:null,type:"promotion",index:function(a) {
    this.promotion = new GS.Models.Promotion(a);
    this.playlists(a)
},playlists:function(a) {
    GS.Controllers.PageController.title("Promotional Playlists");
    this.promotion = new GS.Models.Promotion(a);
    this.element.html(this.view("playlists"));
    this.promotion.getPlaylistsForCampaign(this.callback("loadGridPlaylists"));
    $("input.search").select();
    $(window).resize()
},loadGridPlaylists:function() {
    var a =
            _.toArray(this.promotion.playlists),b,c;
    b = store.get("gs.sort.user.playlists") || {sortCol:"TSAdded",sortDir:0,sortStoreKey:"gs.sort.user.playlists"};
    var g = this.element.find(".gs_grid.playlists").controller();
    if (g) {
        b = g.dataView;
        c = g.grid;
        if (b) {
            b.beginUpdate();
            b.setItems(a, "PlaylistID");
            b.endUpdate();
            b.refresh()
        }
        c && c.onSort(g.sortCol, g.sortDir)
    } else if (a.length)this.element.find(".gs_grid.playlists").gs_grid(a, GS.Controllers.GridController.columns.playlist, b, "playlist"); else {
        this.element.find(".gs_grid.playlists").html(this.view("/shared/noResults",
                {type:"playlist"}));
        $("#searchForm input").select();
        this.addAutocomplete("user")
    }
}});
GS.Controllers.PageController.extend("GS.Controllers.Page.ExtrasController", {}, {index:function(a) {
    this.pageType = a || "features";
    this.subscribe("gs.auth.update", this.callback("index", a));
    this.loadSection()
},loadSection:function() {
    this.user = GS.user;
    this.settings = GS.user.settings;
    this.desktopPrefs = GS.airbridge.getDesktopPreferences();
    this.element.html(this.view("index"));
    switch (this.pageType) {
        case "features":
            GS.Controllers.PageController.title("Features - Extras");
            this.showFeatures();
            break;
        case "desktop":
            GS.Controllers.PageController.title("Desktop - Extras");
            this.showDesktop();
            break;
        case "mobile":
            GS.Controllers.PageController.title("Mobile - Extras");
            this.showMobile();
            break
    }
},showFeatures:function() {
    this.element.find("#page_pane").html(this.view("features"));
    $(window).resize()
},showDesktop:function() {
    this.element.find("#page_pane").html(this.view("desktop"));
    swfobject.embedSWF("/webincludes/flash/InstallDesktop.swf", "installAirApp", "330", "180", "9.0.0", null, {bgcolor:"#eeeeee"});
    $(window).resize()
},showMobile:function() {
    this.element.find("#page_pane").html(this.view("mobile"));
    $(window).resize()
},".extra_feature button click":function(a) {
    var b = $(a).attr("rel");
    GS.features[b].activate(this.callback("updateButton", a))
},updateButton:function(a) {
    var b = GS.features[$(a).attr("rel")];
    $(a).toggleClass("active", b.isActive()).find("span").html(_.printf(b.getButtonKey()))
},"#settings_desktop submit":function(a, b) {
    b.preventDefault();
    var c = {onClose:$("#settings_desktop input[name=settings_desktop_onClose]:checked").val(),onMinimize:$("#settings_desktop input[name=settings_desktop_onMinimize]:checked").val(),
        externalControlEnabled:$("#settings_desktop_globalKeyboard").is(":checked"),notifications:{songNotifications:$("#settings_desktop_songNotifications").is(":checked"),position:parseInt($("select[name=settings_desktop_notifPosition]", a).val(), 10),duration:parseInt($("select[name=settings_desktop_notifDuration]", a).val(), 10)}};
    this.desktopPrefs = c;
    GS.airbridge.setDesktopPreferences(c);
    $("#settings_desktop .form_buttons .status").addClass("success");
    return false
},".page_extras_devices_nav_button click":function(a) {
    $(".page_extras_device").hide();
    $(".page_extras_devices_nav_button").removeClass("active");
    $($(a).addClass("active").attr("rel")).show()
}});
GS.Controllers.BaseController.extend("GS.Controllers.LightboxController", {onElement:"#lightbox_wrapper"}, {priorities:{sessionBad:12,SESSION_BAD:12,maintenance:11,DOWN_FOR_MAINTENANCE:11,invalidClient:10,INVALID_CLIENT:10,badHost:8,BAD_HOST:8,interactionTime:7,INTERACTION_TIMER:7,vipRequiredLogin:5,VIP_REQUIRED_LOGIN:5,vipOnlyFeature:3,VIP_ONLY_FEATURE:3,signup:2,SIGNUP:2,vipSignup:1,VIP_SIGNUP:1},notCloseable:["maintenance","invalidClient","sessionBad","badHost","swfTimeout"],queue:[],queuedOptions:{},
    curType:null,isOpen:false,priority:0,init:function() {
        this.subscribe("window.resize", this.callback(this.positionLightbox));
        $(document).keydown(this.callback(function(a) {
            a.which == _.keys.ESC && this.isOpen && this.notCloseable.indexOf(this.curType) == -1 && this.close()
        }));
        this._super()
    },appReady:function() {
        if (gsConfig.lightboxOnInit) {
            this.open(gsConfig.lightboxOnInit.type, gsConfig.lightboxOnInit.defaults);
            gsConfig.lightboxOnInit = false
        }
    },positionLightbox:function() {
        if (this.isOpen) {
            if (this.curType !== "signup") {
                $("#lightbox_content").css({height:"auto"});
                $("#lightbox").css({width:"auto"})
            }
            var a = Math.max($("#lightbox").width(), 400),b = Math.min(Math.max($("#lightbox").height(), 100), $("body").height() - 70);
            a = Math.round($("#main").width() / 2 - a / 2);
            var c = Math.max(35, Math.round($("#main").height() / 2 - b / 2)),g = $("#lightbox_content").height(),h = $("#lightbox_header", this.element).outerHeight() + $("#div.error.response:visible", this.element).outerHeight() + $("#lightbox_footer", this.element).outerHeight(),k = 0;
            $(".measure", "#lightbox_content").each(function(m) {
                k += $(m).height()
            });
            b = Math.min(Math.max(150, parseInt(b - h, 10)));
            if (b < g && !$("#lightbox_content").is(".fixed_content")) {
                $("#lightbox_content").height(b);
                $(".lightbox_pane_content").height($("#lightbox_content").height() - $("#lightbox_content #pane_footer").outerHeight() - k)
            }
            $("#lightbox_nav").height($("#lightbox_pane").height());
            $("#lightbox_wrapper").css({top:c,left:a});
            this.queuedOptions[this.curType] && this.queuedOptions[this.curType].showPlayerControls && $("#lightbox_overlay").height($(window).height() - $("#player").height());
            $.publish("lightbox.position")
        }
    },open:function(a, b) {
        var c = this.queue.indexOf(a),g = _.orEqual(this.priorities[a], 0);
        b = _.orEqual(b, null);
        var h = this;
        if (this.curType === a)return false;
        this.queuedOptions[a] = b;
        if (g < this.currentPriority)this.queue.indexOf(a) === -1 && this.queue.push(a); else {
            this.curType && this.queue.indexOf(this.curType) === -1 && this.queue.push(this.curType);
            if (!(this.queue.length && c !== -1 && c > -1)) {
                this.curType = a;
                this.currentPriority = g;
                this.isOpen = true;
                $("#lightbox_overlay").height("100%");
                $("#lightbox_wrapper .lbcontainer." +
                        a)[$.String.underscore("gs_lightbox_" + a)](b);
                $("#lightbox .lbcontainer." + a).show(1,
                        function() {
                            h.positionLightbox();
                            $(this).find("form input:first:visible").focus()
                        }).siblings().hide().not(".login").empty();
                this.trackLightboxView(a);
                if ($("#lightbox_wrapper").is(":visible"))this.queue.indexOf(a) === -1 && this.queue.unshift(a); else this.queue.indexOf(a) === -1 && this.queue.push(a);
                $("#theme_home .flash object").hide();
                $("#lightbox_wrapper,#lightbox_overlay").show();
                this.notCloseable.indexOf(this.curType) ==
                        -1 ? $("#lightbox_close").show() : $("#lightbox_close").hide();
                setTimeout(function() {
                    h.positionLightbox()
                }, 150)
            }
        }
    },close:function() {
        var a,b;
        a = this.queue.shift();
        if (_.defined(a)) {
            $("#lightbox_wrapper .lbcontainer." + a).hide().controller().destroy();
            a !== "login" && $("#lightbox_wrapper .lbcontainer." + a).empty()
        }
        this.currentPriority = this.curType = false;
        if (this.queue.length > 0) {
            this.queue = this.sortQueueByPriority(this.queue);
            a = this.queue.shift();
            b = this.queuedOptions[a];
            try {
                this.open(a, b)
            } catch(c) {
                console.warn("error opening next lightbox",
                        c);
                this.isOpen = this.currentPriority = this.curType = false;
                $("#lightbox_wrapper,#lightbox_overlay").hide();
                $("#theme_home .flash object").show()
            }
        } else {
            this.isOpen = this.currentPriority = this.curType = false;
            $("#lightbox_wrapper,#lightbox_overlay").hide();
            $("#theme_home .flash object").show()
        }
    },sortQueueByPriority:function(a) {
        a.sort(this.callback(function(b, c) {
            var g = _.orEqual(this.priorities[b], 0),h = _.orEqual(this.priorities[c], 0);
            return g == h ? 0 : g > h ? 1 : -1
        })).reverse();
        return a
    },trackLightboxView:function(a) {
        a =
                "#/lb/" + a;
        if (window._gaq && window._gaq.push) {
            a = encodeURI(a);
            window._gaq.push(["_trackPageview",a])
        }
    },".close click":function() {
        GS.lightbox.close()
    },"select focus":function(a) {
        a.parents(".input_wrapper").addClass("active")
    },"select blur":function(a) {
        a.parents(".input_wrapper").removeClass("active");
        a.change()
    },"select keydown":function(a) {
        a.change()
    },"select change":function(a) {
        $(a).prev("span").text($(a).find("option:selected").html())
    },"input focus":function(a) {
        $(a).parent().parent().addClass("input_wrapper_active")
    },
    "textarea focus":function(a) {
        $(a).parent().parent().parent().addClass("textarea_wrapper_active")
    },"input blur":function(a) {
        $(a).parent().parent().removeClass("input_wrapper_active")
    },"textarea blur":function(a) {
        $(a).parent().parent().parent().removeClass("textarea_wrapper_active")
    }});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.LoginController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    $("#lightbox_footer li").show();
    if (a && a.callback)this.afterLoginCallback = a.callback;
    a && a.username && $("input[name=username]", this.element).val(a.username);
    a && a.error ? this.showError(a.error) : this.element.find(".error").hide();
    this.showCTA = a && a.showCTA ? true : false;
    $("#login_anywhere_cta").toggleClass("hide", !this.showCTA);
    this.resumeRedeem = a && a.resumeRedeem ?
            true : false;
    if (a && a.premiumRequired) {
        this.premiumRequired = true;
        $("h3", "#lightbox_header").localeDataString("POPUP_SIGNUP_LOGIN_PREMIUM_TITLE")
    } else {
        this.premiumRequired = false;
        $("h3", "#lightbox_header").localeDataString("POPUP_LOGIN_TITLE")
    }
    $("#login_redeem_msg").toggleClass("hide", !this.resumeRedeem);
    $("#login_premium_msg").toggleClass("hide", !this.premiumRequired);
    $("#login_default_msg").toggleClass("hide", this.resumeRedeem || this.premiumRequired);
    $("input[name=password]", this.element).val("");
    $("input[name=username]",
            this.element).focus()
},showError:function(a) {
    $("div.message", this.element).html($.localize.getString(a));
    this.element.find(".error").show()
},showMessage:function(a) {
    $("div.message", this.element).html(a);
    this.element.find(".error").show()
},"input focus":function(a) {
    $(a).parent().parent().addClass("active")
},"input blur":function(a) {
    $(a).parent().parent().removeClass("active")
},"a.submit click":function() {
    $("form", this.element).submit()
},"a.signup click":function() {
    GS.lightbox.close();
    window.location.hash =
            "/signup"
},"a.upgrade click":function() {
    GS.lightbox.close();
    window.location.hash = "/settings/subscriptions"
},"a.forget,a.forgot click":function() {
    GS.lightbox.close();
    GS.lightbox.open("forget")
},"form submit":function(a) {
    var b = $("input[name=username]", a).val(),c = $("input[name=password]", a).val();
    a = $("input[name=save]", a).val() ? 1 : 0;
    switch (b.toLowerCase()) {
        case "dbg:googlelogin":
            GS.google.lastError ? this.showMessage("Last Google Login Error: " + JSON.stringify(GS.google.lastError)) : this.showMessage("There does not appear to be any errors with Google Login");
            break;
        case "dbg:facebooklogin":
            GS.facebook.lastError ? this.showMessage("Last Facebook Login Error: " + JSON.stringify(GS.facebook.lastError)) : this.showMessage("There does not appear to be any errors with Facebook Login");
            break;
        default:
            GS.auth.login(b, c, a, this.callback(this.loginSuccess), this.callback(this.loginFailed));
            break
    }
},"button.facebookLogin click":function() {
    GS.auth.loginViaFacebook(this.callback(this.loginSuccess), this.callback(this.loginFailed))
},"button.googleLogin click":function() {
    GS.auth.loginViaGoogle(this.callback(this.loginSuccess),
            this.callback(this.loginFailed))
},loginSuccess:function() {
    if ($.isFunction(this.afterLoginCallback))GS.auth.authUpdateCallback = this.afterLoginCallback;
    GS.lightbox.close();
    this.resumeRedeem && GS.lightbox.open("redeem", {autoSubmit:true})
},loginFailed:function(a) {
    if (a.error)this.showError(a.error); else if (a && a.authType == "facebook")this.showError("POPUP_SIGNUP_LOGIN_FORM_FACEBOOK_ERROR"); else if (a && a.authType == "google")this.showError("POPUP_SIGNUP_LOGIN_FORM_GOOGLE_ERROR"); else a && a.userID == 0 ? this.showError("POPUP_SIGNUP_LOGIN_FORM_AUTH_ERROR") :
            this.showError("POPUP_SIGNUP_LOGIN_FORM_GENERAL_ERROR");
    GS.lightbox.positionLightbox()
}});
(function() {
    GS.Controllers.VipInterface.extend("GS.Controllers.Lightbox.VipSignupController", {onDocument:false}, {creditCardStages:{payment:"payment",billing:"billing",confirmation:"confirmation"},paypalStages:{payment:"payment",redirect:"redirect",confirmation:"confirmation"},offersStages:{promocode:"promocode",confirmation:"confirmation"},curCreditCardStage:false,curPaypalStage:false,curOffersStage:false,vipToken:false,vipCallbackUrl:false,recurring:true,vipPackage:false,paymentType:"creditcard",
        isSignup:false,init:function(a, b) {
            this.update(b)
        },update:function(a) {
            if (GS.user.isLoggedIn) {
                this.today = new Date;
                this.months = $.localize.getString("MONTHS").split(",");
                this.expYears = [];
                this.vip = this.anywhere = 0;
                this.excludedCountries = GS.Controllers.Lightbox.VipSignupController.excludedCreditCardCountries;
                this.paymentType = "creditcard";
                this.bExtend = (this.bExtend = _.orEqual(a.bExtend, 0)) ? 1 : 0;
                for (var b = (new Date).getFullYear(),c = 0; c < 10; c++)this.expYears.push(b + c);
                this.vipEndpoint = gsConfig.runMode == "production" ?
                        "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/";
                this.vipToken = hex_md5((new Date).getTime());
                this.vipCallbackUrl = location.protocol + "//" + location.host + "/vipCallback.php";
                if (a && a.vipPackage) {
                    this.anywhere = a.vipPackage === this.vipPackages.anywhere ? 1 : 0;
                    this.vip = a.vipPackage === this.vipPackages.vip ? 1 : 0
                }
                if (this.vip) {
                    this.monthPrice = this.vipPackagePrices.month.vip;
                    this.yearPrice = this.vipPackagePrices.year.vip
                } else if (this.anywhere) {
                    this.monthPrice = this.vipPackagePrices.month.anywhere;
                    this.yearPrice =
                            this.vipPackagePrices.year.anywhere
                } else {
                    this.monthPrice = this.vipPackagePrices.month.plus;
                    this.yearPrice = this.vipPackagePrices.year.plus
                }
                if (a && a.isSignup)this.isSignup = true;
                this.element.html(this.view("/lightbox/vipSignup"));
                if (a && a.initOffers)this.initOffersBilling(); else a && a.initPaypal ? this.initPaypalBilling() : this.initCreditCardBilling();
                GS.lightbox.positionLightbox()
            } else _.wait(10).then(function() {
                GS.lightbox.close();
                GS.lightbox.open("login", {callback:function() {
                    GS.lightbox.open("vipSignup",
                            a)
                }})
            })
        },initCreditCardBilling:function() {
            this.paymentType = "creditcard";
            this.curCreditCardStage = this.creditCardStages.payment;
            $("#creditcard_content").show().siblings().hide();
            $("#creditcard_content ul.progress li.payment").addClass("active").siblings().removeClass("active progress_previousStep progress_currentStep").parent().removeClass("progress_onLast");
            $("#creditcard_content ul.stages li.stage.payment").show().siblings().hide();
            $("#billing_options .creditcard.pane a").addClass("active").parent().siblings().children("a").removeClass("active");
            $("#creditcard_content ul.progress li.payment").addClass("progress_currentStep").removeClass("progress_previousStep");
            $("#creditcard_content ul.progress li.billing").addClass("progress_nextStep").removeClass("active progress_currentStep");
            $(".selectbox.cardType span").html($("select.cardType option:selected").html());
            $(".selectbox.expMonth span").html($("select.expMonth option:selected").html());
            $(".selectbox.expYear span").html($("select.expYear option:selected").html());
            $(".selectbox.state span").html($("select.state option:selected").html());
            $(".selectbox.country span").html($("select#ccCountry option:selected").html());
            $("#pane_footer ul.right li.next").show().siblings().hide();
            this.isSignup ? $("#pane_footer ul.left li").show() : $("#pane_footer ul.left li").hide();
            this.element.find(".error.response").hide();
            GS.lightbox.trackLightboxView("vipSignup/creditcard1")
        },initPaypalBilling:function() {
            this.paymentType = "paypal";
            this.curPaypalStage = this.paypalStages.payment;
            $("#paypal_content").show().siblings("").hide();
            $("#paypal_content ul.progress li.payment").siblings().removeClass("active progress_previousStep progress_currentStep").parent().removeClass("progress_onLast");
            $("#paypal_content ul.stages li.stage.payment").show().siblings().hide();
            $("#billing_options .paypal.pane a").addClass("active").parent().siblings().children("a").removeClass("active");
            $("#paypal_content ul.progress li.payment").addClass("progress_currentStep").removeClass("progress_previousStep");
            $("#paypal_content ul.progress li.redirect").addClass("progress_nextStep").removeClass("active progress_currentStep");
            $(".selectbox.country span").html($("select#ccCountry option:selected").html());
            $("#pane_footer ul.right li").show();
            this.isSignup ? $("#pane_footer ul.left li").show() : $("#pane_footer ul.left li").hide();
            this.element.find(".error.response").hide();
            GS.lightbox.trackLightboxView("vipSignup/paypal1")
        },initCellPhoneBilling:function() {
            this.paymentType = "cellphone";
            $("#cellphone_content").show().siblings().hide();
            $("#cellphone_content ul.progress li.payment").addClass("active").siblings().removeClass("active progress_previousStep progress_currentStep").parent().removeClass("progress_onLast");
            $("#cellphone_content ul.stages li.stage.promocode").show().siblings().hide();
            $("#billing_options .cellphone.pane a").addClass("active").parent().siblings().children("a").removeClass("active");
            $("#pane_footer ul.right li").show();
            this.isSignup ? $("#pane_footer ul.left li").show() : $("#pane_footer ul.left li").hide();
            this.element.find(".error.response").hide();
            GS.lightbox.trackLightboxView("vipSignup/cellphone1")
        },initOffersBilling:function() {
            this.paymentType = "offers";
            this.curOffersStage = this.offersStages.promocode;
            this.recurring = false;
            $("#offers_content").show().siblings().hide();
            $("#billing_options .offers.pane a").addClass("active").parent().siblings().children("a").removeClass("active");
            $("#pane_footer ul.right li.next").show().siblings().hide();
            this.isSignup ? $("#pane_footer ul.left li").show() : $("#pane_footer ul.left li").hide();
            this.element.find(".error.response").hide();
            GS.lightbox.trackLightboxView("vipSignup/offers1")
        },"#billing_options .creditcard.pane click":function(a) {
            a.is(".active") || this.initCreditCardBilling()
        },"#billing_options .paypal.pane click":function(a) {
            a.is(".active") ||
            this.initPaypalBilling()
        },"#billing_options .cellphone.pane click":function(a) {
            a.is(".active") || this.initCellPhoneBilling()
        },"#billing_options .offers.pane click":function(a) {
            a.is(".active") || this.initOffersBilling()
        },"#lightbox_footer li.submit, #pane_footer li.submit click":function(a, b) {
            b.preventDefault();
            if (this.paymentType === "creditcard")if (this.curCreditCardStage === this.creditCardStages.payment) {
                if (this.checkCreditCard1()) {
                    $("#creditcard_content ul.progress li.payment").removeClass("progress_currentStep").addClass("progress_previousStep");
                    $("#creditcard_content ul.progress li.billing").addClass("active progress_currentStep").removeClass("progress_nextStep");
                    $("#creditcard_content ul.progress li.confirmation").addClass("progress_lastStep");
                    $("#creditcard_content ul.stages li.stage.billing").show().siblings().hide();
                    $("#creditcard_content ul.right li.next").show().siblings().hide();
                    $("#creditcard_content ul.left li").show();
                    this.curCreditCardStage = this.creditCardStages.billing;
                    this.element.find(".error.response").hide();
                    GS.lightbox.trackLightboxView("vipSignup/creditcard2")
                }
            } else {
                if (this.curCreditCardStage ===
                        this.creditCardStages.billing)if (this.checkCreditCard2())return this.creditCardSubmit()
            } else if (this.paymentType === "paypal")if (this.curPaypalStage === this.paypalStages.payment) {
                $("#paypal_content ul.progress li.payment").removeClass("progress_currentStep").addClass("progress_previousStep");
                $("#paypal_content ul.progress li.redirect").addClass("active progress_currentStep").removeClass("progress_nextStep");
                $("#paypal_content ul.progress li.confirmation").addClass("progress_lastStep");
                $("#paypal_content ul.stages li.stage.redirect").show().siblings().hide();
                $("#paypal_content ul.right li.next").show().siblings().hide();
                $("#paypal_content ul.left li").show();
                this.curPaypalStage = this.paypalStages.redirect;
                this.element.find(".error.response").hide();
                GS.lightbox.trackLightboxView("vipSignup/paypal2")
            }
            this.billingSubmit();
            return false
        },"#lightbox_footer li.back, #pane_footer li.back click":function(a, b) {
            b.preventDefault();
            if (this.paymentType === "creditcard")if (this.curCreditCardStage === this.creditCardStages.payment) {
                if (this.isSignup) {
                    GS.lightbox.close();
                    location.hash =
                            "#/signup/upgrade"
                }
            } else if (this.curCreditCardStage === this.creditCardStages.billing) {
                $("#creditcard_content ul.progress li.payment").addClass("progress_currentStep").removeClass("progress_previousStep");
                $("#creditcard_content ul.progress li.billing").addClass("progress_nextStep").removeClass("active progress_currentStep");
                $("#creditcard_content ul.stages li.stage.payment").show().siblings().hide();
                $("#creditcard_content ul.right li.next").show().siblings().hide();
                this.isSignup ? $("#creditcard_content ul.left li").show() :
                        $("#creditcard_content ul.left li").hide();
                this.curCreditCardStage = this.creditCardStages.payment;
                GS.lightbox.trackLightboxView("vipSignup/creditcard1")
            } else {
                if (this.curCreditCardStage === this.creditCardStages.confirmation) {
                    $("#creditcard_content ul.progress li.billing").addClass("progress_currentStep").removeClass("progress_previousStep").parent().removeClass("progress_onLast");
                    $("#creditcard_content ul.progress li:last").removeClass("active progress_currentStep");
                    $("#creditcard_content ul.stages li.stage.billing").show().siblings().hide();
                    $("#creditcard_content ul.right li.purchase").show().siblings().hide();
                    $("#creditcard_content ul.left li").show();
                    this.curCreditCardStage = this.creditCardStages.billing;
                    GS.lightbox.trackLightboxView("vipSignup/creditcard2")
                }
            } else if (this.paymentType === "paypal")if (this.curPaypalStage === this.paypalStages.payment) {
                if (this.isSignup) {
                    GS.lightbox.close();
                    location.hash = "#/signup/upgrade"
                }
            } else if (this.curPaypalStage === this.paypalStages.redirect) {
                $("#paypal_content ul.progress li.payment").addClass("progress_currentStep").removeClass("progress_previousStep");
                $("#paypal_content ul.progress li.redirect").addClass("progress_nextStep").removeClass("active progress_currentStep");
                $("#paypal_content ul.stages li.stage.payment").show().siblings().hide();
                $("#paypal_content ul.right li.next").show().siblings().hide();
                this.isSignup ? $("#paypal_content ul.left li").show() : $("#paypal_content ul.left li").hide();
                this.curPaypalStage = this.paypalStages.payment;
                GS.lightbox.trackLightboxView("vipSignup/paypal1")
            } else {
                if (this.curPaypalStage === this.paypalStages.confirmation) {
                    $("#paypal_content ul.progress li.redirect").addClass("progress_currentStep").removeClass("progress_previousStep").parent().removeClass("progress_onLast");
                    $("#paypal_content ul.progress li.confirmation").removeClass("active progress_currentStep");
                    $("#paypal_content ul.stages li.stage.redirect").show().siblings().hide();
                    $("#paypal_content ul.right li.next").show().siblings().hide();
                    $("#paypal_content ul.left li").show();
                    this.curPaypalStage = this.paypalStages.redirect;
                    GS.lightbox.trackLightboxView("vipSignup/paypal2")
                }
            } else if (this.paymentType === "cellphone")return false; else if (this.paymentType === "offers")if (this.curOffersStage === this.offersStages.promocode) {
                if (this.isSignup) {
                    GS.lightbox.close();
                    location.hash = "#/signup/upgrade"
                }
            } else {
                $("#offers_content ul.progress li.promocode").addClass("progress_currentStep active").removeClass("progress_previousStep").parent().removeClass("progress_onLast");
                $("#offers_content ul.progress li.confirmation").addClass("progress_nextStep").removeClass("active progress_currentStep").siblings().removeClass("progress_nextStep");
                $("#offers_content #pane_footer ul.right li").show();
                $("#offers_content ul.stages li.stage.promocode").show().siblings().hide();
                this.isSignup ?
                        $("#offers_content ul.left li").show() : $("#offers_content ul.left li").hide();
                this.curOffersStage = this.offersStages.promocode;
                GS.lightbox.trackLightboxView("vipSignup/offers1")
            }
            return false
        },"#lightbox_footer li.close click":function() {
            GS.lightbox.close()
        },"select#ccCountry change":function(a) {
            var b = a.find("option:selected").val();
            $(".input_wrapper_selectbox.country span").text(a.find("option:selected").html());
            b === "US" ? a.parents("ul").removeClass("showRegion", a.parents("ul")) : a.parents("ul").addClass("showRegion")
        },
        ".vipPackage input:radio change":function(a) {
            $(".vipPackage label").removeClass("active");
            $(a).closest("label").toggleClass("active", $(a).is(":checked"))
        },billingSubmit:function() {
            if (this.paymentType === "creditcard") {
                if (this.curCreditCardStage !== this.creditCardStages.payment)if (this.curCreditCardStage !== this.creditCardStages.billing)if (this.curCreditCardStage === this.creditCardStages.confirmation)return this.creditCardConfirmSubmit()
            } else if (this.paymentType === "paypal") {
                if (this.curPaypalStage !== this.paypalStages.payment)if (this.curPaypalStage ===
                        this.paypalStages.redirect)return this.paypalSubmit(); else if (this.curPaypalStage === this.paypalStages.confirmation)return this.paypalConfirmSubmit()
            } else if (this.paymentType === "offers")if (this.curOffersStage === this.offersStages.promocode)return this.offersSubmit(); else {
                if (this.curOffersStage === this.offersStages.confirmation)return this.offersConfirmSubmit()
            } else if (this.paymentType === "cellphone")return this.cellphoneSubmit();
            return false
        },checkCreditCard1:function() {
            var a = [],b = /[^\d ]/,c = $("#creditcard_content select[name=cardType]").val(),
                    g = $("#creditcard_content input[name=cardNumber]").val().replace(/(\s+)/g, "").replace(/(-)/g, ""),h = $("#creditcard_content input[name=secCode]").val(),k = $("#creditcard_content select[name=expMonth]").val(),m = $("#creditcard_content select[name=expYear]").val();
            this.element.find(".error.response").hide();
            if (!c || !g || !h || !k || !m)a.push({errorID:"CC-03"});
            c ? $("#creditcard_content select[name=cardType]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : $("#creditcard_content select[name=cardType]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            if (!g || g.length > 16 || g.length < 13 || b.test(g)) {
                a.push({message:$.localize.getString("VIP_ERROR_CARD_NUMBER")});
                $("#creditcard_content input[name=cardNumber]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error")
            } else $("#creditcard_content input[name=cardNumber]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error");
            if (!h || h.length > 4 || h.length < 3 || b.test(h)) {
                a.push({message:$.localize.getString("VIP_ERROR_INVALID_CVD")});
                $("#creditcard_content input[name=secCode]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error")
            } else $("#creditcard_content input[name=secCode]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error");
            k ? $("#creditcard_content select[name=expMonth]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : $("#creditcard_content select[name=expMonth]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            m ? $("#creditcard_content select[name=expYear]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : $("#creditcard_content select[name=expYear]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            if (a.length) {
                this.showVipErrors({error:a});
                return false
            }
            return true
        },checkCreditCard2:function() {
            var a = [],b = $("#creditcard_content select[name=country]").val(),c = $("#creditcard_content input[name=fname]").val(),g = $("#creditcard_content input[name=address1]").val(),h = $("#creditcard_content input[name=city]").val(),k = $("#creditcard_content input[name=zip]").val();
            this.element.find(".error.response").hide();
            if (!b || !h || !k || !g)a.push({errorID:"CC-03"});
            c || a.push({errorID:"CC-01"});
            b ? $("#creditcard_content select[name=iso]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") :
                    $("#creditcard_content select[name=iso]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            c ? $("#creditcard_content input[name=fname]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : $("#creditcard_content input[name=fname]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            g ? $("#creditcard_content input[name=address1]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") :
                    $("#creditcard_content input[name=address1]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            h ? $("#creditcard_content input[name=city]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") : $("#creditcard_content input[name=city]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            k ? $("#creditcard_content input[name=zip]").parents(".input_wrapper").removeClass("error").siblings("label").removeClass("error") :
                    $("#creditcard_content input[name=zip]").parents(".input_wrapper").addClass("error").siblings("label").addClass("error");
            $("#signupBilling .input_wrapper.error, #signupBilling p.tos.error, #signupBilling div.field.error");
            if (a.length) {
                this.showVipErrors({error:a});
                return false
            }
            return true
        },creditCardSubmit:function() {
            var a = hex_md5((new Date).getTime()),b = {vipToken:this.vipToken,callbackMethod:a,callbackUrl:this.vipCallbackUrl,vipPackage:$("#creditcard_content input[name=ccPackage]:checked").val(),
                anywhere:this.anywhere,bExtend:this.bExtend,recurring:1,iso:$("#creditcard_content select[name=country]").val(),fName:$("#creditcard_content input[name=fname]").val(),cardType:$("#creditcard_content select[name=cardType]").val(),expMonth:$("#creditcard_content select[name=expMonth]").val(),expYear:$("#creditcard_content select[name=expYear]").val(),cardNumber:$("#creditcard_content input[name=cardNumber]").val().replace(/(\s+)/g, "").replace(/(-)/g, ""),secCode:$("#creditcard_content input[name=secCode]").val(),
                address1:$("#creditcard_content input[name=address1]").val(),address2:$("#creditcard_content input[name=address2]").val(),city:$("#creditcard_content input[name=city]").val(),state:$("#creditcard_content select[name=state]").val(),region:$("#creditcard_content input[name=region]").val(),zip:$("#creditcard_content input[name=zip]").val()};
            GS.service.httpsFormSubmit(this.vipEndpoint + "payByCreditCard.php", b);
            window[a] = this.callback(function(c) {
                console.warn("ccsubmit win.callback", b, c, "success:", c.bSuccess,
                        $("#httpsIframe"));
                if (c.bSuccess) {
                    this.creditCardConfirmToken = c.token;
                    $("#creditcard_content .confirmation td.vipPackage").html(c.description);
                    $("#creditcard_content .confirmation td.price").html("$" + c.amount);
                    $("#creditcard_content .confirmation td.tax").html("$" + c.tax);
                    $("#creditcard_content .confirmation td.total").html("$" + c.total);
                    c.bRecurring == true || c.bRecurring == "1" ? $("#creditcard_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_RECURRING")).attr("data-translate-text",
                            "SUBSCRIPTION_RECURRING") : $("#creditcard_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_NOT_RECURRING")).attr("data-translate-text", "SUBSCRIPTION_NOT_RECURRING");
                    $("#creditcard_content ul.progress li.billing").addClass("progress_previousStep").removeClass("progress_currentStep");
                    $("#creditcard_content ul.progress li.confirmation").addClass("active progress_currentStep").parent().addClass("progress_onLast");
                    $("#creditcard_content ul.stages li.stage.confirmation").show().siblings().hide();
                    $("#creditcard_content ul.right li.next").show().siblings().hide();
                    $("#creditcard_content ul.left li").show();
                    this.curCreditCardStage = this.creditCardStages.confirmation;
                    this.element.find(".error.response").hide();
                    GS.lightbox.trackLightboxView("vipSignup/creditcardConfirm")
                } else this.showVipErrors(c)
            });
            return false
        },creditCardConfirmSubmit:function() {
            var a = hex_md5((new Date).getTime()),b = {callbackUrl:this.vipCallbackUrl,callbackMethod:a,token:this.creditCardConfirmToken};
            GS.service.httpsFormSubmit(this.vipEndpoint +
                    "payByCreditCardConfirm.php", b);
            window[a] = this.callback(function(c) {
                console.warn("cc confirmsubmit win.callback", b, c, "success:", c.bSuccess, $("#httpsIframe"));
                var g = this.anywhere || this.vip ? this.vipPackages.anywhere : this.vipPackages.plus;
                if (c.bSuccess) {
                    GS.user.updateAccountType(g);
                    GS.lightbox.trackLightboxView("vipSignup/ccSuccess");
                    GS.lightbox.close();
                    location.hash = "#/signup/complete"
                } else this.showVipErrors(c)
            })
        },paypalSubmit:function() {
            var a = 0,b = this.vipEndpoint + "payByPaypal.php",c = hex_md5((new Date).getTime()),
                    g = {vipToken:this.vipToken,callbackUrl:this.vipCallbackUrl,callbackMethod:c,vipPackage:$("#paypal_content input[name=paypalPackage]:checked").val(),anywhere:this.anywhere,bExtend:this.bExtend,recurring:1,country:$("#paypal_content select[name=country]").val()};
            _.forEach(g, function(h, k) {
                b += a === 0 ? "?" + k + "=" + encodeURI(h) : "&" + k + "=" + encodeURI(h);
                a++
            });
            console.warn("open paypal window", b);
            window.open(b, "_blank");
            $("#paypal_content p.redirectLink a").attr("href", b);
            window[c] = this.callback(function(h) {
                console.warn("paypalsubmit win.callback",
                        g, h, $("#httpsIframe"));
                if (h.bSuccess) {
                    this.paypalConfirmToken = h.token;
                    $("#paypal_content .confirmation td.vipPackage").html(h.description);
                    $("#paypal_content .confirmation td.price").html("$" + h.amount);
                    $("#paypal_content .confirmation td.tax").html("$" + h.tax);
                    $("#paypal_content .confirmation td.total").html("$" + h.total);
                    h.bRecurring == true || h.bRecurring == "1" ? $("#paypal_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_RECURRING")).attr("data-translate-text", "SUBSCRIPTION_RECURRING") :
                            $("#paypal_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_NOT_RECURRING")).attr("data-translate-text", "SUBSCRIPTION_NOT_RECURRING");
                    $("#paypal_content ul.progress li.redirect").addClass("progress_previousStep").removeClass("progress_currentStep");
                    $("#paypal_content ul.progress li.confirmation").addClass("active progress_currentStep").parent().addClass("progress_onLast");
                    $("#paypal_content ul.stages li.stage.confirmation").show().siblings().hide();
                    $("#paypal_content ul.right li.next").show().siblings().hide();
                    $("#paypal_content ul.left li").show();
                    this.curPaypalStage = this.paypalStages.confirmation;
                    this.element.find(".error.response").hide();
                    GS.lightbox.trackLightboxView("vipSignup/paypalConfirm")
                } else this.showVipErrors(h)
            });
            $("#paypal_content ul.progress li").addClass("active");
            $("#paypal_content ul.progress li:last").removeClass("active");
            $("#paypal_content ul.stages li.stage.redirect").show().siblings().hide();
            $("#paypal_content #pane_footer li").hide();
            $("#paypal_content ul.left li").show();
            this.curPaypalStage =
                    this.paypalStages.redirect;
            return false
        },paypalConfirmSubmit:function() {
            var a = hex_md5((new Date).getTime()),b = {callbackMethod:a,callbackUrl:this.vipCallbackUrl,token:this.paypalConfirmToken};
            GS.service.httpsFormSubmit(this.vipEndpoint + "payByPaypalConfirm.php", b);
            window[a] = this.callback(function(c) {
                console.warn("paypal confirmsubmit win.callback", b, c, "success:", c.bSuccess, $("#httpsIframe"));
                var g = this.anywhere || this.vip ? this.vipPackages.anywhere : this.vipPackages.plus;
                if (c.bSuccess) {
                    GS.user.updateAccountType(g);
                    GS.lightbox.trackLightboxView("vipSignup/paypalSuccess");
                    GS.lightbox.close();
                    location.hash = "#/signup/complete"
                } else this.showVipErrors(c)
            });
            return false
        },offersSubmit:function() {
            var a = $("#signup_promocode").val();
            if (a === "")$("#signup_promocode").parent().parent().addClass("error"); else {
                $("#signup_promocode").parent().parent().removeClass("error");
                var b = hex_md5((new Date).getTime()),c = {vipToken:this.vipToken,callbackMethod:b,callbackUrl:this.vipCallbackUrl,anywhere:this.anywhere,bExtend:this.bExtend,
                    code:a};
                GS.service.httpsFormSubmit(this.vipEndpoint + "payByPromoCode.php", c);
                window[b] = this.callback(function(g) {
                    console.warn("offersubmit win.callback", c, g, $("#httpsIframe"));
                    if (g.bSuccess) {
                        this.offersConfirmToken = g.token;
                        $("#offers_content .confirmation .description").html(g.description);
                        g.bRecurring == true || g.bRecurring == "1" ? $("#offers_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_RECURRING")).attr("data-translate-text", "SUBSCRIPTION_RECURRING") : $("#offers_content .confirmation p.recurring").html($.localize.getString("SUBSCRIPTION_NOT_RECURRING")).attr("data-translate-text",
                                "SUBSCRIPTION_NOT_RECURRING");
                        GS.user.IsPremium ? $("#offers_content .confirmation p.userWarning").show() : $("#offers_content .confirmation p.userWarning").hide();
                        $("#offers_content ul.progress li.promocode").addClass("progress_previousStep").removeClass("progress_currentStep");
                        $("#offers_content ul.progress li.confirmation").addClass("active progress_currentStep").parent().addClass("progress_onLast");
                        $("#offers_content ul.stages li.stage.confirmation").show().siblings().hide();
                        $("#offers_content ul.right li.next").show().siblings().hide();
                        $("#offers_content ul.left li").show();
                        this.curOffersStage = this.offersStages.confirmation;
                        this.element.find(".error.response").hide();
                        GS.lightbox.trackLightboxView("vipSignup/offersConfirm")
                    } else this.showVipErrors(g)
                })
            }
            return false
        },offersConfirmSubmit:function() {
            var a = hex_md5((new Date).getTime()),b = {callbackMethod:a,callbackUrl:this.vipCallbackUrl,token:this.offersConfirmToken};
            GS.service.httpsFormSubmit(this.vipEndpoint + "payByPromoCodeConfirm.php", b);
            window[a] = this.callback(function(c) {
                console.warn("offers confirmsubmit win.callback",
                        b, c, "success:", c.bSuccess, $("#httpsIframe"));
                var g = this.anywhere || this.vip ? this.vipPackages.anywhere : this.vipPackages.plus;
                if (c.bSuccess) {
                    GS.user.updateAccountType(g);
                    GS.lightbox.trackLightboxView("vipSignup/offersSuccess");
                    GS.lightbox.close();
                    location.hash = "#/signup/complete"
                } else this.showVipErrors(c)
            });
            return false
        },cellphoneSubmit:function() {
            return false
        },cellphoneConfirmSubmit:function() {
            return false
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.VipExpiresController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.data = _.orEqual(a, {});
    this.daysLeft = _.orEqual(this.data.daysLeft, "days");
    this.timeframe = _.orEqual(this.data.timeframe, "twoWeeks");
    this.element.html(this.view("/lightbox/vipExpires"))
},"button.remind click":function() {
    store.set("gs.vipExpire.hasSeen" + GS.user.UserID, (new Date).getTime());
    GS.lightbox.close()
},"button.renew click":function() {
    GS.lightbox.close();
    var a;
    a = this.data.subscriptionType.match("Anywhere") ? "anywhere" : this.data.subscriptionType.match("Plus") ? "plus" : this.data.bVip === true || this.data.bVip === 1 ? "vip" : "plus";
    if (a === "vip" || a === "anywhere")GS.lightbox.open("vipSignup", {bExtend:1,vipPackage:this.data.bVip ? "vip" : a}); else location.hash = "#/signup/upgrade"
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.VipCancelController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/vipCancel"))
},"form submit":function(a, b) {
    b.preventDefault();
    var c = hex_md5((new Date).getTime()),g = {callbackMethod:c,callbackUrl:location.protocol + "//" + location.host + "/vipCallback.php"};
    GS.service.httpsFormSubmit((gsConfig.runMode == "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/") +
            "disableRecurring.php", g);
    window[c] = this.callback(function(h) {
        console.warn("cancel win.callback", g, h, "success:", h.bSuccess, $("#httpsIframe"));
        GS.lightbox.close();
        location.hash = "/settings/subscriptions?r=" + (new Date).getTime()
    });
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.FollowInviterController", {onDocument:false}, {user:null,init:function(a, b) {
    this.update(b)
},update:function(a) {
    if (this.user = a.user) {
        this.element.html(this.view("/lightbox/followInviter"));
        a = (new GS.Models.DataString($.localize.getString("POPUP_FOLLOW_INVITER_MESSAGE"), {user:this.user.Name})).render();
        $("#message").html(a)
    }
},"button.submit click":function() {
    GS.user.addToUserFavorites(this.user.UserID);
    GS.lightbox.close()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ThemesController", {onDocument:false}, {category:"all",slickbox:null,init:function() {
    this.update()
},update:function() {
    this.list = GS.Controllers.ThemeController.sortOrder;
    this.element.html(this.view("/lightbox/themes"));
    setTimeout(this.callback("renderThemes", this.list), 100)
},renderThemes:function(a) {
    this.slickbox = $("#lightbox_pane.themes").slickbox({itemRenderer:this.themeItem,itemWidth:128,itemHeight:112,padding:10,verticalGap:2}, a);
    $(window).resize()
},
    themeItem:function(a) {
        a = GS.Controllers.ThemeController.themes[a];
        var b = gsConfig.assetHost + "/themes/" + a.location + "/preview.jpg",c = "";
        if (a.premium)c = '<span class="isPremium"></span>';
        return['<a class="theme" rel="',a.themeID,'"><img src="',b,'"><span class="title ellipsis" title="',a.title,'">',a.title,'</span><span class="author">by ',a.author,"</span></a>",c].join("")
    },"#theme_options a click":function(a) {
        $("#theme_options a").removeClass("active");
        $(a).addClass("active");
        switch ($(a).attr("rel")) {
            case "plus":
                this.slickbox.setItems(GS.Controllers.ThemeController.plusThemes);
                break;
            case "promos":
                this.slickbox.setItems(GS.Controllers.ThemeController.promoThemes);
                break;
            case "artists":
                this.slickbox.setItems(GS.Controllers.ThemeController.artistThemes);
                break;
            case "all":
            default:
                this.slickbox.setItems(GS.Controllers.ThemeController.sortOrder);
                break
        }
        $(window).resize()
    },"a.theme click":function(a) {
        var b = _.defined($(a).attr("rel")) ? parseInt($(a).attr("rel"), 10) : 4,c = GS.Controllers.ThemeController.themes[b];
        a = $(".title", a).text();
        if (c && (GS.user.IsPremium || !c.premium)) {
            c.premium ?
                    GS.theme.setCurrentTheme(b, true) : GS.theme.loadFromDFPManual(c.themeID);
            GS.guts.logEvent("themeChangePerformed", {theme:a,id:b});
            GS.lightbox.trackLightboxView("themes/" + a);
            GS.guts.gaTrackEvent("themes", "userChange", b)
        } else if (c) {
            GS.lightbox.close();
            GS.lightbox.open("vipOnlyFeature", {callback:function() {
                c.premium ? GS.theme.setCurrentTheme(b, true) : GS.theme.loadFromDFPManual(c.themeID)
            }})
        }
    }});
(function() {
    GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ShareController", {onDocument:false,allowed:{album:["email","facebook","stumbleupon","twitter","widget"],playlist:["email","facebook","stumbleupon","twitter","reddit","widget"],song:["email","facebook","stumbleupon","twitter","reddit","widget"],manySongs:["widget"]}}, {service:"email",type:null,id:0,ids:[],idsUrl:"",metadata:null,userInfo:{},gutsShareState:{},MAX_TWEET_LENGTH:140,width:250,height:250,playOnLoad:0,colorMap:gsConfig.widgetColorMap,
        paramMap:gsConfig.widgetEmbedParamMap,defaultColors:gsConfig.widgetDefaultColors,featuredColors:gsConfig.widgetFeaturedColors,baseColor:false,primaryColor:false,secondaryColor:false,colorParams:"",theme:"metal",swf:"songWidget",init:function(a, b) {
            this.update(b);
            this.subscribe("lightbox.position", this.callback(this._repositionClips))
        },destroy:function(a) {
            if (this.clipHandler) {
                this.clipHandler.destroy();
                this.clipHandler = null
            }
            if (this.widgetClipHandler) {
                this.widgetClipHandler.destroy();
                this.widgetClipHandler =
                        null
            }
            this._super(a)
        },"#share_message.twitter keyup":function(a) {
            var b = $(a).val();
            b.length <= this.MAX_TWEET_LENGTH ? $("#twitter_counter").html(b.length) : $(a).val(b.substring(0, this.MAX_TWEET_LENGTH))
        },update:function(a) {
            this.service = a.service;
            this.type = a.type;
            this.id = a.id;
            this.userInfo = {};
            this.width = 250;
            this.height = 40;
            this.baseColor = this.defaultColors[this.colorMap.baseColors[0]];
            this.primaryColor = this.defaultColors[this.colorMap.primaryColors[0]];
            this.secondaryColor = this.defaultColors[this.colorMap.secondaryColors[0]];
            this.updateWidgetColorParams();
            this.playOnLoad = 0;
            this.swf = "songWidget";
            this.theme = "metal";
            switch (a.type) {
                case "album":
                    GS.Models.Album.getAlbum(this.id, this.callback(function(b) {
                        this.metadata = b;
                        this.metadata.name = b.AlbumName;
                        this.metadata.by = b.ArtistName;
                        this.metadata.url = "http://grooveshark.com/" + b.toUrl().replace("#/", "");
                        b.getSongs(function(c) {
                            $.each(c, function(g, h) {
                                this.ids.push(h.SongID);
                                this.idsUrl += h.SongID + ","
                            })
                        });
                        self.loadService()
                    }));
                    break;
                case "playlist":
                    this.height = 250;
                    this.swf = "widget";
                    GS.Models.Playlist.getPlaylist(this.id, this.callback(function(b) {
                        this.metadata = b;
                        this.metadata.name = b.PlaylistName;
                        this.metadata.by = b.UserName;
                        this.metadata.url = "http://grooveshark.com/" + b.toUrl().replace("#/", "");
                        this.loadService()
                    }));
                    break;
                case "song":
                    GS.Models.Song.getSong(this.id, this.callback(function(b) {
                        this.metadata = b;
                        this.metadata.name = b.SongName;
                        this.metadata.by = b.ArtistName;
                        this.metadata.url = "http://grooveshark.com/" + b.toUrl().replace("#/", "");
                        this.idsUrl = b.SongID;
                        this.loadService()
                    }));
                    break;
                case "manySongs":
                    this.idsUrl = this.id.join(",");
                    this.height = 250;
                    this.swf = "widget";
                    this.loadService();
                    break
            }
        },loadService:function() {
            this.submitKey = "SHARE";
            this.showSubmit = true;
            switch (this.service) {
                case "facebook":
                    if (GS.facebook.connected)GS.facebook.getFriends(this.callback(function(a) {
                        this.facebookFriends = a || [];
                        this.submitKey = "SHARE_FACEBOOK_WALL";
                        this.renderService();
                        if (a) {
                            var b = [];
                            $.each(this.facebookFriends, this.callback(function(c, g) {
                                b.push([g.id,g.name,g.name])
                            }));
                            a = new $.TextboxList("#facebook_share_to",
                                    {addOnBlur:true,bitsOptions:{editable:{growing:true,growingOptions:{maxWidth:335}}},plugins:{autocomplete:{placeholder:$.localize.getString("SHARE_FACEBOOK_PLACEHOLDER")}},encode:this.callback(function(c) {
                                        var g = [];
                                        if (c.length) {
                                            for (var h = 0; h < c.length; h++)c[h][0] && g.push(c[h][0]);
                                            this.element.find(".submit span").attr("data-translate-text", "SEND_INVITE").html($.localize.getString("SHARE_FACEBOOK_FRIENDS"))
                                        } else this.element.find(".submit span").attr("data-translate-text", "POST_TO_PROFILE").html($.localize.getString("SHARE_FACEBOOK_WALL"));
                                        return g.join(",")
                                    })});
                            a.plugins.autocomplete.setValues(b);
                            a.addEvent("bitAdd", function(c) {
                                if (c.getValue()[1] === "")c.hide(); else {
                                    var g = $("#facebook_share_to").val().split(",");
                                    if (g) {
                                        var h = g.indexOf(c.getValue()[0]);
                                        c.getValue()[0] && h >= 0 && h != g.length - 1 && c.hide()
                                    }
                                }
                            });
                            a.fireEvent("focus")
                        } else {
                            this.element.find("#fbConnected").hide();
                            this.element.find("#fbNotConnected").show();
                            GS.lightbox.positionLightbox()
                        }
                    })); else {
                        this.facebookFriends = [];
                        this.submitKey = "SHARE";
                        this.renderService()
                    }
                    GS.lightbox.trackLightboxView("share/facebook");
                    break;
                case "email":
                    this.renderService();
                    GS.user.UserID > 0 && GS.service.getContactInfoForFollowers(this.callback(function(a) {
                        var b = [];
                        $.each(a, this.callback(function(c, g) {
                            b.push([g.UserID,g.FName + " " + g.Email,g.FName,g.FName]);
                            this.userInfo[g.UserID] = g;
                            this.userInfo[g.Email] = g
                        }));
                        a = new $.TextboxList("#share_to", {addOnBlur:true,bitsOptions:{editable:{growing:true,growingOptions:{maxWidth:335}}},plugins:{autocomplete:{placeholder:$.localize.getString("SHARE_EMAIL_PLACEHOLDER")}},encode:this.callback(function(c) {
                            for (var g =
                                    [],h = 0; h < c.length; h++)if (c[h][0])g.push(c[h][0]); else c[h][1] && g.push(c[h][1]);
                            return g.join(",")
                        })});
                        a.plugins.autocomplete.setValues(b);
                        a.addEvent("bitAdd", function(c) {
                            c.getValue()[1] === "" && c.hide()
                        });
                        a.fireEvent("focus")
                    }), this.callback(function(a) {
                        console.warn("failed grabbing contact info for followers", autocompleteTerms, a);
                        $.publish("gs.notification", {type:"error",message:$.localize.getString("POPUP_FAIL_FANS_EMAIL_ONLY")})
                    }), {async:false});
                    GS.lightbox.trackLightboxView("share/email");
                    setTimeout(function() {
                                $("#share_content .textboxlist-bit-editable-input").focus()
                            },
                            0);
                    break;
                case "twitter":
                    this.monday = (new Date).format("D") === "Mon" ? true : false;
                    GS.service.getDetailsForBroadcast(this.id, this.callback(function(a) {
                        this.tinysong = a;
                        this.submitKey = "SHARE_BROADCAST";
                        this.renderService()
                    }));
                    GS.lightbox.trackLightboxView("share/twitter");
                    break;
                case "stumbleupon":
                    this.submitKey = "SHARE_STUMBLE";
                    this.renderService();
                    GS.lightbox.trackLightboxView("share/stumbleupon");
                    break;
                case "reddit":
                    this.submitKey = "SHARE_REDDIT";
                    this.renderService();
                    GS.lightbox.trackLightboxView("share/reddit");
                    break;
                case "widget":
                    this.renderService();
                    this.initColorPicker();
                    GS.lightbox.trackLightboxView("share/widget");
                    break;
                default:
                    this.showSubmit = false;
                    this.renderService();
                    GS.lightbox.trackLightboxView("share/default");
                    break
            }
        },makeBaseGutsLogState:function() {
            var a = {type:this.type,service:this.service};
            switch (this.type) {
                case "playlist":
                    a.PlaylistID = this.metadata.PlaylistID;
                    break;
                case "song":
                    a.SongID = this.metadata.SongID;
                    break;
                case "album":
                    a.AlbumID = this.metadata.AlbumID;
                    break
            }
            this.gutsShareState = a
        },renderService:function() {
            this.element.html(this.view("/lightbox/share/index"));
            if (this.service == "facebook")if (GS.facebook.connected && this.facebookFriends && this.facebookFriends.length)$("input:nth-child(2)", this.element).focus(); else GS.facebook.connected && this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_SHARE_FACEBOOK_ERROR_FRIENDS"));
            GS.lightbox.positionLightbox()
        },_repositionClips:function() {
            var a = this;
            if ($("#" + this.type + "_share_copy_url").length)if (this.clipHandler)this.clipHandler.reposition(this.type + "_share_copy_url"); else {
                this.clipHandler =
                        new ZeroClipboard.Client;
                this.clipHandler.setText(this.metadata.url);
                this.clipHandler.setHandCursor(true);
                this.clipHandler.setCSSEffects(true);
                this.clipHandler.glue(this.type + "_share_copy_url");
                $("#" + this.type + "_share_copy_url").removeClass("copied").find("a span").html($.localize.getString("SHARE_COPY"));
                this.clipHandler.addEventListener("complete", function() {
                    $("#" + a.type + "_share_copy_url").addClass("copied").find("a span").html($.localize.getString("SHARE_COPIED"))
                })
            }
            if (this.service == "widget" &&
                    $("#widget_copy").length)if (this.widgetClipHandler)this.widgetClipHandler.reposition("widget_copy"); else {
                this.widgetClipHandler = new ZeroClipboard.Client;
                this.widgetClipHandler.setText($("#share_message").val());
                this.widgetClipHandler.setHandCursor(true);
                this.widgetClipHandler.setCSSEffects(true);
                this.widgetClipHandler.glue("widget_copy");
                $("#widget_copy").removeClass("copied").find("a span").html($.localize.getString("SHARE_COPY_TO_CLIPBOARD"));
                this.widgetClipHandler.addEventListener("complete", function() {
                    $("#widget_copy").addClass("copied").find("a span").html($.localize.getString("SHARE_COPIED_TO_CLIPBOARD"))
                })
            }
        },
        "a.submit, button.submit click":function(a, b) {
            $("form", this.element).submit();
            b.preventDefault();
            b.stopPropagation()
        },"form submit":function(a, b) {
            b.preventDefault();
            b.stopPropagation();
            this.makeBaseGutsLogState();
            switch (this.service) {
                case "email":
                    this.broadcastEmail(a, b);
                    break;
                case "stumbleupon":
                case "reddit":
                    window.open(_.makeUrlForShare(this.service, this.type, this.metadata), "_blank");
                    break;
                case "twitter":
                    if (this.type === "song") {
                        var c = $("textarea[name=share_message]", this.element).val();
                        c = c.replace(this.tinysong.tinySongURL,
                                "");
                        window.open("http://twitter.com/share?related=grooveshark&url=" + encodeURIComponent(this.tinysong.tinySongURL) + "&text=" + encodeURIComponent(c), "_blank");
                        GS.lightbox.close()
                    } else if (this.type === "playlist") {
                        c = $("textarea[name=share_message]", this.element).val();
                        window.open("http://twitter.com/share?related=grooveshark&url=http://grooveshark.com/" + encodeURIComponent(this.metadata.toUrl().replace("#/", "")) + "&text=" + encodeURIComponent(c), "_blank");
                        GS.lightbox.close()
                    }
                    break;
                case "facebook":
                    var g = "http://grooveshark.com/" +
                            this.metadata.toUrl().replace("#/", "");
                    if (GS.facebook.connected) {
                        c = $("#facebook_share_to").val() == "" ? [] : $("#facebook_share_to").val().split(",");
                        this.gutsShareState.ids = "[" + c.join(",") + "]";
                        var h = $("textarea[name=facebookMessage]", a).val();
                        c.length ? _.forEach(c, this.callback(function(k) {
                            GS.facebook.postToFeed(k, g, h, this.type, this.callback("facebookSuccess"), this.callback("facebookFailed"))
                        })) : GS.facebook.postLink("me", g, h, this.type, this.callback("facebookSuccess"), this.callback("facebookFailed"))
                    } else {
                        window.open("http://facebook.com/share.php?u=" +
                                encodeURIComponent(g), "_blank");
                        GS.lightbox.close()
                    }
                    break
            }
            GS.guts.forceLogEvent("share", this.gutsShareState);
            this.gutsShareState = {};
            return false
        },broadcastEmail:function(a) {
            var b = ($("input[name=to]", a).val() || "").split(","),c = $("textarea[name=message]", a).val(),g = [],h = $("#share_to").siblings(".textboxlist").find(".textboxlist-bit").not(".textboxlist-bit-box-deletable").filter(":last").text();
            a = $("input[name=privacy]", a).is(":checked");
            _.forEach(b, function(k) {
                if (this.userInfo[k])g.push({userID:this.userInfo[k].UserID,
                    userName:this.userInfo[k].Name,email:this.userInfo[k].Email}); else k && g.push({email:k})
            }, this);
            this.gutsShareState.people = JSON.stringify(g);
            h && g.push({email:h});
            g.length ? GS.service.sendShare(this.type, this.id, g, true, c, a, this.callback("broadcastEmailSuccess"), this.callback("broadcastEmailFailed")) : this.broadcastEmailFailed()
        },broadcastEmailSuccess:function(a) {
            var b = [];
            if (!a)return this.broadcastEmailFailed(a);
            if (a.Result && a.Result.emailsFailed && a.Result.emailsFailed.length > 0) {
                _.forEach(a.Result.emailsFailed,
                        function(c) {
                            switch (c.failReason) {
                                case 1:
                                    b.push("<li>" + (new GS.Models.DataString($.localize.getString("POPUP_SHARE_ERROR_ALREADY_MESSAGED"), {emailAddresses:c.person.email})).render() + "</li>");
                                    break
                            }
                        });
                if (b.length) {
                    a = "<ul>" + b.join("") + "</ul>";
                    this.element.find(".error").show().find(".message").html(a)
                }
            } else {
                GS.lightbox.close();
                $.publish("gs.notification", {message:$.localize.getString("NOTIF_FACEBOOK_SHARE_" + this.type.toUpperCase())})
            }
        },broadcastEmailFailed:function() {
            this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_FAIL_SHARING_FANS"));
            GS.lightbox.positionLightbox()
        },facebookSuccess:function() {
            GS.lightbox.close()
        },facebookFailed:function() {
            this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_SHARE_FACEBOOK_ERROR"));
            GS.lightbox.positionLightbox()
        },"#share_options .email click":function() {
            this.service = "email";
            this.loadService()
        },"#share_options .facebook click":function() {
            this.service = "facebook";
            this.loadService()
        },"#share_options .stumble click":function() {
            this.service = "stumbleupon";
            this.loadService()
        },
        "#share_options .twitter click":function() {
            this.service = "twitter";
            this.loadService()
        },"#share_options .reddit click":function() {
            this.service = "reddit";
            this.loadService()
        },"#share_options .widget click":function() {
            this.service = "widget";
            this.loadService()
        },"button.widgetPreview click":function(a) {
            $("#share_lightbox_wrapper").height();
            var b;
            b = this.type == "manySongs" ? this.view("/shared/widgetEmbed", $.extend(this, {width:250,height:200})) : this.view("/shared/widgetEmbed", $.extend(this, {width:250}));
            $("#share_lightbox_wrapper .container").html(b).css({width:this.width,
                height:this.height});
            $("#share_lightbox_overlay,#share_lightbox_wrapper").show();
            GS.lightbox.positionLightbox();
            a.parent().hide().siblings().show();
            this.widgetClipHandler.reposition("widget_copy");
            GS.lightbox.trackLightboxView("share/widget/preview")
        },"button.widgetCustomize click":function(a) {
            $("#share_lightbox_overlay,#share_lightbox_wrapper").hide();
            GS.lightbox.positionLightbox();
            a.parent().hide().siblings().show();
            this.widgetClipHandler.reposition("widget_copy");
            GS.lightbox.trackLightboxView("share/widget/customize")
        },
        "#share_lightbox_wrapper .widgetPreviewClose click":function() {
            $("button.widgetCustomize", this.element).click()
        },updateWidgetTextarea:function() {
            this.updateWidgetColorParams();
            $("#widget_embed textarea").val(this.view("/shared/widgetEmbed"));
            this.widgetClipHandler.setText($("#share_message").val())
        },updateWidgetColorParams:function() {
            for (var a = [],b = 0; b < this.colorMap.baseColors.length; b++)a.push(this.paramMap[this.colorMap.baseColors[b]] + "=" + this.baseColor);
            for (b = 0; b < this.colorMap.primaryColors.length; b++)a.push(this.paramMap[this.colorMap.primaryColors[b]] +
                    "=" + this.primaryColor);
            for (b = 0; b < this.colorMap.secondaryColors.length; b++)a.push(this.paramMap[this.colorMap.secondaryColors[b]] + "=" + this.secondaryColor);
            this.colorParams = a.join("&")
        },".widgetPanes input change":function(a) {
            if (a.attr("type") == "checkbox")this[a.attr("name")] = a.is(":checked") ? 1 : 0; else this[a.attr("name")] = a.val();
            this.updateWidgetTextarea()
        },".widgetPanes ul.themes li click":function(a) {
            a.addClass("active").siblings().removeClass("active")
        },".widgetPanes select.colorScheme blur":function(a) {
            a.change()
        },
        ".widgetPanes select.colorScheme change":function(a) {
            var b = this.featuredColors[a.val()],c = this.colorMap.baseColors,g = this.colorMap.primaryColors,h = this.colorMap.secondaryColors;
            $("#baseColorInput").val(b[c[0]]).siblings(".colorEx").css("backgroundColor", "#" + b[c[0]]);
            $("#primaryColorInput").val(b[g[0]]).siblings(".colorEx").css("backgroundColor", "#" + b[g[0]]);
            $("#secondaryColorInput").val(b[h[0]]).siblings(".colorEx").css("backgroundColor", "#" + b[h[0]]);
            a.siblings("span").html(a.find("option:selected").html());
            this.baseColor = b[c[0]];
            this.primaryColor = b[g[0]];
            this.secondaryColor = b[h[0]];
            this.updateWidgetTextarea()
        },initColorPicker:function() {
            var a = null,b = false;
            $("button.colorPicker", this.element).each(function() {
                var c = $(this);
                c.ColorPicker({onHide:function(g) {
                    b && a.removeClass("isopen");
                    c.removeClass("active");
                    $(g).slideUp(500);
                    return b = false
                },onShow:function(g) {
                    a && a != c && a.removeClass("isopen");
                    if ($(g).is(":visible")) {
                        c.removeClass("isopen");
                        a.removeClass("isopen");
                        $(g).hide();
                        a = null;
                        b = false
                    } else {
                        $(g).slideDown(500);
                        c.addClass("active").addClass("isopen");
                        a = c;
                        b = true
                    }
                    return false
                },onBeforeShow:function() {
                    $(this).ColorPickerSetColor($(this).siblings("input").attr("value"));
                    return false
                },onChange:function(g, h) {
                    c.siblings(".colorEx").css("backgroundColor", "#" + h);
                    c.siblings("input").attr("value", h);
                    c.siblings("input").change()
                }})
            })
        },"#lightbox .error .message .resetPerms click":function(a, b) {
            b.preventDefault();
            GS.facebook.logout(function() {
                GS.facebook.login(function() {
                    $("#lightbox").find(".error").hide()
                }, function(c) {
                    c &&
                            c.error ? $("#lightbox").find(".error").find(".message").html($.localize.getString("POPUP_SHARE_FACEBOOK_ERROR_PREPEND_ERROR") + "<br />" + $.localize.getString(c.error)) : $("#lightbox").find(".error").find(".message").text($.localize.getString("POPUP_SHARE_FACEBOOK_ERROR_PREPEND_ERROR"))
                })
            })
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ForgetController", {onDocument:false}, {MIN_USERPASS_LENGTH:5,MAX_USERPASS_LENGTH:32,init:function(a, b) {
    this.update(b)
},update:function(a) {
    if (a && _.defined(a.resetCode)) {
        this.reset = true;
        this.resetCode = a.resetCode
    } else this.resetCode = this.reset = false;
    this.element.html(this.view("/lightbox/forget"))
},showError:function(a) {
    $("div.message", this.element).html($.localize.getString(a));
    this.element.find(".error").show();
    GS.lightbox.positionLightbox()
},
    "a.login click":function() {
        GS.lightbox.close();
        GS.lightbox.open("login")
    },"a.submit click":function() {
        $("form", this.element).submit()
    },"form submit":function(a, b) {
        b.preventDefault();
        var c = $("input[name=username]", a).val();
        if (this.reset) {
            var g = $("input[name=newPassword]", a).val(),h = $("input[name=confirmPassword]", a).val();
            g == h && g.length && g.length >= this.MIN_USERPASS_LENGTH && g.length <= this.MAX_USERPASS_LENGTH ? GS.service.resetPassword(c, this.resetCode, g, this.callback(this.resetSuccess, c, g), this.callback(this.resetFailed)) :
                    this.showError("POPUP_SIGNUP_FORM_PASSWORD_INVALID_NO_MATCH")
        } else GS.service.userForgotPassword(c, this.callback(this.serviceSuccess), this.callback(this.serviceFailed));
        return false
    },serviceSuccess:function(a) {
        if (a && a.userID == 0 || !a)return this.serviceFailed(a);
        GS.lightbox.close()
    },serviceFailed:function() {
        this.showError("POPUP_SIGNUP_FORGOT_FORM_RESPONSE_ERROR")
    },resetSuccess:function(a, b, c) {
        if (!c || c.success != 1)return this.resetFailed(c);
        GS.lightbox.close();
        GS.auth.login(a, b)
    },resetFailed:function(a) {
        if (_.defined(a.success))a.success ==
                0 ? this.showError("POPUP_FORGET_RESET_ERROR_BADUSER") : this.showError("POPUP_FORGET_RESET_ERROR_BADCODE"); else this.showError("POPUP_FORGET_RESET_ERROR_UNKNOWN")
    }});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.FeedbackController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.user = GS.user;
    this.feelings = $.localize.getString("POPUP_FEEDBACK_FEELINGS").split(",");
    this.element.html(this.view("/lightbox/feedback"))
},"a.submit, button.submit click":function() {
    $("form", this.element).submit()
},"#feedback_feeling change":function(a) {
    $(a).siblings("span").text($(a).val())
},"form submit":function(a, b) {
    b.preventDefault();
    var c =
            $("input[name=email]", a).val(),g = $("select[name=feeling]", a).val(),h = $("textarea[name=feedback]", a).val();
    if (h.length && c.length) {
        g = "User email address: " + c + "\nMood: " + g + "\nFeedback report:\n" + h;
        this.element.find(".error").hide();
        GS.service.provideVIPFeedback(c, g, this.callback(this.feedbackSuccess), this.callback(this.feedbackFailed))
    } else if (h.length)c.length || this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_FEEDBACK_ERROR_FEEDBACK")); else this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_FEEDBACK_ERROR_FEEDBACK"));
    return false
},feedbackSuccess:function(a) {
    if (a && a.Success == 0 || !a)return this.feedbackFailed(a);
    GS.lightbox.close();
    $.publish("gs.user.feedback", a)
},feedbackFailed:function() {
    this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_FEEDBACK_ERROR"));
    GS.lightbox.close()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.BadHostController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/badHost"))
},"a.submit click":function() {
    window.location.href = "http://www.grooveshark.com"
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.InteractionTimeController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    GS.player.pauseNextSong();
    this.element.html(this.view("/lightbox/interactionTime"));
    this.subscribe("gs.player.paused", this.callback("onSongPause"))
},onSongPause:function() {
    $("#lb_interacation_message").attr("data-translate-text", "POPUP_INTERACTION_MSG_PAUSED").html($.localize.getString("POPUP_INTERACTION_MSG_PAUSED"));
    $("#lb_interacation_submit").attr("data-translate-text",
            "POPUP_INTERACTION_RESUME").html($.localize.getString("POPUP_INTERACTION_RESUME"))
},"#lightbox a.upgrade click":function() {
    GS.player.pauseNextQueueSongID = false;
    GS.player.resumeSong();
    GS.lightbox.close()
},"#lightbox a.submit click":function() {
    $("form", this.element).submit()
},"#lightbox a.close click":function() {
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    GS.player.pauseNextQueueSongID = false;
    GS.player.resumeSong();
    GS.lightbox.close();
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.InvalidClientController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/invalidClient"))
},"a.submit click":function() {
    window.location.reload(true)
},"button click":function() {
    window.location.reload(true)
}});
GS.Controllers.InviteInterface.extend("GS.Controllers.Lightbox.InviteController", {onDocument:false}, {userInfo:{},googleContacts:null,facebookFriends:[],fbIDs:{},slickbox:false,init:function(a, b) {
    this.update(b)
},update:function(a) {
    a = _.orEqual(a, {});
    this.submitType = "facebook";
    this.element.html(this.view("/lightbox/invite/invite"));
    $("#lightbox_pane").html(this.view("/lightbox/invite/facebook"));
    GS.facebook.connected && GS.facebook.getFriends(this.callback("onFacebookFriends"));
    this.subscribe("gs.facebook.profile.update",
            this.callback(function() {
                $("#lightbox_pane", this.element).html(this.view("/lightbox/invite/facebook"));
                GS.lightbox.positionLightbox();
                GS.facebook.getFriends(this.callback("onFacebookFriends"))
            }));
    if (a.gotoFacebook)$("#invite_options a.facebook_service").click(); else a.gotoGoogle && $("#invite_options a.google_service").click()
},"a.submit click":function() {
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    this.element.find(".error").hide();
    this.formSubmit();
    return false
},
    sendInviteSuccessCallback:function() {
        GS.lightbox.close()
    },googContactsSuccessCallback:function() {
        this.submitType = "googleContacts";
        $("#lightbox_pane", this.element).html(this.view("/lightbox/invite/googleContacts"));
        $("ul.google_contacts", this.element).html(this.view("/shared/googleContacts")).show();
        GS.lightbox.positionLightbox();
        $("ul.google_contacts li:even").addClass("even contactRow_even");
        $("ul.google_contacts li:odd").addClass("odd contactRow_odd")
    },facebookSuccessCallback:function() {
        GS.lightbox.close()
    },
    "#invite_options a click":function(a, b) {
        b.preventDefault();
        if (!$(a).is(".active")) {
            $("#invite_options a.active").removeClass("active");
            $(a).addClass("active");
            switch ($(a).attr("name")) {
                case "email":
                    this.submitType = "email";
                    $("#lightbox_pane", this.element).html(this.view("/lightbox/invite/email"));
                    new $.TextboxList("#emails", {addOnBlur:true,bitsOptions:{editable:{growing:true,growingOptions:{maxWidth:$("#emails").innerWidth() - 10}}}});
                    break;
                case "google":
                    this.submitType = "googleLogin";
                    $("#lightbox_pane",
                            this.element).html(this.view("/lightbox/invite/googleLogin"));
                    $("input[name=google_username]", this.element).focus();
                    break;
                case "facebook":
                    this.submitType = "facebook";
                    $("#lightbox_pane", this.element).html(this.view("/lightbox/invite/facebook"));
                    break
            }
        }
        GS.lightbox.positionLightbox();
        return false
    }});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.LocaleController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.languages = [
        {locale:"ca",name:"Catal\u00e0"},
        {locale:"cs",name:"\u010ce\u0161tina"},
        {locale:"cy",name:"Cymraeg"},
        {locale:"da",name:"Dansk"},
        {locale:"de",name:"Deutsch"},
        {locale:"en",name:"English"},
        {locale:"es",name:"Espa\u00f1ol"},
        {locale:"et",name:"Eesti"},
        {locale:"eu",name:"Euskara"},
        {locale:"fr",name:"Fran\u00e7ais"},
        {locale:"gl",name:"Galego"},
        {locale:"el",name:"\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac"},
        {locale:"nl",name:"Nederlands"},
        {locale:"lt",name:"Lietuvi\u0173"},
        {locale:"pl",name:"Polski"},
        {locale:"pt",name:"Portugu\u00eas"},
        {locale:"ru",name:"\u0420\u0443\u0441\u0441\u043a\u0438\u0439"},
        {locale:"sk",name:"Sloven\u010dina"},
        {locale:"fi",name:"Suomi"},
        {locale:"sv",name:"Svenska"},
        {locale:"tr",name:"T\u00fcrk\u00e7e"},
        {locale:"uk",name:"Y\u043a\u0440\u0430\u0457\u0301\u043d\u0441\u044c\u043a\u0430"},
        {locale:"zh",name:"\u4e2d\u6587"},
        {locale:"bg",name:"\u0411\u044a\u043b\u0433\u0430\u0440\u0441\u043a\u0438"},
        {locale:"it",name:"Italiano"},
        {locale:"ja",name:"\u65e5\u672c\u8a9e"},
        {locale:"nb",name:"Norsk "},
        {locale:"ro",name:"Rom\u00e2n\u0103"},
        {locale:"sl",name:"Sloven\u0161\u010dina"}
    ];
    this.languages.sort(function(a, b) {
        return a.name > b.name ? 1 : -1
    });
    this.element.html(this.view("/lightbox/locale"))
},"a.language click":function(a) {
    $.publish("gs.locale.update", $(a).attr("rel"));
    a = $(a).attr("rel");
    GS.guts.logEvent("localeChangePerformed",
            {locale:a});
    GS.guts.beginContext({locale:a});
    GS.lightbox.close()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.MaintenanceController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/maintenance"))
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.SessionBadController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/sessionBad"))
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.VIPOnlyFeatureController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    if (a && a.callback)GS.auth.vipUpdateCallback = a.callback;
    this.element.html(this.view("/lightbox/vipOnlyFeature"));
    GS.lightbox.positionLightbox()
},"button.submit click":function() {
    GS.lightbox.close();
    if (GS.user.UserID > 0)GS.lightbox.open("vipPerks"); else location.hash = "#/signup"
},"button.login_button click":function() {
    GS.lightbox.close();
    GS.user.UserID >
            0 ? GS.lightbox.open("vipPerks") : GS.lightbox.open("login")
}});
(function() {
    GS.Controllers.VipInterface.extend("GS.Controllers.Lightbox.VipPerksController", {onDocument:false}, {tourStep:0,vipPackage:null,PLUS_STEPS:5,ANYWHERE_STEPS:7,STEP_WIDTH:648,STEP_TRANSITION:600,init:function(a, b) {
        this.update(b)
    },update:function() {
        this.element.html(this.view("/lightbox/perks/index"));
        GS.lightbox.positionLightbox();
        GS.lightbox.trackLightboxView("/lightbox/perks")
    },"button.upgrade click":function(a) {
        a = _.orEqual($(a).attr("rel"), this.vipPackage);
        GS.lightbox.close();
        GS.lightbox.open("vipSignup",
                {vipPackage:a,isSignup:false})
    },"a.takeTour click":function(a) {
        $("#intro_tour").hide();
        if ($(a).attr("rel") == "plus") {
            this.vipPackage = "plus";
            $("#perks_title").text("Grooveshark Plus");
            $("#anywhere_tour").hide();
            $("#plus_tour").show().scrollLeft(0);
            $("#plus_tour_steps").css("left", 0)
        } else {
            this.vipPackage = "anywhere";
            $("#perks_title").text("Grooveshark Anywhere");
            $("#plus_tour").hide();
            $("#anywhere_tour").show().scrollLeft(0);
            $("#anywhere_tour_steps").css("left", 0)
        }
        this.tourStep = 0;
        $("#lightbox_footer").show();
        this.updateNavigation();
        GS.lightbox.positionLightbox()
    },"button.intro click":function() {
        $("#intro_tour").show();
        $("#lightbox_footer, #plus_tour, #anywhere_tour").hide();
        $("#perks_title").text($.localize.getString("POPUP_PERKS_TITLE"));
        GS.lightbox.positionLightbox()
    },"a.gotoStep click":function(a) {
        this.tourStep = _.defined($(a).attr("rel")) ? parseInt($(a).attr("rel")) : 0;
        this.animateToStep();
        this.updateNavigation()
    },"button.next click":function() {
        this.tourStep++;
        this.animateToStep();
        this.updateNavigation()
    },
        "button.back click":function() {
            if (this.tourStep > 0) {
                this.tourStep--;
                this.animateToStep();
                this.updateNavigation()
            }
        },updateNavigation:function() {
            if (this.tourStep == 0) {
                $("#lightbox_footer .intro").show();
                $("#lightbox_footer .back").hide();
                $("#lightbox_footer .next").show();
                $("#lightbox_footer .finish").hide()
            } else if (this.vipPackage == "plus" && this.tourStep + 1 == this.PLUS_STEPS || this.vipPackage == "anywhere" && this.tourStep + 1 == this.ANYWHERE_STEPS) {
                $("#lightbox_footer .intro").hide();
                $("#lightbox_footer .back").show();
                $("#lightbox_footer .next").hide();
                $("#lightbox_footer .finish").show()
            } else {
                $("#lightbox_footer .intro").hide();
                $("#lightbox_footer .back").show();
                $("#lightbox_footer .next").show();
                $("#lightbox_footer .finish").hide()
            }
            var a = this.vipPackage == "plus" ? this.PLUS_STEPS : this.ANYWHERE_STEPS;
            a = $(".tour_steps_nav", this.element).html(this.view("/lightbox/perks/stepProgress", {steps:a,index:this.tourStep}));
            a.css("marginLeft", a.width() / 2 * -1);
            GS.lightbox.trackLightboxView("lightbox/perks/" + this.vipPackage + "/step" +
                    this.tourStep)
        },animateToStep:function() {
            if (this.vipPackage == "plus" && this.tourStep < this.PLUS_STEPS)$.browser.msie ? $("#plus_tour_steps").stop().animate({left:-(this.STEP_WIDTH * this.tourStep)}, this.STEP_TRANSITION) : $("#plus_tour").stop().animate({scrollLeft:this.STEP_WIDTH * this.tourStep}, this.STEP_TRANSITION); else if (this.vipPackage == "anywhere" && this.tourStep < this.ANYWHERE_STEPS)$.browser.msie ? $("#anywhere_tour_steps").stop().animate({left:-(this.STEP_WIDTH * this.tourStep)}, this.STEP_TRANSITION) : $("#anywhere_tour").stop().animate({scrollLeft:this.STEP_WIDTH *
                    this.tourStep}, this.STEP_TRANSITION)
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.NewPlaylistController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.songIDs = $.makeArray(a);
    this.overrideDupe = false;
    this.element.html(this.view("/lightbox/newPlaylist"))
},"a.submit click":function() {
    $("form", this.element).submit()
},"#newPlaylistForm input[name=name] change":function() {
    this.overrideDupe = false
},saveToSidebar:false,"form submit":function(a) {
    var b = $("input[name=name]", a).val(),c = $("textarea[name=description]",
            a).val();
    this.saveToSidebar = $("input[name=save]", a).is(":checked");
    if (b.length)if (this.overrideDupe || GS.user.isPlaylistNameAvailable(b))GS.user.createPlaylist(b, this.songIDs, c, this.callback("createSuccess"), this.callback("createFailed")); else {
        this.overrideDupe = true;
        $("div.error .message", this.element).text(_.getString("POPUP_PLAYLIST_METADATA_DUPLICATE_NAME_ERROR", {name:b}));
        $("div.error", this.element).show()
    } else {
        $("div.error .message", this.element).text($.localize.getString("POPUP_PLAYLIST_METADATA_ENTER_NAME_ERROR"));
        $("div.error", this.element).show()
    }
    return false
},createSuccess:function(a) {
    this.playlist = a;
    $("div.error", this.element).hide();
    this.saveToSidebar && this.playlist.addShortcut(false);
    GS.lightbox.close()
},createFailed:function(a) {
    console.error("playlist.new failed", a);
    $("div.error .message", this.element).text($.localize.getString("POPUP_PLAYLIST_METADATA_ERROR"));
    $("div.error", this.element).show()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.RemovePlaylistSidebarController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.playlistID = a;
    this.playlist = GS.Models.Playlist.getOneFromCache(a);
    this.isSubscribed = this.playlist.isSubscribed();
    a = (new GS.Models.DataString($.localize.getString("POPUP_DELETE_PLAYLIST_QUESTION"), {playlist:this.playlist.PlaylistName})).render();
    this.element.html(this.view("/lightbox/removePlaylistSidebar"));
    this.element.find("#message").html(a)
},
    "button.shortcut click":function(a, b) {
        b.stopImmediatePropagation();
        this.playlist.removeShortcut();
        GS.lightbox.close()
    },"button.playlist click":function(a, b) {
        b.stopImmediatePropagation();
        this.playlist.isSubscribed() ? this.playlist.unsubscribe() : this.playlist.remove();
        GS.lightbox.close()
    },"form submit":function(a, b) {
        b.preventDefault();
        b.stopPropagation()
    }});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.RenamePlaylistController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.playlistID = a;
    this.playlist = GS.Models.Playlist.getOneFromCache(a);
    this.element.html(this.view("/lightbox/renamePlaylist"))
},"a.submit click":function() {
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    this.name = $("input[name=name]", a).val();
    this.description = $("textarea[name=description]", a).val();
    this.counter =
            0;
    if (this.name.length) {
        this.playlist.rename(this.name, this.callback(this.renameSuccess), this.callback(this.renameFailed));
        this.playlist.changeDescription(this.description, this.callback(this.renameSuccess), this.callback(this.renameFailed))
    } else {
        $("div.error .message", this.element).text($.localize.getString("POPUP_PLAYLIST_METADATA_ENTER_NAME_ERROR")).show();
        $("div.error", this.element).show()
    }
    return false
},renameSuccess:function() {
    this.counter++;
    if (this.counter === 2) {
        GS.lightbox.close();
        location.hash =
                this.playlist.toUrl()
    }
},renameFailed:function() {
    $("div.error .message", this.element).text($.localize.getString("POPUP_PLAYLIST_META_TITLE_ERROR")).show();
    $("div.error", this.element).show()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.DeletePlaylistController", {onDocument:false}, {user:null,init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.playlistID = a;
    this.playlist = GS.Models.Playlist.getOneFromCache(a);
    this.element.html(this.view("/lightbox/deletePlaylist"));
    a = (new GS.Models.DataString($.localize.getString("POPUP_DELETE_PLAYLIST_MESSAGE"), {playlist:this.playlist.PlaylistName})).render();
    this.element.find("#message").html(a)
},"button.submit click":function(a, b) {
    b.stopImmediatePropagation();
    this.playlist.remove();
    GS.lightbox.close()
},"form submit":function(a, b) {
    b.preventDefault();
    b.stopPropagation()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.AddSongsToPlaylistController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.songIDs = a;
    this.playlists = GS.Models.Playlist.getPlaylistsOrdered("PlaylistName");
    this.element.html(this.view("/lightbox/addSongsToPlaylist"))
},"input.playlist click":function(a) {
    $(a).is(":checked") ? $(a).closest("li.playlist").addClass("selected") : $(a).closest("li.playlist").removeClass("selected")
},"a.submit click":function() {
    $("form",
            this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    var c,g,h = this,k = false;
    $("input:checked", this.element).each(function() {
        c = this.value;
        if (g = GS.Models.Playlist.getOneFromCache(c)) {
            k = true;
            g.addSongs(h.songIDs, null, true)
        }
    });
    k && GS.lightbox.close();
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.BuySongController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.songID = a;
    (this.song = GS.Models.Song.getOneFromCache(this.songID)) ? GS.service.getAffiliateDownloadURLs(this.song.SongName, this.song.ArtistName, this.callback("urlsSuccess"), this.callback("urlsFailed")) : this.urlsFailed();
    this.element.html(this.view("/lightbox/buySong"))
},urlsSuccess:function(a) {
    var b = false,c = false;
    if (a.amazon && a.amazon.url)$("a.amazon",
            this.element).attr("href", a.amazon.url).show(); else b = true;
    if (a.iTunes && a.iTunes.url)$("a.itunes", this.element).attr("href", a.iTunes.url).show(); else c = true;
    b && c && this.urlsFailed()
},urlsFailed:function() {
    $(".error", this.element).show()
},"a click":function() {
    GS.lightbox.close()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.LastfmApprovalController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.user = GS.user;
    this.visited = false;
    this.element.html(this.view("/lightbox/lastfm_approval"))
},"a.gotoLastfm click":function(a, b) {
    b.preventDefault();
    if (this.visited) {
        GS.lastfm.saveSession();
        GS.lightbox.close()
    } else {
        window.open(a[0].getAttribute("href"), "", "height=450,width=780,status=1,location=1,resizable=yes");
        $(a).find("span").text($.localize.getString("LASTFM_SERVICE_BACK_FROM"));
        $("button.close", this.element).hide();
        this.visited = true
    }
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.RestoreQueueController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    $(this.element).html(this.view("/lightbox/restoreQueue"))
},"a.submit click":function() {
    GS.player.restoreQueue();
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    var c = $("input[name=save]", a).val();
    store.set("player.restoreQueue", c);
    c && GS.player.restoreQueue();
    GS.lightbox.close();
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.RadioClearQueueController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.stationID = a;
    $(this.element).html(this.view("/lightbox/radioClearQueue"))
},"a.submit click":function() {
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    GS.player.clearQueue();
    GS.player.setAutoplay(true, this.stationID);
    GS.lightbox.close();
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.NoFlashController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/noFlash"))
},"a.submit click":function() {
    window.location.reload(true)
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.UnsupportedBrowserController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/unsupportedBrowser"))
}});
(function() {
    GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.VideoController", {onDocument:false}, {embed:null,wasPlaying:false,isVideoMode:false,showPlayerControls:false,init:function(a, b) {
        this.update(b);
        this.subscribe("gs.video.playing", this.callback("setVideo"));
        this.subscribe("gs.video.player.ready", this.callback("setVideos"));
        this.subscribe("gs.player.streamserver", this.callback(this.onStreamServer))
    },update:function(a) {
        this.options = a;
        this.startIndex = this.currentIndex = _.orEqual(a.index,
                0);
        this.video = a.video;
        if ((this.videos = _.orEqual(a.videos, [this.video])) && this.videos.length == 1) {
            this.video = this.options.video = this.videos[0];
            this.videos = this.options.videos = null
        }
        this.element.html(this.view("/lightbox/video"));
        this.wasPlaying = GS.player.isPlaying;
        GS.player.pauseSong();
        if (a.isVideoMode)this.isVideoMode = true;
        GS.theme.currentTheme.sections.indexOf("#theme_lightbox_header") >= 0 && GS.theme.renderSection("#theme_lightbox_header");
        if (this.options.videos && this.options.videos.length) {
            this.element.addClass("videos");
            this.options.video.flashvars.index = this.startIndex
        } else this.element.removeClass("videos");
        this.options.video && setTimeout(this.callback("embedVideo"), 50);
        $(window).resize()
    },embedVideo:function() {
        if (this.video && this.video.type) {
            switch (this.video.type) {
                case "iframe":
                    if (!$("#videoPlayer") || !$("#videoPlayer").length)$(".content", this.element).html('<div id="videoPlayer"></div>');
                    this.video.embed("videoPlayer");
                    break;
                case "youtube":
                    GS.youtube.attachPlayer(this.video.VideoID, this.video.width, this.video.height);
                    break;
                case "flash":
                default:
                    if (document.videoPlayer && document.videoPlayer.setVideo)document.videoPlayer.setVideo(this.currentIndex); else this.embed = this.options.video.embed("videoPlayer");
                    break
            }
            this.video.title ? $("#lightbox_header .title").text(this.video.title) : $("#lightbox_header .title").text("");
            $(window).resize()
        }
    },onStreamServer:function(a) {
        document.videoPlayer && document.videoPlayer.loadCrossdomain && document.videoPlayer.loadCrossdomain(a.streamServer)
    },currentIndex:0,setNextVideo:function() {
        if (this.videos &&
                this.videos.length) {
            var a = this.currentIndex + 1;
            if (a >= this.videos.length)a = 0;
            this.currentIndex = a;
            $("a.video").removeClass("active");
            $($("a.video").get(this.currentIndex)).addClass("active");
            this.video = this.videos[this.currentIndex];
            this.embedVideo()
        }
    },setVideo:function(a) {
        $("a.video").removeClass("active");
        $($("a.video").get(a.index)).addClass("active")
    },setVideos:function() {
        if (this.options.video && !this.options.videos)document.videoPlayer.setVideos([this.options.video]); else if (document.videoPlayer &&
                document.videoPlayer.setVideos) {
            for (var a = [],b,c = 0; c < this.options.videos.length; c++) {
                b = this.options.videos[c];
                a.push({author:b.author,height:b.height,src:b.src,thumbnail:b.thumbnail,title:b.title,width:b.width,duration:b.duration,originalWidth:b.originalWidth,originalHeight:b.originalHeight})
            }
            document.videoPlayer.setVideos(a)
        }
        $(window).resize()
    },detach:function() {
        GS.player.enableVideoMode && GS.player.disableVideoMode()
    },destroy:function() {
        GS.player.videoModeEnabled && this.isVideoMode && GS.player.disableVideoMode();
        this.wasPlaying && GS.player.resumeSong()
    },"a.video click":function(a) {
        $("a.video").removeClass("active");
        $(a).addClass("active");
        a = _.orEqual(parseInt($(a).attr("data-video-index"), 10), 0);
        this.video = this.videos[a];
        this.currentIndex = a;
        this.embedVideo()
    },"#videoPlayerPrev click":function() {
        GS.player.youtubePrevSong()
    },"#videoPlayerNext click":function() {
        GS.player.youtubeNextSong()
    }})
})();
(function() {
    GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.VisualizerController", {onDocument:false}, {embed:null,wasPlaying:false,visualizers:[
        {src:gsConfig.assetHost + "/webincludes/visualizers/LineNoFourier.swf",title:"Amped",thumbnail:gsConfig.assetHost + "/webincludes/images/lightbox/visualizer/linenofourier_thumb.png",width:480,height:270},
        {src:gsConfig.assetHost + "/webincludes/visualizers/LineWorm.swf",title:"Worms",thumbnail:gsConfig.assetHost + "/webincludes/images/lightbox/visualizer/lineworm_thumb.png",
            width:480,height:270},
        {src:gsConfig.assetHost + "/webincludes/visualizers/Tunnel.swf",title:"Tunnel",thumbnail:gsConfig.assetHost + "/webincludes/images/lightbox/visualizer/tunnel_thumb.png",width:480,height:270},
        {src:gsConfig.assetHost + "/webincludes/visualizers/LineSmooth.swf",title:"Linear",thumbnail:gsConfig.assetHost + "/webincludes/images/lightbox/visualizer/linesmooth_thumb.png",width:480,height:270},
        {src:gsConfig.assetHost + "/webincludes/visualizers/Explosion.swf",title:"Explosion",thumbnail:gsConfig.assetHost +
                "/webincludes/images/lightbox/visualizer/explosion_thumb.png",width:480,height:270}
    ],init:function(a, b) {
        for (var c = _.orEqual(b.index, 0),g = 0; g < this.visualizers.length; g++)this.visualizers[g] = new GS.Models.Visualizer(this.visualizers[g]);
        this.subscribe("gs.visualizer.playing", this.callback("setVisualizer"));
        this.subscribe("gs.visualizer.player.ready", this.callback("setVisualizers"));
        this.subscribe("gs.player.streamserver", this.callback(this.onStreamServer));
        this.update({visualizer:this.visualizers[c],
            visualizers:this.visualizers,index:c})
    },update:function(a) {
        this.options = a;
        this.element.html(this.view("/lightbox/visualizer"));
        if (this.options.visualizers && this.options.visualizers.length)this.options.visualizer.flashvars.index = this.options.index;
        this.options.visualizer && setTimeout(this.callback("embedVisualizer"), 50);
        $(window).resize()
    },embedVisualizer:function() {
        this.embed = this.options.visualizer.embed("visualizerPlayer")
    },onStreamServer:function(a) {
        document.visualizerPlayer && document.visualizerPlayer.loadCrossdomain &&
        document.visualizerPlayer.loadCrossdomain(a.streamServer)
    },setVisualizer:function(a) {
        $("a.visualizer").removeClass("active");
        $($("a.visualizer").get(a.index)).addClass("active")
    },setVisualizers:function() {
        if (document.visualizerPlayer && document.visualizerPlayer.setVisualizers) {
            for (var a = [],b,c = 0; c < this.options.visualizers.length; c++) {
                b = this.options.visualizers[c];
                a.push({author:b.author,height:b.height,src:b.src,thumbnail:b.thumbnail,title:b.title,width:b.width})
            }
            document.visualizerPlayer.setVisualizers(a)
        }
    },
        "a.visualizer click":function(a) {
            if (document.visualizerPlayer.setVisualizer) {
                $("a.visualizer").removeClass("active");
                $(a).addClass("active");
                document.visualizerPlayer.setVisualizer(parseInt($(a).attr("data-visualizer-index")))
            }
        }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ReAuthFacebookController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/reAuthFacebook"))
},"#lightbox button.submit click":function() {
    GS.facebook.clearInfo();
    GS.facebook.login(function() {
        GS.lightbox.close()
    })
},"#lightbox button.close click":function() {
    GS.facebook.logout(function() {
        GS.lightbox.close()
    })
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.SwfTimeoutController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/swfTimeout"));
    this.checkPlayer()
},checkPlayerTimeout:false,checkPlayerWait:1E3,checkPlayerCount:0,checkPlayerMaxTries:60,checkPlayer:function() {
    console.log("player exists?", GS.player.player);
    if (GS.player.player) {
        GS.lightbox.trackLightboxView("swfTimeout/autoClosed");
        setTimeout(function() {
                    GS.lightbox.close()
                },
                10)
    } else if (this.checkPlayerCount < this.checkPlayerMaxTries) {
        this.checkPlayerCount++;
        setTimeout(this.callback("checkPlayer"), this.checkPlayerWait)
    }
},"button.reload click":function() {
    window.location.reload(true)
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.DeactivateAccountController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/deactivateAccount"))
},"a.submit, button.submit click":function() {
    $("form", this.element).submit()
},"form submit":function(a, b) {
    b.preventDefault();
    var c = parseInt($("input[name=deactivate_reason]:checked", a).val(), 10),g = $("textarea[name=deactivate_other_details]", a).val(),h = parseInt($("input[name=deactive_contact]:checked",
            a).val(), 10),k = $("input[name=deactivate_confirm]", a).val();
    if (c && k.length) {
        this.element.find(".error").hide();
        GS.service.userDisableAccount(k, c, g, h, this.callback(this.disableSuccess), this.callback(this.disableFailed))
    } else if (c)k.length || this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_DEACTIVATE_ERROR_PASSWORD")); else this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_DEACTIVATE_ERROR_REASON"));
    return false
},"input[name=deactivate_reason] change":function() {
    parseInt($("#deactivateAccountForm input[name=deactivate_reason]:checked").val(),
            10)
},"textarea[name=deactivate_other_details] click":function() {
    $("#deactivate_reason_other").attr("checked", true);
    $("#deactivateAccountForm textarea[name=deactivate_other_details]").focus()
},disableSuccess:function(a) {
    if (!a)return this.disableFailed(a);
    GS.auth.logout();
    GS.lightbox.close()
},disableFailed:function() {
    this.element.find(".error").show().find(".message").html($.localize.getString("POPUP_DEACTIVATE_ERROR"))
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.PromotionController", {onDocument:false,PROMOTION_PENDING:"pending",PROMOTION_COMPLETE:"complete"}, {theme:null,promptOnLogin:false,type:"link",state:"pending",formHandler:null,init:function(a, b) {
    this.update(b);
    this.subscribe("lightbox.close.click", this.callback(this.onClose));
    this.subscribe("gs.auth.playlists.update", this.callback(this.render))
},update:function(a) {
    this.options = a;
    this.theme = _.orEqual(a.theme, "");
    this.render()
},render:function() {
    if (this.element) {
        this.element.html(this.view("themes/" +
                this.theme.location + "/promotion"));
        $(window).resize()
    }
},"button.promo_login click":function() {
    GS.theme.promptOnLogin = true;
    GS.theme.lastDFPChange = (new Date).getTime() + 6E5;
    GS.lightbox.close();
    GS.lightbox.open("login")
},"button.promo_signup click":function() {
    GS.theme.promptOnLogin = true;
    GS.theme.lastDFPChange = (new Date).getTime() + 6E5;
    GS.lightbox.close();
    location.hash = "#/signup"
},"a.switchUser click":function() {
    GS.theme.promptOnLogin = true;
    GS.theme.lastDFPChange = (new Date).getTime() + 6E5;
    GS.lightbox.close();
    GS.auth.logout();
    setTimeout(GS.lightbox.open("login"), 0)
},"a.submit click":function(a, b) {
    GS.theme.currentTheme.handleClick(b);
    GS.lightbox.close();
    GS.theme.promptOnLogin = false
},"button.submit click":function() {
    this.element.find("form").submit()
},"form submit":function(a, b) {
    b.stopImmediatePropagation();
    switch ($(a).attr("rel")) {
        case "playlist":
            this.playlistSubmission(a);
            break
    }
    return false
},playlistSubmission:function(a) {
    var b = $(a).find("input[name=campaignID]").val();
    a = $(a).find("input[name=playlistID]:checked").val();
    b && a && GS.Models.Promotion.submitPlaylistForCampaign(a, b, this.callback("playlistSuccess"), this.callback("playlistFailure"))
},playlistSuccess:function(a) {
    if (a == 1) {
        this.state = GS.Controllers.Lightbox.PromotionController.PROMOTION_COMPLETE;
        this.element.html(this.view("themes/" + this.theme.location + "/promotion"));
        $(window).resize()
    } else console.warn("result", a)
},playlistFailure:function() {
},onClose:function() {
    GS.theme.promptOnLogin = false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ConfirmPasswordProfileController", {onDocument:false}, {profileParams:null,serviceCallback:null,serviceErrback:null,init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.profileParams = a.params;
    this.serviceCallback = a.callback;
    this.serviceErrback = a.errback;
    this.element.html(this.view("/lightbox/confirmPasswordProfile"))
},"form submit":function(a, b) {
    b.preventDefault();
    var c = $("input[name=confirmPassword]", a).val();
    if (c) {
        this.profileParams.password =
                c;
        GS.user.settings.updateProfile(this.profileParams, this.serviceCallback, this.serviceErrback);
        GS.lightbox.close()
    } else {
        $("div.message", this.element).html($.localize.getString("POPUP_CONFIRM_EMAIL_ERROR_NOPW"));
        this.element.find(".error").show()
    }
    return false
}});
(function() {
    GS.Controllers.VipInterface.extend("GS.Controllers.Lightbox.RedeemController", {onDocument:false}, {type:"",promoCode:"",threeDays:2592E5,anywhere:false,vip:false,init:function(a, b) {
        this.update(b)
    },update:function(a) {
        a = _.orEqual(a, {});
        this.type = _.orEqual(a.type, "");
        this.vipEndpoint = gsConfig.runMode == "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/";
        this.vipToken = hex_md5((new Date).getTime());
        this.vipCallbackUrl = location.protocol + "//" + location.host + "/vipCallback.php";
        var b = (new Date).getTime();
        redeemInfo = store.get("lastRedeemCode");
        this.promoCode = "";
        if (redeemInfo && redeemInfo.promoCode && redeemInfo.expires >= b) {
            this.type = _.orEqual(redeemInfo.type, this.type);
            this.promoCode = redeemInfo.promoCode
        }
        this.element.html(this.view("/lightbox/redeem/index"));
        if (a && a.autoSubmit && this.promoCode)GS.user.isLoggedIn ? this.redeemFormSubmit() : this.subscribe("gs.auth.update", this.callback(function() {
            this.redeemFormSubmit()
        }));
        GS.lightbox.trackLightboxView("redeem")
    },"#redeem_promocode focus":function(a) {
        a.val() ==
                $.localize.getString("POPUP_REDEEM_ENTER_CODE") && a.val("");
        $("#redeem_invalid_code").hide()
    },"#redeem_promocode keyup":function() {
        $("#redeem_invalid_code").hide()
    },"#redeem_promocode blur":function(a) {
        a.val() == "" && a.val($.localize.getString("POPUP_REDEEM_ENTER_CODE"))
    },"#redeemForm submit":function(a, b) {
        b.preventDefault();
        this.redeemFormSubmit();
        return false
    },redeemFormSubmit:function() {
        var a,b = $("#redeem_promocode").val();
        if (b === "")$("#redeem_promocode").parent().parent().addClass("error"); else if (GS.user.isLoggedIn) {
            $("#redeem_promocode").parent().parent().removeClass("error");
            a = hex_md5((new Date).getTime());
            GS.service.httpsFormSubmit(this.vipEndpoint + "payByPromoCode.php", {vipToken:this.vipToken,callbackMethod:a,callbackUrl:this.vipCallbackUrl,code:b});
            window[a] = this.callback(function(c) {
                console.error("offersubmit win.callback", h, c, $("#httpsIframe"));
                if (c.bSuccess) {
                    this.element.find(".error.response").hide();
                    GS.lightbox.trackLightboxView("redeem/offersConfirm");
                    var g = hex_md5((new Date).getTime()),h = {callbackMethod:g,callbackUrl:this.vipCallbackUrl,token:c.token};
                    if (c.description.match(/anywhere/i))this.anywhere =
                            true; else if (c.description.match(/vip/i))this.vip = true;
                    GS.service.httpsFormSubmit(this.vipEndpoint + "payByPromoCodeConfirm.php", h);
                    window[g] = this.callback(function(k) {
                        console.error("offers confirmsubmit win.callback", h, k, "success:", k.bSuccess, $("#httpsIframe"));
                        var m = this.anywhere || this.vip ? this.vipPackages.anywhere : this.vipPackages.plus;
                        if (k.bSuccess) {
                            GS.user.updateAccountType(m);
                            this.element.html(this.view("/lightbox/redeem/success"));
                            GS.lightbox.trackLightboxView("redeem/success")
                        } else this.showVipErrors(k)
                    })
                } else this.showVipErrors(c)
            })
        } else {
            a =
                    (new Date).getTime() + this.threeDays;
            store.set("lastRedeemCode", {promoCode:b,expires:a,type:this.type});
            GS.lightbox.close();
            GS.lightbox.open("login", {showCTA:true,resumeRedeem:true})
        }
    }})
})();
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.StartSurveyController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.survey = _.orEqual(a.survey, {});
    this.clearvoiceToGroovesharkConversion = GS.Models.Clearvoice.CLEARVOICE_TO_GROOVESHARK_CONVERSION;
    this.element.html(this.view("/lightbox/startSurvey"))
},"button.survey click":function(a, b) {
    b.preventDefault();
    window.open(this.survey.SurveyUrl);
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ConfirmController", {onDocument:false}, {approveCallback:null,cancelCallback:null,data:null,init:function(a, b) {
    this.update(b)
},update:function(a) {
    a = _.orEqual(a, {});
    this.title = a.title;
    this.message = _.orEqual(a.message, "");
    this.approveCallback = a.callback;
    this.cancelCallback = a.errback;
    this.data = _.orEqual(a.data, {});
    this.element.html(this.view("/lightbox/confirm"))
},"button.submit click":function() {
    this.approveCallback && this.approveCallback(this.data);
    GS.lightbox.close()
},"button.cancel click":function() {
    this.cancelCallback && this.cancelCallback(this.data);
    GS.lightbox.close()
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ClearvoiceSignupController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function() {
    this.user = GS.user;
    this.email = GS.user.Email;
    this.fname = this.user.Name;
    this.lname = "";
    this.gender = _.orEqual(this.user.Sex, "");
    this.zip = _.orEqual(this.user.Zip, "");
    this.day = this.month = this.year = "";
    var a = this.fname.split(" ");
    dobParts = (this.user.TSDOB || "").split("-");
    if (this.lname.length === 0 && a.length > 1) {
        this.fname = a[0];
        this.lname = a[1]
    }
    if (dobParts.length ===
            3) {
        this.year = dobParts[0];
        this.month = dobParts[1];
        this.day = dobParts[2]
    }
    this.today = new Date;
    this.months = $.localize.getString("MONTHS").split(",");
    this.expYears = [];
    a = (new Date).getFullYear();
    for (var b = 0; b < 5; b++)this.expYears.push(a + b);
    this.formLock = false;
    this.element.html(this.view("/lightbox/clearvoiceSignup"));
    $("input,select", this.element).change()
},"select focus":function(a) {
    a.parents(".input_wrapper").addClass("active");
    a.change()
},"select blur":function(a) {
    a.parents(".input_wrapper").removeClass("active");
    a.change()
},"select keydown":function(a) {
    a.change()
},"select change":function(a) {
    a.siblings("span").html(a.find("option:selected").html())
},"select focus":function(a) {
    a.parents(".input_wrapper").addClass("active");
    a.change()
},"select blur":function(a) {
    a.parents(".input_wrapper").removeClass("active");
    a.change()
},"select keydown":function(a) {
    a.change()
},"select change":function(a) {
    a.siblings("span").html(a.find("option:selected").html())
},formLock:false,"form submit":function(a, b) {
    b.preventDefault();
    if (this.formLock)return false;
    this.formLock = true;
    var c = $("input[name=email]", this.element).val(),g = $("input[name=fname]", this.element).val(),h = $("input[name=lname]", this.element).val(),k = $("select[name=gender]", this.element).val(),m = $("input[name=zip]", this.element).val(),n = $("select[name=month]", this.element).val(),o = $("select[name=day]", this.element).val(),r = $("select[name=year]", this.element).val(),t = [r,n,o].join("-"),w = $("input[name=tos]", this.element).is(":checked");
    this.email = c;
    this.fname = g;
    this.lname = h;
    this.gender = k;
    this.zip = m;
    this.month = n;
    this.day = o;
    this.year = r;
    this.dob = t = n !== "" && o !== "" && r !== "" ? t : "";
    $("li.error", a).removeClass("error");
    $("li .input_wrapper, li label", a).removeClass("error");
    if (w && c && g && h && k && m && t) {
        $(".error.message").hide();
        $(".loading", this.element).show().siblings().hide();
        GS.lightbox.positionLightbox();
        GS.Models.Clearvoice.createMember(c, g, h, k, m, t, this.callback("createSuccess"), this.callback("createFail"))
    } else {
        $(".loading", this.element).hide().siblings().show();
        this.formLock = false;
        n = ['<ul class="errors">'];
        if (!g) {
            $("li.fname .input_wrapper, li.fname label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_NAME_ERROR") + "</li>")
        }
        if (!h) {
            $("li.lname .input_wrapper, li.lname label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_NAME_ERROR") + "</li>")
        }
        if (!c) {
            $("li.email .input_wrapper, li.email label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_EMAIL_ERROR") +
                    "</li>")
        }
        if (!k) {
            $("li.gender .input_wrapper, li.gender label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_GENDER_ERROR") + "</li>")
        }
        if (!m) {
            $("li.zip .input_wrapper, li.zip label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_ZIP_ERROR") + "</li>")
        }
        if (!t) {
            $("li.dob .input_wrapper, li.dob label", this.element).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_DOB_ERROR") + "</li>")
        }
        if (!w) {
            $("li.tos label",
                    a).addClass("error");
            n.push("<li>" + $.localize.getString("SURVEY_CLEARVOICE_SIGNUP_TOS_ERROR") + "</li>")
        }
        n.push("</ul>");
        $(".error .message", this.element).html("<strong>" + $.localize.getString("POPUP_SIGNUP_ERROR_MESSAGE") + "</strong> " + n.join("")).parent().show();
        GS.lightbox.positionLightbox()
    }
    return false
},createSuccess:function() {
    this.formLock = false;
    $(".loading", this.element).hide().siblings().show();
    GS.lightbox.positionLightbox();
    this.element.html(this.view("/lightbox/clearvoiceSignupSuccess"));
    GS.lightbox.trackLightboxView("clearvoiceSignup/success");
    location.hash = "/surveys/profiler"
},createFail:function(a, b) {
    this.formLock = false;
    $(".loading", this.element).hide().siblings().show();
    console.log("create user fail", a);
    GS.lightbox.trackLightboxView("clearvoiceSignup/fail");
    if (a && a.HasError && a.ExceptionMessage) {
        console.log("err message", $(".error.message", this.element));
        var c = a.ExceptionMessage;
        if (c.match(/email/i)) {
            $("li.email .input_wrapper, li.email label", this.element).addClass("error");
            c.match(/exists/i) ? $(".error .message", this.element).text($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_EMAIL_UNIQUE_ERROR")).parent().show() :
                    $(".error .message", this.element).text($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_EMAIL_ERROR")).parent().show()
        } else if (c.match(/firstname/i)) {
            $("li.fname .input_wrapper, li.fname label", this.element).addClass("error");
            $(".error .message", this.element).text($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_NAME_ERROR")).parent().show()
        } else if (c.match(/lastname/i)) {
            $("li.lname .input_wrapper, li.lname label", this.element).addClass("error");
            $(".error .message", this.element).text($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_NAME_ERROR")).parent().show()
        }
    } else if (a ==
            false)$(".error .message", this.element).text($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_SAVE_ERROR")).parent().show(); else {
        c = JSON.stringify(a);
        var g = _.orEqual(JSON.stringify(b), "");
        c = (new GS.Models.DataString($.localize.getString("SURVEY_CLEARVOICE_SIGNUP_ALREADY_TAKEN_ERROR"), {dataInfo:c,memberInfo:g,username:GS.user.Name})).render();
        $(".error .message", this.element).html(c).parent().show()
    }
    $(window).resize()
}});
GS.Controllers.VipInterface.extend("GS.Controllers.Lightbox.RedeemPointsController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.vipPackage = a.type == "plus" ? "plus" : "anywhere";
    if (this.vipPackage == "plus") {
        this.points = GS.Models.Clearvoice.numPointsForPlus;
        this.packageName = "Grooveshark Plus"
    } else {
        this.points = GS.Models.Clearvoice.numPointsForAnywhere;
        this.packageName = "Grooveshark Anywhere"
    }
    GS.user.getPoints(this.callback("pointsSuccess"), this.callback("pointsFail"))
},pointsSuccess:function(a) {
    if (a <
            this.points) {
        this.points = a;
        this.element.html(this.view("/lightbox/redeemPointsNotEnough"))
    } else this.element.html(this.view("/lightbox/redeemPoints"))
},pointsFail:function(a) {
    console.warn("userGetPoints bad points", a);
    this.element.html(this.view("/lightbox/redeemPoints"))
},"button.submit click":function(a, b) {
    b.preventDefault();
    var c = hex_md5((new Date).getTime()),g = {callbackMethod:c,callbackUrl:location.protocol + "//" + location.host + "/vipCallback.php",bExtend:GS.user.IsPremium ? 1 : 0,anywhere:this.vipPackage ==
            "plus" ? 0 : 1};
    GS.service.httpsFormSubmit((gsConfig.runMode == "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/") + "payByPoints.php", g);
    window[c] = this.callback(function(h) {
        console.warn("payByPoints win.callback", g, h, "success:", h.bSuccess, $("#httpsIframe"));
        if (h.bSuccess && h.token) {
            var k = hex_md5((new Date).getTime()),m = h.description.match(/anywhere/i) ? "anywhere" : "plus",n = {callbackMethod:k,callbackUrl:location.protocol + "//" + location.host + "/vipCallback.php",token:h.token};
            GS.service.httpsFormSubmit((gsConfig.runMode ==
                    "production" ? "https://vip.grooveshark.com/" : "https://stagingvip.grooveshark.com/") + "payByPointsConfirm.php", n);
            window[k] = this.callback(function(o) {
                console.warn("payByPointsConfirm win.callback", n, o, "success:", o.bSuccess, $("#httpsIframe"));
                if (o.bSuccess) {
                    GS.user.updateAccountType(m);
                    GS.user.invalidatePoints();
                    if (location.hash.substring(2).match(/^survey/i))location.hash += " ";
                    GS.lightbox.close();
                    location.hash = "#/signup/complete"
                } else {
                    console.warn("redeemPointsConfirm error", o);
                    this.showVipErrors(o)
                }
            })
        } else {
            console.warn("redeemPoints error",
                    h);
            this.showVipErrors(h)
        }
    });
    return false
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.SurveyResultController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.result = _.orEqual(a, {});
    this.element.html(this.view("/lightbox/surveyResult"))
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.TunipopController", {onDocument:false}, {init:function(a, b) {
    this.update(b)
},update:function(a) {
    this.defaults = a;
    this.element.html(this.view("/lightbox/tunipop"));
    if (this.defaults.tunipopID && this.defaults.tunipopID > 0)this.loadTunipop(this.defaults.tunipopID); else {
        if (this.defaults.artistID)this.artist = GS.Models.Artist.getOneFromCache(this.defaults.artistID); else if (this.defaults.songID) {
            this.song = GS.Models.Song.getOneFromCache(this.defaults.songID);
            this.artist = GS.Models.Artist.getOneFromCache(this.song.ArtistID);
            if (!this.artist && this.song)this.artist = GS.Models.Artist.wrap({ArtistID:this.song.ArtistID,ArtistName:this.song.ArtistName})
        }
        this.artist ? this.artist.getTunipopID().then(this.callback("loadTunipop"), this.callback("loadTunipop")) : this.loadTunipop(0)
    }
},loadTunipop:function(a) {
    if (a && a > 0) {
        this.tunipopID = parseInt(a, 10);
        a = $('<iframe id="tunipopFrame" name="tunipopFrame" scrolling="no" width="100%" height="480px"></iframe>');
        a.attr("src", "https://app.tunipop.net/ui/TunipopWidget.php?brandid=" +
                this.tunipopID + "&rid=7300")
    } else {
        this.tunipopID = 0;
        a = $(this.view("/lightbox/noResults"))
    }
    $("#tunipopForm #lightbox_content").html(a)
}});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.gsUsersFromFacebookController", {onDocument:false}, {gsUsers:[],slickbox:false,selected:{},init:function(a, b) {
    this.gsUsers = b;
    $.each(b, this.callback(function(c, g) {
        b[c].selected = true;
        this.selected[g.UserID] = g.UserID
    }));
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/gsUsersFromFacebook"));
    this.slickbox = $("#lightbox_content .gsusers.contactsContainer").html("").show().slickbox({itemRenderer:this.userItemRenderer,itemClass:this.userItemClass,
        itemWidth:181,itemHeight:47,verticalGap:5,horizontalGap:8,hidePositionInfo:true,listClass:"contacts facebook_contacts"}, this.gsUsers)
},userItemClass:function() {
    return"contact clear"
},userItemRenderer:function(a) {
    return['<label class="',a.selected ? "selected" : "",'"><img src="http://graph.facebook.com/',a.FacebookUserID,'/picture" /><input class="groovesharkUser hide" type="checkbox" value="',a.UserID,'" ',a.selected ? "checked" : "",' /><span class="facebookUsername">',a.FacebookName,"</span></label>"].join("")
},
    "input.groovesharkUser click":function(a) {
        if ($(a).is(":checked")) {
            $(a).parent().addClass("selected");
            this.selected[a.val()] = a.val();
            this.gsUsers[parseInt(a.parents("li.contact").attr("rel"), 10)].selected = true
        } else {
            $(a).parent().removeClass("selected");
            delete this.selected[a.val()];
            this.gsUsers[parseInt(a.parents("li.contact").attr("rel"), 10)].selected = false
        }
        this.slickbox.setItems(this.gsUsers)
    },"button.uncheckAll click":function() {
        _.forEach(this.gsUsers, function(a, b) {
                    this.gsUsers[b].selected = false
                },
                this);
        this.selected = {};
        this.slickbox.setItems(this.gsUsers)
    },"button.checkAll click":function() {
        _.forEach(this.gsUsers, function(a, b) {
            this.gsUsers[b].selected = true;
            this.selected[a.UserID] = a.UserID
        }, this);
        this.slickbox.setItems(this.gsUsers)
    },"#lightbox button.submit click":function() {
        var a = 0;
        $.each(this.selected, function(b) {
            GS.Models.User.getUser(b, function(c) {
                GS.user.addToUserFavorites(c.UserID, false)
            }, null, false);
            a++
        });
        a > 0 && $.publish("gs.notification.favorite.user", this.selected);
        GS.lightbox.close()
    }});
GS.Controllers.BaseController.extend("GS.Controllers.Lightbox.ReAuthGoogleController", {onDocument:false}, {init:function() {
    this.update()
},update:function() {
    this.element.html(this.view("/lightbox/reAuthGoogle"))
},"#lightbox button.submit click":function() {
    GS.google.logout(function() {
        GS.google.login(function() {
            GS.lightbox.close()
        })
    })
},"#lightbox button.close click":function() {
    GS.google.logout(function() {
        GS.lightbox.close()
    })
}});
GS.Controllers.BaseController.extend("GS.Controllers.LightboxController", {onElement:"#lightbox_wrapper"}, {priorities:{sessionBad:12,SESSION_BAD:12,maintenance:11,DOWN_FOR_MAINTENANCE:11,invalidClient:10,INVALID_CLIENT:10,badHost:8,BAD_HOST:8,interactionTime:7,INTERACTION_TIMER:7,vipRequiredLogin:5,VIP_REQUIRED_LOGIN:5,vipOnlyFeature:3,VIP_ONLY_FEATURE:3,signup:2,SIGNUP:2,vipSignup:1,VIP_SIGNUP:1},notCloseable:["maintenance","invalidClient","sessionBad","badHost","swfTimeout"],queue:[],queuedOptions:{},
    curType:null,isOpen:false,priority:0,init:function() {
        this.subscribe("window.resize", this.callback(this.positionLightbox));
        $(document).keydown(this.callback(function(a) {
            a.which == _.keys.ESC && this.isOpen && this.notCloseable.indexOf(this.curType) == -1 && this.close()
        }));
        this._super()
    },appReady:function() {
        if (gsConfig.lightboxOnInit) {
            this.open(gsConfig.lightboxOnInit.type, gsConfig.lightboxOnInit.defaults);
            gsConfig.lightboxOnInit = false
        }
    },positionLightbox:function() {
        if (this.isOpen) {
            if (this.curType !== "signup") {
                $("#lightbox_content").css({height:"auto"});
                $("#lightbox").css({width:"auto"})
            }
            var a = Math.max($("#lightbox").width(), 400),b = Math.min(Math.max($("#lightbox").height(), 100), $("body").height() - 70);
            a = Math.round($("#main").width() / 2 - a / 2);
            var c = Math.max(35, Math.round($("#main").height() / 2 - b / 2)),g = $("#lightbox_content").height(),h = $("#lightbox_header", this.element).outerHeight() + $("#div.error.response:visible", this.element).outerHeight() + $("#lightbox_footer", this.element).outerHeight(),k = 0;
            $(".measure", "#lightbox_content").each(function(m) {
                k += $(m).height()
            });
            b = Math.min(Math.max(150, parseInt(b - h, 10)));
            if (b < g && !$("#lightbox_content").is(".fixed_content")) {
                $("#lightbox_content").height(b);
                $(".lightbox_pane_content").height($("#lightbox_content").height() - $("#lightbox_content #pane_footer").outerHeight() - k)
            }
            $("#lightbox_nav").height($("#lightbox_pane").height());
            $("#lightbox_wrapper").css({top:c,left:a});
            this.queuedOptions[this.curType] && this.queuedOptions[this.curType].showPlayerControls && $("#lightbox_overlay").height($(window).height() - $("#player").height());
            $.publish("lightbox.position")
        }
    },open:function(a, b) {
        var c = this.queue.indexOf(a),g = _.orEqual(this.priorities[a], 0);
        b = _.orEqual(b, null);
        var h = this;
        if (this.curType === a)return false;
        this.queuedOptions[a] = b;
        if (g < this.currentPriority)this.queue.indexOf(a) === -1 && this.queue.push(a); else {
            this.curType && this.queue.indexOf(this.curType) === -1 && this.queue.push(this.curType);
            if (!(this.queue.length && c !== -1 && c > -1)) {
                this.curType = a;
                this.currentPriority = g;
                this.isOpen = true;
                $("#lightbox_overlay").height("100%");
                $("#lightbox_wrapper .lbcontainer." +
                        a)[$.String.underscore("gs_lightbox_" + a)](b);
                $("#lightbox .lbcontainer." + a).show(1,
                        function() {
                            h.positionLightbox();
                            $(this).find("form input:first:visible").focus()
                        }).siblings().hide().not(".login").empty();
                this.trackLightboxView(a);
                if ($("#lightbox_wrapper").is(":visible"))this.queue.indexOf(a) === -1 && this.queue.unshift(a); else this.queue.indexOf(a) === -1 && this.queue.push(a);
                $("#theme_home .flash object").hide();
                $("#lightbox_wrapper,#lightbox_overlay").show();
                this.notCloseable.indexOf(this.curType) ==
                        -1 ? $("#lightbox_close").show() : $("#lightbox_close").hide();
                setTimeout(function() {
                    h.positionLightbox()
                }, 150)
            }
        }
    },close:function() {
        var a,b;
        a = this.queue.shift();
        if (_.defined(a)) {
            $("#lightbox_wrapper .lbcontainer." + a).hide().controller().destroy();
            a !== "login" && $("#lightbox_wrapper .lbcontainer." + a).empty()
        }
        this.currentPriority = this.curType = false;
        if (this.queue.length > 0) {
            this.queue = this.sortQueueByPriority(this.queue);
            a = this.queue.shift();
            b = this.queuedOptions[a];
            try {
                this.open(a, b)
            } catch(c) {
                console.warn("error opening next lightbox",
                        c);
                this.isOpen = this.currentPriority = this.curType = false;
                $("#lightbox_wrapper,#lightbox_overlay").hide();
                $("#theme_home .flash object").show()
            }
        } else {
            this.isOpen = this.currentPriority = this.curType = false;
            $("#lightbox_wrapper,#lightbox_overlay").hide();
            $("#theme_home .flash object").show()
        }
    },sortQueueByPriority:function(a) {
        a.sort(this.callback(function(b, c) {
            var g = _.orEqual(this.priorities[b], 0),h = _.orEqual(this.priorities[c], 0);
            return g == h ? 0 : g > h ? 1 : -1
        })).reverse();
        return a
    },trackLightboxView:function(a) {
        a =
                "#/lb/" + a;
        if (window._gaq && window._gaq.push) {
            a = encodeURI(a);
            window._gaq.push(["_trackPageview",a])
        }
    },".close click":function() {
        GS.lightbox.close()
    },"select focus":function(a) {
        a.parents(".input_wrapper").addClass("active")
    },"select blur":function(a) {
        a.parents(".input_wrapper").removeClass("active");
        a.change()
    },"select keydown":function(a) {
        a.change()
    },"select change":function(a) {
        $(a).prev("span").text($(a).find("option:selected").html())
    },"input focus":function(a) {
        $(a).parent().parent().addClass("input_wrapper_active")
    },
    "textarea focus":function(a) {
        $(a).parent().parent().parent().addClass("textarea_wrapper_active")
    },"input blur":function(a) {
        $(a).parent().parent().removeClass("input_wrapper_active")
    },"textarea blur":function(a) {
        $(a).parent().parent().parent().removeClass("textarea_wrapper_active")
    }});
(function(a) {
    function b(o) {
        if (_.defined(o.inviteCode)) {
            gsConfig.inviteCode = o.inviteCode;
            var r = (new Date).valueOf() + 12096E5;
            try {
                store.set("lastInviteCode", {inviteCode:o.inviteCode,expires:r})
            } catch(t) {
            }
        }
        if (o.hasOwnProperty("password")) {
            r = {};
            if (o.hasOwnProperty("code"))r.resetCode = o.code;
            GS.lightbox.open("forget", r)
        }
        o.hasOwnProperty("invite") && GS.lightbox.open("invite");
        o.hasOwnProperty("signup") && GS.lightbox.open("signup");
        if (o.hasOwnProperty("login"))if (!GS.user || !GS.user.isLoggedIn)GS.lightbox.open("login");
        if (o.hasOwnProperty("testAds"))GS.ad.useTestAds = true;
        o.hasOwnProperty("unsubscribeClearvoiceEmail") && GS.lightbox.open("surveyResult", {gsResult:-999,ResultCode:"Unsub"});
        o.hasOwnProperty("activateClearvoiceEmail") && GS.lightbox.open("surveyResult", {gsResult:-999,ResultCode:"Activate"});
        if (o.hasOwnProperty("measurePerformance")) {
            var w = false,y = function() {
                if (a("#grid ul.options").length) {
                    top.hasLoaded("search");
                    GS.player.addSongsToQueueAt([a("#grid ul.options:first").attr("rel")], -1, true);
                    setTimeout(u,
                            1)
                } else setTimeout(y, 1)
            },u = function() {
                if (GS.player.isPlaying && !GS.player.isLoading && !w) {
                    w = true;
                    top.hasLoaded("play")
                } else setTimeout(u, 1)
            };
            if (window.top && window != top && a.isFunction(top.hasLoaded)) {
                top.hasLoaded("page");
                setTimeout(y, 1);
                location.hash = "/search?q=eminem"
            }
        }
    }

    function c(o) {
        o = _.defined(o.search);
        GS.router.page.activate("home", null).index(o);
        GS.guts.handlePageLoad("home", {})
    }

    function g(o) {
        o = new m(o.splat, "login", "id", "section", "subpage");
        var r = GS.router.page.activate("user", o.id);
        switch (o.length) {
            case 2:
                r.index(o.id);
                break;
            case 3:
                r[o.section](o.id, "");
                break;
            case 4:
                r[o.section](o.id, o.subpage);
                break;
            default:
                this.notFound()
        }
        GS.guts.handlePageLoad("user", o)
    }

    function h(o) {
        var r = o.splat.shift(),t = new m(o.splat, "name", "id", "subpage"),w = GS.router.page.activate(r, t.id);
        switch (t.length) {
            case 2:
            case 3:
                var y = _.orEqual(t.subpage, "music");
                w.index(t.id, y, o.play);
                t.subpage = y;
                break;
            default:
                this.notFound()
        }
        GS.guts.handlePageLoad(r, t)
    }

    function k(o, r) {
        var t = o.indexOf("/");
        return t !== -1 ? o.substring(0, t) + "/" + r + o.substring(t) : o + "/" +
                r
    }

    function m() {
        var o = a.makeArray(arguments),r = o.shift()[0],t = this;
        if (_.isEmpty(r))t.length = 0; else {
            r = r.replace(/\/$/, "").split("/");
            t.length = r.length;
            var w;
            _.forEach(r, function(y, u) {
                w = o[u];
                t[w] = y
            })
        }
    }

    GS.router = new (function() {
        var o = this;
        this._routes = [];
        this._history = [];
        this._nextHashShift = this._historyIndex = 0;
        this._pageNameCache = {};
        this.hasForward = this.hasBack = false;
        this.get = function(r, t, w) {
            w = _.orEqual(w, this);
            if (!(r instanceof RegExp) && !_.isString(r))console.error("invalid route, must be String or RegExp");
            else {
                if (_.isString(r))r = RegExp("^" + r + "$");
                this._routes.push({path:r,callback:t,context:w})
            }
        };
        this.notFound = function() {
            window.location.hash = "#/notFound"
        };
        this.back = function() {
            this.navHistory(-1)
        };
        this.forward = function() {
            this.navHistory(1)
        };
        this.navHistory = function(r) {
            var t = this._historyIndex + r;
            if (t >= 0 && t < this._history.length) {
                this._nextHashShift = r;
                window.location.hash = this._history[t]
            }
        };
        this.performSearch = function(r, t) {
            t = t.toString();
            if (t.indexOf("http://") == 0 && t.indexOf("tinysong") == -1) {
                t = t.substring(7);
                var w = t.indexOf("#");
                if (w != -1)window.location.hash = t.substring(w); else {
                    w = t.indexOf("/");
                    window.location.hash = "#" + t.substring(w)
                }
            } else {
                r = r.toLowerCase();
                t = encodeURIComponent(t);
                t = t.replace(/%20/g, "+");
                window.location.hash = r ? "#/search/" + r + "?q=" + t : "#/search?q=" + t
            }
        };
        this.cachePageName = function(r, t, w) {
            this._pageNameCache[r] = {type:t,id:w}
        };
        this.run = function() {
            this.page = GS.Controllers.PageController;
            this.before = this.page.checkLock;
            a(window).hashchange(function() {
                var r = location.hash;
                if (r && r.length)r = location.href.substring(location.href.indexOf("#"));
                o._onHashChange(r)
            });
            a(window).trigger("hashchange")
        };
        this._onHashChange = function(r) {
            if (a.isFunction(this.before))if (!this.before())return;
            window._gaq && _gaq.push && _gaq.push(["_trackPageview",r]);
            window.COMSCORE && COMSCORE.beacon && COMSCORE.beacon({c1:2,c2:"8187464",c4:(location.protocol + "//" + location.host + "/" + r).replace("#/", "")});
            if (this._nextHashShift != 0) {
                var t = this._historyIndex + this._nextHashShift;
                if (t >= 0 && t < this._history.length && this._history[t] == r)this._historyIndex = t; else this._nextHashShift =
                        0
            }
            if (this._nextHashShift == 0) {
                this._history = this._history.slice(0, this._historyIndex + 1);
                r && this._history.push(r);
                this._historyIndex = this._history.length - 1
            }
            this._nextHashShift = 0;
            t = this._parseQueryString(r);
            var w = r.replace(n, "");
            if (r = this._getRouteForPath(w)) {
                w = w.match(r.path);
                w.shift();
                t.splat = w;
                if (a.isFunction(r.callback)) {
                    r.callback.call(r.context, t);
                    b(t)
                }
                this.hasBack = this._history.length && this._historyIndex > 0;
                this.hasForward = this._history.length && this._historyIndex < this._history.length - 1;
                a.publish("gs.router.history.change")
            } else this.notFound()
        };
        this._getRouteForPath = function(r) {
            var t,w;
            for (w = 0; w < this._routes.length; w++) {
                var y = this._routes[w];
                if (y.path.test(r)) {
                    t = y;
                    break
                }
            }
            return t
        };
        this._parseQueryString = function(r) {
            var t = {},w,y;
            if (r = r.match(n)) {
                r = r[1].split("&");
                for (y = 0; y < r.length; y++) {
                    w = r[y].split("=");
                    if (w[0] === "q")w[1] = w[1].replace(/\+/g, "%20");
                    t = this._parseParamPair(t, decodeURIComponent(w[0]), decodeURIComponent(w[1]))
                }
            }
            return t
        };
        this._parseParamPair = function(r, t, w) {
            if (r[t])if (_isArray(r[t]))r[t].push(w); else r[t] = [r[t],w]; else r[t] =
                    w;
            return r
        };
        this._getTypeIDForPageName = function(r) {
            var t = a.Deferred(),w,y,u;
            _.defined(this._pageNameCache[r]) ? t.resolve(this._pageNameCache[r]) : GS.service.getItemByPageName(r, function(E) {
                if (E && E.type)if (u = E[E.type]) {
                    u.PageName = r;
                    switch (E.type) {
                        case "user":
                            w = GS.Models.User.wrap(u);
                            y = w.UserID;
                            break;
                        case "artist":
                            w = GS.Models.Artist.wrap(u);
                            y = w.ArtistID;
                            break;
                        case "album":
                            w = GS.Models.Album.wrap(u);
                            y = w.AlbumID;
                            break;
                        case "theme":
                            y = u.themeID;
                            break;
                        default:
                            console.warn("unknown type for PageName", E.type,
                                    r);
                            t.reject(E);
                            return
                    }
                    o._pageNameCache[r] = {type:E.type,id:y};
                    t.resolve(o._pageNameCache[r])
                } else t.reject(E); else t.reject(E)
            }, function(E) {
                t.reject(E)
            });
            return t.promise()
        }
    });
    GS.router.get("", function(o) {
        c(o)
    });
    GS.router.get("#/", function(o) {
        c(o)
    });
    GS.router.get("#/notFound", function(o) {
        this.page.activate("home", null).notFound();
        GS.guts.handlePageLoad("notFound", o)
    });
    GS.router.get(/^#\/user\/(.*)\/?$/, g);
    GS.router.get(/^#\/playlist\/(.*)\/?/, function(o) {
        var r = new m(o.splat, "name", "id", "subpage"),
                t = this.page.activate("playlist", r.id);
        switch (r.length) {
            case 2:
            case 3:
                var w = _.orEqual(r.subpage, "music");
                t.index(r.id, w, o.play);
                r.subpage = w;
                break;
            default:
                this.notFound()
        }
        GS.guts.handlePageLoad("playlist", r)
    });
    GS.router.get(/^#\/s(?:ong)?\/(.*)\/?/, function(o) {
        o = new m(o.splat, "name", "token", "subpage");
        var r = this.page.activate("song", o.token);
        switch (o.length) {
            case 2:
            case 3:
                var t = _.orEqual(o.subpage, "comments");
                r.index(o.token, t);
                break;
            default:
                this.notFound()
        }
        o.subpage = t;
        GS.guts.handlePageLoad("song",
                o)
    });
    GS.router.get(/^#\/(album|artist|promotion)\/(.*)\/?/, h);
    GS.router.get(/^#\/redeem\/?(.*)\/?/, function(o) {
        o = new m(o.splat, "type");
        o.redeemingPromoCard = true;
        GS.guts.handlePageLoad("home", o);
        this.page.activate("home", null).index();
        GS.lightbox.open("redeem", {type:o.type})
    });
    GS.router.get(/^#\/login\/?(.*)\/?/, function(o) {
        o = new m(o.splat, "type");
        GS.guts.handlePageLoad("home", o);
        this.page.activate("home", null).index();
        GS.lightbox.open("login", {type:o.type})
    });
    GS.router.get(/^#\/themes\/?(.*)\/?/,
            function(o) {
                o = new m(o.splat, "type");
                GS.guts.handlePageLoad("home", o);
                this.page.activate("home", null).index();
                GS.lightbox.open("themes", {type:o.type})
            });
    GS.router.get(/^#\/(theme)\/(.*)\/?/, function(o) {
        o.splat.shift();
        var r = new m(o.splat, "name", "themeid", "type");
        GS.theme.loadFromDFPManual(r.themeid);
        GS.guts.handlePageLoad("home", o);
        this.page.activate("home", null).index()
    });
    GS.router.get(/^#\/(sessions)/, function() {
        GS.theme.setCurrentTheme(247, true);
        this.page.activate("home", null).index()
    });
    GS.router.get(/^#\/search\/?(.*)?\/?/,
            function(o) {
                var r = new m(o.splat, "type");
                this.page.activate("search", (r.type || "everything") + (o.q || o.query)).index(r.type, o.q || o.query);
                if (r.type)r.subpage = r.type; else r.type = "everything"
            });
    GS.router.get(/^#\/surveys\/?(.*)?\/?(.*)?\/?/, function(o) {
        var r = this.page.activate("surveys");
        o = new m(o.splat, "subpage", "id");
        if (!o.subpage)o.subpage = "index";
        if (!o.id)o.id = false;
        r.index(o.subpage, o.id);
        GS.guts.handlePageLoad("surveys", o)
    });
    GS.router.get(/^#\/(.*)\/?$/, function(o) {
        var r = new m(o.splat, "page", "subpage"),
                t = this.page.activate(r.page, null),w = this;
        _.defined(t) ? t.index(r.subpage) : this._getTypeIDForPageName(r.page).done(
                function(y) {
                    switch (y.type) {
                        case "user":
                            o.splat[0] = k(o.splat[0], y.id);
                            g(o);
                            break;
                        case "artist":
                        case "album":
                            o.splat[1] = k(o.splat[2], y.id);
                            h(o);
                            break;
                        case "theme":
                            GS.theme.loadFromDFPManual(y.id);
                            window.location.hash = "/";
                            break;
                        default:
                            console.warn("cant handle pageName type", y);
                            w.notFound();
                            break
                    }
                }).fail(function() {
            w.notFound()
        })
    });
    var n = /\?([^#]*)$/
})(jQuery);
(function(a) {
    function b() {
        var H = false;
        if (h != a("#application").width()) {
            h = a("#application").width();
            H = true;
            a.browser.msie && a(window).resize()
        }
        GS.wideScreen = h >= o;
        a("#content").css({height:a(window).height() - a("#header").height() - a("#footer").height()});
        H ? a("#sidebar").css({height:a(window).height() - a("#header").height() - a("#footer").height(),width:h < k ? 100 : h < m ? 150 : h < n ? 175 : 200}) : a("#sidebar").css({height:a(window).height() - a("#header").height() - a("#footer").height()});
        a("#page_wrapper").css({height:a(window).height() -
                a("#header").height() - a("#footer").height(),width:a("#application").width() - a("#sidebar").width()});
        a("#page_nav").css("visibility", "hidden");
        a("#page_nav").removeClass("page_nav_collapsed");
        a("#page_wrapper .meta").outerWidth() + 30 + a("#page_wrapper .page_options").outerWidth() > a("#page_wrapper").width() && a("#page_nav").addClass("page_nav_collapsed");
        a("#page_nav").css("visibility", "visible");
        a("#page_content").css({height:a("#page_wrapper").height() - a("#page_header").height() - a("#page_subheader").height() -
                a("#page_footer").height() - a("#theme_page_header.active").height(),width:a("#page_wrapper").width()});
        a("#page_content .noResults_pane").css({height:a("#page_content").height() - 20});
        a(".noResults_block_column").removeClass("js-center").css({margin:0});
        a(".noResults_block_center").removeClass("hide");
        if (a("#page_content .noResults").width() <= 550) {
            a(".noResults_block_center").addClass("hide");
            a(".noResults_block_column").addClass("js-center")
        }
        a("#page_content .noResults").css({top:Math.max((a("#page_content .noResults_pane").height() -
                a("#page_content .noResults").height()) / 2, 0)});
        a("#page_content .page_column_fluid").each(function() {
            var A = 0,x = a("#page_wrapper").width();
            a(this).siblings(".page_column").each(function() {
                a(this).height(a("#page_content").height());
                if (a(this).is(".page_filter")) {
                    if (!a(this).is(".suppressAutoCollapse"))if (h < m && !a(this).is(".manualOpen"))a(this).addClass("collapsed"); else if (h < n && A > 0 && !a(this).is(".manualOpen"))a(this).addClass("collapsed"); else a(this).is(".manualCollapse") || a(this).removeClass("collapsed");
                    a(this).removeClass("suppressAutoCollapse");
                    if (a(this).is(".collapsed")) {
                        var B = a(this).find(".gs_grid").controller();
                        B && B.grid && a(this).width(B.grid.getScrollWidth())
                    } else a(this).width(175)
                }
                A += a(this).outerWidth()
            });
            a(this).is(".scrollable") ? a(this).css({width:x - A,height:a("#page_content").height()}) : a(this).css({width:x - A})
        });
        a(".js-center").each(function() {
            var A = a(this);
            A.css({marginLeft:Math.max(0, (A.parent().width() - A.outerWidth()) / 2)})
        });
        a.publish("window.resize");
        a(".gs_grid").resize()
    }

    function c() {
        clearTimeout(r);
        if (w) {
            clearTimeout(w);
            a.browser.msie ? a("#homeSearch,.ui-autocomplete").show() : a("#homeSearch,.ui-autocomplete").stop().css({opacity:1})
        }
        r = setTimeout(function() {
            var H = GS.player.getPlaybackStatus();
            H && H.status === GS.player.PLAY_STATUS_PLAYING && !GS.user.IsPremium && GS.lightbox.open("interactionTime")
        }, t);
        if (GS.theme && GS.theme.currentTheme && GS.theme.currentTheme.screensaver)w = setTimeout(function() {
            a.browser.msie ? a("#homeSearch,.ui-autocomplete").hide() : a("#homeSearch,.ui-autocomplete").animate({opacity:0},
                    500)
        }, y)
    }

    function g() {
        var H = document.title || "";
        if (H.indexOf("#") != -1)H = H.substring(0, H.indexOf("#"));
        if (document.title != H && H != "")document.title = H
    }

    var h = 0,k = 620,m = 844,n = 1060,o = 1260;
    a(window).resize(b);
    a(window).unload(function() {
        GS.user.isLoggedIn && GS.user.storeData();
        GS.theme && GS.theme.savePreferences()
    });
    var r,t = 36E5,w,y = 15E3;
    a("body").konami(function() {
        a.publish("gs.playlist.play", {playlistID:40563861,playOnAdd:true})
    });
    a("body").bind("mousemove", c);
    a("body").bind("keydown", c);
    c();
    a.browser.msie &&
    a(document).bind("propertychange", function() {
        event.propertyName == "title" && g()
    });
    GS.windowResizeTimeout = null;
    GS.windowResizeWait = 10;
    a(window).resize();
    if (window.gsViewBundles)GS.Controllers.BaseController.viewBundles = window.gsViewBundles;
    if (window.gsBundleVersions)GS.Controllers.BaseController.bundleVersions = window.gsBundleVersions;
    if (window.gsPageBundle && a.isPlainObject(gsPageBundle))for (var u in gsPageBundle)if (gsPageBundle.hasOwnProperty(u))a.View.preCached[u] = gsPageBundle[u];
    window.reportUploadComplete =
            window.uploadComplete = function() {
                window.GS && GS.user && GS.user.uploadComplete()
            };
    GS.airbridge = GS.Controllers.AirbridgeController.instance();
    GS.service = GS.Controllers.ServiceController.instance();
    GS.auth = GS.Controllers.AuthController.instance();
    GS.lightbox = GS.Controllers.LightboxController.instance();
    GS.notice = GS.Controllers.NotificationsController.instance();
    GS.header = GS.Controllers.HeaderController.instance();
    GS.sidebar = GS.Controllers.SidebarController.instance();
    GS.theme = GS.Controllers.ThemeController.instance();
    GS.page = GS.Controllers.PageController;
    GS.player = GS.Controllers.PlayerController.instance();
    GS.youtube = GS.Controllers.YoutubeController.instance();
    GS.vimeo = GS.Controllers.VimeoController.instance();
    GS.ad = GS.Controllers.AdController.instance();
    GS.guts = GS.Controllers.GUTSController.instance();
    GS.locale = GS.Controllers.LocaleController.instance();
    GS.facebook = GS.Controllers.FacebookController.instance();
    GS.lastfm = GS.Controllers.LastfmController.instance();
    GS.google = GS.Controllers.GoogleController.instance();
    GS.features = GS.Models.Feature.Features;
    GS.search = {search:"",type:"",lastSearch:"",lastType:"",version:""};
    GS.resize = b;
    GS.wideScreen = false;
    GS.gotoUpgradePage = function() {
        location.hash = "/settings/subscriptions"
    };
    window.Grooveshark = GS.Controllers.ApiController.instance();
    a(document).bind("keydown", "ctrl+a", function(H) {
        var A = [],x = a(".gs_grid:last").controller();
        if (!a(H.target).is("input,select,textarea") && x) {
            for (H = 0; H < x.dataView.rows.length; H++) {
                A.push(H);
                x.selectedRowIDs.push(x.dataView.rows[H].id)
            }
            x.grid.setSelectedRows(A);
            x.grid.onSelectedRowsChanged();
            return false
        }
    });
    (function() {
        var H = new a.Event("remove"),A = a.fn.remove;
        a.fn.remove = function() {
            a(this).trigger(H);
            A.apply(this, arguments)
        }
    })();
    u = true;
    var E = _.browserDetect();
    switch (E.browser) {
        case "chrome":
            if (E.version >= 6)u = false;
            break;
        case "safari":
            if (E.version >= 5)u = false;
            break;
        case "msie":
            if (E.version >= 7 && E.version < 9)u = false;
            break;
        case "firefox":
            if (E.version >= 3)u = false;
            break;
        case "mozilla":
            if (E.version >= 1.9)u = false;
            break;
        case "opera":
            if (E.version >= 11)u = false;
            break;
        case "adobeair":
            u =
                    false;
            break
    }
    u && GS.lightbox.open("unsupportedBrowser", {browser:E});
    window.playSongFromAd = function(H) {
        try {
            H = H || [];
            typeof H == "object" && H.constructor == Array || (H = [H]);
            GS.player.addSongsToQueueAt(H, null, true)
        } catch(A) {
        }
    };
    a(function() {
        function H() {
            var x = "";
            try {
                if (window.getSelection)x = window.getSelection(); else if (document.getSelection)x = document.getSelection(); else if (document.selection)x = document.selection.createRange().text; else return""
            } catch(B) {
                console.log("getText failed:", B);
                return""
            }
            return x.toString()
        }

        var A = null;
        a("body").mouseup(function() {
            A = H();
            f = A.length;
            var x = 0,B = A.replace(/\s/g, " ");
            B = B.split(" ");
            for (z = 0; z < B.length; z++)B[z].length > 0 && x++;
            d = x;
            A !== null && d < 60 && f > 3 && _gaq.push(["_trackEvent","user","copyText",A])
        })
    });
    a(document).ready(function() {
        a("*").scrollTop(0);
        document.body.scroll = "no";
        a("body,#main,#page_wrapper,#mainContainer").scroll(function(H) {
            if (a(this).scrollTop() > 0) {
                console.warn("Fixing Scroll", H.target);
                a(this).scrollTop(0)
            }
            return false
        });
        a.browser.msie && g();
        a.publish("gs.app.ready");
        GS.router.run()
    })
})(jQuery);
window.onbeforeunload = function(a) {
    GS.player.storeQueue();
    GS.guts.forceSend();
    var b;
    a = a || window.event;
    if (!GS.user.isLoggedIn && GS.user.isDirty) {
        b = $.localize.getString("ONCLOSE_PROMPT_LOGIN");
        GS.lightbox.open("login")
    }
    if (GS.player.isPlaying)b = $.localize.getString("ONCLOSE_PLAYING");
    if (!GS.Controllers.PageController.ALLOW_LOAD)b = GS.Controllers.PageController.confirmMessage;
    if (b) {
        if (a)a.returnValue = b;
        return b
    }
};
